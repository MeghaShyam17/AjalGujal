package com.ilp.inventory_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.inventory_service.Entity.ComponentReturnEntity;

import java.util.List;

@Repository
public interface ComponentReturnRepository
        extends JpaRepository<ComponentReturnEntity, Long> {

    ComponentReturnEntity findByComponentReturnId(Long componentReturnId);

    ComponentReturnEntity findByReturnCode(String returnCode);

    List<ComponentReturnEntity> findByProjectId(Long projectId);

    List<ComponentReturnEntity> findByReturnedBy(Long returnedBy);

    List<ComponentReturnEntity> findByReceivedBy(Long receivedBy);

    List<ComponentReturnEntity> findByReturnStatus(String returnStatus);

    List<ComponentReturnEntity>
            findByComponentRequestComponentRequestId(
                    Long componentRequestId);

    List<ComponentReturnEntity>
            findByProjectIdAndReturnStatus(
                    Long projectId,
                    String returnStatus);

    List<ComponentReturnEntity>
            findByReturnedByAndReturnStatus(
                    Long returnedBy,
                    String returnStatus);

    List<ComponentReturnEntity>
            findByReceivedByAndReturnStatus(
                    Long receivedBy,
                    String returnStatus);
}