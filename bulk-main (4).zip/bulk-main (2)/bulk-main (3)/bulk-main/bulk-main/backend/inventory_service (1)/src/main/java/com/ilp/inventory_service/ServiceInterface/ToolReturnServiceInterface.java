// package com.ilp.inventory_service.ServiceInterface;

// import java.util.List;

// import com.ilp.inventory_service.ToolEnums.ReturnStatus;
// import com.ilp.inventory_service.Dto.ToolReturnDto;

// public interface ToolReturnServiceInterface {

//     ToolReturnDto createReturn(
//             ToolReturnDto dto);

//     ToolReturnDto getById(
//             Long toolReturnId);

//     List<ToolReturnDto> getAll();

//     List<ToolReturnDto> getByReturnedBy(
//             Long returnedBy);

//     List<ToolReturnDto> getByProjectId(
//             Long projectId);

//     List<ToolReturnDto> getByStatus(
//             ReturnStatus status);

//     ToolReturnDto completeReturn(
//             Long toolReturnId,
//             Long receivedBy);

//     ToolReturnDto verifyReturn(
//             Long id,
//             ToolReturnDto verificationDto);

//     void delete(
//             Long toolReturnId);
// }
package com.ilp.inventory_service.ServiceInterface;

import java.util.List;

import com.ilp.inventory_service.ToolEnums.ReturnStatus;
import com.ilp.inventory_service.Dto.ToolReturnDto;

public interface ToolReturnServiceInterface {

    ToolReturnDto createReturn(
            ToolReturnDto dto);

    ToolReturnDto getById(
            Long toolReturnId);

    List<ToolReturnDto> getAll();

    List<ToolReturnDto> getByReturnedBy(
            Long returnedBy);

    List<ToolReturnDto> getByProjectId(
            Long projectId);

    List<ToolReturnDto> getByStatus(
            ReturnStatus status);

    ToolReturnDto completeReturn(
            Long toolReturnId,
            Long receivedBy);

    ToolReturnDto completeReturnByRequestId(
            Long toolRequestId,
            Long receivedBy);

    void delete(
            Long toolReturnId);
}
