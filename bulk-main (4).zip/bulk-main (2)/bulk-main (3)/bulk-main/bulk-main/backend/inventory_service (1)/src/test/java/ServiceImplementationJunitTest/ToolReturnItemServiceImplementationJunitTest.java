package ServiceImplementationJunitTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.ilp.inventory_service.Dto.ToolReturnItemDto;
import com.ilp.inventory_service.Entity.DamageReportEntity;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Entity.ToolRequestEntity;
import com.ilp.inventory_service.Entity.ToolReturnEntity;
import com.ilp.inventory_service.Entity.ToolReturnItemEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.DamageReportRepository;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.Repository.ToolReturnItemRespository;
import com.ilp.inventory_service.Repository.ToolReturnRepository;
import com.ilp.inventory_service.ServiceImplementation.ToolReturnItemServiceImplementation;
import com.ilp.inventory_service.ToolEnums.ItemCondition;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ToolReturnItemServiceImplementationJunitTest {

    @Mock
    private ToolReturnItemRespository toolReturnItemRespository;

    @Mock
    private ToolReturnRepository toolReturnRepository;

    @Mock
    private InventoryRepository inventoryRepository;

    @Mock
    private DamageReportRepository damageReportRepository;

    @InjectMocks
    private ToolReturnItemServiceImplementation service;

    private ToolReturnItemDto dto;
    private ToolReturnEntity toolReturn;
    private InventoryEntity inventory;
    private ToolReturnItemEntity itemEntity;

    @BeforeEach
    void setUp() {

        ToolRequestEntity request = new ToolRequestEntity();
        request.setToolRequestId(1L);
        request.setProjectId(100L);

        toolReturn = new ToolReturnEntity();
        toolReturn.setToolReturnId(1L);
        toolReturn.setToolRequest(request);
        toolReturn.setReturnedBy(111L);

        inventory = new InventoryEntity();
        inventory.setItemId(10L);
        inventory.setAvailableQuantity(5);

        dto = new ToolReturnItemDto();
        dto.setToolReturnId(1L);
        dto.setItemId(10L);
        dto.setReturnedQuantity(2);
        dto.setDamagedQuantity(0);
        dto.setLostQuantity(0);
        dto.setCondition(ItemCondition.GOOD);
        dto.setVerifiedBy(1L);
        dto.setRemarks("Test");

        itemEntity = new ToolReturnItemEntity();
        itemEntity.setReturnItemId(1L);
        itemEntity.setToolReturn(toolReturn);
        itemEntity.setInventory(inventory);
        itemEntity.setReturnedQuantity(2);
        itemEntity.setCondition(ItemCondition.GOOD);
    }

    // =====================================
    // CREATE
    // =====================================

    @Test
    void create_Success() {

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.of(toolReturn));

        when(inventoryRepository.findById(10L))
                .thenReturn(Optional.of(inventory));

        when(toolReturnItemRespository.save(any()))
                .thenReturn(itemEntity);

        ToolReturnItemDto result = service.create(dto);

        assertNotNull(result);

        verify(toolReturnItemRespository).save(any());
        verify(inventoryRepository).save(any());
    }

    @Test
    void create_ToolReturnNotFound() {

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.create(dto));
    }

    @Test
    void create_InventoryNotFound() {

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.of(toolReturn));

        when(inventoryRepository.findById(10L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.create(dto));
    }

    // =====================================
    // DAMAGE REPORT CREATION
    // =====================================

    @Test
    void create_DamagedItem_ShouldCreateDamageReport() {

        dto.setCondition(ItemCondition.DAMAGED);

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.of(toolReturn));

        when(inventoryRepository.findById(10L))
                .thenReturn(Optional.of(inventory));

        when(toolReturnItemRespository.save(any()))
                .thenReturn(itemEntity);

        service.create(dto);

        verify(damageReportRepository)
                .save(any(DamageReportEntity.class));
    }

    @Test
    void create_LostItem_ShouldCreateDamageReport() {

        dto.setCondition(ItemCondition.LOST);

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.of(toolReturn));

        when(inventoryRepository.findById(10L))
                .thenReturn(Optional.of(inventory));

        when(toolReturnItemRespository.save(any()))
                .thenReturn(itemEntity);

        service.create(dto);

        verify(damageReportRepository)
                .save(any(DamageReportEntity.class));
    }

    // =====================================
    // GET BY ID
    // =====================================

    @Test
    void getById_Success() {

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.of(itemEntity));

        ToolReturnItemDto result =
                service.getById(1L);

        assertNotNull(result);
    }

    @Test
    void getById_NotFound() {

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.getById(1L));
    }

    // =====================================
    // GET ALL
    // =====================================

    @Test
    void getAll_Success() {

        when(toolReturnItemRespository.findAll())
                .thenReturn(List.of(itemEntity));

        assertEquals(
                1,
                service.getAll().size());
    }

    @Test
    void getAll_Empty() {

        when(toolReturnItemRespository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(service.getAll().isEmpty());
    }

    // =====================================
    // GET BY TOOL RETURN ID
    // =====================================

    @Test
    void getByToolReturnId_Success() {

        when(toolReturnItemRespository
                .findByToolReturnToolReturnId(1L))
                .thenReturn(List.of(itemEntity));

        assertEquals(
                1,
                service.getByToolReturnId(1L).size());
    }

    @Test
    void getByToolReturnId_Empty() {

        when(toolReturnItemRespository
                .findByToolReturnToolReturnId(1L))
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getByToolReturnId(1L).isEmpty());
    }

    // =====================================
    // VERIFY ITEM
    // =====================================

    @Test
    void verifyItem_Success() {

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.of(itemEntity));

        service.verifyItem(1L, 999L);

        verify(toolReturnItemRespository)
                .save(any(ToolReturnItemEntity.class));
    }

    @Test
    void verifyItem_NotFound() {

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.verifyItem(1L, 999L));
    }

    // =====================================
    // DELETE
    // =====================================

    @Test
    void delete_Success() {

        itemEntity.setVerifiedBy(null);

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.of(itemEntity));

        service.delete(1L);

        verify(toolReturnItemRespository)
                .delete(itemEntity);
    }

    @Test
    void delete_NotFound() {

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.delete(1L));
    }

    @Test
    void delete_VerifiedItem() {

        itemEntity.setVerifiedBy(100L);

        when(toolReturnItemRespository.findById(1L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.delete(1L));
    }

    // =====================================
    // EDGE CASES
    // =====================================

    @Test
    void create_WhenAvailableQuantityNull() {

        inventory.setAvailableQuantity(null);

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.of(toolReturn));

        when(inventoryRepository.findById(10L))
                .thenReturn(Optional.of(inventory));

        when(toolReturnItemRespository.save(any()))
                .thenReturn(itemEntity);

        service.create(dto);

        verify(inventoryRepository).save(any());
    }

    @Test
    void create_WhenReturnedQuantityNull() {

        dto.setReturnedQuantity(null);

        when(toolReturnRepository.findById(1L))
                .thenReturn(Optional.of(toolReturn));

        when(inventoryRepository.findById(10L))
                .thenReturn(Optional.of(inventory));

        when(toolReturnItemRespository.save(any()))
                .thenReturn(itemEntity);

        assertDoesNotThrow(
                () -> service.create(dto));
    }
}
