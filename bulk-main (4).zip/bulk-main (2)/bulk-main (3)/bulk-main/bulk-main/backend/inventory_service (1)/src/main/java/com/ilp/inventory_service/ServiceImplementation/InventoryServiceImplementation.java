package com.ilp.inventory_service.ServiceImplementation;

import com.ilp.inventory_service.Dto.BulkUploadResponseDto;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Exception.InventoryException;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.ServiceInterface.InventoryServiceInterface;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class InventoryServiceImplementation
        implements InventoryServiceInterface {

    @Autowired
    private InventoryRepository inventoryRepository;

    @Override
    @Transactional
    public BulkUploadResponseDto bulkUpload(MultipartFile file) {
        List<String> errors = new ArrayList<>();
        int totalRecords = 0;
        int successCount = 0;
        int failureCount = 0;
        DataFormatter formatter = new DataFormatter();

        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            boolean header = true;

            for (Row row : sheet) {
                if (header) {
                    header = false;
                    continue;
                }

                if (isBlankRow(row, formatter)) {
                    continue;
                }

                totalRecords++;

                try {
                    String itemCode = formatter.formatCellValue(row.getCell(0)).trim();
                    String itemName = formatter.formatCellValue(row.getCell(1)).trim();
                    String itemCategory = formatter.formatCellValue(row.getCell(2)).trim();
                    String quantityText = formatter.formatCellValue(row.getCell(3)).trim();

                    if (itemCode.isEmpty()) {
                        throw new InventoryException("Item Code Cannot Be Empty");
                    }

                    if (itemName.isEmpty()) {
                        throw new InventoryException("Item Name Cannot Be Empty");
                    }

                    if (itemCategory.isEmpty()) {
                        throw new InventoryException("Item Category Cannot Be Empty");
                    }

                    int quantity = Integer.parseInt(quantityText);

                    if (quantity < 0) {
                        throw new InventoryException("Quantity Cannot Be Negative");
                    }

                    InventoryEntity existing = inventoryRepository.findByItemCode(itemCode);
                    if (existing != null && !Boolean.TRUE.equals(existing.getIsDeleted())) {
                        throw new InventoryException("Duplicate Item Code");
                    }

                    InventoryEntity item = new InventoryEntity();
                    item.setItemCode(itemCode);
                    item.setItemName(itemName);
                    item.setItemCategory(itemCategory.toUpperCase());
                    item.setTotalQuantity(quantity);
                    item.setAvailableQuantity(quantity);
                    item.setMinimumStock(0);
                    item.setStatus(quantity == 0 ? "Out of Stock" : "Available");
                    item.setIsDeleted(false);

                    inventoryRepository.save(item);
                    successCount++;
                } catch (Exception exception) {
                    failureCount++;
                    errors.add(
                            "Row " + (row.getRowNum() + 1)
                                    + " : " + exception.getMessage()
                    );
                }
            }
        } catch (Exception exception) {
            throw new InventoryException(
                    "Error Reading Excel File: " + exception.getMessage()
            );
        }

        BulkUploadResponseDto response = new BulkUploadResponseDto();
        response.setTotalRecords(totalRecords);
        response.setSuccessCount(successCount);
        response.setFailureCount(failureCount);
        response.setErrors(errors);
        return response;
    }

    private boolean isBlankRow(Row row, DataFormatter formatter) {
        if (row == null) {
            return true;
        }

        for (int i = 0; i < 4; i++) {
            Cell cell = row.getCell(i);
            if (cell != null
                    && cell.getCellType() != CellType.BLANK
                    && !formatter.formatCellValue(cell).trim().isEmpty()) {
                return false;
            }
        }

        return true;
    }

    @Override
    @Transactional
    public String uploadImage(Long itemId, MultipartFile file) {
        try {
            InventoryEntity item = getActiveInventory(itemId);
            item.setItemImage(file.getBytes());
            inventoryRepository.saveAndFlush(item);
            return "Image Uploaded Successfully";
        } catch (InventoryException exception) {
            throw exception;
        } catch (Exception exception) {
            throw new InventoryException(
                    "Image Upload Failed: " + exception.getMessage()
            );
        }
    }

    @Override
    @Transactional
    public InventoryEntity saveInventoryItem(InventoryEntity inventory) {
        if (inventory == null) {
            throw new InventoryException("Inventory Item Cannot Be Null");
        }

        if (inventory.getItemCode() == null
                || inventory.getItemCode().trim().isEmpty()) {
            throw new InventoryException("Item Code Cannot Be Empty");
        }

        if (inventory.getAvailableQuantity() != null
                && inventory.getAvailableQuantity() < 0) {
            throw new InventoryException(
                    "Available Quantity Cannot Be Negative"
            );
        }

        if (inventory.getTotalQuantity() != null
                && inventory.getTotalQuantity() < 0) {
            throw new InventoryException(
                    "Total Quantity Cannot Be Negative"
            );
        }

        inventory.setIsDeleted(false);
        return inventoryRepository.saveAndFlush(inventory);
    }

    @Override
    @Transactional(readOnly = true)
    public InventoryEntity getInventoryById(Long itemId) {
        return getActiveInventory(itemId);
    }

    @Override
    @Transactional(readOnly = true)
    public InventoryEntity getInventoryByCode(String itemCode) {
        InventoryEntity inventory = inventoryRepository.findByItemCode(itemCode);

        if (inventory == null || Boolean.TRUE.equals(inventory.getIsDeleted())) {
            throw new InventoryException(
                    "Inventory Item Not Found With Code : " + itemCode
            );
        }

        return inventory;
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getAllInventoryItems() {
        return inventoryRepository.findByIsDeletedFalse();
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getInventoryByCategory(String category) {
        return inventoryRepository.getInventoryByCategory(category);
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> searchInventoryByName(String itemName) {
        return inventoryRepository.findByItemNameContainingIgnoreCase(itemName)
                .stream()
                .filter(item -> !Boolean.TRUE.equals(item.getIsDeleted()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getInventoryByStatus(String status) {
        return inventoryRepository.findByStatus(status)
                .stream()
                .filter(item -> !Boolean.TRUE.equals(item.getIsDeleted()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getLowStockItems() {
        return inventoryRepository.findLowStockItems();
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getMinimumStockItems() {
        return inventoryRepository.findMinimumStockItems();
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getAvailableItems() {
        return inventoryRepository.findAvailableItems();
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryEntity> getOutOfStockItems() {
        return inventoryRepository.findOutOfStockItems();
    }

    @Override
    @Transactional(readOnly = true)
    public InventoryEntity checkAvailableStock(
            Long itemId,
            Integer requestedQuantity) {

        if (requestedQuantity == null || requestedQuantity <= 0) {
            throw new InventoryException(
                    "Requested Quantity Must Be Greater Than Zero"
            );
        }

        InventoryEntity inventory = getActiveInventory(itemId);

        if (inventory.getAvailableQuantity() == null
                || inventory.getAvailableQuantity() < requestedQuantity) {
            throw new InventoryException(
                    "Requested Quantity " + requestedQuantity
                            + " Exceeds Available Quantity "
                            + inventory.getAvailableQuantity()
            );
        }

        return inventory;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countLowStockItems() {
        Long count = inventoryRepository.countLowStockItems();
        return count == null ? 0L : count;
    }

    @Override
    @Transactional(readOnly = true)
    public Long getTotalAvailableStock() {
        Long total = inventoryRepository.getTotalAvailableStock();
        return total == null ? 0L : total;
    }

    @Override
    @Transactional
    public InventoryEntity updateInventoryItem(InventoryEntity inventory) {
        if (inventory == null || inventory.getItemId() == null) {
            throw new InventoryException(
                    "Inventory Item ID Cannot Be Null"
            );
        }

        InventoryEntity existing = getActiveInventory(inventory.getItemId());

        inventory.setIsDeleted(false);

        if (inventory.getCreatedAt() == null) {
            inventory.setCreatedAt(existing.getCreatedAt());
        }

        return inventoryRepository.saveAndFlush(inventory);
    }

    @Override
    @Transactional
    public void deleteInventoryItem(Long itemId) {
        InventoryEntity inventory = getActiveInventory(itemId);
        inventory.setIsDeleted(true);
        inventoryRepository.saveAndFlush(inventory);
    }

    @Override
    @Transactional
    public void softDeleteInventory(Long itemId) {
        deleteInventoryItem(itemId);
    }

    private InventoryEntity getActiveInventory(Long itemId) {
        if (itemId == null || itemId <= 0) {
            throw new InventoryException(
                    "A Valid Inventory Item ID Is Required"
            );
        }

        return inventoryRepository
                .findByItemIdAndIsDeletedFalse(itemId)
                .orElseThrow(() -> new InventoryException(
                        "Inventory Item Not Found With ID : " + itemId
                ));
    }
}
