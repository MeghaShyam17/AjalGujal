package com.ilp.inventory_service.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;

@Component
public class DatabaseMigrationConfig implements CommandLineRunner {

    @Autowired
    private DataSource dataSource;

    @Override
    public void run(String... args) throws Exception {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            
            conn.setAutoCommit(true);
            
            System.out.println("Running database migration to drop outdated enum check constraints...");
            
            try {
                stmt.execute("ALTER TABLE tool_return DROP CONSTRAINT IF EXISTS tool_return_return_status_check");
                System.out.println("Successfully dropped constraint tool_return_return_status_check");
            } catch (Exception e) {
                System.err.println("Migration warning (tool_return constraint): " + e.getMessage());
            }

            try {
                stmt.execute("ALTER TABLE tool_request DROP CONSTRAINT IF EXISTS tool_request_approval_status_check");
                System.out.println("Successfully dropped constraint tool_request_approval_status_check");
            } catch (Exception e) {
                System.err.println("Migration warning (tool_request constraint): " + e.getMessage());
            }
            
        } catch (Exception e) {
            System.err.println("Database migration failed: " + e.getMessage());
        }
    }
}
