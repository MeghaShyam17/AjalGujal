package com.ilp.inventory_service.Dto;

import java.util.List;

public class ComponentReturnDto {

    private Long componentRequestId;

    private Long projectId;

    private Long returnedBy;

    private String remarks;

    private List<ComponentReturnItemDto> returnItems;

    public ComponentReturnDto() {
    }

    public ComponentReturnDto(
            Long componentRequestId,
            Long projectId,
            Long returnedBy,
            String remarks,
            List<ComponentReturnItemDto> returnItems) {

        this.componentRequestId = componentRequestId;
        this.projectId = projectId;
        this.returnedBy = returnedBy;
        this.remarks = remarks;
        this.returnItems = returnItems;
    }

    public Long getComponentRequestId() {
        return componentRequestId;
    }

    public void setComponentRequestId(Long componentRequestId) {
        this.componentRequestId = componentRequestId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getReturnedBy() {
        return returnedBy;
    }

    public void setReturnedBy(Long returnedBy) {
        this.returnedBy = returnedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public List<ComponentReturnItemDto> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(
            List<ComponentReturnItemDto> returnItems) {
        this.returnItems = returnItems;
    }
}