package com.ilp.inventory_service.Entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "inventory_item")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class InventoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Long itemId;

    @Column(name = "item_code", unique = true)
    private String itemCode;

    @Column(name = "item_name", nullable = false)
    private String itemName;

    @Column(name = "item_category")
    private String itemCategory;

    @Column(name = "make")
    private String make;

    @Column(name = "specification")
    private String specification;

    @Column(name = "cost")
    private BigDecimal cost;

    @Column(name = "return_timeline")
    private String returnTimeline;

    @Column(name = "total_quantity")
    private Integer totalQuantity;

    @Column(name = "available_quantity")
    private Integer availableQuantity;

    @Column(name = "minimum_stock")
    private Integer minimumStock;

    @Column(name = "unit")
    private String unit;

    @Column(name = "lab")
    private String lab;

    @Column(name = "cupboard")
    private String cupboard;

    @Column(name = "shelf_1")
    private String shelf1;

    @Column(name = "shelf_1_count")
    private Integer shelf1Count;

    @Column(name = "shelf_2")
    private String shelf2;

    @Column(name = "shelf_2_count")
    private Integer shelf2Count;

    @Column(name = "purpose")
    private String purpose;

    @Column(name = "comments")
    private String comments;

    @Lob
    @Column(name = "item_image")
    private byte[] itemImage;

    @Column(name = "status")
    private String status;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "updated_at")
    private Timestamp updatedAt;
    
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
@JsonIgnore
    @OneToMany(mappedBy = "inventory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ComponentRequestItemEntity> componentRequestItems;
@JsonIgnore
    @OneToMany(mappedBy = "inventory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ComponentReturnItemEntity> componentReturnItems;
@JsonIgnore
    @OneToMany(mappedBy = "inventory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ToolRequestItemEntity> toolRequestItems;
@JsonIgnore
    @OneToMany(mappedBy = "inventory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ToolReturnItemEntity> toolReturnItems;
@JsonIgnore
    @OneToMany(mappedBy = "inventory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<DamageReportEntity> damageReports;

    public InventoryEntity() {
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCategory() {
        return itemCategory;
    }

    public void setItemCategory(String itemCategory) {
        this.itemCategory = itemCategory;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public String getReturnTimeline() {
        return returnTimeline;
    }

    public void setReturnTimeline(String returnTimeline) {
        this.returnTimeline = returnTimeline;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public Integer getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(Integer availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public Integer getMinimumStock() {
        return minimumStock;
    }

    public void setMinimumStock(Integer minimumStock) {
        this.minimumStock = minimumStock;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getLab() {
        return lab;
    }

    public void setLab(String lab) {
        this.lab = lab;
    }

    public String getCupboard() {
        return cupboard;
    }

    public void setCupboard(String cupboard) {
        this.cupboard = cupboard;
    }

    public String getShelf1() {
        return shelf1;
    }

    public void setShelf1(String shelf1) {
        this.shelf1 = shelf1;
    }

    public Integer getShelf1Count() {
        return shelf1Count;
    }

    public void setShelf1Count(Integer shelf1Count) {
        this.shelf1Count = shelf1Count;
    }

    public String getShelf2() {
        return shelf2;
    }

    public void setShelf2(String shelf2) {
        this.shelf2 = shelf2;
    }

    public Integer getShelf2Count() {
        return shelf2Count;
    }

    public void setShelf2Count(Integer shelf2Count) {
        this.shelf2Count = shelf2Count;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public byte[] getItemImage() {
        return itemImage;
    }

    public void setItemImage(byte[] itemImage) {
        this.itemImage = itemImage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<ComponentRequestItemEntity> getComponentRequestItems() {
        return componentRequestItems;
    }

    public void setComponentRequestItems(List<ComponentRequestItemEntity> componentRequestItems) {
        this.componentRequestItems = componentRequestItems;
    }

    public List<ComponentReturnItemEntity> getComponentReturnItems() {
        return componentReturnItems;
    }

    public void setComponentReturnItems(List<ComponentReturnItemEntity> componentReturnItems) {
        this.componentReturnItems = componentReturnItems;
    }

    public List<ToolRequestItemEntity> getToolRequestItems() {
        return toolRequestItems;
    }

    public void setToolRequestItems(List<ToolRequestItemEntity> toolRequestItems) {
        this.toolRequestItems = toolRequestItems;
    }

    public List<ToolReturnItemEntity> getToolReturnItems() {
        return toolReturnItems;
    }

    public void setToolReturnItems(List<ToolReturnItemEntity> toolReturnItems) {
        this.toolReturnItems = toolReturnItems;
    }

    public List<DamageReportEntity> getDamageReports() {
        return damageReports;
    }

    public void setDamageReports(List<DamageReportEntity> damageReports) {
        this.damageReports = damageReports;
    }
   
    
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
}