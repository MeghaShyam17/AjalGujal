package com.ilp.inventory_service.Dto;

import java.sql.Timestamp;

import com.ilp.inventory_service.ToolEnums.ReturnStatus;

public class ToolReturnDto {

    private Long toolReturnId;

    private Long toolRequestId;

    private Long returnedBy;

    private Long receivedBy;

    private Timestamp returnDate;

    private ReturnStatus returnStatus;

    private String remarks;

    private UserDto user;

    private ProjectTeamDto project;

    public Long getToolReturnId() {
        return toolReturnId;
    }

    public void setToolReturnId(Long toolReturnId) {
        this.toolReturnId = toolReturnId;
    }

    public Long getToolRequestId() {
        return toolRequestId;
    }

    public void setToolRequestId(Long toolRequestId) {
        this.toolRequestId = toolRequestId;
    }

    public Long getReturnedBy() {
        return returnedBy;
    }

    public void setReturnedBy(Long returnedBy) {
        this.returnedBy = returnedBy;
    }

    public Long getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Long receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Timestamp getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Timestamp returnDate) {
        this.returnDate = returnDate;
    }

    public ReturnStatus getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(ReturnStatus returnStatus) {
        this.returnStatus = returnStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public ProjectTeamDto getProject() {
        return project;
    }

    public void setProject(ProjectTeamDto project) {
        this.project = project;
    }

    private java.util.List<ToolReturnItemDto> items;

    public java.util.List<ToolReturnItemDto> getItems() {
        return items;
    }

    public void setItems(java.util.List<ToolReturnItemDto> items) {
        this.items = items;
    }

    private String projectName;
    private Long teamLeaderId;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Long getTeamLeaderId() {
        return teamLeaderId;
    }

    public void setTeamLeaderId(Long teamLeaderId) {
        this.teamLeaderId = teamLeaderId;
    }
}