package com.ilp.inventory_service.Dto;

import java.sql.Timestamp;
import java.util.List;

public class ComponentReturnResponseDto {

    private Long componentReturnId;

    private String returnCode;

    private Long componentRequestId;

    private Long projectId;

    private Long returnedBy;

    private Long receivedBy;

    private Timestamp returnDate;

    private String returnStatus;

    private String remarks;

    private Timestamp createdAt;

    private List<ComponentReturnItemResponseDto> returnItems;

    public ComponentReturnResponseDto() {
    }

    public ComponentReturnResponseDto(
            Long componentReturnId,
            String returnCode,
            Long componentRequestId,
            Long projectId,
            Long returnedBy,
            Long receivedBy,
            Timestamp returnDate,
            String returnStatus,
            String remarks,
            Timestamp createdAt,
            List<ComponentReturnItemResponseDto> returnItems) {

        this.componentReturnId = componentReturnId;
        this.returnCode = returnCode;
        this.componentRequestId = componentRequestId;
        this.projectId = projectId;
        this.returnedBy = returnedBy;
        this.receivedBy = receivedBy;
        this.returnDate = returnDate;
        this.returnStatus = returnStatus;
        this.remarks = remarks;
        this.createdAt = createdAt;
        this.returnItems = returnItems;
    }

    public Long getComponentReturnId() {
        return componentReturnId;
    }

    public void setComponentReturnId(Long componentReturnId) {
        this.componentReturnId = componentReturnId;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public Long getComponentRequestId() {
        return componentRequestId;
    }

    public void setComponentRequestId(Long componentRequestId) {
        this.componentRequestId = componentRequestId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getReturnedBy() {
        return returnedBy;
    }

    public void setReturnedBy(Long returnedBy) {
        this.returnedBy = returnedBy;
    }

    public Long getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Long receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Timestamp getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Timestamp returnDate) {
        this.returnDate = returnDate;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public List<ComponentReturnItemResponseDto> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(
            List<ComponentReturnItemResponseDto> returnItems) {
        this.returnItems = returnItems;
    }
}