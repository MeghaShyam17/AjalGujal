package com.ilp.inventory_service.ServiceImplementation;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.ToolEnums;
import com.ilp.inventory_service.Client.NotificationFeignClient;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ComponentReturnDto;
import com.ilp.inventory_service.Dto.ComponentReturnItemResponseDto;
import com.ilp.inventory_service.Dto.ComponentReturnResponseDto;
import com.ilp.inventory_service.Dto.NotificationRequestDto;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Dto.UserServiceResponseDto;
import com.ilp.inventory_service.Entity.ComponentReturnEntity;
import com.ilp.inventory_service.Entity.ComponentReturnItemEntity;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Entity.ComponentRequestEntity;
import com.ilp.inventory_service.Repository.ComponentRequestRepository;
import com.ilp.inventory_service.Repository.ComponentReturnRepository;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.ServiceInterface.ComponentReturnServiceInterface;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComponentReturnServiceImplementation
        implements ComponentReturnServiceInterface {

    @Autowired
    private ComponentReturnRepository componentReturnRepository;

    @Autowired
    private ComponentRequestRepository componentRequestRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private NotificationFeignClient notificationFeignClient;

    @Override
    public ComponentReturnResponseDto createComponentReturn(
            ComponentReturnDto dto) {

        if (dto == null) {
            throw new ToolBusinessException("Component return details must not be null");
        }

        ComponentRequestEntity requestEntity = null;
        if (dto.getComponentRequestId() != null) {
            requestEntity = componentRequestRepository.findById(dto.getComponentRequestId())
                    .orElseThrow(() -> new ToolResourceNotFoundException("Component Request Not Found"));

            if (!ToolEnums.ApprovalStatus.ISSUED.name().equalsIgnoreCase(requestEntity.getApprovalStatus())) {
                throw new ToolBusinessException("Component return can only be created for an ISSUED component request");
            }
        }

        Long projectId = dto.getProjectId() != null ? dto.getProjectId() : (requestEntity != null ? requestEntity.getProjectId() : null);
        if (projectId == null) {
            throw new ToolBusinessException("Project ID is required");
        }

        ProjectTeamDto project = validateProject(projectId);

        // Deadline restriction removed — components can be returned at any time

        UserDto returnedByUser = validateUser(dto.getReturnedBy(), "Returned By User Not Found");

        UserDto facultyUser = null;
        if (project.getFacultyId() != null) {
            facultyUser = validateUser(
                    Long.valueOf(project.getFacultyId()),
                    "Faculty User Not Found");
        }

        ComponentReturnEntity entity = new ComponentReturnEntity();
        entity.setComponentRequest(requestEntity);
        entity.setProjectId(projectId);
        entity.setReturnedBy(dto.getReturnedBy());
        entity.setRemarks(dto.getRemarks());
        entity.setReturnCode("CR-" + System.currentTimeMillis());
        entity.setReturnStatus(ToolEnums.ReturnStatus.PENDING.name());
        entity.setReturnDate(new Timestamp(System.currentTimeMillis()));
        entity.setCreatedAt(new Timestamp(System.currentTimeMillis()));

        if (dto.getReturnItems() != null && !dto.getReturnItems().isEmpty()) {
            List<ComponentReturnItemEntity> returnItems = dto.getReturnItems().stream().map(itemDto -> {
                InventoryEntity inventory = inventoryRepository.findById(itemDto.getItemId())
                        .orElseThrow(() -> new ToolResourceNotFoundException("Inventory Item Not Found"));

                int issuedQty = itemDto.getIssuedQuantity() == null ? 0 : itemDto.getIssuedQuantity();
                int returnedQty = itemDto.getReturnedQuantity() == null ? 0 : itemDto.getReturnedQuantity();
                int consumedQty = itemDto.getConsumedQuantity() == null ? 0 : itemDto.getConsumedQuantity();
                int damagedQty = itemDto.getDamagedQuantity() == null ? 0 : itemDto.getDamagedQuantity();
                int lostQty = itemDto.getLostQuantity() == null ? 0 : itemDto.getLostQuantity();

                if (issuedQty > 0 && (returnedQty + consumedQty + damagedQty + lostQty) > issuedQty) {
                    throw new ToolBusinessException("Total returned, consumed, damaged, and lost quantity exceeds issued quantity for item ID: " + inventory.getItemId());
                }

                ComponentReturnItemEntity returnItem = new ComponentReturnItemEntity();
                returnItem.setComponentReturn(entity);
                returnItem.setInventory(inventory);
                returnItem.setIssuedQuantity(issuedQty);
                returnItem.setReturnedQuantity(returnedQty);
                returnItem.setConsumedQuantity(consumedQty);
                returnItem.setDamagedQuantity(damagedQty);
                returnItem.setLostQuantity(lostQty);
                returnItem.setCondition(itemDto.getCondition() != null ? itemDto.getCondition() : ToolEnums.ItemCondition.GOOD.name());
                returnItem.setRemarks(itemDto.getRemarks());

                return returnItem;
            }).collect(Collectors.toList());

            entity.setReturnItems(returnItems);
        }

        ComponentReturnEntity saved = componentReturnRepository.save(entity);

        if (facultyUser != null) {
            sendNotification(
                    facultyUser.getUserId(),
                    "New Component Return",
                    returnedByUser.getUserName()
                            + " submitted a component return for project "
                            + project.getProjectName()
                            + ". Return code: "
                            + saved.getReturnCode(),
                    "COMPONENT_RETURN_CREATED",
                    saved.getComponentReturnId(),
                    returnedByUser.getUserId()
            );
        }

        return mapToResponse(saved);
    }

    @Override
    public ComponentReturnResponseDto getById(Long componentReturnId) {
        ComponentReturnEntity entity = findEntityById(componentReturnId);
        return mapToResponse(entity);
    }

    @Override
    public List<ComponentReturnResponseDto> getReturns(
            Long projectId,
            Long returnedBy,
            Long receivedBy,
            Long componentRequestId,
            String status) {

        if (projectId != null) {
            return getByProjectId(projectId);
        }
        if (returnedBy != null) {
            return getByReturnedBy(returnedBy);
        }
        if (receivedBy != null) {
            return getByReceivedBy(receivedBy);
        }
        if (componentRequestId != null) {
            return getByRequestId(componentRequestId);
        }
        if (status != null && !status.trim().isEmpty()) {
            return componentReturnRepository.findByReturnStatus(status.toUpperCase())
                    .stream()
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
        }
        return getAll();
    }

    @Override
    public List<ComponentReturnResponseDto> getAll() {
        return componentReturnRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnResponseDto> getByProjectId(Long projectId) {
        validateProject(projectId);
        return componentReturnRepository.findByProjectId(projectId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnResponseDto> getByReturnedBy(Long returnedBy) {
        validateUser(returnedBy, "Returned By User Not Found");
        return componentReturnRepository.findByReturnedBy(returnedBy)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnResponseDto> getByReceivedBy(Long receivedBy) {
        validateUser(receivedBy, "Received By User Not Found");
        return componentReturnRepository.findByReceivedBy(receivedBy)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnResponseDto> getByRequestId(Long componentRequestId) {
        return componentReturnRepository
                .findByComponentRequestComponentRequestId(componentRequestId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnResponseDto> getPendingReturns() {
        return getReturns(null, null, null, null, ToolEnums.ReturnStatus.PENDING.name());
    }

    @Override
    public List<ComponentReturnResponseDto> getReceivedReturns() {
        return getReturns(null, null, null, null, ToolEnums.ReturnStatus.COMPLETED.name());
    }

    @Override
    public ComponentReturnResponseDto receiveReturn(
            Long componentReturnId,
            Long receivedBy) {

        ComponentReturnEntity entity = findEntityById(componentReturnId);

        if (!ToolEnums.ReturnStatus.PENDING.name().equalsIgnoreCase(entity.getReturnStatus())) {
            return mapToResponse(entity);
        }

        UserDto receivedByUser = validateUser(receivedBy, "Received By User Not Found");
        UserDto returnedByUser = validateUser(entity.getReturnedBy(), "Returned By User Not Found");
        ProjectTeamDto project = validateProject(entity.getProjectId());

        if (entity.getReturnItems() != null) {
            for (ComponentReturnItemEntity item : entity.getReturnItems()) {
                if (item.getInventory() != null) {
                    InventoryEntity inventory = item.getInventory();
                    int currentAvailable = inventory.getAvailableQuantity() == null ? 0 : inventory.getAvailableQuantity();
                    int returnedQty = item.getReturnedQuantity() == null ? 0 : item.getReturnedQuantity();

                    inventory.setAvailableQuantity(currentAvailable + returnedQty);
                    inventoryRepository.save(inventory);
                }
            }
        }

        entity.setReceivedBy(receivedBy);
        entity.setReturnStatus(ToolEnums.ReturnStatus.COMPLETED.name());

        ComponentReturnEntity updated = componentReturnRepository.save(entity);

        sendNotification(
                returnedByUser.getUserId(),
                "Component Return Received",
                "Your component return "
                        + updated.getReturnCode()
                        + " for project "
                        + project.getProjectName()
                        + " has been received by "
                        + receivedByUser.getUserName(),
                "COMPONENT_RETURN_RECEIVED",
                updated.getComponentReturnId(),
                receivedByUser.getUserId()
        );

        return mapToResponse(updated);
    }

    @Override
    public void delete(Long componentReturnId) {
        ComponentReturnEntity entity = findEntityById(componentReturnId);
        componentReturnRepository.delete(entity);
    }

    private ComponentReturnEntity findEntityById(Long componentReturnId) {
        return componentReturnRepository.findById(componentReturnId)
                .orElseThrow(() -> new ToolResourceNotFoundException("Component Return Not Found"));
    }

    private ProjectTeamDto validateProject(Long projectId) {
        if (projectId == null) {
            throw new ToolBusinessException("Project ID must not be null");
        }

        Integer projectIdValue;
        try {
            projectIdValue = Math.toIntExact(projectId);
        } catch (ArithmeticException exception) {
            throw new ToolBusinessException("Project ID is outside the supported range");
        }

        ProjectTeamDto project = projectClient.getProjectById(projectIdValue);
        if (project == null || project.getProjectId() == null) {
            throw new ToolResourceNotFoundException("Project Not Found");
        }

        return project;
    }

    private UserDto validateUser(Long userId, String errorMessage) {
        if (userId == null) {
            throw new ToolBusinessException("User ID must not be null");
        }

        Integer userIdValue;
        try {
            userIdValue = Math.toIntExact(userId);
        } catch (ArithmeticException exception) {
            throw new ToolBusinessException("User ID is outside the supported range");
        }

        UserServiceResponseDto response = userClient.getUserResponseById(userIdValue);
        if (response == null || response.getUserId() == null) {
            throw new ToolResourceNotFoundException(errorMessage);
        }

        return mapToUserDto(response);
    }

    private UserDto mapToUserDto(UserServiceResponseDto response) {
        if (response == null) {
            return null;
        }

        UserDto userDto = new UserDto();
        userDto.setUserId(response.getUserId());
        userDto.setUserName(response.getName());
        userDto.setEmail(response.getEmail());
        userDto.setMobileNumber(response.getPhone());

        if (response.getRole() != null) {
            userDto.setRole(response.getRole().getRoleName());
        }

        return userDto;
    }


    private void sendNotification(
            Long recipientId,
            String title,
            String message,
            String notificationType,
            Long returnId,
            Long senderId) {

        NotificationRequestDto notification = new NotificationRequestDto(
                Math.toIntExact(recipientId),
                title,
                message,
                notificationType,
                "INVENTORY",
                Math.toIntExact(returnId),
                "HIGH",
                Math.toIntExact(senderId)
        );

        notificationFeignClient.createNotification(notification);
    }

    private ComponentReturnResponseDto mapToResponse(ComponentReturnEntity entity) {
        ComponentReturnResponseDto dto = new ComponentReturnResponseDto();

        dto.setComponentReturnId(entity.getComponentReturnId());
        dto.setReturnCode(entity.getReturnCode());

        if (entity.getComponentRequest() != null) {
            dto.setComponentRequestId(entity.getComponentRequest().getComponentRequestId());
        }

        dto.setProjectId(entity.getProjectId());
        dto.setReturnedBy(entity.getReturnedBy());
        dto.setReceivedBy(entity.getReceivedBy());
        dto.setReturnDate(entity.getReturnDate());
        dto.setReturnStatus(entity.getReturnStatus());
        dto.setRemarks(entity.getRemarks());
        dto.setCreatedAt(entity.getCreatedAt());

        if (entity.getReturnItems() != null) {
            List<ComponentReturnItemResponseDto> items = entity.getReturnItems()
                    .stream()
                    .map(this::mapToItemResponse)
                    .collect(Collectors.toList());

            dto.setReturnItems(items);
        }

        return dto;
    }

    private ComponentReturnItemResponseDto mapToItemResponse(ComponentReturnItemEntity item) {
        ComponentReturnItemResponseDto itemDto = new ComponentReturnItemResponseDto();

        itemDto.setReturnItemId(item.getReturnItemId());
        if (item.getInventory() != null) {
            itemDto.setItemId(item.getInventory().getItemId());
        }

        itemDto.setIssuedQuantity(item.getIssuedQuantity());
        itemDto.setReturnedQuantity(item.getReturnedQuantity());
        itemDto.setConsumedQuantity(item.getConsumedQuantity());
        itemDto.setDamagedQuantity(item.getDamagedQuantity());
        itemDto.setLostQuantity(item.getLostQuantity());
        itemDto.setCondition(item.getCondition());
        itemDto.setRemarks(item.getRemarks());

        return itemDto;
    }
}

