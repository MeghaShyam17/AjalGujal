package com.ilp.inventory_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.inventory_service.ToolEnums.ItemStatus;
import com.ilp.inventory_service.Entity.ToolRequestItemEntity;

import java.util.List;

@Repository
public interface ToolRequestItemRepository
        extends JpaRepository<ToolRequestItemEntity, Long> {

    ToolRequestItemEntity findByToolRequestItemId(
            Long toolRequestItemId);

    List<ToolRequestItemEntity>
    findByToolRequestToolRequestId(
            Long toolRequestId);

    List<ToolRequestItemEntity>
    findByInventoryItemId(
            Long itemId);

    List<ToolRequestItemEntity>
    findByItemStatus(
            ItemStatus itemStatus);

    List<ToolRequestItemEntity>
    findByToolRequestProjectId(
            Long projectId);

    List<ToolRequestItemEntity>
    findByToolRequestRequestedBy(
            Long requestedBy);

    List<ToolRequestItemEntity>
    findByToolRequestApprovedBy(
            Long approvedBy);
}