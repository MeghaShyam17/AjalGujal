package com.ilp.inventory_service.Exception;

public class DamageReportException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public DamageReportException() {
        super();
    }

    public DamageReportException(String message) {
        super(message);
    }

    public DamageReportException(String message, Throwable cause) {
        super(message, cause);
    }

    public DamageReportException(Throwable cause) {
        super(cause);
    }
}
