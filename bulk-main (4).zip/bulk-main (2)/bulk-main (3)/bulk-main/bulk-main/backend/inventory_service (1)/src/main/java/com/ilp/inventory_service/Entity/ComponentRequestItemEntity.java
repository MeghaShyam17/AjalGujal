package com.ilp.inventory_service.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "component_request_item")
public class ComponentRequestItemEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_item_id")
    private Long requestItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "component_request_id")
    private ComponentRequestEntity componentRequest;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id")
    private InventoryEntity inventory;

    @Column(name = "requested_quantity")
    private Integer requestedQuantity;

    @Column(name = "approved_quantity")
    private Integer approvedQuantity;

    @Column(name = "issued_quantity")
    private Integer issuedQuantity;

    @Column(name = "item_status")
    private String itemStatus;

    @Column(name = "faculty_comments")
    private String facultyComments;

    public ComponentRequestItemEntity() {
    }

    public ComponentRequestItemEntity(
            Long requestItemId,
            ComponentRequestEntity componentRequest,
            InventoryEntity inventory,
            Integer requestedQuantity,
            Integer approvedQuantity,
            Integer issuedQuantity,
            String itemStatus,
            String facultyComments) {

        this.requestItemId = requestItemId;
        this.componentRequest = componentRequest;
        this.inventory = inventory;
        this.requestedQuantity = requestedQuantity;
        this.approvedQuantity = approvedQuantity;
        this.issuedQuantity = issuedQuantity;
        this.itemStatus = itemStatus;
        this.facultyComments = facultyComments;
    }

    public Long getRequestItemId() {
        return requestItemId;
    }

    public void setRequestItemId(Long requestItemId) {
        this.requestItemId = requestItemId;
    }

    public ComponentRequestEntity getComponentRequest() {
        return componentRequest;
    }

    public void setComponentRequest(ComponentRequestEntity componentRequest) {
        this.componentRequest = componentRequest;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public Integer getRequestedQuantity() {
        return requestedQuantity;
    }

    public void setRequestedQuantity(Integer requestedQuantity) {
        this.requestedQuantity = requestedQuantity;
    }

    public Integer getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(Integer approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public String getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }

    public String getFacultyComments() {
        return facultyComments;
    }

    public void setFacultyComments(String facultyComments) {
        this.facultyComments = facultyComments;
    }
}