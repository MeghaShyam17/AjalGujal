
package com.ilp.inventory_service.Dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class InventoryDTO {

    private Long itemId;
    private String itemCode;
    private String itemName;
    private String itemCategory;
    private String make;
    private String specification;
    private BigDecimal cost;
    private String returnTimeline;
    private Integer totalQuantity;
    private Integer availableQuantity;
    private Integer minimumStock;
    private String unit;
    private String lab;
    private String cupboard;
    private String shelf1;
    private Integer shelf1Count;
    private String shelf2;
    private Integer shelf2Count;
    private String purpose;
    private String comments;
    private byte[] itemImage;
    private String status;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public InventoryDTO() {
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCategory() {
        return itemCategory;
    }

    public void setItemCategory(String itemCategory) {
        this.itemCategory = itemCategory;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public String getReturnTimeline() {
        return returnTimeline;
    }

    public void setReturnTimeline(String returnTimeline) {
        this.returnTimeline = returnTimeline;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public Integer getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(Integer availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public Integer getMinimumStock() {
        return minimumStock;
    }

    public void setMinimumStock(Integer minimumStock) {
        this.minimumStock = minimumStock;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getLab() {
        return lab;
    }

    public void setLab(String lab) {
        this.lab = lab;
    }

    public String getCupboard() {
        return cupboard;
    }

    public void setCupboard(String cupboard) {
        this.cupboard = cupboard;
    }

    public String getShelf1() {
        return shelf1;
    }

    public void setShelf1(String shelf1) {
        this.shelf1 = shelf1;
    }

    public Integer getShelf1Count() {
        return shelf1Count;
    }

    public void setShelf1Count(Integer shelf1Count) {
        this.shelf1Count = shelf1Count;
    }

    public String getShelf2() {
        return shelf2;
    }

    public void setShelf2(String shelf2) {
        this.shelf2 = shelf2;
    }

    public Integer getShelf2Count() {
        return shelf2Count;
    }

    public void setShelf2Count(Integer shelf2Count) {
        this.shelf2Count = shelf2Count;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public byte[] getItemImage() {
        return itemImage;
    }

    public void setItemImage(byte[] itemImage) {
        this.itemImage = itemImage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}