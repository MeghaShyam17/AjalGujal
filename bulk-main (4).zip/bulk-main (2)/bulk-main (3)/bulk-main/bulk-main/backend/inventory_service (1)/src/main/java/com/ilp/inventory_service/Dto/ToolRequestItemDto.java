package com.ilp.inventory_service.Dto;



public class ToolRequestItemDto {

    private Long toolRequestId;

    private Long itemId;

    private Integer requestedQuantity;

    public Long getToolRequestId() {
        return toolRequestId;
    }

    public void setToolRequestId(Long toolRequestId) {
        this.toolRequestId = toolRequestId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Integer getRequestedQuantity() {
        return requestedQuantity;
    }

    public void setRequestedQuantity(Integer requestedQuantity) {
        this.requestedQuantity = requestedQuantity;
    }
}