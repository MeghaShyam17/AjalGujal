package com.ilp.inventory_service.Dto;

import java.util.List;

public class ComponentRequestDto {

    private Long projectId;

    private Long requestedBy;

    private Long facultyId;

    private String remarks;

    private List<ComponentRequestItemDto> requestItems;

    public ComponentRequestDto() {
    }

    public ComponentRequestDto(
            Long projectId,
            Long requestedBy,
            Long facultyId,
            String remarks,
            List<ComponentRequestItemDto> requestItems) {

        this.projectId = projectId;
        this.requestedBy = requestedBy;
        this.facultyId = facultyId;
        this.remarks = remarks;
        this.requestItems = requestItems;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(Long requestedBy) {
        this.requestedBy = requestedBy;
    }

    public Long getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Long facultyId) {
        this.facultyId = facultyId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public List<ComponentRequestItemDto> getRequestItems() {
        return requestItems;
    }

    public void setRequestItems(
            List<ComponentRequestItemDto> requestItems) {
        this.requestItems = requestItems;
    }
}