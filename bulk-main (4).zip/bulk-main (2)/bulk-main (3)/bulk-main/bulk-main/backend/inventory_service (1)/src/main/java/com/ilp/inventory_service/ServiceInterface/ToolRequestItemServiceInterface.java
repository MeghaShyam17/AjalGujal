package com.ilp.inventory_service.ServiceInterface;



import java.util.List;

import com.ilp.inventory_service.Dto.ToolRequestItemDto;
import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
import com.ilp.inventory_service.Dto.ToolRequestItemApprovalDto;
import com.ilp.inventory_service.Dto.ToolRequestItemRejectionDto;

public interface ToolRequestItemServiceInterface {

    ToolRequestItemResponseDto create(
            ToolRequestItemDto dto);

    ToolRequestItemResponseDto getById(
            Long id);

    List<ToolRequestItemResponseDto> getAll();

    List<ToolRequestItemResponseDto> getByToolRequestId(
            Long toolRequestId);

    ToolRequestItemResponseDto approveItem(
            Long itemId,
            Integer approvedQuantity);

    ToolRequestItemResponseDto rejectItem(
            Long itemId);

    ToolRequestItemResponseDto approveItemPayload(
            ToolRequestItemApprovalDto dto);

    ToolRequestItemResponseDto rejectItemPayload(
            ToolRequestItemRejectionDto dto);

    ToolRequestItemResponseDto issueItem(
            Long itemId,
            Integer issuedQuantity);

    void delete(Long id);
}
