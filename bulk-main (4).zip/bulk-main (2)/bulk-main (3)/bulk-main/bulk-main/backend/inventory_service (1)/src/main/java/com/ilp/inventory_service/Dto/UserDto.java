package com.ilp.inventory_service.Dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDto {

    private Long userId;

    // user-service returns "name" field, not "userName"
    @JsonProperty("name")
    private String userName;

    private String email;

    // role in user-service is a nested RoleEntity object, not a String.
    // We must ignore it to avoid Jackson deserialization failure.
    @JsonIgnore
    private String role;

    // user-service uses "phone" instead of "mobileNumber"
    @JsonProperty("phone")
    private String mobileNumber;

    // Default Constructor
    public UserDto() {
    }

    // Parameterized Constructor
    public UserDto(Long userId, String userName, String email,
                   String role, String mobileNumber) {
        this.userId = userId;
        this.userName = userName;
        this.email = email;
        this.role = role;
        this.mobileNumber = mobileNumber;
    }

    // Getters and Setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    @Override
    public String toString() {
        return "UserDto{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", mobileNumber='" + mobileNumber + '\'' +
                '}';
    }
}