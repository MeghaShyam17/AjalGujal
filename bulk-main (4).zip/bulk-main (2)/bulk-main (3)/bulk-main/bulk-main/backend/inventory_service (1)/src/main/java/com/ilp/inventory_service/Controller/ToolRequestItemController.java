package com.ilp.inventory_service.Controller;



import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ToolRequestItemDto;
import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
import com.ilp.inventory_service.Dto.ToolRequestItemApprovalDto;
import com.ilp.inventory_service.Dto.ToolRequestItemRejectionDto;
import com.ilp.inventory_service.ServiceInterface.ToolRequestItemServiceInterface;

import java.util.List;

@RestController
@RequestMapping("/api/tool-request-items")

@RequiredArgsConstructor
public class ToolRequestItemController {
@Autowired
    private  ToolRequestItemServiceInterface toolRequestItemService ;

    @PostMapping
    public ToolRequestItemResponseDto create(
            @RequestBody ToolRequestItemDto dto) {

        return toolRequestItemService.create(dto);
    }

    @PostMapping("/approve")
    public ToolRequestItemResponseDto approveItemPayload(
            @RequestBody ToolRequestItemApprovalDto dto) {

        return toolRequestItemService.approveItemPayload(dto);
    }

    @PostMapping("/reject")
    public ToolRequestItemResponseDto rejectItemPayload(
            @RequestBody ToolRequestItemRejectionDto dto) {

        return toolRequestItemService.rejectItemPayload(dto);
    }

    @GetMapping("/{id}")
    public ToolRequestItemResponseDto getById(
            @PathVariable Long id) {

        return toolRequestItemService.getById(id);
    }

    @GetMapping
    public List<ToolRequestItemResponseDto> getAll() {

        return toolRequestItemService.getAll();
    }

    @GetMapping("/toolRequest/{toolRequestId}")
    public List<ToolRequestItemResponseDto> getByToolRequestId(
            @PathVariable Long toolRequestId) {

        return toolRequestItemService
            .getByToolRequestId(toolRequestId);
    }

    @PutMapping("/{itemId}/approve")
    public ToolRequestItemResponseDto approveItem(
            @PathVariable Long itemId,
            @RequestParam Integer approvedQuantity) {

        return toolRequestItemService
                .approveItem(itemId, approvedQuantity);
    }

    @PutMapping("/{itemId}/reject")
    public ToolRequestItemResponseDto rejectItem(
            @PathVariable Long itemId) {

        return toolRequestItemService
                .rejectItem(itemId);
    }

    @PutMapping("/{itemId}/issue")
    public ToolRequestItemResponseDto issueItem(
            @PathVariable Long itemId,
            @RequestParam Integer issuedQuantity) {

        return toolRequestItemService
                .issueItem(itemId, issuedQuantity);
    }

    @DeleteMapping("/{id}")
    public void delete(
            @PathVariable Long id) {

        toolRequestItemService.delete(id);
    }
}