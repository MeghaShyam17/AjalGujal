package com.ilp.inventory_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ilp.inventory_service.Entity.DamageReportEntity;

import java.util.List;

public interface DamageReportRepository
        extends JpaRepository<DamageReportEntity, Long> {

    List<DamageReportEntity> findByTicketStatus(String ticketStatus);

    List<DamageReportEntity> findByPriority(String priority);

    List<DamageReportEntity> findByDamageType(String damageType);

}
