package com.ilp.inventory_service.Dto;

import java.sql.Date;
import java.sql.Timestamp;

import com.ilp.inventory_service.ToolEnums.ApprovalStatus;

public class ToolRequestResponseDto {

    private Long toolRequestId;

    private Long projectId;

    private Long requestedBy;

    private Timestamp requestDate;

    private Date expectedReturnDate;

    private ApprovalStatus approvalStatus;

    private Long approvedBy;

    private Timestamp approvedOn;

    private Long issuedBy;

    private Timestamp issuedOn;

    private String remarks;

    private UserDto user;

    private ProjectTeamDto project;

    public Long getToolRequestId() {
        return toolRequestId;
    }

    public void setToolRequestId(Long toolRequestId) {
        this.toolRequestId = toolRequestId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(Long requestedBy) {
        this.requestedBy = requestedBy;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public Date getExpectedReturnDate() {
        return expectedReturnDate;
    }

    public void setExpectedReturnDate(Date expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    public ApprovalStatus getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(
            ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Long getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Long approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Timestamp getApprovedOn() {
        return approvedOn;
    }

    public void setApprovedOn(Timestamp approvedOn) {
        this.approvedOn = approvedOn;
    }

    public Long getIssuedBy() {
        return issuedBy;
    }

    public void setIssuedBy(Long issuedBy) {
        this.issuedBy = issuedBy;
    }

    public Timestamp getIssuedOn() {
        return issuedOn;
    }

    public void setIssuedOn(Timestamp issuedOn) {
        this.issuedOn = issuedOn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public ProjectTeamDto getProject() {
        return project;
    }

    public void setProject(ProjectTeamDto project) {
        this.project = project;
    }

    private java.util.List<ToolRequestItemResponseDto> items;

    public java.util.List<ToolRequestItemResponseDto> getItems() {
        return items;
    }

    public void setItems(java.util.List<ToolRequestItemResponseDto> items) {
        this.items = items;
    }

    private String projectName;
    private Long teamLeaderId;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Long getTeamLeaderId() {
        return teamLeaderId;
    }

    public void setTeamLeaderId(Long teamLeaderId) {
        this.teamLeaderId = teamLeaderId;
    }
}