package com.ilp.inventory_service.Dto;

import com.ilp.inventory_service.ToolEnums.ItemStatus;

public class ToolRequestItemResponseDto {

    private Long toolRequestItemId;

    private Long toolRequestId;

    private Long itemId;

    private String itemName;

    private Integer requestedQuantity;

    private Integer approvedQuantity;

    private Integer issuedQuantity;

    private ItemStatus itemStatus;

    private UserDto user;

    private ProjectTeamDto project;

    public Long getToolRequestItemId() {
        return toolRequestItemId;
    }

    public void setToolRequestItemId(Long toolRequestItemId) {
        this.toolRequestItemId = toolRequestItemId;
    }

    public Long getToolRequestId() {
        return toolRequestId;
    }

    public void setToolRequestId(Long toolRequestId) {
        this.toolRequestId = toolRequestId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getRequestedQuantity() {
        return requestedQuantity;
    }

    public void setRequestedQuantity(Integer requestedQuantity) {
        this.requestedQuantity = requestedQuantity;
    }

    public Integer getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(Integer approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public ItemStatus getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(ItemStatus itemStatus) {
        this.itemStatus = itemStatus;
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public ProjectTeamDto getProject() {
        return project;
    }

    public void setProject(ProjectTeamDto project) {
        this.project = project;
    }
}