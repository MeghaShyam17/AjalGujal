package com.ilp.inventory_service.ServiceInterface;

import java.util.List;

import com.ilp.inventory_service.Entity.DamageReportEntity;

public interface DamageReportServiceInterface {

    DamageReportEntity saveDamageReport(
            DamageReportEntity damageReport);

    DamageReportEntity getDamageReportById(
            Long damageId);

    List<DamageReportEntity> getAllDamageReports();

    List<DamageReportEntity> getDamageReportsByTicketStatus(
            String ticketStatus);

    List<DamageReportEntity> getDamageReportsByPriority(
            String priority);

    List<DamageReportEntity> getDamageReportsByDamageType(
            String damageType);

    DamageReportEntity updateDamageReport(
            DamageReportEntity damageReport);

    void deleteDamageReport(
            Long damageId);
}