package com.ilp.inventory_service.Entity;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "component_request")
public class ComponentRequestEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "component_request_id")
    private Long componentRequestId;

    @Column(name = "project_id")
    private Long projectId;

    @Column(name = "requested_by")
    private Long requestedBy;

    @Column(name = "faculty_id")
    private Long facultyId;

    @Column(name = "request_date")
    private Timestamp requestDate;

    @Column(name = "approval_status")
    private String approvalStatus;

    @Column(name = "approved_by")
    private Long approvedBy;

    @Column(name = "approved_on")
    private Timestamp approvedOn;

    @Column(name = "issued_by")
    private Long issuedBy;

    @Column(name = "issued_on")
    private Timestamp issuedOn;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @OneToMany(
            mappedBy = "componentRequest",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private List<ComponentRequestItemEntity> requestItems;

    public ComponentRequestEntity() {
    }

    public ComponentRequestEntity(
            Long componentRequestId,
            Long projectId,
            Long requestedBy,
            Long facultyId,
            Timestamp requestDate,
            String approvalStatus,
            Long approvedBy,
            Timestamp approvedOn,
            Long issuedBy,
            Timestamp issuedOn,
            String remarks,
            Timestamp createdAt,
            List<ComponentRequestItemEntity> requestItems) {

        this.componentRequestId = componentRequestId;
        this.projectId = projectId;
        this.requestedBy = requestedBy;
        this.facultyId = facultyId;
        this.requestDate = requestDate;
        this.approvalStatus = approvalStatus;
        this.approvedBy = approvedBy;
        this.approvedOn = approvedOn;
        this.issuedBy = issuedBy;
        this.issuedOn = issuedOn;
        this.remarks = remarks;
        this.createdAt = createdAt;
        this.requestItems = requestItems;
    }

    public Long getComponentRequestId() {
        return componentRequestId;
    }

    public void setComponentRequestId(Long componentRequestId) {
        this.componentRequestId = componentRequestId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(Long requestedBy) {
        this.requestedBy = requestedBy;
    }

    public Long getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Long facultyId) {
        this.facultyId = facultyId;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Long getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Long approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Timestamp getApprovedOn() {
        return approvedOn;
    }

    public void setApprovedOn(Timestamp approvedOn) {
        this.approvedOn = approvedOn;
    }

    public Long getIssuedBy() {
        return issuedBy;
    }

    public void setIssuedBy(Long issuedBy) {
        this.issuedBy = issuedBy;
    }

    public Timestamp getIssuedOn() {
        return issuedOn;
    }

    public void setIssuedOn(Timestamp issuedOn) {
        this.issuedOn = issuedOn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public List<ComponentRequestItemEntity> getRequestItems() {
        return requestItems;
    }

    public void setRequestItems(List<ComponentRequestItemEntity> requestItems) {
        this.requestItems = requestItems;
    }
}
