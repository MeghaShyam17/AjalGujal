package ServiceImplementationJunitTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;

import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Exception.InventoryException;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.ServiceImplementation.InventoryServiceImplementation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class InventoryServiceImplementationJunitTest {

    @Mock
    private InventoryRepository inventoryRepository;

    @InjectMocks
    private InventoryServiceImplementation inventoryService;

    private InventoryEntity inventory;

    @BeforeEach
    void setUp() {

        inventory = new InventoryEntity();

        inventory.setItemId(1L);
        inventory.setItemCode("ITM001");
        inventory.setItemName("Mouse");
        inventory.setAvailableQuantity(10);
        inventory.setIsDeleted(false);
    }

    // ==================================================
    // saveInventoryItem()
    // ==================================================

    @Test
    void saveInventoryItemPositiveTestCase() {

        when(inventoryRepository.save(any()))
                .thenReturn(inventory);

        InventoryEntity result =
                inventoryService.saveInventoryItem(inventory);

        assertNotNull(result);
        assertEquals("ITM001", result.getItemCode());
    }

    @Test
    void saveInventoryItemNegativeTestCase() {

        assertThrows(
                InventoryException.class,
                () -> inventoryService.saveInventoryItem(null));
    }

    @Test
    void saveInventoryItemEdgeTestCase() {

        inventory.setAvailableQuantity(0);

        when(inventoryRepository.save(any()))
                .thenReturn(inventory);

        InventoryEntity result =
                inventoryService.saveInventoryItem(inventory);

        assertEquals(0,
                result.getAvailableQuantity());
    }

    // ==================================================
    // getInventoryById()
    // ==================================================

    @Test
    void getInventoryByIdPositiveTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        InventoryEntity result =
                inventoryService.getInventoryById(1L);

        assertNotNull(result);
    }

    @Test
    void getInventoryByIdNegativeTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(null);

        assertThrows(
                InventoryException.class,
                () -> inventoryService.getInventoryById(1L));
    }

    @Test
    void getInventoryByIdEdgeTestCase() {

        inventory.setIsDeleted(true);

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        assertThrows(
                InventoryException.class,
                () -> inventoryService.getInventoryById(1L));
    }

    // ==================================================
    // getInventoryByCode()
    // ==================================================

    @Test
    void getInventoryByCodePositiveTestCase() {

        when(inventoryRepository.findByItemCode("ITM001"))
                .thenReturn(inventory);

        InventoryEntity result =
                inventoryService.getInventoryByCode("ITM001");

        assertEquals("ITM001",
                result.getItemCode());
    }

    @Test
    void getInventoryByCodeNegativeTestCase() {

        when(inventoryRepository.findByItemCode("ABC"))
                .thenReturn(null);

        assertThrows(
                InventoryException.class,
                () -> inventoryService.getInventoryByCode("ABC"));
    }

    @Test
    void getInventoryByCodeEdgeTestCase() {

        when(inventoryRepository.findByItemCode(""))
                .thenReturn(null);

        assertThrows(
                InventoryException.class,
                () -> inventoryService.getInventoryByCode(""));
    }

    // ==================================================
    // getAllInventoryItems()
    // ==================================================

    @Test
    void getAllInventoryItemsPositiveTestCase() {

        when(inventoryRepository.findByIsDeletedFalse())
                .thenReturn(Arrays.asList(inventory));

        assertEquals(
                1,
                inventoryService.getAllInventoryItems().size());
    }

    @Test
    void getAllInventoryItemsNegativeTestCase() {

        when(inventoryRepository.findByIsDeletedFalse())
                .thenReturn(Collections.emptyList());

        assertThrows(
                InventoryException.class,
                () -> inventoryService.getAllInventoryItems());
    }

    @Test
    void getAllInventoryItemsEdgeTestCase() {

        when(inventoryRepository.findByIsDeletedFalse())
                .thenReturn(Collections.singletonList(inventory));

        assertEquals(
                1,
                inventoryService.getAllInventoryItems().size());
    }

    // ==================================================
    // checkAvailableStock()
    // ==================================================

    @Test
    void checkAvailableStockPositiveTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        InventoryEntity result =
                inventoryService.checkAvailableStock(1L, 5);

        assertNotNull(result);
    }

    @Test
    void checkAvailableStockNegativeTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        assertThrows(
                InventoryException.class,
                () -> inventoryService.checkAvailableStock(1L, 100));
    }

    @Test
    void checkAvailableStockEdgeTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        InventoryEntity result =
                inventoryService.checkAvailableStock(1L, 10);

        assertNotNull(result);
    }

    // ==================================================
    // countLowStockItems()
    // ==================================================

    @Test
    void countLowStockItemsPositiveTestCase() {

        when(inventoryRepository.countLowStockItems())
                .thenReturn(5L);

        assertEquals(
                5,
                inventoryService.countLowStockItems());
    }

    @Test
    void countLowStockItemsNegativeTestCase() {

        when(inventoryRepository.countLowStockItems())
                .thenReturn(0L);

        assertEquals(
                0,
                inventoryService.countLowStockItems());
    }

    @Test
    void countLowStockItemsEdgeTestCase() {

        when(inventoryRepository.countLowStockItems())
                .thenReturn(Long.MAX_VALUE);

        assertEquals(
                Long.MAX_VALUE,
                inventoryService.countLowStockItems());
    }

    // ==================================================
    // getTotalAvailableStock()
    // ==================================================

    @Test
    void getTotalAvailableStockPositiveTestCase() {

        when(inventoryRepository.getTotalAvailableStock())
                .thenReturn(500L);

        assertEquals(
                500L,
                inventoryService.getTotalAvailableStock());
    }

    @Test
    void getTotalAvailableStockNegativeTestCase() {

        when(inventoryRepository.getTotalAvailableStock())
                .thenReturn(null);

        assertEquals(
                0L,
                inventoryService.getTotalAvailableStock());
    }

    @Test
    void getTotalAvailableStockEdgeTestCase() {

        when(inventoryRepository.getTotalAvailableStock())
                .thenReturn(1L);

        assertEquals(
                1L,
                inventoryService.getTotalAvailableStock());
    }

    // ==================================================
    // deleteInventoryItem()
    // ==================================================

    @Test
    void deleteInventoryItemPositiveTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        inventoryService.deleteInventoryItem(1L);

        verify(inventoryRepository)
                .save(any(InventoryEntity.class));
    }

    @Test
    void deleteInventoryItemNegativeTestCase() {

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(null);

        assertThrows(
                InventoryException.class,
                () -> inventoryService.deleteInventoryItem(1L));
    }

    @Test
    void deleteInventoryItemEdgeTestCase() {

        inventory.setIsDeleted(true);

        when(inventoryRepository.findByItemId(1L))
                .thenReturn(inventory);

        inventoryService.deleteInventoryItem(1L);

        verify(inventoryRepository)
                .save(any(InventoryEntity.class));
    }
}