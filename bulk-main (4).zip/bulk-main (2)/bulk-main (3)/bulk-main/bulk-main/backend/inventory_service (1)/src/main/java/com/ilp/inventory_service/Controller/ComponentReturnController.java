package com.ilp.inventory_service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ComponentReturnDto;
import com.ilp.inventory_service.Dto.ComponentReturnResponseDto;
import com.ilp.inventory_service.ServiceInterface.ComponentReturnServiceInterface;

@RestController
@RequestMapping("/api/component-return")

public class ComponentReturnController {

    @Autowired
    private ComponentReturnServiceInterface componentReturnService;

    @PostMapping
    public ComponentReturnResponseDto createComponentReturn(
            @RequestBody ComponentReturnDto dto) {

        return componentReturnService
                .createComponentReturn(dto);
    }

    @GetMapping("/{componentReturnId}")
    public ComponentReturnResponseDto getById(
            @PathVariable Long componentReturnId) {

        return componentReturnService
                .getById(componentReturnId);
    }

    @GetMapping
    public List<ComponentReturnResponseDto> getReturns(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) Long returnedBy,
            @RequestParam(required = false) Long receivedBy,
            @RequestParam(required = false) Long componentRequestId,
            @RequestParam(required = false) String status) {

        return componentReturnService
                .getReturns(projectId, returnedBy, receivedBy, componentRequestId, status);
    }


    @PutMapping("/{componentReturnId}/receive/{receivedBy}")
    public ComponentReturnResponseDto receiveReturn(
            @PathVariable Long componentReturnId,
            @PathVariable Long receivedBy) {

        return componentReturnService
                .receiveReturn(
                        componentReturnId,
                        receivedBy);
    }

    @DeleteMapping("/{componentReturnId}")
    public void delete(
            @PathVariable Long componentReturnId) {

        componentReturnService.delete(
                componentReturnId);
    }
}
