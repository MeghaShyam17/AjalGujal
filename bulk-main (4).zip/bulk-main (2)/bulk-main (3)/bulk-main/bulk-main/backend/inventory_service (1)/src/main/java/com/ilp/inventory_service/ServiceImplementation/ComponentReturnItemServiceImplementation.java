package com.ilp.inventory_service.ServiceImplementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.Client.NotificationFeignClient;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ComponentReturnItemResponseDto;
import com.ilp.inventory_service.Entity.ComponentReturnItemEntity;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.ComponentReturnItemRepository;
import com.ilp.inventory_service.ServiceInterface.ComponentReturnItemServiceInterface;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComponentReturnItemServiceImplementation
        implements ComponentReturnItemServiceInterface {

    @Autowired
    private ComponentReturnItemRepository componentReturnItemRepository;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private NotificationFeignClient notificationFeignClient;

    @Override
    public ComponentReturnItemResponseDto getById(Long returnItemId) {
        ComponentReturnItemEntity entity = findEntityById(returnItemId);
        return mapToResponse(entity);
    }

    @Override
    public List<ComponentReturnItemResponseDto> getReturnItems(
            Long componentReturnId,
            Long itemId,
            String condition) {

        if (componentReturnId != null) {
            return getByComponentReturnId(componentReturnId);
        }
        if (itemId != null) {
            return getByItemId(itemId);
        }
        if (condition != null && !condition.trim().isEmpty()) {
            return getByCondition(condition);
        }
        return getAll();
    }

    @Override
    public List<ComponentReturnItemResponseDto> getAll() {
        return componentReturnItemRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnItemResponseDto> getByComponentReturnId(Long componentReturnId) {
        return componentReturnItemRepository.getReturnItems(componentReturnId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnItemResponseDto> getByItemId(Long itemId) {
        return componentReturnItemRepository.findByInventoryItemId(itemId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnItemResponseDto> getByCondition(String condition) {
        return componentReturnItemRepository.findByCondition(condition)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnItemResponseDto> getDamagedItems() {
        return componentReturnItemRepository.getDamagedItems()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnItemResponseDto> getConsumedItems() {
        return componentReturnItemRepository.getConsumedItems()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentReturnItemResponseDto> getInventoryReturnHistory(Long itemId) {
        return componentReturnItemRepository.getInventoryReturnHistory(itemId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private ComponentReturnItemEntity findEntityById(Long returnItemId) {
        return componentReturnItemRepository.findById(returnItemId)
                .orElseThrow(() -> new ToolResourceNotFoundException("Component Return Item Not Found"));
    }

    private ComponentReturnItemResponseDto mapToResponse(ComponentReturnItemEntity entity) {
        ComponentReturnItemResponseDto dto = new ComponentReturnItemResponseDto();

        dto.setReturnItemId(entity.getReturnItemId());
        if (entity.getInventory() != null) {
            dto.setItemId(entity.getInventory().getItemId());
        }

        dto.setIssuedQuantity(entity.getIssuedQuantity());
        dto.setReturnedQuantity(entity.getReturnedQuantity());
        dto.setConsumedQuantity(entity.getConsumedQuantity());
        dto.setDamagedQuantity(entity.getDamagedQuantity());
        dto.setCondition(entity.getCondition());
        dto.setRemarks(entity.getRemarks());

        return dto;
    }
}
