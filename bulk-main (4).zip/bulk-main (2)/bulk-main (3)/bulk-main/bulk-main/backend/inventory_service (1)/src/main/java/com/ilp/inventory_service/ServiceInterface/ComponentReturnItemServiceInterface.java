package com.ilp.inventory_service.ServiceInterface;

import com.ilp.inventory_service.Dto.ComponentReturnItemResponseDto;

import java.util.List;

public interface ComponentReturnItemServiceInterface {

    ComponentReturnItemResponseDto getById(
            Long returnItemId);

    List<ComponentReturnItemResponseDto> getReturnItems(
            Long componentReturnId,
            Long itemId,
            String condition);

    List<ComponentReturnItemResponseDto> getAll();

    List<ComponentReturnItemResponseDto> getByComponentReturnId(
            Long componentReturnId);

    List<ComponentReturnItemResponseDto> getByItemId(
            Long itemId);

    List<ComponentReturnItemResponseDto> getByCondition(
            String condition);

    List<ComponentReturnItemResponseDto> getDamagedItems();

    List<ComponentReturnItemResponseDto> getConsumedItems();

    List<ComponentReturnItemResponseDto> getInventoryReturnHistory(
            Long itemId);
}
