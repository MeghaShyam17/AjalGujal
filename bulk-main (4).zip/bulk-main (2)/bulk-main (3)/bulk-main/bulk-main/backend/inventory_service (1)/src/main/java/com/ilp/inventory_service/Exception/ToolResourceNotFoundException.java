package com.ilp.inventory_service.Exception;





public class ToolResourceNotFoundException
        extends RuntimeException {

    public ToolResourceNotFoundException(
            String message) {

        super(message);
    }
}