package ServiceImplementationJunitTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.ilp.inventory_service.Dto.IssueQuantityDto;
import com.ilp.inventory_service.Dto.ToolRequestDto;
import com.ilp.inventory_service.Dto.ToolRequestResponseDto;
import com.ilp.inventory_service.Entity.ToolRequestEntity;
import com.ilp.inventory_service.Exception.ToolBadRequestException;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.ToolRequestRepository;
import com.ilp.inventory_service.ServiceImplementation.ToolRequestServiceImplementation;
import com.ilp.inventory_service.ToolEnums.ApprovalStatus;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ToolRequestServiceImplementationJunitTest {

    @Mock
    private ToolRequestRepository repository;

    @InjectMocks
    private ToolRequestServiceImplementation service;

    private ToolRequestDto dto;
    private ToolRequestEntity entity;
    private List<IssueQuantityDto> issueQuantities;

    @BeforeEach
    void setUp() {
        dto = new ToolRequestDto();
        dto.setProjectId(100L);
        dto.setRequestedBy(1L);
        dto.setExpectedReturnDate(Date.valueOf("2030-01-01"));
        dto.setRemarks("Test Request");

        entity = new ToolRequestEntity();
        entity.setToolRequestId(1L);
        entity.setProjectId(100L);
        entity.setRequestedBy(1L);
        entity.setExpectedReturnDate(Date.valueOf("2030-01-01"));
        entity.setApprovalStatus(ApprovalStatus.PENDING);
        entity.setRequestDate(new Timestamp(System.currentTimeMillis()));

        issueQuantities = Collections.emptyList();
    }

    @Test
    void createToolRequest_Success() {
        when(repository.findByProjectIdAndApprovalStatus(
                100L,
                ApprovalStatus.PENDING))
                .thenReturn(Collections.emptyList());

        when(repository.save(any(ToolRequestEntity.class)))
                .thenReturn(entity);

        ToolRequestResponseDto response =
                service.createToolRequest(dto);

        assertNotNull(response);
        assertEquals(100L, response.getProjectId());

        verify(repository).save(any(ToolRequestEntity.class));
    }

    @Test
    void createToolRequest_NullReturnDate() {
        dto.setExpectedReturnDate(null);

        assertThrows(
                ToolBadRequestException.class,
                () -> service.createToolRequest(dto));
    }

    @Test
    void createToolRequest_PastDate() {
        dto.setExpectedReturnDate(Date.valueOf("2020-01-01"));

        assertThrows(
                ToolBadRequestException.class,
                () -> service.createToolRequest(dto));
    }

    @Test
    void createToolRequest_PendingRequestExists() {
        when(repository.findByProjectIdAndApprovalStatus(
                100L,
                ApprovalStatus.PENDING))
                .thenReturn(List.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.createToolRequest(dto));
    }

    @Test
    void getById_Success() {
        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        ToolRequestResponseDto response =
                service.getById(1L);

        assertNotNull(response);
        assertEquals(1L, response.getToolRequestId());
    }

    @Test
    void getById_NotFound() {
        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.getById(1L));
    }

    @Test
    void getAll_Success() {
        when(repository.findAll())
                .thenReturn(List.of(entity));

        List<ToolRequestResponseDto> list =
                service.getAll();

        assertNotNull(list);
        assertEquals(1, list.size());
    }

    @Test
    void getAll_EmptyList() {
        when(repository.findAll())
                .thenReturn(Collections.emptyList());

        List<ToolRequestResponseDto> list =
                service.getAll();

        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void approveRequest_Success() {
        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        when(repository.save(any(ToolRequestEntity.class)))
                .thenReturn(entity);

        ToolRequestResponseDto response =
                service.approveRequest(1L, 10L);

        assertNotNull(response);

        verify(repository).save(any(ToolRequestEntity.class));
    }

    @Test
    void approveRequest_NotFound() {
        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.approveRequest(1L, 10L));
    }

    @Test
    void approveRequest_AlreadyProcessed() {
        entity.setApprovalStatus(ApprovalStatus.APPROVED);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.approveRequest(1L, 10L));
    }

    @Test
    void rejectRequest_Success() {
        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        when(repository.save(any(ToolRequestEntity.class)))
                .thenReturn(entity);

        ToolRequestResponseDto response =
                service.rejectRequest(1L, 10L);

        assertNotNull(response);

        verify(repository).save(any(ToolRequestEntity.class));
    }

    @Test
    void rejectRequest_NonPendingRequest() {
        entity.setApprovalStatus(ApprovalStatus.APPROVED);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.rejectRequest(1L, 10L));
    }

    @Test
    void issueRequest_Success() {
        entity.setApprovalStatus(ApprovalStatus.APPROVED);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        when(repository.save(any(ToolRequestEntity.class)))
                .thenReturn(entity);

        ToolRequestResponseDto response =
                service.issueRequest(
                        1L,
                        20L,
                        issueQuantities);

        assertNotNull(response);

        verify(repository).save(any(ToolRequestEntity.class));
    }

    @Test
    void issueRequest_NotApproved() {
        entity.setApprovalStatus(ApprovalStatus.PENDING);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.issueRequest(
                        1L,
                        20L,
                        issueQuantities));
    }

    @Test
    void issueRequest_AlreadyIssued() {
        entity.setApprovalStatus(ApprovalStatus.APPROVED);
        entity.setIssuedOn(new Timestamp(System.currentTimeMillis()));

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.issueRequest(
                        1L,
                        20L,
                        issueQuantities));
    }

    @Test
    void delete_Success() {
        entity.setApprovalStatus(ApprovalStatus.REJECTED);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(repository).delete(entity);
    }

    @Test
    void delete_ApprovedRequest() {
        entity.setApprovalStatus(ApprovalStatus.APPROVED);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.delete(1L));

        verify(repository, never())
                .delete(any(ToolRequestEntity.class));
    }

    @Test
    void delete_IssuedRequest() {
        entity.setApprovalStatus(ApprovalStatus.ISSUED);

        when(repository.findById(1L))
                .thenReturn(Optional.of(entity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.delete(1L));

        verify(repository, never())
                .delete(any(ToolRequestEntity.class));
    }

    @Test
    void getPendingRequests_Success() {
        when(repository.findByApprovalStatus(ApprovalStatus.PENDING))
                .thenReturn(List.of(entity));

        List<ToolRequestResponseDto> result =
                service.getPendingRequests();

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void getApprovedRequests_Success() {
        entity.setApprovalStatus(ApprovalStatus.APPROVED);

        when(repository.findByApprovalStatus(ApprovalStatus.APPROVED))
                .thenReturn(List.of(entity));

        List<ToolRequestResponseDto> result =
                service.getApprovedRequests();

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void getDueRequests_Success() {
        entity.setApprovalStatus(ApprovalStatus.ISSUED);
        entity.setExpectedReturnDate(Date.valueOf("2020-01-01"));

        when(repository.findAll())
                .thenReturn(Arrays.asList(entity));

        List<ToolRequestResponseDto> result =
                service.getDueRequests();

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void getDueRequests_NoDueRequests() {
        entity.setApprovalStatus(ApprovalStatus.ISSUED);
        entity.setExpectedReturnDate(Date.valueOf("2035-01-01"));

        when(repository.findAll())
                .thenReturn(List.of(entity));

        List<ToolRequestResponseDto> result =
                service.getDueRequests();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}