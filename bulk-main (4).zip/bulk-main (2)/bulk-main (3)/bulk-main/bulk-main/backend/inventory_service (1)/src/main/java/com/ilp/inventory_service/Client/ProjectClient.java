package com.ilp.inventory_service.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ilp.inventory_service.Dto.ProjectTeamDto;

@FeignClient(
        name = "project-service",
        url = "http://localhost:8081"
)
public interface ProjectClient {

    @GetMapping("/api/projects/{projectId}")
    ProjectTeamDto getProjectById(
            @PathVariable("projectId") Integer projectId);
}