package com.ilp.inventory_service.Dto;

public class ToolRequestItemRejectionDto {
    private Long toolRequestItemId;

    public ToolRequestItemRejectionDto() {
    }

    public ToolRequestItemRejectionDto(Long toolRequestItemId) {
        this.toolRequestItemId = toolRequestItemId;
    }

    public Long getToolRequestItemId() {
        return toolRequestItemId;
    }

    public void setToolRequestItemId(Long toolRequestItemId) {
        this.toolRequestItemId = toolRequestItemId;
    }
}
