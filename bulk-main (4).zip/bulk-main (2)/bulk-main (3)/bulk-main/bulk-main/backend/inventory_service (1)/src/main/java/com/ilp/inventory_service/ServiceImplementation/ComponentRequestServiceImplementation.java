package com.ilp.inventory_service.ServiceImplementation;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.ToolEnums;
import com.ilp.inventory_service.Client.NotificationFeignClient;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ComponentRequestDto;
import com.ilp.inventory_service.Dto.ComponentRequestItemResponseDto;
import com.ilp.inventory_service.Dto.ComponentRequestResponseDto;
import com.ilp.inventory_service.Dto.NotificationRequestDto;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Dto.UserServiceResponseDto;
import com.ilp.inventory_service.Dto.IssueQuantityDto;
import com.ilp.inventory_service.Entity.ComponentRequestEntity;
import com.ilp.inventory_service.Entity.ComponentRequestItemEntity;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.ComponentRequestRepository;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.ServiceInterface.ComponentRequestServiceInterface;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComponentRequestServiceImplementation
        implements ComponentRequestServiceInterface {

    @Autowired
    private ComponentRequestRepository componentRequestRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private NotificationFeignClient notificationFeignClient;

    @Override
    public ComponentRequestResponseDto createComponentRequest(
            ComponentRequestDto dto) {

        ProjectTeamDto project = validateProject(dto.getProjectId());
        UserDto requestedUser = validateUser(dto.getRequestedBy(), "Requested User Not Found");
        UserDto facultyUser = validateUser(dto.getFacultyId(), "Faculty User Not Found");

        if (dto.getRequestItems() == null || dto.getRequestItems().isEmpty()) {
            throw new ToolBusinessException("At least one component request item is required");
        }

        ComponentRequestEntity entity = new ComponentRequestEntity();
        entity.setProjectId(dto.getProjectId());
        entity.setRequestedBy(dto.getRequestedBy());
        entity.setFacultyId(dto.getFacultyId());
        entity.setRemarks(dto.getRemarks());
        entity.setRequestDate(new Timestamp(System.currentTimeMillis()));
        entity.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        entity.setApprovalStatus(ToolEnums.ApprovalStatus.PENDING.name());

        List<ComponentRequestItemEntity> items = dto.getRequestItems()
                .stream()
                .map(itemDto -> {
                    InventoryEntity inventory = inventoryRepository
                            .findById(itemDto.getItemId())
                            .orElseThrow(() -> new ToolResourceNotFoundException("Inventory Item Not Found"));

                    if (itemDto.getRequestedQuantity() <= 0) {
                        throw new ToolBusinessException("Requested quantity must be greater than zero");
                    }

                    ComponentRequestItemEntity item = new ComponentRequestItemEntity();
                    item.setComponentRequest(entity);
                    item.setInventory(inventory);
                    item.setRequestedQuantity(itemDto.getRequestedQuantity());
                    item.setApprovedQuantity(0);
                    item.setIssuedQuantity(0);
                    item.setItemStatus(ToolEnums.ItemStatus.PENDING.name());
                    item.setFacultyComments(itemDto.getFacultyComments());

                    return item;
                })
                .collect(Collectors.toList());

        entity.setRequestItems(items);

        ComponentRequestEntity saved = componentRequestRepository.save(entity);

        sendNotification(
                facultyUser.getUserId(),
                "New Component Request",
                requestedUser.getUserName() + " created a component request for project " + project.getProjectName(),
                "COMPONENT_REQUEST_CREATED",
                saved.getComponentRequestId(),
                dto.getRequestedBy()
        );

        return mapToResponse(saved);
    }

    @Override
    public ComponentRequestResponseDto getById(Long componentRequestId) {
        ComponentRequestEntity entity = findEntityById(componentRequestId);
        return mapToResponse(entity);
    }

    @Override
    public List<ComponentRequestResponseDto> getRequests(
            Long projectId,
            Long requestedBy,
            Long facultyId,
            String status) {

        if (projectId != null) {
            return getByProjectId(projectId);
        }
        if (requestedBy != null) {
            return getByRequestedBy(requestedBy);
        }
        if (facultyId != null) {
            return getByFacultyId(facultyId);
        }
        if (status != null && !status.trim().isEmpty()) {
            return componentRequestRepository.findByApprovalStatus(status.toUpperCase())
                    .stream()
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
        }
        return getAll();
    }

    @Override
    public List<ComponentRequestResponseDto> getAll() {
        return componentRequestRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestResponseDto> getByProjectId(Long projectId) {
        validateProject(projectId);
        return componentRequestRepository.findByProjectId(projectId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestResponseDto> getByRequestedBy(Long requestedBy) {
        validateUser(requestedBy, "Requested User Not Found");
        return componentRequestRepository.findByRequestedBy(requestedBy)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestResponseDto> getByFacultyId(Long facultyId) {
        validateUser(facultyId, "Faculty User Not Found");
        return componentRequestRepository.findByFacultyId(facultyId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestResponseDto> getPendingRequests() {
        return getRequests(null, null, null, ToolEnums.ApprovalStatus.PENDING.name());
    }

    @Override
    public List<ComponentRequestResponseDto> getApprovedRequests() {
        return getRequests(null, null, null, ToolEnums.ApprovalStatus.APPROVED.name());
    }

    @Override
    public List<ComponentRequestResponseDto> getRejectedRequests() {
        return getRequests(null, null, null, ToolEnums.ApprovalStatus.REJECTED.name());
    }

    @Override
    public ComponentRequestResponseDto approveRequest(
            Long componentRequestId,
            Long approvedBy) {

        ComponentRequestEntity entity = findEntityById(componentRequestId);
        validateStatus(entity, ToolEnums.ApprovalStatus.PENDING.name(), "Only pending component requests can be approved");

        UserDto approvedByUser = validateUser(approvedBy, "Approving User Not Found");
        UserDto requestedUser = validateUser(entity.getRequestedBy(), "Requested User Not Found");

        entity.setApprovalStatus(ToolEnums.ApprovalStatus.APPROVED.name());
        entity.setApprovedBy(approvedBy);
        entity.setApprovedOn(new Timestamp(System.currentTimeMillis()));

        if (entity.getRequestItems() != null) {
            for (ComponentRequestItemEntity item : entity.getRequestItems()) {
                item.setItemStatus(ToolEnums.ItemStatus.APPROVED.name());
                int approvedQty = (item.getApprovedQuantity() != null && item.getApprovedQuantity() > 0)
                        ? item.getApprovedQuantity()
                        : (item.getRequestedQuantity() == null ? 0 : item.getRequestedQuantity());
                item.setApprovedQuantity(approvedQty);
            }
        }

        ComponentRequestEntity saved = componentRequestRepository.save(entity);

        sendNotification(
                requestedUser.getUserId(),
                "Component Request Approved",
                "Your component request " + saved.getComponentRequestId() + " has been approved by " + approvedByUser.getUserName(),
                "COMPONENT_REQUEST_APPROVED",
                saved.getComponentRequestId(),
                approvedBy
        );

        return mapToResponse(saved);
    }

    @Override
    public ComponentRequestResponseDto rejectRequest(
            Long componentRequestId,
            Long approvedBy,
            String remarks) {

        ComponentRequestEntity entity = findEntityById(componentRequestId);
        validateStatus(entity, ToolEnums.ApprovalStatus.PENDING.name(), "Only pending component requests can be rejected");

        if (remarks == null || remarks.trim().isEmpty()) {
            throw new ToolBusinessException("Remarks are required when rejecting a request");
        }

        UserDto rejectedByUser = validateUser(approvedBy, "Rejecting User Not Found");
        UserDto requestedUser = validateUser(entity.getRequestedBy(), "Requested User Not Found");

        entity.setApprovalStatus(ToolEnums.ApprovalStatus.REJECTED.name());
        entity.setApprovedBy(approvedBy);
        entity.setApprovedOn(new Timestamp(System.currentTimeMillis()));
        entity.setRemarks(remarks);

        if (entity.getRequestItems() != null) {
            for (ComponentRequestItemEntity item : entity.getRequestItems()) {
                item.setItemStatus(ToolEnums.ItemStatus.REJECTED.name());
            }
        }

        ComponentRequestEntity saved = componentRequestRepository.save(entity);

        sendNotification(
                requestedUser.getUserId(),
                "Component Request Rejected",
                "Your component request " + saved.getComponentRequestId()
                        + " has been rejected by " + rejectedByUser.getUserName()
                        + ". Remarks: " + remarks,
                "COMPONENT_REQUEST_REJECTED",
                saved.getComponentRequestId(),
                approvedBy
        );

        return mapToResponse(saved);
    }

    @Override
    public ComponentRequestResponseDto issueRequest(
            Long componentRequestId,
            Long issuedBy,
            List<IssueQuantityDto> itemsToIssue) {

        ComponentRequestEntity entity = findEntityById(componentRequestId);
        if (!ToolEnums.ApprovalStatus.APPROVED.name().equalsIgnoreCase(entity.getApprovalStatus())
                && !ToolEnums.ApprovalStatus.PENDING.name().equalsIgnoreCase(entity.getApprovalStatus())
                && !ToolEnums.ApprovalStatus.PARTIALLY_APPROVED.name().equalsIgnoreCase(entity.getApprovalStatus())
                && !ToolEnums.ApprovalStatus.ISSUED.name().equalsIgnoreCase(entity.getApprovalStatus())) {
            throw new ToolBusinessException("Only pending, approved, partially approved, or already issued component requests can be issued");
        }

        boolean allAlreadyIssued = true;
        if (entity.getRequestItems() != null) {
            for (ComponentRequestItemEntity item : entity.getRequestItems()) {
                if (!ToolEnums.ItemStatus.ISSUED.name().equalsIgnoreCase(item.getItemStatus())) {
                    allAlreadyIssued = false;
                    break;
                }
            }
        }

        if (allAlreadyIssued) {
            throw new ToolBusinessException("Component request is already fully issued");
        }

        UserDto issuedByUser = validateUser(issuedBy, "Issuing User Not Found");
        UserDto requestedUser = validateUser(entity.getRequestedBy(), "Requested User Not Found");

        if (entity.getRequestItems() != null && itemsToIssue != null) {
            for (IssueQuantityDto issueDto : itemsToIssue) {
                ComponentRequestItemEntity matchedItem = null;
                for (ComponentRequestItemEntity item : entity.getRequestItems()) {
                    if (item.getInventory() != null && item.getInventory().getItemId().equals(issueDto.getItemId())) {
                        matchedItem = item;
                        break;
                    }
                }

                if (matchedItem != null) {
                    int qtyToIssue = issueDto.getQty() != null ? issueDto.getQty() : 0;
                    if (qtyToIssue <= 0) {
                        continue;
                    }

                    int currentIssued = matchedItem.getIssuedQuantity() != null ? matchedItem.getIssuedQuantity() : 0;
                    int approvedQty = (matchedItem.getApprovedQuantity() != null && matchedItem.getApprovedQuantity() > 0)
                            ? matchedItem.getApprovedQuantity()
                            : (matchedItem.getRequestedQuantity() == null ? 0 : matchedItem.getRequestedQuantity());

                    if (currentIssued + qtyToIssue > approvedQty) {
                        throw new ToolBusinessException("Issued quantity cannot exceed approved quantity for item ID: " + issueDto.getItemId());
                    }

                    InventoryEntity inventory = matchedItem.getInventory();
                    int currentAvailable = inventory.getAvailableQuantity() == null ? 0 : inventory.getAvailableQuantity();
                    if (currentAvailable < qtyToIssue) {
                        throw new ToolBusinessException("Insufficient stock for inventory item ID: " + inventory.getItemId());
                    }

                    inventory.setAvailableQuantity(currentAvailable - qtyToIssue);
                    inventoryRepository.save(inventory);

                    int newIssued = currentIssued + qtyToIssue;
                    matchedItem.setApprovedQuantity(approvedQty);
                    matchedItem.setIssuedQuantity(newIssued);

                    if (newIssued < approvedQty) {
                        matchedItem.setItemStatus(ToolEnums.ItemStatus.PARTIALLY_ISSUED.name());
                    } else {
                        matchedItem.setItemStatus(ToolEnums.ItemStatus.ISSUED.name());
                    }
                }
            }
        }

        boolean allNowIssued = true;
        if (entity.getRequestItems() != null) {
            for (ComponentRequestItemEntity item : entity.getRequestItems()) {
                int issuedQty = item.getIssuedQuantity() != null ? item.getIssuedQuantity() : 0;
                int approvedQty = item.getApprovedQuantity() != null ? item.getApprovedQuantity() : 0;
                if (issuedQty < approvedQty) {
                    allNowIssued = false;
                }
            }
        }

        if (allNowIssued) {
            entity.setApprovalStatus(ToolEnums.ApprovalStatus.ISSUED.name());
        } else {
            entity.setApprovalStatus(ToolEnums.ApprovalStatus.PARTIALLY_APPROVED.name());
        }

        entity.setIssuedBy(issuedBy);
        entity.setIssuedOn(new Timestamp(System.currentTimeMillis()));

        ComponentRequestEntity saved = componentRequestRepository.save(entity);

        sendNotification(
                requestedUser.getUserId(),
                "Component Request Issued",
                "Items for your component request " + saved.getComponentRequestId()
                        + " have been issued by " + issuedByUser.getUserName(),
                "COMPONENT_REQUEST_ISSUED",
                saved.getComponentRequestId(),
                issuedBy
        );

        return mapToResponse(saved);
    }

    @Override
    public void delete(Long componentRequestId) {
        ComponentRequestEntity entity = findEntityById(componentRequestId);
        componentRequestRepository.delete(entity);
    }

    private ComponentRequestEntity findEntityById(Long componentRequestId) {
        return componentRequestRepository.findById(componentRequestId)
                .orElseThrow(() -> new ToolResourceNotFoundException("Component Request Not Found"));
    }

    private void validateStatus(ComponentRequestEntity entity, String expectedStatus, String errorMessage) {
        if (!expectedStatus.equalsIgnoreCase(entity.getApprovalStatus())) {
            throw new ToolBusinessException(errorMessage);
        }
    }

    private ProjectTeamDto validateProject(Long projectId) {
        if (projectId == null) {
            throw new ToolBusinessException("Project ID must not be null");
        }

        ProjectTeamDto project = projectClient.getProjectById(Math.toIntExact(projectId));
        if (project == null || project.getProjectId() == null) {
            throw new ToolResourceNotFoundException("Project Not Found");
        }

        return project;
    }

    private UserDto validateUser(Long userId, String errorMessage) {
        if (userId == null) {
            throw new ToolBusinessException("User ID must not be null");
        }

        UserServiceResponseDto response = userClient.getUserResponseById(Math.toIntExact(userId));
        if (response == null || response.getUserId() == null) {
            throw new ToolResourceNotFoundException(errorMessage);
        }

        return mapToUserDto(response);
    }

    private UserDto mapToUserDto(UserServiceResponseDto response) {
        if (response == null) {
            return null;
        }

        UserDto userDto = new UserDto();
        userDto.setUserId(response.getUserId());
        userDto.setUserName(response.getName());
        userDto.setEmail(response.getEmail());
        userDto.setMobileNumber(response.getPhone());

        if (response.getRole() != null) {
            userDto.setRole(response.getRole().getRoleName());
        }

        return userDto;
    }

    private void sendNotification(
            Long recipientId,
            String title,
            String message,
            String notificationType,
            Long requestId,
            Long senderId) {

        NotificationRequestDto notification = new NotificationRequestDto(
                Math.toIntExact(recipientId),
                title,
                message,
                notificationType,
                "INVENTORY",
                Math.toIntExact(requestId),
                "HIGH",
                Math.toIntExact(senderId)
        );

        notificationFeignClient.createNotification(notification);
    }

    private ComponentRequestResponseDto mapToResponse(ComponentRequestEntity entity) {
        ComponentRequestResponseDto dto = new ComponentRequestResponseDto();

        dto.setComponentRequestId(entity.getComponentRequestId());
        dto.setProjectId(entity.getProjectId());
        dto.setRequestedBy(entity.getRequestedBy());
        dto.setFacultyId(entity.getFacultyId());
        dto.setRequestDate(entity.getRequestDate());
        dto.setApprovalStatus(entity.getApprovalStatus());
        dto.setApprovedBy(entity.getApprovedBy());
        dto.setApprovedOn(entity.getApprovedOn());
        dto.setIssuedBy(entity.getIssuedBy());
        dto.setIssuedOn(entity.getIssuedOn());
        dto.setRemarks(entity.getRemarks());
        dto.setCreatedAt(entity.getCreatedAt());

        if (entity.getRequestItems() != null) {
            List<ComponentRequestItemResponseDto> items = entity.getRequestItems()
                    .stream()
                    .map(this::mapToItemResponse)
                    .collect(Collectors.toList());

            dto.setRequestItems(items);
        }

        return dto;
    }

    private ComponentRequestItemResponseDto mapToItemResponse(ComponentRequestItemEntity item) {
        ComponentRequestItemResponseDto itemDto = new ComponentRequestItemResponseDto();

        itemDto.setRequestItemId(item.getRequestItemId());
        if (item.getInventory() != null) {
            itemDto.setItemId(item.getInventory().getItemId());
        }
        itemDto.setRequestedQuantity(item.getRequestedQuantity());
        itemDto.setApprovedQuantity(item.getApprovedQuantity());
        itemDto.setIssuedQuantity(item.getIssuedQuantity());
        itemDto.setItemStatus(item.getItemStatus());
        itemDto.setFacultyComments(item.getFacultyComments());

        return itemDto;
    }
}

