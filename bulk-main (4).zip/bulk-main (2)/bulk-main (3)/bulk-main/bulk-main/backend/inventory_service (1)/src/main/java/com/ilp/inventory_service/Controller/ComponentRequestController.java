package com.ilp.inventory_service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ComponentRequestDto;
import com.ilp.inventory_service.Dto.ComponentRequestResponseDto;
import com.ilp.inventory_service.ServiceInterface.ComponentRequestServiceInterface;

@RestController
@RequestMapping("/api/component-request")

public class ComponentRequestController {

    @Autowired
    private ComponentRequestServiceInterface componentRequestService;

    @PostMapping
    public ComponentRequestResponseDto createComponentRequest(
            @RequestBody ComponentRequestDto dto) {

        return componentRequestService
                .createComponentRequest(dto);
    }

    @GetMapping("/{componentRequestId}")
    public ComponentRequestResponseDto getById(
            @PathVariable Long componentRequestId) {

        return componentRequestService
                .getById(componentRequestId);
    }

    @GetMapping
    public List<ComponentRequestResponseDto> getRequests(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) Long requestedBy,
            @RequestParam(required = false) Long facultyId,
            @RequestParam(required = false) String status) {

        return componentRequestService
                .getRequests(projectId, requestedBy, facultyId, status);
    }


    @PutMapping("/{componentRequestId}/approve/{approvedBy}")
    public ComponentRequestResponseDto approveRequest(
            @PathVariable Long componentRequestId,
            @PathVariable Long approvedBy) {

        return componentRequestService
                .approveRequest(
                        componentRequestId,
                        approvedBy);
    }

    @PutMapping("/{componentRequestId}/reject/{approvedBy}")
    public ComponentRequestResponseDto rejectRequest(
            @PathVariable Long componentRequestId,
            @PathVariable Long approvedBy,
            @RequestParam String remarks) {

        return componentRequestService
                .rejectRequest(
                        componentRequestId,
                        approvedBy,
                        remarks);
    }

    @PutMapping("/{componentRequestId}/issue/{issuedBy}")
    public ComponentRequestResponseDto issueRequest(
            @PathVariable Long componentRequestId,
            @PathVariable Long issuedBy,
            @RequestBody List<com.ilp.inventory_service.Dto.IssueQuantityDto> itemsToIssue) {

        return componentRequestService
                .issueRequest(
                        componentRequestId,
                        issuedBy,
                        itemsToIssue);
    }

    @DeleteMapping("/{componentRequestId}")
    public void delete(
            @PathVariable Long componentRequestId) {

        componentRequestService.delete(
                componentRequestId);
    }
}


