package com.ilp.inventory_service.Repository;

import com.ilp.inventory_service.Entity.ComponentRequestItemEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ComponentRequestItemRepository
        extends JpaRepository<ComponentRequestItemEntity, Long> {

    Optional<ComponentRequestItemEntity> findByRequestItemId(Long requestItemId);

    List<ComponentRequestItemEntity>
            findByComponentRequestComponentRequestId(Long componentRequestId);

    List<ComponentRequestItemEntity>
            findByInventoryItemId(Long itemId);

    List<ComponentRequestItemEntity>
            findByItemStatus(String itemStatus);

    List<ComponentRequestItemEntity>
            findByComponentRequestProjectId(Long projectId);

    List<ComponentRequestItemEntity>
            findByComponentRequestRequestedBy(Long requestedBy);

    List<ComponentRequestItemEntity>
            findByComponentRequestFacultyId(Long facultyId);
}