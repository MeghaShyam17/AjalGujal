package com.ilp.inventory_service.ServiceImplementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.Client.NotificationFeignClient;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ComponentRequestItemResponseDto;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Dto.UserServiceResponseDto;
import com.ilp.inventory_service.Entity.ComponentRequestItemEntity;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.ComponentRequestItemRepository;
import com.ilp.inventory_service.Repository.ComponentRequestRepository;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.ServiceInterface.ComponentRequestItemServiceInterface;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComponentRequestItemServiceImplementation
        implements ComponentRequestItemServiceInterface {

    @Autowired
    private ComponentRequestItemRepository componentRequestItemRepository;

    @Autowired
    private ComponentRequestRepository componentRequestRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private NotificationFeignClient notificationFeignClient;

    @Override
    public ComponentRequestItemResponseDto getById(Long requestItemId) {
        ComponentRequestItemEntity entity = findEntityById(requestItemId);
        return mapToResponse(entity);
    }

    @Override
    public List<ComponentRequestItemResponseDto> getRequestItems(
            Long componentRequestId,
            Long itemId,
            String itemStatus,
            Long projectId,
            Long requestedBy,
            Long facultyId) {

        if (componentRequestId != null) {
            return getByComponentRequestId(componentRequestId);
        }
        if (itemId != null) {
            return getByItemId(itemId);
        }
        if (itemStatus != null && !itemStatus.trim().isEmpty()) {
            return getByItemStatus(itemStatus);
        }
        if (projectId != null) {
            return getByProjectId(projectId);
        }
        if (requestedBy != null) {
            return getByRequestedBy(requestedBy);
        }
        if (facultyId != null) {
            return getByFacultyId(facultyId);
        }
        return getAll();
    }

    @Override
    public List<ComponentRequestItemResponseDto> getAll() {
        return componentRequestItemRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestItemResponseDto> getByComponentRequestId(Long componentRequestId) {
        return componentRequestItemRepository
                .findByComponentRequestComponentRequestId(componentRequestId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestItemResponseDto> getByItemId(Long itemId) {
        return componentRequestItemRepository
                .findByInventoryItemId(itemId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestItemResponseDto> getByItemStatus(String itemStatus) {
        return componentRequestItemRepository
                .findByItemStatus(itemStatus)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestItemResponseDto> getByProjectId(Long projectId) {
        validateProject(projectId);
        return componentRequestItemRepository
                .findByComponentRequestProjectId(projectId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestItemResponseDto> getByRequestedBy(Long requestedBy) {
        validateUser(requestedBy, "Requested User Not Found");
        return componentRequestItemRepository
                .findByComponentRequestRequestedBy(requestedBy)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComponentRequestItemResponseDto> getByFacultyId(Long facultyId) {
        validateUser(facultyId, "Faculty User Not Found");
        return componentRequestItemRepository
                .findByComponentRequestFacultyId(facultyId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private ComponentRequestItemEntity findEntityById(Long requestItemId) {
        return componentRequestItemRepository
                .findByRequestItemId(requestItemId)
                .orElseThrow(() -> new ToolResourceNotFoundException("Component Request Item Not Found"));
    }

    private ProjectTeamDto validateProject(Long projectId) {
        ProjectTeamDto project = projectClient.getProjectById(Math.toIntExact(projectId));
        if (project == null || project.getProjectId() == null) {
            throw new ToolResourceNotFoundException("Project Not Found");
        }
        return project;
    }

    private UserDto validateUser(Long userId, String errorMessage) {
        UserServiceResponseDto response = userClient.getUserResponseById(Math.toIntExact(userId));
        if (response == null || response.getUserId() == null) {
            throw new ToolResourceNotFoundException(errorMessage);
        }
        return mapToUserDto(response);
    }

    private UserDto mapToUserDto(UserServiceResponseDto response) {
        if (response == null) {
            return null;
        }

        UserDto userDto = new UserDto();
        userDto.setUserId(response.getUserId());
        userDto.setUserName(response.getName());
        userDto.setEmail(response.getEmail());
        userDto.setMobileNumber(response.getPhone());

        if (response.getRole() != null) {
            userDto.setRole(response.getRole().getRoleName());
        }

        return userDto;
    }


    private ComponentRequestItemResponseDto mapToResponse(ComponentRequestItemEntity entity) {
        ComponentRequestItemResponseDto dto = new ComponentRequestItemResponseDto();

        dto.setRequestItemId(entity.getRequestItemId());
        if (entity.getInventory() != null) {
            dto.setItemId(entity.getInventory().getItemId());
        }
        dto.setRequestedQuantity(entity.getRequestedQuantity());
        dto.setApprovedQuantity(entity.getApprovedQuantity());
        dto.setIssuedQuantity(entity.getIssuedQuantity());
        dto.setItemStatus(entity.getItemStatus());
        dto.setFacultyComments(entity.getFacultyComments());

        return dto;
    }
}
