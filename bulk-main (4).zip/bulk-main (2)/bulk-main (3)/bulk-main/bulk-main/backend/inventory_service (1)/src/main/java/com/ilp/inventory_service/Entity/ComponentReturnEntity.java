package com.ilp.inventory_service.Entity;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "component_return")
public class ComponentReturnEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "component_return_id")
    private Long componentReturnId;

    @Column(name = "return_code", unique = true)
    private String returnCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "component_request_id")
    private ComponentRequestEntity componentRequest;

    @Column(name = "project_id")
    private Long projectId;

    @Column(name = "returned_by")
    private Long returnedBy;

    @Column(name = "received_by")
    private Long receivedBy;

    @Column(name = "return_date")
    private Timestamp returnDate;

    @Column(name = "return_status")
    private String returnStatus;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @OneToMany(
            mappedBy = "componentReturn",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private List<ComponentReturnItemEntity> returnItems;

    public ComponentReturnEntity() {
    }

    public ComponentReturnEntity(
            Long componentReturnId,
            String returnCode,
            ComponentRequestEntity componentRequest,
            Long projectId,
            Long returnedBy,
            Long receivedBy,
            Timestamp returnDate,
            String returnStatus,
            String remarks,
            Timestamp createdAt,
            List<ComponentReturnItemEntity> returnItems) {

        this.componentReturnId = componentReturnId;
        this.returnCode = returnCode;
        this.componentRequest = componentRequest;
        this.projectId = projectId;
        this.returnedBy = returnedBy;
        this.receivedBy = receivedBy;
        this.returnDate = returnDate;
        this.returnStatus = returnStatus;
        this.remarks = remarks;
        this.createdAt = createdAt;
        this.returnItems = returnItems;
    }

    public Long getComponentReturnId() {
        return componentReturnId;
    }

    public void setComponentReturnId(Long componentReturnId) {
        this.componentReturnId = componentReturnId;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public ComponentRequestEntity getComponentRequest() {
        return componentRequest;
    }

    public void setComponentRequest(ComponentRequestEntity componentRequest) {
        this.componentRequest = componentRequest;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getReturnedBy() {
        return returnedBy;
    }

    public void setReturnedBy(Long returnedBy) {
        this.returnedBy = returnedBy;
    }

    public Long getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Long receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Timestamp getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Timestamp returnDate) {
        this.returnDate = returnDate;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public List<ComponentReturnItemEntity> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(List<ComponentReturnItemEntity> returnItems) {
        this.returnItems = returnItems;
    }
}
