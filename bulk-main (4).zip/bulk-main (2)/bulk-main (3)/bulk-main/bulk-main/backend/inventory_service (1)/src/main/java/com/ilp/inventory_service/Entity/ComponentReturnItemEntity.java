package com.ilp.inventory_service.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "component_return_item")
public class ComponentReturnItemEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "return_item_id")
    private Long returnItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "component_return_id")
    private ComponentReturnEntity componentReturn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id")
    private InventoryEntity inventory;

    @Column(name = "issued_quantity")
    private Integer issuedQuantity;

    @Column(name = "returned_quantity")
    private Integer returnedQuantity;

    @Column(name = "consumed_quantity")
    private Integer consumedQuantity;

    @Column(name = "damaged_quantity")
    private Integer damagedQuantity;

    @Column(name = "lost_quantity")
    private Integer lostQuantity;

    @Column(name = "condition")
    private String condition;

    @Column(name = "remarks")
    private String remarks;

    public ComponentReturnItemEntity() {
    }

    public ComponentReturnItemEntity(
            Long returnItemId,
            ComponentReturnEntity componentReturn,
            InventoryEntity inventory,
            Integer issuedQuantity,
            Integer returnedQuantity,
            Integer consumedQuantity,
            Integer damagedQuantity,
            Integer lostQuantity,
            String condition,
            String remarks) {

        this.returnItemId = returnItemId;
        this.componentReturn = componentReturn;
        this.inventory = inventory;
        this.issuedQuantity = issuedQuantity;
        this.returnedQuantity = returnedQuantity;
        this.consumedQuantity = consumedQuantity;
        this.damagedQuantity = damagedQuantity;
        this.lostQuantity = lostQuantity;
        this.condition = condition;
        this.remarks = remarks;
    }

    public Long getReturnItemId() {
        return returnItemId;
    }

    public void setReturnItemId(Long returnItemId) {
        this.returnItemId = returnItemId;
    }

    public ComponentReturnEntity getComponentReturn() {
        return componentReturn;
    }

    public void setComponentReturn(ComponentReturnEntity componentReturn) {
        this.componentReturn = componentReturn;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public Integer getReturnedQuantity() {
        return returnedQuantity;
    }

    public void setReturnedQuantity(Integer returnedQuantity) {
        this.returnedQuantity = returnedQuantity;
    }

    public Integer getConsumedQuantity() {
        return consumedQuantity;
    }

    public void setConsumedQuantity(Integer consumedQuantity) {
        this.consumedQuantity = consumedQuantity;
    }

    public Integer getDamagedQuantity() {
        return damagedQuantity;
    }

    public void setDamagedQuantity(Integer damagedQuantity) {
        this.damagedQuantity = damagedQuantity;
    }

    public Integer getLostQuantity() {
        return lostQuantity;
    }

    public void setLostQuantity(Integer lostQuantity) {
        this.lostQuantity = lostQuantity;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
