package com.ilp.inventory_service.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.inventory_service.ToolEnums.ItemCondition;
import com.ilp.inventory_service.Entity.ToolReturnItemEntity;

import java.util.List;

@Repository
public interface ToolReturnItemRespository
        extends JpaRepository<ToolReturnItemEntity, Long> {

    ToolReturnItemEntity findByReturnItemId(
            Long returnItemId);

    List<ToolReturnItemEntity>
    findByToolReturnToolReturnId(
            Long toolReturnId);

    List<ToolReturnItemEntity>
    findByInventoryItemId(
            Long itemId);

    List<ToolReturnItemEntity>
    findByVerifiedBy(
            Long verifiedBy);

    List<ToolReturnItemEntity>
    findByCondition(
            ItemCondition condition);

    List<ToolReturnItemEntity>
    findByToolReturnToolRequestProjectId(
            Long projectId);
}
