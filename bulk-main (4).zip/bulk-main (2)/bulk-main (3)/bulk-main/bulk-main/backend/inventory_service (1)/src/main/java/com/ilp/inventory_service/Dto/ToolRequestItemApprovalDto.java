package com.ilp.inventory_service.Dto;

public class ToolRequestItemApprovalDto {
    private Long toolRequestItemId;
    private Integer approvedQuantity;

    public ToolRequestItemApprovalDto() {
    }

    public ToolRequestItemApprovalDto(Long toolRequestItemId, Integer approvedQuantity) {
        this.toolRequestItemId = toolRequestItemId;
        this.approvedQuantity = approvedQuantity;
    }

    public Long getToolRequestItemId() {
        return toolRequestItemId;
    }

    public void setToolRequestItemId(Long toolRequestItemId) {
        this.toolRequestItemId = toolRequestItemId;
    }

    public Integer getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(Integer approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }
}
