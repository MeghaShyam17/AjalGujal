package com.ilp.inventory_service.Exception;

import java.time.LocalDateTime;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(
            ToolResourceNotFoundException.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleNotFoundException(
            ToolResourceNotFoundException ex) {

        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        ex.getMessage(),
                        HttpStatus.NOT_FOUND.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(
            ToolBadRequestException.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleBadRequestException(
            ToolBadRequestException ex) {

        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        ex.getMessage(),
                        HttpStatus.BAD_REQUEST.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(
            ToolBusinessException.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleBusinessException(
            ToolBusinessException ex) {

        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        ex.getMessage(),
                        HttpStatus.CONFLICT.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.CONFLICT);
    }

    @ExceptionHandler(
            InventoryException.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleInventoryException(
            InventoryException ex) {

        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        ex.getMessage(),
                        HttpStatus.BAD_REQUEST.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(
            DamageReportException.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleDamageReportException(
            DamageReportException ex) {

        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        ex.getMessage(),
                        HttpStatus.BAD_REQUEST.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(
            DataIntegrityViolationException.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleDatabaseException(
            DataIntegrityViolationException ex) {

        String specificCause = ex.getMostSpecificCause() != null ? ex.getMostSpecificCause().getMessage() : ex.getMessage();
        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        "Invalid reference data. Details: " + specificCause,
                        HttpStatus.BAD_REQUEST.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ToolErrorResponseDTO>
    handleGenericException(
            Exception ex) {

        ToolErrorResponseDTO error =
                new ToolErrorResponseDTO(
                        ex.getMessage(),
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                error,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
