package com.ilp.inventory_service.ServiceInterface;

import com.ilp.inventory_service.Dto.ComponentReturnDto;
import com.ilp.inventory_service.Dto.ComponentReturnResponseDto;

import java.util.List;

public interface ComponentReturnServiceInterface {

    ComponentReturnResponseDto createComponentReturn(
            ComponentReturnDto dto);

    ComponentReturnResponseDto getById(
            Long componentReturnId);

    List<ComponentReturnResponseDto> getReturns(
            Long projectId,
            Long returnedBy,
            Long receivedBy,
            Long componentRequestId,
            String status);

    List<ComponentReturnResponseDto> getAll();

    List<ComponentReturnResponseDto> getByProjectId(
            Long projectId);

    List<ComponentReturnResponseDto> getByReturnedBy(
            Long returnedBy);

    List<ComponentReturnResponseDto> getByReceivedBy(
            Long receivedBy);

    List<ComponentReturnResponseDto> getByRequestId(
            Long componentRequestId);

    List<ComponentReturnResponseDto> getPendingReturns();

    List<ComponentReturnResponseDto> getReceivedReturns();

    ComponentReturnResponseDto receiveReturn(
            Long componentReturnId,
            Long receivedBy);

    void delete(
            Long componentReturnId);
}
