package com.ilp.inventory_service.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Entity.DamageReportEntity;
import com.ilp.inventory_service.Exception.DamageReportException;
import com.ilp.inventory_service.Repository.DamageReportRepository;
import com.ilp.inventory_service.ServiceInterface.DamageReportServiceInterface;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
@Service
public class DamageReportServiceImplementation
        implements DamageReportServiceInterface {

    @Autowired
    private DamageReportRepository damageReportRepository;

    @Autowired
    private NotificationHelperServiceImplementation
            notificationHelperService;

    @Autowired
    private ProjectClient projectClient;
    
    @Autowired
    private UserClient userClient;
    

    @Override
    public DamageReportEntity saveDamageReport(
            DamageReportEntity damageReport) {

        if (damageReport == null) {
            throw new DamageReportException(
                    "Damage Report Cannot Be Null");
        }

        if (damageReport.getDamageCode() == null
                || damageReport.getDamageCode()
                        .trim()
                        .isEmpty()) {

            throw new DamageReportException(
                    "Damage Code Cannot Be Empty");
        }

        validateProject(damageReport);

        DamageReportEntity saved =
                damageReportRepository.save(
                        damageReport);

        if (saved.getReportedBy() != null) {

            notificationHelperService.sendNotification(
                    saved.getReportedBy().intValue(),
                    "Damage Report Created",
                    "Damage report "
                            + saved.getDamageCode()
                            + " has been created.",
                    "DAMAGE",
                    saved.getDamageId().intValue(),
                    "High",
                    saved.getReportedBy().intValue());
        }

        return saved;
    }

    @Override
    public DamageReportEntity getDamageReportById(
            Long damageId) {

        return damageReportRepository
                .findById(damageId)
                .orElseThrow(() ->
                        new DamageReportException(
                                "Damage Report Not Found With ID : "
                                        + damageId));
    }

    @Override
    public List<DamageReportEntity> getAllDamageReports() {

        List<DamageReportEntity> reports =
                damageReportRepository.findAll();

        return reports;
    }

    @Override
    public List<DamageReportEntity>
            getDamageReportsByTicketStatus(
                    String ticketStatus) {

        List<DamageReportEntity> reports =
                damageReportRepository
                        .findByTicketStatus(ticketStatus);

        if (reports.isEmpty()) {

            throw new DamageReportException(
                    "No Damage Reports Found For Ticket Status : "
                            + ticketStatus);
        }

        return reports;
    }

    @Override
    public List<DamageReportEntity>
            getDamageReportsByPriority(
                    String priority) {

        List<DamageReportEntity> reports =
                damageReportRepository
                        .findByPriority(priority);

        if (reports.isEmpty()) {

            throw new DamageReportException(
                    "No Damage Reports Found For Priority : "
                            + priority);
        }

        return reports;
    }

    @Override
    public List<DamageReportEntity>
            getDamageReportsByDamageType(
                    String damageType) {

        List<DamageReportEntity> reports =
                damageReportRepository
                        .findByDamageType(damageType);

        if (reports.isEmpty()) {

            throw new DamageReportException(
                    "No Damage Reports Found For Damage Type : "
                            + damageType);
        }

        return reports;
    }

    @Override
    public DamageReportEntity updateDamageReport(
            DamageReportEntity damageReport) {

        if (damageReport == null) {

            throw new DamageReportException(
                    "Damage Report Cannot Be Null");
        }

        if (damageReport.getDamageId() == null) {

            throw new DamageReportException(
                    "Damage Report ID Cannot Be Null");
        }

        if (!damageReportRepository.existsById(
                damageReport.getDamageId())) {

            throw new DamageReportException(
                    "Damage Report Not Found With ID : "
                            + damageReport.getDamageId());
        }

        DamageReportEntity updated =
                damageReportRepository.save(
                        damageReport);

        if (updated.getReportedBy() != null) {

            notificationHelperService.sendNotification(
                    updated.getReportedBy().intValue(),
                    "Damage Report Updated",
                    "Damage report "
                            + updated.getDamageCode()
                            + " has been updated.",
                    "DAMAGE",
                    updated.getDamageId().intValue(),
                    "Medium",
                    updated.getReportedBy().intValue());
        }

        return updated;
    }

    @Override
    public void deleteDamageReport(
            Long damageId) {

        DamageReportEntity report =
                damageReportRepository.findById(
                                damageId)
                        .orElseThrow(() ->
                                new DamageReportException(
                                        "Damage Report Not Found With ID : "
                                                + damageId));

        if (report.getReportedBy() != null) {

            notificationHelperService.sendNotification(
                    report.getReportedBy().intValue(),
                    "Damage Report Deleted",
                    "Damage report "
                            + report.getDamageCode()
                            + " has been deleted.",
                    "DAMAGE",
                    report.getDamageId().intValue(),
                    "Medium",
                    report.getReportedBy().intValue());
        }

        damageReportRepository.deleteById(
                damageId);
    }

    private UserDto getUserDetails(
            Long userId) {

        if (userId == null) {
            return null;
        }

        return userClient.getUserById(
                userId.intValue());
    }
    
    private void validateProject(
            DamageReportEntity damageReport) {

        if (damageReport.getProjectId() == null) {

            throw new DamageReportException(
                    "Project ID cannot be null");
        }

        ProjectTeamDto project =
                projectClient.getProjectById(
                        damageReport
                                .getProjectId()
                                .intValue());

        if (project == null) {

            throw new DamageReportException(
                    "Project not found");
        }

        if (!"Active".equalsIgnoreCase(
                project.getProjectStatus())
                &&
                !"Ongoing".equalsIgnoreCase(
                        project.getProjectStatus())) {

            throw new DamageReportException(
                    "Damage report can be created only for active projects");
        }

        if (damageReport.getReportedBy() != null
                &&
                project.getTeamLeaderId() != null) {

            if (!damageReport.getReportedBy()
                    .equals(project.getTeamLeaderId().longValue())) {

                throw new DamageReportException(
                        "Only project team leader can create damage report");
            }
        }
    }
}