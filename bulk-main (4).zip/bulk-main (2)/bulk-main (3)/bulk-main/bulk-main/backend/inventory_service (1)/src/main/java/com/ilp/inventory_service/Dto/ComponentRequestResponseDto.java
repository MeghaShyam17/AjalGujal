package com.ilp.inventory_service.Dto;

import java.sql.Timestamp;
import java.util.List;

public class ComponentRequestResponseDto {

    private Long componentRequestId;

    private Long projectId;

    private Long requestedBy;

    private Long facultyId;

    private Timestamp requestDate;

    private String approvalStatus;

    private Long approvedBy;

    private Timestamp approvedOn;

    private Long issuedBy;

    private Timestamp issuedOn;

    private String remarks;

    private Timestamp createdAt;

    private List<ComponentRequestItemResponseDto> requestItems;

    public ComponentRequestResponseDto() {
    }

    public ComponentRequestResponseDto(
            Long componentRequestId,
            Long projectId,
            Long requestedBy,
            Long facultyId,
            Timestamp requestDate,
            String approvalStatus,
            Long approvedBy,
            Timestamp approvedOn,
            Long issuedBy,
            Timestamp issuedOn,
            String remarks,
            Timestamp createdAt,
            List<ComponentRequestItemResponseDto> requestItems) {

        this.componentRequestId = componentRequestId;
        this.projectId = projectId;
        this.requestedBy = requestedBy;
        this.facultyId = facultyId;
        this.requestDate = requestDate;
        this.approvalStatus = approvalStatus;
        this.approvedBy = approvedBy;
        this.approvedOn = approvedOn;
        this.issuedBy = issuedBy;
        this.issuedOn = issuedOn;
        this.remarks = remarks;
        this.createdAt = createdAt;
        this.requestItems = requestItems;
    }

    public Long getComponentRequestId() {
        return componentRequestId;
    }

    public void setComponentRequestId(Long componentRequestId) {
        this.componentRequestId = componentRequestId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(Long requestedBy) {
        this.requestedBy = requestedBy;
    }

    public Long getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Long facultyId) {
        this.facultyId = facultyId;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Long getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Long approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Timestamp getApprovedOn() {
        return approvedOn;
    }

    public void setApprovedOn(Timestamp approvedOn) {
        this.approvedOn = approvedOn;
    }

    public Long getIssuedBy() {
        return issuedBy;
    }

    public void setIssuedBy(Long issuedBy) {
        this.issuedBy = issuedBy;
    }

    public Timestamp getIssuedOn() {
        return issuedOn;
    }

    public void setIssuedOn(Timestamp issuedOn) {
        this.issuedOn = issuedOn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public List<ComponentRequestItemResponseDto> getRequestItems() {
        return requestItems;
    }

    public void setRequestItems(
            List<ComponentRequestItemResponseDto> requestItems) {
        this.requestItems = requestItems;
    }
}