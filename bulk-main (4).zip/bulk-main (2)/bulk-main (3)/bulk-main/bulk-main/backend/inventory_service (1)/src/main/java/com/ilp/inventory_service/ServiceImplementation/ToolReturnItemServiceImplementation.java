package com.ilp.inventory_service.ServiceImplementation;

import java.sql.Timestamp;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ToolReturnItemDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Entity.DamageReportEntity;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Entity.ToolReturnEntity;
import com.ilp.inventory_service.Entity.ToolReturnItemEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.DamageReportRepository;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.Repository.ToolReturnItemRespository;
import com.ilp.inventory_service.Repository.ToolReturnRepository;
import com.ilp.inventory_service.ServiceInterface.ToolReturnItemServiceInterface;
import com.ilp.inventory_service.ToolEnums.DamageType;
import com.ilp.inventory_service.ToolEnums.ItemCondition;
import com.ilp.inventory_service.ToolEnums.Priority;
import com.ilp.inventory_service.ToolEnums.TicketStatus;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ToolReturnItemServiceImplementation
        implements ToolReturnItemServiceInterface {

    @Autowired
    private ToolReturnItemRespository toolReturnItemRespository;

    @Autowired
    private ToolReturnRepository toolReturnRepository;
    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private DamageReportRepository damageReportRepository;

    @Autowired
    private NotificationHelperServiceImplementation notificationHelperService;

    @Autowired
    private UserClient userClient;

    @Override
    @Transactional
    public ToolReturnItemDto create(
            ToolReturnItemDto dto) {

        ToolReturnEntity toolReturn =
                toolReturnRepository.findById(
                                dto.getToolReturnId())
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Not Found"));

        InventoryEntity inventory =
                inventoryRepository.findById(
                                dto.getItemId())
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Inventory Item Not Found"));

        ToolReturnItemEntity entity =
                new ToolReturnItemEntity();

        entity.setToolReturn(toolReturn);
        entity.setInventory(inventory);
        entity.setReturnedQuantity(dto.getReturnedQuantity());
        entity.setDamagedQuantity(dto.getDamagedQuantity());
        entity.setLostQuantity(dto.getLostQuantity());
        entity.setCondition(dto.getCondition());
        entity.setVerifiedBy(dto.getVerifiedBy());
        entity.setRemarks(dto.getRemarks());
        entity.setVerifiedOn(
                new Timestamp(System.currentTimeMillis()));

        ToolReturnItemEntity saved =
                toolReturnItemRespository.save(entity);

        Integer currentQuantity =
                inventory.getAvailableQuantity() == null
                        ? 0
                        : inventory.getAvailableQuantity();

        Integer returnedQuantity =
                dto.getReturnedQuantity() == null
                        ? 0
                        : dto.getReturnedQuantity();

        if (dto.getCondition() == ItemCondition.GOOD || dto.getCondition() == null) {
            inventory.setAvailableQuantity(
                    currentQuantity + returnedQuantity);
            inventoryRepository.save(inventory);
        }

        notificationHelperService.sendNotification(
                toolReturn.getToolRequest()
                        .getRequestedBy()
                        .intValue(),
                "Tool Returned",
                "Tool return item has been recorded successfully.",
                "RETURN",
                saved.getReturnItemId().intValue(),
                "Medium",
                toolReturn.getReturnedBy().intValue());

        if (dto.getCondition() == ItemCondition.DAMAGED
                || dto.getCondition() == ItemCondition.LOST) {

            DamageReportEntity damageReport =
                    new DamageReportEntity();

            damageReport.setDamageCode(
                    "DR-" + System.currentTimeMillis());

            damageReport.setProjectId(
                    toolReturn.getToolRequest()
                            .getProjectId());

            damageReport.setInventory(inventory);

            damageReport.setToolReturnItemId(
                    saved.getReturnItemId());

            damageReport.setReportedBy(
                    toolReturn.getReturnedBy());

            if (dto.getCondition()
                    == ItemCondition.DAMAGED) {

                damageReport.setDamageType(
                        DamageType.BROKEN);

            } else {

                damageReport.setDamageType(
                        DamageType.LOST);
            }

            damageReport.setPriority(
                    Priority.MEDIUM);

            damageReport.setTicketStatus(
                    TicketStatus.OPEN);

            damageReport.setCreatedAt(
                    new Timestamp(System.currentTimeMillis()));

            DamageReportEntity savedDamageReport =
                    damageReportRepository.save(
                            damageReport);

            notificationHelperService.sendNotification(
                    toolReturn.getToolRequest()
                            .getRequestedBy()
                            .intValue(),
                    "Damage Report Generated",
                    "Damage/Loss reported for returned item.",
                    "DAMAGE",
                    savedDamageReport.getDamageId().intValue(),
                    "High",
                    toolReturn.getReturnedBy().intValue());
        }

        return mapToDto(saved);
    }

    @Override
    public ToolReturnItemDto getById(
            Long returnItemId) {

        ToolReturnItemEntity entity =
                toolReturnItemRespository.findById(
                                returnItemId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Item Not Found"));

        return mapToDto(entity);
    }

    @Override
    public List<ToolReturnItemDto> getAll() {

        return toolReturnItemRespository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolReturnItemDto> getByToolReturnId(
            Long toolReturnId) {

        return toolReturnItemRespository
                .findByToolReturnToolReturnId(
                        toolReturnId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void verifyItem(
            Long returnItemId,
            Long verifiedBy) {

        ToolReturnItemEntity entity =
                toolReturnItemRespository.findById(
                                returnItemId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Item Not Found"));

        entity.setVerifiedBy(verifiedBy);

        entity.setVerifiedOn(
                new Timestamp(System.currentTimeMillis()));

        ToolReturnItemEntity updated =
                toolReturnItemRespository.save(entity);

        notificationHelperService.sendNotification(
                updated.getToolReturn()
                        .getToolRequest()
                        .getRequestedBy()
                        .intValue(),
                "Return Item Verified",
                "Returned item has been verified successfully.",
                "RETURN",
                updated.getReturnItemId().intValue(),
                "Medium",
                verifiedBy.intValue());
    }

    @Override
    @Transactional
    public void delete(
            Long returnItemId) {

        ToolReturnItemEntity entity =
                toolReturnItemRespository.findById(
                                returnItemId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Item Not Found"));

        if (entity.getVerifiedBy() != null) {

            throw new ToolBusinessException(
                    "Verified Item Cannot Be Deleted");
        }

        toolReturnItemRespository.delete(entity);
    }

    private ToolReturnItemDto mapToDto(
            ToolReturnItemEntity entity) {

        ToolReturnItemDto dto =
                new ToolReturnItemDto();

        dto.setToolReturnId(
                entity.getToolReturn()
                        .getToolReturnId());

        dto.setItemId(
                entity.getInventory()
                        .getItemId());

        dto.setReturnedQuantity(
                entity.getReturnedQuantity());

        dto.setDamagedQuantity(
                entity.getDamagedQuantity());

        dto.setLostQuantity(
                entity.getLostQuantity());

        dto.setCondition(
                entity.getCondition());

        dto.setVerifiedBy(
                entity.getVerifiedBy());

        dto.setRemarks(
                entity.getRemarks());

        // User Details
        if (entity.getToolReturn() != null
                && entity.getToolReturn().getToolRequest() != null
                && entity.getToolReturn().getToolRequest().getRequestedBy() != null) {

            UserDto userDto =
                    userClient.getUserById(
                            entity.getToolReturn()
                                    .getToolRequest()
                                    .getRequestedBy()
                                    .intValue());

            dto.setUser(userDto);
        }

        // Project Details
        if (entity.getToolReturn() != null
                && entity.getToolReturn().getToolRequest() != null
                && entity.getToolReturn().getToolRequest().getProjectId() != null) {

            ProjectTeamDto projectDto =
                    projectClient.getProjectById(
                            entity.getToolReturn()
                                    .getToolRequest()
                                    .getProjectId()
                                    .intValue());

            dto.setProject(projectDto);
        }

        return dto;
    }
}