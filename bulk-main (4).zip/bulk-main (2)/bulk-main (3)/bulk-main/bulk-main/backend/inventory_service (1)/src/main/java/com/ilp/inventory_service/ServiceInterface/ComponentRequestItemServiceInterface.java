package com.ilp.inventory_service.ServiceInterface;

import com.ilp.inventory_service.Dto.ComponentRequestItemResponseDto;

import java.util.List;

public interface ComponentRequestItemServiceInterface {

    ComponentRequestItemResponseDto getById(
            Long requestItemId);

    List<ComponentRequestItemResponseDto> getRequestItems(
            Long componentRequestId,
            Long itemId,
            String itemStatus,
            Long projectId,
            Long requestedBy,
            Long facultyId);

    List<ComponentRequestItemResponseDto> getAll();

    List<ComponentRequestItemResponseDto> getByComponentRequestId(
            Long componentRequestId);

    List<ComponentRequestItemResponseDto> getByItemId(
            Long itemId);

    List<ComponentRequestItemResponseDto> getByItemStatus(
            String itemStatus);

    List<ComponentRequestItemResponseDto> getByProjectId(
            Long projectId);

    List<ComponentRequestItemResponseDto> getByRequestedBy(
            Long requestedBy);

    List<ComponentRequestItemResponseDto> getByFacultyId(
            Long facultyId);
}
