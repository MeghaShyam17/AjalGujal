package com.ilp.inventory_service.Dto;

public class ComponentReturnItemDto {

    private Long itemId;

    private Integer issuedQuantity;

    private Integer returnedQuantity;

    private Integer consumedQuantity;

    private Integer damagedQuantity;

    private Integer lostQuantity;

    private String condition;

    private String remarks;

    public ComponentReturnItemDto() {
    }

    public ComponentReturnItemDto(
            Long itemId,
            Integer issuedQuantity,
            Integer returnedQuantity,
            Integer consumedQuantity,
            Integer damagedQuantity,
            Integer lostQuantity,
            String condition,
            String remarks) {

        this.itemId = itemId;
        this.issuedQuantity = issuedQuantity;
        this.returnedQuantity = returnedQuantity;
        this.consumedQuantity = consumedQuantity;
        this.damagedQuantity = damagedQuantity;
        this.lostQuantity = lostQuantity;
        this.condition = condition;
        this.remarks = remarks;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public Integer getReturnedQuantity() {
        return returnedQuantity;
    }

    public void setReturnedQuantity(Integer returnedQuantity) {
        this.returnedQuantity = returnedQuantity;
    }

    public Integer getConsumedQuantity() {
        return consumedQuantity;
    }

    public void setConsumedQuantity(Integer consumedQuantity) {
        this.consumedQuantity = consumedQuantity;
    }

    public Integer getDamagedQuantity() {
        return damagedQuantity;
    }

    public void setDamagedQuantity(Integer damagedQuantity) {
        this.damagedQuantity = damagedQuantity;
    }

    public Integer getLostQuantity() {
        return lostQuantity;
    }

    public void setLostQuantity(Integer lostQuantity) {
        this.lostQuantity = lostQuantity;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
