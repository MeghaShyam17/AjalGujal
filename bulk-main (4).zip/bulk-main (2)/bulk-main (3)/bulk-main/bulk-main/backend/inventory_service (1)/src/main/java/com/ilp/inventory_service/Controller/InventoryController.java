package com.ilp.inventory_service.Controller;

import com.ilp.inventory_service.Dto.BulkUploadResponseDto;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.ServiceInterface.InventoryServiceInterface;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    private InventoryServiceInterface inventoryService;

    @PostMapping("/upload-image/{itemId}")
    public ResponseEntity<String> uploadImage(
            @PathVariable Long itemId,
            @RequestParam("file") MultipartFile file) {

        return ResponseEntity.ok(
                inventoryService.uploadImage(itemId, file)
        );
    }

    @PostMapping("/bulk-upload")
    public ResponseEntity<BulkUploadResponseDto> bulkUpload(
            @RequestParam("file") MultipartFile file) {

        return ResponseEntity.ok(
                inventoryService.bulkUpload(file)
        );
    }

    @PostMapping("/save")
    public ResponseEntity<InventoryEntity> saveInventoryItem(
            @RequestBody InventoryEntity inventory) {

        return ResponseEntity.ok(
                inventoryService.saveInventoryItem(inventory)
        );
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<InventoryEntity> getInventoryById(
            @PathVariable Long itemId) {

        return ResponseEntity.ok(
                inventoryService.getInventoryById(itemId)
        );
    }

    @GetMapping("/code/{itemCode}")
    public ResponseEntity<InventoryEntity> getInventoryByCode(
            @PathVariable String itemCode) {

        return ResponseEntity.ok(
                inventoryService.getInventoryByCode(itemCode)
        );
    }

    @GetMapping("/all")
    public ResponseEntity<List<InventoryEntity>> getAllInventoryItems() {
        return ResponseEntity.ok(
                inventoryService.getAllInventoryItems()
        );
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<InventoryEntity>> getInventoryByCategory(
            @PathVariable String category) {

        return ResponseEntity.ok(
                inventoryService.getInventoryByCategory(category)
        );
    }

    @GetMapping("/search/{itemName}")
    public ResponseEntity<List<InventoryEntity>> searchInventoryByName(
            @PathVariable String itemName) {

        return ResponseEntity.ok(
                inventoryService.searchInventoryByName(itemName)
        );
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<InventoryEntity>> getInventoryByStatus(
            @PathVariable String status) {

        return ResponseEntity.ok(
                inventoryService.getInventoryByStatus(status)
        );
    }

    @GetMapping("/low-stock")
    public ResponseEntity<List<InventoryEntity>> getLowStockItems() {
        return ResponseEntity.ok(
                inventoryService.getLowStockItems()
        );
    }

    @GetMapping("/minimum-stock")
    public ResponseEntity<List<InventoryEntity>> getMinimumStockItems() {
        return ResponseEntity.ok(
                inventoryService.getMinimumStockItems()
        );
    }

    @GetMapping("/available")
    public ResponseEntity<List<InventoryEntity>> getAvailableItems() {
        return ResponseEntity.ok(
                inventoryService.getAvailableItems()
        );
    }

    @GetMapping("/out-of-stock")
    public ResponseEntity<List<InventoryEntity>> getOutOfStockItems() {
        return ResponseEntity.ok(
                inventoryService.getOutOfStockItems()
        );
    }

    @GetMapping("/check-stock/{itemId}/{requestedQuantity}")
    public ResponseEntity<InventoryEntity> checkAvailableStock(
            @PathVariable Long itemId,
            @PathVariable Integer requestedQuantity) {

        return ResponseEntity.ok(
                inventoryService.checkAvailableStock(
                        itemId,
                        requestedQuantity
                )
        );
    }

    @GetMapping("/low-stock/count")
    public ResponseEntity<Long> countLowStockItems() {
        return ResponseEntity.ok(
                inventoryService.countLowStockItems()
        );
    }

    @GetMapping("/total-available-stock")
    public ResponseEntity<Long> getTotalAvailableStock() {
        return ResponseEntity.ok(
                inventoryService.getTotalAvailableStock()
        );
    }

    @PutMapping("/update")
    public ResponseEntity<InventoryEntity> updateInventoryItem(
            @RequestBody InventoryEntity inventory) {

        return ResponseEntity.ok(
                inventoryService.updateInventoryItem(inventory)
        );
    }

    @DeleteMapping("/delete/{itemId}")
    public ResponseEntity<String> deleteInventoryItem(
            @PathVariable Long itemId) {

        inventoryService.deleteInventoryItem(itemId);

        return ResponseEntity.ok(
                "Inventory Item Deleted Successfully"
        );
    }
}
