package com.ilp.inventory_service;



public final class ToolEnums {

    public enum ApprovalStatus {
    	PENDING,
    	APPROVED,
    	
    	PARTIALLY_APPROVED,
    	
    	REJECTED,
    	
    	ISSUED,

    	RETURNED,

    	COMPLETED
    }

    public enum ItemStatus {
        PENDING, APPROVED, REJECTED, ISSUED, PARTIALLY_ISSUED
    }

    public enum ReturnStatus {
        PENDING, COMPLETED, PARTIAL,DUE
    }

    public enum ItemCondition {
        GOOD, DAMAGED, LOST
    }

    public enum InventoryStatus {
        ACTIVE, INACTIVE
    }

    public enum ItemCategory {
        COMPONENT, TOOL
    }

    public enum UnitType {
        PIECES, SETS
    }

    public enum DamageType {
        BROKEN, LOST, BURNT, FAULTY, MISSING
    }

    public enum Priority {
        LOW, MEDIUM, HIGH, CRITICAL
    }

    public enum TicketStatus {
        OPEN, IN_PROGRESS, RESOLVED, CLOSED
    }
    public enum ReturnItemStatus {
    PENDING,
    VERIFIED,
    REJECTED
}
}
