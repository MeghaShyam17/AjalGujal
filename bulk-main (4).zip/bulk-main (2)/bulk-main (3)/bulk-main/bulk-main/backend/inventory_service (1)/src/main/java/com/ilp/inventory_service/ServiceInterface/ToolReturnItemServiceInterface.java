package com.ilp.inventory_service.ServiceInterface;



import java.util.List;

import com.ilp.inventory_service.Dto.ToolReturnItemDto;

public interface ToolReturnItemServiceInterface {

    ToolReturnItemDto create(
            ToolReturnItemDto dto);

    ToolReturnItemDto getById(
            Long returnItemId);

    List<ToolReturnItemDto> getAll();

    List<ToolReturnItemDto> getByToolReturnId(
            Long toolReturnId);

    void verifyItem(
            Long returnItemId,
            Long verifiedBy);

    void delete(Long returnItemId);
}
