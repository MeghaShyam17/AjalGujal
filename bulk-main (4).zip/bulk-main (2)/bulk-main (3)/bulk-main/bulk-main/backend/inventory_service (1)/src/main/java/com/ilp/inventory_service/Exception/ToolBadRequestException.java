package com.ilp.inventory_service.Exception;




public class ToolBadRequestException
        extends RuntimeException {

    public ToolBadRequestException(
            String message) {

        super(message);
    }
}

