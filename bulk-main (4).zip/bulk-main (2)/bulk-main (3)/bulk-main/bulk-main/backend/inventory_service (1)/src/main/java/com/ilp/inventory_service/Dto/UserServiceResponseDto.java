package com.ilp.inventory_service.Dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserServiceResponseDto {

    private Long userId;
    private String name;
    private String email;
    private String phone;
    private UserServiceRoleResponseDto role;

    public UserServiceResponseDto() {
    }

    public UserServiceResponseDto(Long userId, String name, String email, String phone, UserServiceRoleResponseDto role) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.role = role;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public UserServiceRoleResponseDto getRole() {
        return role;
    }

    public void setRole(UserServiceRoleResponseDto role) {
        this.role = role;
    }
}
