package com.ilp.inventory_service.Entity;

import java.sql.Timestamp;

import com.ilp.inventory_service.ToolEnums.DamageType;
import com.ilp.inventory_service.ToolEnums.Priority;
import com.ilp.inventory_service.ToolEnums.TicketStatus;

import jakarta.persistence.*;

@Entity
@Table(name = "damage_report")
public class DamageReportEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "damage_id")
    private Long damageId;

    @Column(name = "damage_code", unique = true)
    private String damageCode;

    @Column(name = "project_id")
    private Long projectId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id")
    private InventoryEntity inventory;

    @Column(name = "equipment_id")
    private Long equipmentId;

    @Column(name = "tool_return_item_id")
    private Long toolReturnItemId;

    @Column(name = "component_return_item_id")
    private Long componentReturnItemId;

    @Column(name = "reported_by")
    private Long reportedBy;

    @Column(name = "assigned_to")
    private Long assignedTo;

    @Enumerated(EnumType.STRING)
    @Column(name = "damage_type")
    private DamageType damageType;

    @Enumerated(EnumType.STRING)
    @Column(name = "priority")
    private Priority priority;

    @Enumerated(EnumType.STRING)
    @Column(name = "ticket_status")
    private TicketStatus ticketStatus;

    @Column(name = "damage_description")
    private String damageDescription;

    @Column(name = "resolution_notes")
    private String resolutionNotes;

    @Column(name = "verified_by")
    private Long verifiedBy;

    @Column(name = "verified_on")
    private Timestamp verifiedOn;

    @Column(name = "resolved_on")
    private Timestamp resolvedOn;

    @Column(name = "closed_on")
    private Timestamp closedOn;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "updated_at")
    private Timestamp updatedAt;

    public DamageReportEntity() {
    }

    public DamageReportEntity(
            Long damageId,
            String damageCode,
            Long projectId,
            InventoryEntity inventory,
            Long equipmentId,
            Long toolReturnItemId,
            Long componentReturnItemId,
            Long reportedBy,
            Long assignedTo,
            DamageType damageType,
            Priority priority,
            TicketStatus ticketStatus,
            String damageDescription,
            String resolutionNotes,
            Long verifiedBy,
            Timestamp verifiedOn,
            Timestamp resolvedOn,
            Timestamp closedOn,
            Timestamp createdAt,
            Timestamp updatedAt) {

        this.damageId = damageId;
        this.damageCode = damageCode;
        this.projectId = projectId;
        this.inventory = inventory;
        this.equipmentId = equipmentId;
        this.toolReturnItemId = toolReturnItemId;
        this.componentReturnItemId = componentReturnItemId;
        this.reportedBy = reportedBy;
        this.assignedTo = assignedTo;
        this.damageType = damageType;
        this.priority = priority;
        this.ticketStatus = ticketStatus;
        this.damageDescription = damageDescription;
        this.resolutionNotes = resolutionNotes;
        this.verifiedBy = verifiedBy;
        this.verifiedOn = verifiedOn;
        this.resolvedOn = resolvedOn;
        this.closedOn = closedOn;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getDamageId() {
        return damageId;
    }

    public void setDamageId(Long damageId) {
        this.damageId = damageId;
    }

    public String getDamageCode() {
        return damageCode;
    }

    public void setDamageCode(String damageCode) {
        this.damageCode = damageCode;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public Long getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(Long equipmentId) {
        this.equipmentId = equipmentId;
    }

    public Long getToolReturnItemId() {
        return toolReturnItemId;
    }

    public void setToolReturnItemId(Long toolReturnItemId) {
        this.toolReturnItemId = toolReturnItemId;
    }

    public Long getComponentReturnItemId() {
        return componentReturnItemId;
    }

    public void setComponentReturnItemId(Long componentReturnItemId) {
        this.componentReturnItemId = componentReturnItemId;
    }

    public Long getReportedBy() {
        return reportedBy;
    }

    public void setReportedBy(Long reportedBy) {
        this.reportedBy = reportedBy;
    }

    public Long getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(Long assignedTo) {
        this.assignedTo = assignedTo;
    }

    public DamageType getDamageType() {
        return damageType;
    }

    public void setDamageType(DamageType damageType) {
        this.damageType = damageType;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public TicketStatus getTicketStatus() {
        return ticketStatus;
    }

    public void setTicketStatus(TicketStatus ticketStatus) {
        this.ticketStatus = ticketStatus;
    }

    public String getDamageDescription() {
        return damageDescription;
    }

    public void setDamageDescription(String damageDescription) {
        this.damageDescription = damageDescription;
    }

    public String getResolutionNotes() {
        return resolutionNotes;
    }

    public void setResolutionNotes(String resolutionNotes) {
        this.resolutionNotes = resolutionNotes;
    }

    public Long getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(Long verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Timestamp getVerifiedOn() {
        return verifiedOn;
    }

    public void setVerifiedOn(Timestamp verifiedOn) {
        this.verifiedOn = verifiedOn;
    }

    public Timestamp getResolvedOn() {
        return resolvedOn;
    }

    public void setResolvedOn(Timestamp resolvedOn) {
        this.resolvedOn = resolvedOn;
    }

    public Timestamp getClosedOn() {
        return closedOn;
    }

    public void setClosedOn(Timestamp closedOn) {
        this.closedOn = closedOn;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}