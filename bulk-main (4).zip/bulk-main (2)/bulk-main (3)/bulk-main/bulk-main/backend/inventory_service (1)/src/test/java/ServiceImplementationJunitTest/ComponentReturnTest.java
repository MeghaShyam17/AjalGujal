// package ServiceImplementationJunitTest;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.sql.Timestamp;
// import java.util.Arrays;
// import java.util.Collections;
// import java.util.List;
// import java.util.Optional;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.ArgumentCaptor;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import com.ilp.inventory_service.Client.NotificationFeignClient;
// import com.ilp.inventory_service.Client.ProjectClient;
// import com.ilp.inventory_service.Client.UserClient;
// import com.ilp.inventory_service.Dto.ComponentReturnDto;
// import com.ilp.inventory_service.Dto.ComponentReturnItemResponseDto;
// import com.ilp.inventory_service.Dto.ComponentReturnResponseDto;
// import com.ilp.inventory_service.Dto.NotificationRequestDto;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;
// import com.ilp.inventory_service.Dto.UserDto;
// import com.ilp.inventory_service.Entity.ComponentReturnEntity;
// import com.ilp.inventory_service.Entity.ComponentReturnItemEntity;
// import com.ilp.inventory_service.Entity.InventoryEntity;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.ComponentReturnItemRepository;
// import com.ilp.inventory_service.Repository.ComponentReturnRepository;
// import com.ilp.inventory_service.ServiceImplementation.ComponentReturnItemServiceImplementation;
// import com.ilp.inventory_service.ServiceImplementation.ComponentReturnServiceImplementation;

// @ExtendWith(MockitoExtension.class)
// public class ComponentReturnTest {

//     @Mock
//     private ComponentReturnRepository componentReturnRepository;

//     @Mock
//     private ComponentReturnItemRepository componentReturnItemRepository;

//     @Mock
//     private ProjectClient projectClient;

//     @Mock
//     private UserClient userClient;

//     @Mock
//     private NotificationFeignClient notificationFeignClient;

//     @InjectMocks
//     private ComponentReturnServiceImplementation componentReturnService;

//     @InjectMocks
//     private ComponentReturnItemServiceImplementation componentReturnItemService;

//     private ComponentReturnDto componentReturnDto;

//     private ComponentReturnEntity componentReturnEntity;

//     private ComponentReturnItemEntity componentReturnItemEntity;

//     private InventoryEntity inventory;

//     private ProjectTeamDto project;

//     private UserDto returnedByUser;

//     private UserDto facultyUser;

//     private UserDto receivedByUser;

//     @BeforeEach
//     void setUp() {

//         componentReturnDto = new ComponentReturnDto();
//         componentReturnDto.setProjectId(1L);
//         componentReturnDto.setReturnedBy(10L);
//         componentReturnDto.setRemarks(
//                 "Returning project components");

//         project = new ProjectTeamDto();
//         project.setProjectId(1);
//         project.setProjectName(
//                 "Inventory Management Project");
//         project.setFacultyId(20);
//         project.setProjectStatus("ACTIVE");

//         returnedByUser = new UserDto(
//                 10L,
//                 "Student User",
//                 "student@example.com",
//                 "STUDENT",
//                 "9876543210"
//         );

//         facultyUser = new UserDto(
//                 20L,
//                 "Faculty User",
//                 "faculty@example.com",
//                 "FACULTY",
//                 "9876543211"
//         );

//         receivedByUser = new UserDto(
//                 30L,
//                 "Inventory Admin",
//                 "admin@example.com",
//                 "ADMIN",
//                 "9876543212"
//         );

//         inventory = new InventoryEntity();
//         inventory.setItemId(50L);

//         componentReturnItemEntity =
//                 createComponentReturnItemEntity(
//                         200L,
//                         "GOOD"
//                 );

//         componentReturnEntity =
//                 createComponentReturnEntity(
//                         100L,
//                         "PENDING"
//                 );
//     }

//     @Test
//     void createComponentReturn_ShouldCreateSuccessfully() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(userClient.getUserById(20))
//                 .thenReturn(facultyUser);

//         when(componentReturnRepository.save(
//                 any(ComponentReturnEntity.class)))
//                 .thenAnswer(invocation -> {

//                     ComponentReturnEntity entity =
//                             invocation.getArgument(0);

//                     entity.setComponentReturnId(100L);

//                     return entity;
//                 });

//         ComponentReturnResponseDto response =
//                 componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto);

//         assertNotNull(response);
//         assertEquals(
//                 Long.valueOf(100L),
//                 response.getComponentReturnId());
//         assertEquals(
//                 Long.valueOf(1L),
//                 response.getProjectId());
//         assertEquals(
//                 Long.valueOf(10L),
//                 response.getReturnedBy());
//         assertEquals(
//                 "PENDING",
//                 response.getReturnStatus());
//         assertEquals(
//                 "Returning project components",
//                 response.getRemarks());
//         assertNotNull(response.getReturnCode());
//         assertNotNull(response.getReturnDate());
//         assertNotNull(response.getCreatedAt());

//         verify(projectClient, times(1))
//                 .getProjectById(1);

//         verify(userClient, times(1))
//                 .getUserById(10);

//         verify(userClient, times(1))
//                 .getUserById(20);

//         verify(componentReturnRepository, times(1))
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, times(1))
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentReturn_ShouldSendCorrectNotification() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(userClient.getUserById(20))
//                 .thenReturn(facultyUser);

//         when(componentReturnRepository.save(
//                 any(ComponentReturnEntity.class)))
//                 .thenAnswer(invocation -> {

//                     ComponentReturnEntity entity =
//                             invocation.getArgument(0);

//                     entity.setComponentReturnId(100L);

//                     return entity;
//                 });

//         componentReturnService.createComponentReturn(
//                 componentReturnDto);

//         ArgumentCaptor<NotificationRequestDto> captor =
//                 ArgumentCaptor.forClass(
//                         NotificationRequestDto.class);

//         verify(notificationFeignClient)
//                 .createNotification(captor.capture());

//         NotificationRequestDto notification =
//                 captor.getValue();

//         assertNotNull(notification);

//         assertEquals(
//                 Integer.valueOf(20),
//                 notification.getUserId());

//         assertEquals(
//                 "New Component Return",
//                 notification.getTitle());

//         assertEquals(
//                 "COMPONENT_RETURN_CREATED",
//                 notification.getNotificationType());

//         assertEquals(
//                 "INVENTORY",
//                 notification.getModuleName());

//         assertEquals(
//                 Integer.valueOf(100),
//                 notification.getReferenceId());

//         assertEquals(
//                 "HIGH",
//                 notification.getPriority());

//         assertEquals(
//                 Integer.valueOf(10),
//                 notification.getCreatedBy());
//     }

//     @Test
//     void createComponentReturn_ShouldThrowException_WhenDtoIsNull() {

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentReturnService
//                         .createComponentReturn(null)
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentReturn_ShouldThrowException_WhenProjectIdIsNull() {

//         componentReturnDto.setProjectId(null);

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto)
//         );

//         verify(projectClient, never())
//                 .getProjectById(any(Integer.class));

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));
//     }

//     @Test
//     void createComponentReturn_ShouldThrowException_WhenProjectNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto)
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentReturn_ShouldThrowException_WhenReturnedByIsNull() {

//         componentReturnDto.setReturnedBy(null);

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto)
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));
//     }

//     @Test
//     void createComponentReturn_ShouldThrowException_WhenReturnedUserNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(10))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto)
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentReturn_ShouldThrowException_WhenFacultyNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(userClient.getUserById(20))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto)
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentReturn_ShouldNotSendNotification_WhenFacultyIdIsNull() {

//         project.setFacultyId(null);

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(componentReturnRepository.save(
//                 any(ComponentReturnEntity.class)))
//                 .thenAnswer(invocation -> {

//                     ComponentReturnEntity entity =
//                             invocation.getArgument(0);

//                     entity.setComponentReturnId(100L);

//                     return entity;
//                 });

//         ComponentReturnResponseDto response =
//                 componentReturnService
//                         .createComponentReturn(
//                                 componentReturnDto);

//         assertNotNull(response);

//         assertEquals(
//                 "PENDING",
//                 response.getReturnStatus());

//         verify(userClient, never())
//                 .getUserById(20);

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void getById_ShouldReturnComponentReturn() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         ComponentReturnResponseDto response =
//                 componentReturnService.getById(100L);

//         assertNotNull(response);

//         assertEquals(
//                 Long.valueOf(100L),
//                 response.getComponentReturnId());

//         assertEquals(
//                 "CR-100",
//                 response.getReturnCode());

//         assertEquals(
//                 Long.valueOf(1L),
//                 response.getProjectId());

//         assertEquals(
//                 Long.valueOf(10L),
//                 response.getReturnedBy());

//         assertEquals(
//                 "PENDING",
//                 response.getReturnStatus());

//         verify(componentReturnRepository, times(1))
//                 .findById(100L);
//     }

//     @Test
//     void getById_ShouldThrowException_WhenReturnNotFound() {

//         when(componentReturnRepository.findById(999L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .getById(999L)
//         );

//         verify(componentReturnRepository, times(1))
//                 .findById(999L);
//     }

//     @Test
//     void getAll_ShouldReturnAllComponentReturns() {

//         ComponentReturnEntity secondEntity =
//                 createComponentReturnEntity(
//                         101L,
//                         "RECEIVED"
//                 );

//         when(componentReturnRepository.findAll())
//                 .thenReturn(
//                         Arrays.asList(
//                                 componentReturnEntity,
//                                 secondEntity
//                         ));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService.getAll();

//         assertNotNull(responses);
//         assertEquals(2, responses.size());

//         assertEquals(
//                 Long.valueOf(100L),
//                 responses.get(0)
//                         .getComponentReturnId());

//         assertEquals(
//                 Long.valueOf(101L),
//                 responses.get(1)
//                         .getComponentReturnId());

//         verify(componentReturnRepository, times(1))
//                 .findAll();
//     }

//     @Test
//     void getAll_ShouldReturnEmptyList_WhenNoReturnsExist() {

//         when(componentReturnRepository.findAll())
//                 .thenReturn(Collections.emptyList());

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService.getAll();

//         assertNotNull(responses);
//         assertEquals(0, responses.size());
//     }

//     @Test
//     void getByProjectId_ShouldReturnMatchingReturns() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(componentReturnRepository.findByProjectId(1L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnEntity));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService
//                         .getByProjectId(1L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 Long.valueOf(1L),
//                 responses.get(0)
//                         .getProjectId());

//         verify(projectClient, times(1))
//                 .getProjectById(1);

//         verify(componentReturnRepository, times(1))
//                 .findByProjectId(1L);
//     }

//     @Test
//     void getByProjectId_ShouldThrowException_WhenProjectNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .getByProjectId(1L)
//         );

//         verify(componentReturnRepository, never())
//                 .findByProjectId(any(Long.class));
//     }

//     @Test
//     void getByReturnedBy_ShouldReturnMatchingReturns() {

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(componentReturnRepository.findByReturnedBy(10L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnEntity));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService
//                         .getByReturnedBy(10L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 Long.valueOf(10L),
//                 responses.get(0)
//                         .getReturnedBy());

//         verify(userClient, times(1))
//                 .getUserById(10);

//         verify(componentReturnRepository, times(1))
//                 .findByReturnedBy(10L);
//     }

//     @Test
//     void getByReturnedBy_ShouldThrowException_WhenUserNotFound() {

//         when(userClient.getUserById(10))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .getByReturnedBy(10L)
//         );

//         verify(componentReturnRepository, never())
//                 .findByReturnedBy(any(Long.class));
//     }

//     @Test
//     void getByReceivedBy_ShouldReturnMatchingReturns() {

//         componentReturnEntity.setReceivedBy(30L);
//         componentReturnEntity.setReturnStatus("RECEIVED");

//         when(userClient.getUserById(30))
//                 .thenReturn(receivedByUser);

//         when(componentReturnRepository.findByReceivedBy(30L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnEntity));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService
//                         .getByReceivedBy(30L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 Long.valueOf(30L),
//                 responses.get(0)
//                         .getReceivedBy());

//         verify(userClient, times(1))
//                 .getUserById(30);

//         verify(componentReturnRepository, times(1))
//                 .findByReceivedBy(30L);
//     }

//     @Test
//     void getByReceivedBy_ShouldThrowException_WhenUserNotFound() {

//         when(userClient.getUserById(30))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .getByReceivedBy(30L)
//         );

//         verify(componentReturnRepository, never())
//                 .findByReceivedBy(any(Long.class));
//     }

//     @Test
//     void getByRequestId_ShouldReturnMatchingReturns() {

//         when(componentReturnRepository
//                 .findByComponentRequestComponentRequestId(50L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnEntity));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService
//                         .getByRequestId(50L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         verify(componentReturnRepository, times(1))
//                 .findByComponentRequestComponentRequestId(
//                         50L);
//     }

//     @Test
//     void getPendingReturns_ShouldReturnPendingReturns() {

//         when(componentReturnRepository
//                 .findByReturnStatus("PENDING"))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnEntity));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService
//                         .getPendingReturns();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 "PENDING",
//                 responses.get(0)
//                         .getReturnStatus());

//         verify(componentReturnRepository, times(1))
//                 .findByReturnStatus("PENDING");
//     }

//     @Test
//     void getReceivedReturns_ShouldReturnReceivedReturns() {

//         ComponentReturnEntity receivedEntity =
//                 createComponentReturnEntity(
//                         101L,
//                         "RECEIVED"
//                 );

//         receivedEntity.setReceivedBy(30L);

//         when(componentReturnRepository
//                 .findByReturnStatus("RECEIVED"))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 receivedEntity));

//         List<ComponentReturnResponseDto> responses =
//                 componentReturnService
//                         .getReceivedReturns();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 "RECEIVED",
//                 responses.get(0)
//                         .getReturnStatus());

//         assertEquals(
//                 Long.valueOf(30L),
//                 responses.get(0)
//                         .getReceivedBy());

//         verify(componentReturnRepository, times(1))
//                 .findByReturnStatus("RECEIVED");
//     }

//     @Test
//     void receiveReturn_ShouldReceiveSuccessfully() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         when(userClient.getUserById(30))
//                 .thenReturn(receivedByUser);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(componentReturnRepository.save(
//                 any(ComponentReturnEntity.class)))
//                 .thenAnswer(invocation ->
//                         invocation.getArgument(0));

//         ComponentReturnResponseDto response =
//                 componentReturnService
//                         .receiveReturn(
//                                 100L,
//                                 30L
//                         );

//         assertNotNull(response);

//         assertEquals(
//                 Long.valueOf(100L),
//                 response.getComponentReturnId());

//         assertEquals(
//                 Long.valueOf(30L),
//                 response.getReceivedBy());

//         assertEquals(
//                 "RECEIVED",
//                 response.getReturnStatus());

//         verify(componentReturnRepository, times(1))
//                 .save(componentReturnEntity);

//         verify(notificationFeignClient, times(1))
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void receiveReturn_ShouldSendCorrectNotification() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         when(userClient.getUserById(30))
//                 .thenReturn(receivedByUser);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(componentReturnRepository.save(
//                 any(ComponentReturnEntity.class)))
//                 .thenAnswer(invocation ->
//                         invocation.getArgument(0));

//         componentReturnService.receiveReturn(
//                 100L,
//                 30L
//         );

//         ArgumentCaptor<NotificationRequestDto> captor =
//                 ArgumentCaptor.forClass(
//                         NotificationRequestDto.class);

//         verify(notificationFeignClient)
//                 .createNotification(captor.capture());

//         NotificationRequestDto notification =
//                 captor.getValue();

//         assertNotNull(notification);

//         assertEquals(
//                 Integer.valueOf(10),
//                 notification.getUserId());

//         assertEquals(
//                 "Component Return Received",
//                 notification.getTitle());

//         assertEquals(
//                 "COMPONENT_RETURN_RECEIVED",
//                 notification.getNotificationType());

//         assertEquals(
//                 "INVENTORY",
//                 notification.getModuleName());

//         assertEquals(
//                 Integer.valueOf(100),
//                 notification.getReferenceId());

//         assertEquals(
//                 "HIGH",
//                 notification.getPriority());

//         assertEquals(
//                 Integer.valueOf(30),
//                 notification.getCreatedBy());
//     }

//     @Test
//     void receiveReturn_ShouldThrowException_WhenReturnNotFound() {

//         when(componentReturnRepository.findById(999L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .receiveReturn(
//                                 999L,
//                                 30L
//                         )
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void receiveReturn_ShouldThrowException_WhenReceivedUserNotFound() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         when(userClient.getUserById(30))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .receiveReturn(
//                                 100L,
//                                 30L
//                         )
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void receiveReturn_ShouldThrowException_WhenReturnedUserNotFound() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         when(userClient.getUserById(30))
//                 .thenReturn(receivedByUser);

//         when(userClient.getUserById(10))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .receiveReturn(
//                                 100L,
//                                 30L
//                         )
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void receiveReturn_ShouldThrowException_WhenProjectNotFound() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         when(userClient.getUserById(30))
//                 .thenReturn(receivedByUser);

//         when(userClient.getUserById(10))
//                 .thenReturn(returnedByUser);

//         when(projectClient.getProjectById(1))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .receiveReturn(
//                                 100L,
//                                 30L
//                         )
//         );

//         verify(componentReturnRepository, never())
//                 .save(any(ComponentReturnEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void delete_ShouldDeleteComponentReturn() {

//         when(componentReturnRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentReturnEntity));

//         componentReturnService.delete(100L);

//         verify(componentReturnRepository, times(1))
//                 .findById(100L);

//         verify(componentReturnRepository, times(1))
//                 .delete(componentReturnEntity);
//     }

//     @Test
//     void delete_ShouldThrowException_WhenReturnNotFound() {

//         when(componentReturnRepository.findById(999L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnService
//                         .delete(999L)
//         );

//         verify(componentReturnRepository, never())
//                 .delete(any(ComponentReturnEntity.class));
//     }

//     @Test
//     void returnItemGetById_ShouldReturnItem() {

//         when(componentReturnItemRepository.findById(200L))
//                 .thenReturn(
//                         Optional.of(
//                                 componentReturnItemEntity));

//         ComponentReturnItemResponseDto response =
//                 componentReturnItemService
//                         .getById(200L);

//         assertNotNull(response);

//         assertEquals(
//                 Long.valueOf(200L),
//                 response.getReturnItemId());

//         assertEquals(
//                 Long.valueOf(50L),
//                 response.getItemId());

//         assertEquals(
//                 5,
//                 response.getIssuedQuantity());

//         assertEquals(
//                 4,
//                 response.getReturnedQuantity());

//         assertEquals(
//                 1,
//                 response.getConsumedQuantity());

//         assertEquals(
//                 0,
//                 response.getDamagedQuantity());

//         assertEquals(
//                 "GOOD",
//                 response.getCondition());

//         assertEquals(
//                 "Returned successfully",
//                 response.getRemarks());

//         verify(componentReturnItemRepository, times(1))
//                 .findById(200L);
//     }

//     @Test
//     void returnItemGetById_ShouldThrowException_WhenNotFound() {

//         when(componentReturnItemRepository.findById(999L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentReturnItemService
//                         .getById(999L)
//         );

//         verify(componentReturnItemRepository, times(1))
//                 .findById(999L);
//     }

//     @Test
//     void returnItemGetAll_ShouldReturnAllItems() {

//         ComponentReturnItemEntity secondItem =
//                 createComponentReturnItemEntity(
//                         201L,
//                         "DAMAGED"
//                 );

//         when(componentReturnItemRepository.findAll())
//                 .thenReturn(
//                         Arrays.asList(
//                                 componentReturnItemEntity,
//                                 secondItem
//                         ));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService.getAll();

//         assertNotNull(responses);
//         assertEquals(2, responses.size());

//         assertEquals(
//                 Long.valueOf(200L),
//                 responses.get(0)
//                         .getReturnItemId());

//         assertEquals(
//                 Long.valueOf(201L),
//                 responses.get(1)
//                         .getReturnItemId());

//         verify(componentReturnItemRepository, times(1))
//                 .findAll();
//     }

//     @Test
//     void returnItemGetByComponentReturnId_ShouldReturnItems() {

//         when(componentReturnItemRepository
//                 .getReturnItems(100L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnItemEntity));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService
//                         .getByComponentReturnId(100L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 Long.valueOf(200L),
//                 responses.get(0)
//                         .getReturnItemId());

//         verify(componentReturnItemRepository, times(1))
//                 .getReturnItems(100L);
//     }

//     @Test
//     void returnItemGetByItemId_ShouldReturnItems() {

//         when(componentReturnItemRepository
//                 .findByInventoryItemId(50L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnItemEntity));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService
//                         .getByItemId(50L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 Long.valueOf(50L),
//                 responses.get(0)
//                         .getItemId());

//         verify(componentReturnItemRepository, times(1))
//                 .findByInventoryItemId(50L);
//     }

//     @Test
//     void returnItemGetByCondition_ShouldReturnItems() {

//         when(componentReturnItemRepository
//                 .findByCondition("GOOD"))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentReturnItemEntity));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService
//                         .getByCondition("GOOD");

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 "GOOD",
//                 responses.get(0)
//                         .getCondition());

//         verify(componentReturnItemRepository, times(1))
//                 .findByCondition("GOOD");
//     }

//     @Test
//     void returnItemGetDamagedItems_ShouldReturnDamagedItems() {

//         ComponentReturnItemEntity damagedItem =
//                 createComponentReturnItemEntity(
//                         201L,
//                         "DAMAGED"
//                 );

//         damagedItem.setReturnedQuantity(3);
//         damagedItem.setConsumedQuantity(0);
//         damagedItem.setDamagedQuantity(2);

//         when(componentReturnItemRepository
//                 .getDamagedItems())
//                 .thenReturn(
//                         Collections.singletonList(
//                                 damagedItem));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService
//                         .getDamagedItems();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 "DAMAGED",
//                 responses.get(0)
//                         .getCondition());

//         assertEquals(
//                 2,
//                 responses.get(0)
//                         .getDamagedQuantity());

//         verify(componentReturnItemRepository, times(1))
//                 .getDamagedItems();
//     }

//     @Test
//     void returnItemGetConsumedItems_ShouldReturnConsumedItems() {

//         ComponentReturnItemEntity consumedItem =
//                 createComponentReturnItemEntity(
//                         202L,
//                         "CONSUMED"
//                 );

//         consumedItem.setReturnedQuantity(2);
//         consumedItem.setConsumedQuantity(3);
//         consumedItem.setDamagedQuantity(0);

//         when(componentReturnItemRepository
//                 .getConsumedItems())
//                 .thenReturn(
//                         Collections.singletonList(
//                                 consumedItem));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService
//                         .getConsumedItems();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());

//         assertEquals(
//                 "CONSUMED",
//                 responses.get(0)
//                         .getCondition());

//         assertEquals(
//                 3,
//                 responses.get(0)
//                         .getConsumedQuantity());

//         verify(componentReturnItemRepository, times(1))
//                 .getConsumedItems();
//     }

//     @Test
//     void returnItemGetInventoryReturnHistory_ShouldReturnHistory() {

//         ComponentReturnItemEntity previousItem =
//                 createComponentReturnItemEntity(
//                         199L,
//                         "GOOD"
//                 );

//         when(componentReturnItemRepository
//                 .getInventoryReturnHistory(50L))
//                 .thenReturn(
//                         Arrays.asList(
//                                 previousItem,
//                                 componentReturnItemEntity
//                         ));

//         List<ComponentReturnItemResponseDto> responses =
//                 componentReturnItemService
//                         .getInventoryReturnHistory(50L);

//         assertNotNull(responses);
//         assertEquals(2, responses.size());

//         assertEquals(
//                 Long.valueOf(50L),
//                 responses.get(0)
//                         .getItemId());

//         assertEquals(
//                 Long.valueOf(50L),
//                 responses.get(1)
//                         .getItemId());

//         verify(componentReturnItemRepository, times(1))
//                 .getInventoryReturnHistory(50L);
//     }

//     private ComponentReturnEntity createComponentReturnEntity(
//             Long componentReturnId,
//             String returnStatus) {

//         ComponentReturnEntity entity =
//                 new ComponentReturnEntity();

//         entity.setComponentReturnId(
//                 componentReturnId);

//         entity.setReturnCode(
//                 "CR-" + componentReturnId);

//         entity.setProjectId(1L);
//         entity.setReturnedBy(10L);
//         entity.setReturnStatus(returnStatus);

//         entity.setRemarks(
//                 "Returning project components");

//         entity.setReturnDate(
//                 new Timestamp(
//                         System.currentTimeMillis()));

//         entity.setCreatedAt(
//                 new Timestamp(
//                         System.currentTimeMillis()));

//         entity.setReturnItems(
//                 Collections.emptyList());

//         return entity;
//     }

//     private ComponentReturnItemEntity createComponentReturnItemEntity(
//             Long returnItemId,
//             String condition) {

//         ComponentReturnItemEntity entity =
//                 new ComponentReturnItemEntity();

//         entity.setReturnItemId(returnItemId);
//         entity.setInventory(inventory);
//         entity.setIssuedQuantity(5);
//         entity.setReturnedQuantity(4);
//         entity.setConsumedQuantity(1);
//         entity.setDamagedQuantity(0);
//         entity.setCondition(condition);

//         entity.setRemarks(
//                 "Returned successfully");

//         return entity;
//     }
// }