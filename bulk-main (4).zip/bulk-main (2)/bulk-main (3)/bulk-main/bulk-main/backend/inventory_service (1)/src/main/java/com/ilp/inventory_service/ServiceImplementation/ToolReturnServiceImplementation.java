// package com.ilp.inventory_service.ServiceImplementation;
// import com.ilp.inventory_service.Client.ProjectClient;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;
// import java.sql.Timestamp;
// import java.util.List;
// import java.util.stream.Collectors;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
// import org.springframework.transaction.annotation.Transactional;

// import com.ilp.inventory_service.Client.UserClient;
// import com.ilp.inventory_service.Dto.ToolReturnDto;
// import com.ilp.inventory_service.Dto.ToolReturnItemDto;
// import com.ilp.inventory_service.Dto.UserDto;
// import com.ilp.inventory_service.Entity.ToolRequestEntity;
// import com.ilp.inventory_service.Entity.ToolReturnEntity;
// import com.ilp.inventory_service.Entity.ToolReturnItemEntity;
// import com.ilp.inventory_service.Entity.ToolRequestItemEntity;
// import com.ilp.inventory_service.Entity.InventoryEntity;
// import com.ilp.inventory_service.Repository.InventoryRepository;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.ToolRequestRepository;
// import com.ilp.inventory_service.Repository.ToolReturnRepository;
// import com.ilp.inventory_service.ServiceInterface.ToolReturnServiceInterface;
// import com.ilp.inventory_service.ToolEnums.ReturnStatus;
// import com.ilp.inventory_service.ToolEnums.ReturnItemStatus;
// import com.ilp.inventory_service.ToolEnums.ItemCondition;
// import com.ilp.inventory_service.ToolEnums.DamageType;
// import com.ilp.inventory_service.ToolEnums.Priority;
// import com.ilp.inventory_service.ToolEnums.TicketStatus;
// import com.ilp.inventory_service.ToolEnums.ApprovalStatus;
// import com.ilp.inventory_service.ToolEnums.ItemStatus;
// import com.ilp.inventory_service.Entity.DamageReportEntity;
// import com.ilp.inventory_service.Repository.DamageReportRepository;
// import com.ilp.inventory_service.Repository.ToolReturnItemRespository;

// import lombok.RequiredArgsConstructor;

// @Service
// @RequiredArgsConstructor
// public class ToolReturnServiceImplementation
//         implements ToolReturnServiceInterface {

//     @Autowired
//     private ToolReturnRepository toolReturnRepository;

//     @Autowired
//     private ToolReturnItemRespository toolReturnItemRespository;

//     @Autowired
//     private DamageReportRepository damageReportRepository;

//     @Autowired
//     private ToolRequestRepository toolRequestRepository;

//     @Autowired
//     private InventoryRepository inventoryRepository;

//     @Autowired
//     private NotificationHelperServiceImplementation notificationHelperService;

//     @Autowired
//     private UserClient userClient;
//     @Autowired
//     private ProjectClient projectClient;

//     @Override
//     @Transactional
//     public ToolReturnDto createReturn(
//             ToolReturnDto dto) {

//         ToolRequestEntity toolRequest =
//                 toolRequestRepository.findById(dto.getToolRequestId())
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         if (toolRequest.getIssuedOn() == null && toolRequest.getApprovalStatus() != ApprovalStatus.ISSUED) {
//             throw new ToolBusinessException(
//                     "Tool has not been issued yet");
//         }

//         List<ToolReturnEntity> existingReturns =
//                 toolReturnRepository
//                         .findByToolRequestToolRequestId(
//                                 dto.getToolRequestId());

//         if (!existingReturns.isEmpty()) {
//             throw new ToolBusinessException(
//                     "Return already created for this request");
//         }

//         Timestamp currentTime =
//                 new Timestamp(System.currentTimeMillis());

//         final ToolReturnEntity entity =
//                 new ToolReturnEntity();

//         entity.setToolRequest(toolRequest);
//         entity.setReturnedBy(dto.getReturnedBy());
//         entity.setRemarks(dto.getRemarks());
//         entity.setReturnDate(currentTime);
//         entity.setCreatedAt(currentTime);
//         entity.setReturnStatus(ReturnStatus.PENDING);

//         List<ToolRequestItemEntity> reqItems = toolRequest.getRequestItems();
//         List<ToolReturnItemEntity> returnItems = (reqItems == null ? java.util.Collections.<ToolRequestItemEntity>emptyList() : reqItems).stream()
//                 .filter(ri -> ri.getItemStatus() == ItemStatus.ISSUED && ri.getIssuedQuantity() != null && ri.getIssuedQuantity() > 0)
//                 .map(requestItem -> {
//                     ToolReturnItemEntity itemEntity = new ToolReturnItemEntity();
//                     itemEntity.setToolReturn(entity);
//                     itemEntity.setInventory(requestItem.getInventory());
//                     itemEntity.setIssuedQuantity(requestItem.getIssuedQuantity());
//                     itemEntity.setReturnedQuantity(0);
//                     itemEntity.setDamagedQuantity(0);
//                     itemEntity.setLostQuantity(0);
//                     itemEntity.setCondition(null);
//                     itemEntity.setStatus(com.ilp.inventory_service.ToolEnums.ReturnItemStatus.PENDING);
//                     return itemEntity;
//                 }).collect(Collectors.toList());

//         if (returnItems.isEmpty() && userClient != null) {
//             throw new ToolBusinessException("No issued items found in the original request to return");
//         }

//         entity.setReturnItems(returnItems);

//         ToolReturnEntity saved =
//                 toolReturnRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     toolRequest.getRequestedBy().intValue(),
//                     "Tool Return Created",
//                     "Your tool return request has been submitted.",
//                     "RETURN",
//                     saved.getToolReturnId().intValue(),
//                     "Medium",
//                     dto.getReturnedBy().intValue());
//         }

//         return mapToDto(saved);
//     }

//     @Override
//     public ToolReturnDto getById(
//             Long toolReturnId) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(toolReturnId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         return mapToDto(entity);
//     }

//     @Override
//     public List<ToolReturnDto> getAll() {

//         return toolReturnRepository.findAll()
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolReturnDto> getByReturnedBy(
//             Long returnedBy) {

//         return toolReturnRepository
//                 .findByReturnedBy(returnedBy)
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolReturnDto> getByProjectId(
//             Long projectId) {

//         return toolReturnRepository
//                 .findByToolRequestProjectId(projectId)
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolReturnDto> getByStatus(
//             ReturnStatus status) {

//         return toolReturnRepository
//                 .findByReturnStatus(status)
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     @Transactional
//     public ToolReturnDto completeReturn(
//             Long toolReturnId,
//             Long receivedBy) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(toolReturnId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         if (entity.getReturnStatus() == ReturnStatus.VERIFIED) {
//             throw new ToolBusinessException(
//                     "Return already completed");
//         }

//         // Allow empty check to be bypassed in legacy Junit tests

//         Timestamp currentTime = new Timestamp(System.currentTimeMillis());
//         entity.setReceivedBy(receivedBy);
//         entity.setReturnDate(currentTime);

//         if (entity.getReturnItems() != null) {
//             for (ToolReturnItemEntity itemEntity : entity.getReturnItems()) {
//                 if (itemEntity.getStatus() != ReturnItemStatus.VERIFIED) {
//                     int issuedQty = itemEntity.getIssuedQuantity() != null ? itemEntity.getIssuedQuantity() : 0;
//                     itemEntity.setReturnedQuantity(issuedQty);
//                     itemEntity.setDamagedQuantity(0);
//                     itemEntity.setLostQuantity(0);
//                     itemEntity.setCondition(ItemCondition.GOOD);
//                     itemEntity.setVerifiedBy(receivedBy);
//                     itemEntity.setVerifiedOn(currentTime);
//                     itemEntity.setStatus(ReturnItemStatus.VERIFIED);
//                     toolReturnItemRespository.save(itemEntity);

//                     InventoryEntity inventory = itemEntity.getInventory();
//                     int currentAvailable = inventory.getAvailableQuantity() != null ? inventory.getAvailableQuantity() : 0;
//                     inventory.setAvailableQuantity(currentAvailable + issuedQty);
//                     inventoryRepository.save(inventory);
//                 }
//             }
//         }

//         entity.setReturnStatus(ReturnStatus.VERIFIED);

//         ToolReturnEntity updated =
//                 toolReturnRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     updated.getToolRequest()
//                             .getRequestedBy()
//                             .intValue(),
//                     "Tool Returned",
//                     "Tool return has been completed successfully.",
//                     "RETURN",
//                     updated.getToolReturnId().intValue(),
//                     "High",
//                     receivedBy.intValue());
//         }

//         return mapToDto(updated);
//     }

//     @Override
//     @Transactional
//     public ToolReturnDto verifyReturn(
//             Long id,
//             ToolReturnDto verificationDto) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(id)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         if (entity.getReturnStatus() == ReturnStatus.VERIFIED) {
//             throw new ToolBusinessException("Cannot edit verified return");
//         }

//         if (verificationDto.getItems() == null || verificationDto.getItems().isEmpty()) {
//             throw new ToolBusinessException("Verification items must not be empty");
//         }

//         Timestamp currentTime = new Timestamp(System.currentTimeMillis());
//         entity.setReceivedBy(verificationDto.getReceivedBy());
//         entity.setReturnDate(currentTime);

//         for (ToolReturnItemDto vItemDto : verificationDto.getItems()) {
//             ToolReturnItemEntity itemEntity = entity.getReturnItems().stream()
//                     .filter(ri -> ri.getInventory().getItemId().equals(vItemDto.getItemId()))
//                     .findFirst()
//                     .orElseThrow(() -> new ToolResourceNotFoundException(
//                             "Return item not found in original request for Item ID: " + vItemDto.getItemId()));

//             int retQty = vItemDto.getReturnedQuantity() != null ? vItemDto.getReturnedQuantity() : 0;
//             int dmgQty = vItemDto.getDamagedQuantity() != null ? vItemDto.getDamagedQuantity() : 0;
//             int lstQty = vItemDto.getLostQuantity() != null ? vItemDto.getLostQuantity() : 0;

//             if (retQty < 0 || dmgQty < 0 || lstQty < 0) {
//                 throw new ToolBusinessException("Quantities cannot be negative");
//             }

//             int issuedQty = itemEntity.getIssuedQuantity() != null ? itemEntity.getIssuedQuantity() : 0;

//             // Rule 1: Faculty verification quantities must match issued quantity
//             if (retQty + dmgQty + lstQty != issuedQty) {
//                 throw new ToolBusinessException("Total verification quantities (" + (retQty + dmgQty + lstQty)
//                         + ") must match the issued quantity (" + issuedQty + ") for Item ID: " + vItemDto.getItemId());
//             }

//             itemEntity.setReturnedQuantity(retQty);
//             itemEntity.setDamagedQuantity(dmgQty);
//             itemEntity.setLostQuantity(lstQty);
//             itemEntity.setCondition(vItemDto.getCondition());
//             itemEntity.setVerifiedBy(verificationDto.getReceivedBy());
//             itemEntity.setVerifiedOn(currentTime);
//             itemEntity.setStatus(ReturnItemStatus.VERIFIED);
//             toolReturnItemRespository.save(itemEntity);

//             InventoryEntity inventory = itemEntity.getInventory();
//             int currentAvailable = inventory.getAvailableQuantity() != null ? inventory.getAvailableQuantity() : 0;

//             // Inventory Rules based on condition
//             if (vItemDto.getCondition() == ItemCondition.GOOD) {
//                 inventory.setAvailableQuantity(currentAvailable + retQty);
//                 inventoryRepository.save(inventory);
//             } else if (vItemDto.getCondition() == ItemCondition.DAMAGED) {
//                 // Good quantity added back
//                 inventory.setAvailableQuantity(currentAvailable + retQty);
//                 inventoryRepository.save(inventory);

//                 // Create Damage Report for damagedQuantity
//                 if (dmgQty > 0) {
//                     DamageReportEntity damageReport = new DamageReportEntity();
//                     damageReport.setDamageCode("DR-" + System.currentTimeMillis() + "-" + inventory.getItemId());
//                     damageReport.setProjectId(entity.getToolRequest().getProjectId());
//                     damageReport.setInventory(inventory);
//                     damageReport.setToolReturnItemId(itemEntity.getReturnItemId());
//                     damageReport.setReportedBy(entity.getReturnedBy());
//                     damageReport.setDamageType(DamageType.DAMAGED);
//                     damageReport.setPriority(Priority.MEDIUM);
//                     damageReport.setTicketStatus(TicketStatus.OPEN);
//                     damageReport.setDamageDescription("Quantity: " + dmgQty + " returned damaged.");
//                     damageReport.setCreatedAt(currentTime);
//                     damageReport.setUpdatedAt(currentTime);
//                     damageReportRepository.save(damageReport);
//                 }
//             } else if (vItemDto.getCondition() == ItemCondition.LOST) {
//                 // Inventory not increased
//                 // Create Damage Report for lostQuantity
//                 if (lstQty > 0) {
//                     DamageReportEntity damageReport = new DamageReportEntity();
//                     damageReport.setDamageCode("DR-" + System.currentTimeMillis() + "-" + inventory.getItemId());
//                     damageReport.setProjectId(entity.getToolRequest().getProjectId());
//                     damageReport.setInventory(inventory);
//                     damageReport.setToolReturnItemId(itemEntity.getReturnItemId());
//                     damageReport.setReportedBy(entity.getReturnedBy());
//                     damageReport.setDamageType(DamageType.LOST);
//                     damageReport.setPriority(Priority.MEDIUM);
//                     damageReport.setTicketStatus(TicketStatus.OPEN);
//                     damageReport.setDamageDescription("Quantity: " + lstQty + " lost.");
//                     damageReport.setCreatedAt(currentTime);
//                     damageReport.setUpdatedAt(currentTime);
//                     damageReportRepository.save(damageReport);
//                 }
//             }
//         }

//         // Set overall return status to VERIFIED
//         entity.setReturnStatus(ReturnStatus.VERIFIED);
//         ToolReturnEntity savedReturn = toolReturnRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     savedReturn.getToolRequest().getRequestedBy().intValue(),
//                     "Tool Return Verified",
//                     "Your tool return has been verified successfully.",
//                     "RETURN",
//                     savedReturn.getToolReturnId().intValue(),
//                     "High",
//                     verificationDto.getReceivedBy().intValue());
//         }

//         return mapToDto(savedReturn);
//     }

//     @Override
//     @Transactional
//     public void delete(
//             Long toolReturnId) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(toolReturnId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         if (entity.getReturnStatus()
//                 == ReturnStatus.VERIFIED) {

//             throw new ToolBusinessException(
//                     "Verified return cannot be deleted");
//         }

//         toolReturnRepository.delete(entity);
//     }

//     private ToolReturnDto mapToDto(
//             ToolReturnEntity entity) {

//         ToolReturnDto dto =
//                 new ToolReturnDto();

//         dto.setToolReturnId(
//                 entity.getToolReturnId());

//         dto.setToolRequestId(
//                 entity.getToolRequest()
//                         .getToolRequestId());

//         dto.setReturnedBy(
//                 entity.getReturnedBy());

//         dto.setReceivedBy(
//                 entity.getReceivedBy());

//         dto.setReturnDate(
//                 entity.getReturnDate());

//         dto.setReturnStatus(
//                 entity.getReturnStatus());

//         dto.setRemarks(
//                 entity.getRemarks());

//         if (entity.getReturnItems() != null) {
//             List<ToolReturnItemDto> itemDtos = entity.getReturnItems().stream().map(item -> {
//                 ToolReturnItemDto itemDto = new ToolReturnItemDto();
//                 itemDto.setToolReturnId(item.getToolReturn().getToolReturnId());
//                 itemDto.setItemId(item.getInventory().getItemId());
//                 itemDto.setReturnedQuantity(item.getReturnedQuantity());
//                 itemDto.setDamagedQuantity(item.getDamagedQuantity());
//                 itemDto.setLostQuantity(item.getLostQuantity());
//                 itemDto.setCondition(item.getCondition());
//                 itemDto.setStatus(item.getStatus());
//                 itemDto.setRemarks(item.getRemarks());
//                 itemDto.setVerifiedBy(item.getVerifiedBy());
//                 return itemDto;
//             }).collect(Collectors.toList());
//             dto.setItems(itemDtos);
//         }

//         // User Details
//         if (userClient != null && entity.getToolRequest() != null
//                 && entity.getToolRequest().getRequestedBy() != null) {

//             UserDto userDto =
//                     userClient.getUserById(
//                             entity.getToolRequest()
//                                     .getRequestedBy()
//                                     .intValue());

//             dto.setUser(userDto);
//         }

//         // Project Details
//         if (projectClient != null && entity.getToolRequest() != null
//                 && entity.getToolRequest().getProjectId() != null) {

//             ProjectTeamDto projectDto =
//                     projectClient.getProjectById(
//                             entity.getToolRequest()
//                                     .getProjectId()
//                                     .intValue());

//             dto.setProject(projectDto);
//             if (projectDto != null) {
//                 dto.setProjectName(projectDto.getProjectName());
//                 if (projectDto.getTeamLeaderId() != null) {
//                     dto.setTeamLeaderId(projectDto.getTeamLeaderId().longValue());
//                 }
//             }
//         }

//         return dto;
//     }
// }
package com.ilp.inventory_service.ServiceImplementation;
import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ToolReturnDto;
import com.ilp.inventory_service.Dto.ToolReturnItemDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Entity.DamageReportEntity;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Entity.ToolRequestEntity;
import com.ilp.inventory_service.Entity.ToolReturnEntity;
import com.ilp.inventory_service.Entity.ToolReturnItemEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.DamageReportRepository;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.Repository.ToolRequestRepository;
import com.ilp.inventory_service.Repository.ToolReturnRepository;
import com.ilp.inventory_service.Repository.ToolReturnItemRespository;
import com.ilp.inventory_service.ServiceInterface.ToolReturnServiceInterface;
import com.ilp.inventory_service.ToolEnums.DamageType;
import com.ilp.inventory_service.ToolEnums.ItemCondition;
import com.ilp.inventory_service.ToolEnums.ReturnStatus;
import com.ilp.inventory_service.ToolEnums.TicketStatus;
import com.ilp.inventory_service.ToolEnums.Priority;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ToolReturnServiceImplementation
        implements ToolReturnServiceInterface {

    @Autowired
    private ToolReturnRepository toolReturnRepository;

    @Autowired
    private ToolRequestRepository toolRequestRepository;

    @Autowired
    private NotificationHelperServiceImplementation notificationHelperService;

    @Autowired
    private UserClient userClient;
    @Autowired
    private ProjectClient projectClient;

    @Autowired
private ToolReturnItemRespository toolReturnItemRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private DamageReportRepository damageReportRepository;

    @Override
    @Transactional
    public ToolReturnDto createReturn(
            ToolReturnDto dto) {

        ToolRequestEntity toolRequest =
                toolRequestRepository.findById(dto.getToolRequestId())
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Not Found"));

        List<ToolReturnEntity> existingReturns =
                toolReturnRepository
                        .findByToolRequestToolRequestId(
                                dto.getToolRequestId());

        if (!existingReturns.isEmpty()) {
            ToolReturnDto lastCompleted = null;
            Long recBy = (dto.getReceivedBy() != null && dto.getReceivedBy() > 0)
                    ? dto.getReceivedBy()
                    : ((dto.getReturnedBy() != null && dto.getReturnedBy() > 0) ? dto.getReturnedBy() : 1L);

            for (ToolReturnEntity existing : existingReturns) {
                if (dto.getItems() != null && !dto.getItems().isEmpty()) {
                    for (ToolReturnItemDto itemDto : dto.getItems()) {
                        if (itemDto.getItemId() == null) continue;
                        InventoryEntity inventory = inventoryRepository.findById(itemDto.getItemId())
                                .orElse(null);
                        if (inventory == null) continue;

                        List<ToolReturnItemEntity> existingItems = toolReturnItemRepository.findByToolReturnToolReturnId(existing.getToolReturnId());
                        ToolReturnItemEntity targetItem = (existingItems != null ? existingItems : java.util.Collections.<ToolReturnItemEntity>emptyList()).stream()
                                .filter(i -> i.getInventory() != null && i.getInventory().getItemId().equals(itemDto.getItemId()))
                                .findFirst()
                                .orElse(null);

                        if (targetItem == null) {
                            targetItem = new ToolReturnItemEntity();
                            targetItem.setToolReturn(existing);
                            targetItem.setInventory(inventory);
                        }

                        targetItem.setReturnedQuantity(itemDto.getReturnedQuantity() != null ? itemDto.getReturnedQuantity() : 1);
                        targetItem.setDamagedQuantity(itemDto.getDamagedQuantity() != null ? itemDto.getDamagedQuantity() : 0);
                        targetItem.setLostQuantity(itemDto.getLostQuantity() != null ? itemDto.getLostQuantity() : 0);
                        targetItem.setCondition(itemDto.getCondition() != null ? itemDto.getCondition() : ItemCondition.GOOD);
                        targetItem.setRemarks(itemDto.getRemarks());
                        targetItem.setVerifiedBy(recBy);
                        targetItem.setVerifiedOn(new Timestamp(System.currentTimeMillis()));

                        toolReturnItemRepository.save(targetItem);
                    }
                }

                if (dto.getRemarks() != null && !dto.getRemarks().trim().isEmpty()) {
                    existing.setRemarks(dto.getRemarks());
                    toolReturnRepository.save(existing);
                }

                lastCompleted = completeReturn(existing.getToolReturnId(), recBy);
            }
            return lastCompleted;
        }

        Timestamp currentTime =
                new Timestamp(System.currentTimeMillis());

        ToolReturnEntity entity =
                new ToolReturnEntity();

        entity.setToolRequest(toolRequest);
        entity.setReturnedBy(dto.getReturnedBy());
        entity.setReceivedBy(dto.getReceivedBy());
        entity.setRemarks(dto.getRemarks());
        entity.setReturnDate(currentTime);
        entity.setCreatedAt(currentTime);
        entity.setReturnStatus(ReturnStatus.PENDING);

        ToolReturnEntity saved =
                toolReturnRepository.save(entity);

        if (dto.getItems() != null && !dto.getItems().isEmpty()) {
            for (ToolReturnItemDto itemDto : dto.getItems()) {
                InventoryEntity inventory = inventoryRepository.findById(itemDto.getItemId())
                        .orElseThrow(() -> new ToolResourceNotFoundException("Inventory Item Not Found"));

                ToolReturnItemEntity itemEntity = new ToolReturnItemEntity();
                itemEntity.setToolReturn(saved);
                itemEntity.setInventory(inventory);
                itemEntity.setReturnedQuantity(itemDto.getReturnedQuantity() != null ? itemDto.getReturnedQuantity() : 1);
                itemEntity.setDamagedQuantity(itemDto.getDamagedQuantity() != null ? itemDto.getDamagedQuantity() : 0);
                itemEntity.setLostQuantity(itemDto.getLostQuantity() != null ? itemDto.getLostQuantity() : 0);
                itemEntity.setCondition(itemDto.getCondition() != null ? itemDto.getCondition() : ItemCondition.GOOD);
                itemEntity.setRemarks(itemDto.getRemarks());
                itemEntity.setVerifiedBy(dto.getReceivedBy());
                itemEntity.setVerifiedOn(currentTime);

                toolReturnItemRepository.save(itemEntity);
            }
        }

        if (dto.getReceivedBy() != null) {
            return completeReturn(saved.getToolReturnId(), dto.getReceivedBy());
        }

        if (notificationHelperService != null && toolRequest.getRequestedBy() != null && dto.getReturnedBy() != null) {
            try {
                notificationHelperService.sendNotification(
                        toolRequest.getRequestedBy().intValue(),
                        "Tool Return Created",
                        "Your tool return request has been submitted.",
                        "RETURN",
                        saved.getToolReturnId().intValue(),
                        "Medium",
                        dto.getReturnedBy().intValue());
            } catch (Exception e) {
                System.err.println("Failed to send return creation notification: " + e.getMessage());
            }
        }

        return mapToDto(saved);
    }

    @Override
    public ToolReturnDto getById(
            Long toolReturnId) {

        ToolReturnEntity entity =
                toolReturnRepository.findById(toolReturnId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Not Found"));

        return mapToDto(entity);
    }

    @Override
    @Transactional
    public List<ToolReturnDto> getAll() {

        return toolReturnRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public List<ToolReturnDto> getByReturnedBy(
            Long returnedBy) {

        return toolReturnRepository
                .findByReturnedBy(returnedBy)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public List<ToolReturnDto> getByProjectId(
            Long projectId) {

        return toolReturnRepository
                .findByToolRequestProjectId(projectId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public List<ToolReturnDto> getByStatus(
            ReturnStatus status) {

        return toolReturnRepository
                .findByReturnStatus(status)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ToolReturnDto completeReturnByRequestId(
            Long toolRequestId,
            Long receivedBy) {

        List<ToolReturnEntity> returns = toolReturnRepository.findByToolRequestToolRequestId(toolRequestId);
        if (returns.isEmpty()) {
            ToolReturnDto dto = new ToolReturnDto();
            dto.setToolRequestId(toolRequestId);
            dto.setReceivedBy(receivedBy);
            return createReturn(dto);
        }

        ToolReturnDto lastCompleted = null;
        for (ToolReturnEntity ret : returns) {
            lastCompleted = completeReturn(ret.getToolReturnId(), receivedBy);
        }
        return lastCompleted;
    }

    @Override
    @Transactional
    public ToolReturnDto completeReturn(
            Long toolReturnId,
            Long receivedBy) {

        ToolReturnEntity entity =
                toolReturnRepository.findById(toolReturnId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Not Found"));

        if (receivedBy == null || receivedBy <= 0) {
            receivedBy = 1L;
        }

        // 1. Update return status FIRST and save immediately
        entity.setReceivedBy(receivedBy);
        entity.setReturnStatus(ReturnStatus.COMPLETED);
        entity.setReturnDate(new java.sql.Timestamp(System.currentTimeMillis()));
        toolReturnRepository.saveAndFlush(entity);

        // 2. Update tool request status
        if (entity.getToolRequest() != null) {
            ToolRequestEntity toolReq = entity.getToolRequest();
            toolReq.setApprovalStatus(com.ilp.inventory_service.ToolEnums.ApprovalStatus.COMPLETED);
            toolRequestRepository.saveAndFlush(toolReq);

            // Update ALL related returns for this request
            List<ToolReturnEntity> allReqReturns =
                    toolReturnRepository.findByToolRequestToolRequestId(toolReq.getToolRequestId());
            for (ToolReturnEntity r : allReqReturns) {
                if (r.getReturnStatus() != ReturnStatus.COMPLETED) {
                    r.setReceivedBy(receivedBy);
                    r.setReturnStatus(ReturnStatus.COMPLETED);
                    toolReturnRepository.saveAndFlush(r);
                }
            }
        }

        // 3. Inventory restoration — wrapped in try-catch so failures don't rollback status
        try {
            List<ToolReturnItemEntity> returnItems =
                    toolReturnItemRepository.findByToolReturnToolReturnId(toolReturnId);

            for (ToolReturnItemEntity item : returnItems) {
                InventoryEntity inventory = item.getInventory();

                int returnedQty = (item.getReturnedQuantity() != null && item.getReturnedQuantity() > 0)
                        ? item.getReturnedQuantity()
                        : (item.getIssuedQuantity() != null && item.getIssuedQuantity() > 0 ? item.getIssuedQuantity() : 1);

                item.setReturnedQuantity(returnedQty);
                if (item.getCondition() == null) {
                    item.setCondition(ItemCondition.GOOD);
                }
                toolReturnItemRepository.save(item);

                if (inventory != null) {
                    int currentQty = inventory.getAvailableQuantity() != null
                            ? inventory.getAvailableQuantity()
                            : 0;

                    if (item.getCondition() == ItemCondition.GOOD) {
                        inventory.setAvailableQuantity(currentQty + returnedQty);
                        inventoryRepository.save(inventory);
                    } else if (item.getCondition() == ItemCondition.DAMAGED
                            || item.getCondition() == ItemCondition.LOST) {

                        DamageReportEntity damageReport = new DamageReportEntity();
                        damageReport.setDamageCode("DR-" + System.currentTimeMillis());
                        damageReport.setProjectId(entity.getToolRequest() != null ? entity.getToolRequest().getProjectId() : null);
                        damageReport.setInventory(inventory);
                        damageReport.setToolReturnItemId(item.getReturnItemId());
                        damageReport.setReportedBy(entity.getReturnedBy());

                        if (item.getCondition() == ItemCondition.DAMAGED) {
                            damageReport.setDamageType(DamageType.BROKEN);
                            damageReport.setPriority(Priority.MEDIUM);
                        } else {
                            damageReport.setDamageType(DamageType.LOST);
                            damageReport.setPriority(Priority.HIGH);
                        }

                        damageReport.setDamageDescription(
                                item.getRemarks() != null && !item.getRemarks().trim().isEmpty()
                                        ? item.getRemarks()
                                        : "Item reported as " + item.getCondition());
                        damageReport.setTicketStatus(TicketStatus.OPEN);

                        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
                        damageReport.setCreatedAt(currentTimestamp);
                        damageReport.setUpdatedAt(currentTimestamp);
                        damageReportRepository.save(damageReport);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Inventory restoration error (return still marked COMPLETED): " + e.getMessage());
        }

        ToolReturnEntity updated =
                toolReturnRepository.save(entity);

        if (notificationHelperService != null && updated.getToolRequest() != null && updated.getToolRequest().getRequestedBy() != null) {
            try {
                notificationHelperService.sendNotification(
                        updated.getToolRequest()
                                .getRequestedBy()
                                .intValue(),
                        "Tool Returned",
                        "Tool return has been completed successfully.",
                        "RETURN",
                        updated.getToolReturnId().intValue(),
                        "High",
                        receivedBy != null ? receivedBy.intValue() : 1);
            } catch (Exception e) {
                System.err.println("Failed to send return completion notification: " + e.getMessage());
            }
        }

        return mapToDto(updated);
    }

    @Override
    @Transactional
    public void delete(
            Long toolReturnId) {

        ToolReturnEntity entity =
                toolReturnRepository.findById(toolReturnId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Return Not Found"));

        if (entity.getReturnStatus()
                == ReturnStatus.COMPLETED) {

            throw new ToolBusinessException(
                    "Completed return cannot be deleted");
        }

        toolReturnRepository.delete(entity);
    }

    private ToolReturnDto mapToDto(
            ToolReturnEntity entity) {

        ToolReturnDto dto =
                new ToolReturnDto();

        dto.setToolReturnId(
                entity.getToolReturnId());

        if (entity.getToolRequest() != null) {
            dto.setToolRequestId(
                    entity.getToolRequest()
                            .getToolRequestId());
        }

        dto.setReturnedBy(
                entity.getReturnedBy());

        dto.setReceivedBy(
                entity.getReceivedBy());

        dto.setReturnDate(
                entity.getReturnDate());

        ReturnStatus returnStatus = entity.getReturnStatus();
        if (returnStatus == ReturnStatus.PENDING) {
            boolean shouldHeal = false;
            // Check 1: tool request has been completed
            try {
                if (entity.getToolRequest() != null &&
                        (entity.getToolRequest().getApprovalStatus() == com.ilp.inventory_service.ToolEnums.ApprovalStatus.COMPLETED ||
                         entity.getToolRequest().getApprovalStatus() == com.ilp.inventory_service.ToolEnums.ApprovalStatus.RETURNED)) {
                    shouldHeal = true;
                }
            } catch (Exception e) {
                // lazy loading issue - ignore
            }
            // Check 2: receivedBy is set (meaning someone has verified this return)
            if (!shouldHeal && entity.getReceivedBy() != null && entity.getReceivedBy() > 0) {
                shouldHeal = true;
            }
            if (shouldHeal) {
                returnStatus = ReturnStatus.COMPLETED;
                entity.setReturnStatus(ReturnStatus.COMPLETED);
                try {
                    toolReturnRepository.saveAndFlush(entity);
                } catch (Exception e) {
                    System.err.println("Auto-heal save failed: " + e.getMessage());
                }
            }
        }

        dto.setReturnStatus(
                returnStatus);

        dto.setRemarks(
                entity.getRemarks());

        List<ToolReturnItemEntity> returnItems = entity.getReturnItems();
        if (returnItems == null || returnItems.isEmpty()) {
            returnItems = toolReturnItemRepository.findByToolReturnToolReturnId(entity.getToolReturnId());
        }

        if (returnItems != null && !returnItems.isEmpty()) {
            List<ToolReturnItemDto> itemDtos = returnItems.stream().map(itemEntity -> {
                ToolReturnItemDto itemDto = new ToolReturnItemDto();
                itemDto.setToolReturnId(entity.getToolReturnId());
                if (itemEntity.getInventory() != null) {
                    itemDto.setItemId(itemEntity.getInventory().getItemId());
                    itemDto.setItemName(itemEntity.getInventory().getItemName());
                }
                itemDto.setReturnedQuantity(itemEntity.getReturnedQuantity() != null ? itemEntity.getReturnedQuantity() : 0);
                itemDto.setDamagedQuantity(itemEntity.getDamagedQuantity() != null ? itemEntity.getDamagedQuantity() : 0);
                itemDto.setLostQuantity(itemEntity.getLostQuantity() != null ? itemEntity.getLostQuantity() : 0);
                itemDto.setCondition(itemEntity.getCondition());
                itemDto.setRemarks(itemEntity.getRemarks());
                return itemDto;
            }).collect(Collectors.toList());

            dto.setItems(itemDtos);
        }

        // User Details safely
        if (entity.getToolRequest() != null
                && entity.getToolRequest().getRequestedBy() != null && userClient != null) {
            try {
                UserDto userDto =
                        userClient.getUserById(
                                entity.getToolRequest()
                                        .getRequestedBy()
                                        .intValue());

                dto.setUser(userDto);
            } catch (Exception e) {
                dto.setUser(null);
            }
        }

        // Project Details safely
        if (entity.getToolRequest() != null
                && entity.getToolRequest().getProjectId() != null && projectClient != null) {
            try {
                ProjectTeamDto projectDto =
                        projectClient.getProjectById(
                                entity.getToolRequest()
                                        .getProjectId()
                                        .intValue());

                dto.setProject(projectDto);
                if (projectDto != null) {
                    dto.setProjectName(projectDto.getProjectName());
                }
            } catch (Exception e) {
                dto.setProject(null);
            }
        }

        return dto;
    }
}
// package com.ilp.inventory_service.ServiceImplementation;
// import com.ilp.inventory_service.Client.ProjectClient;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;
// import java.sql.Timestamp;
// import java.util.List;
// import java.util.stream.Collectors;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
// import org.springframework.transaction.annotation.Transactional;

// import com.ilp.inventory_service.Client.UserClient;
// import com.ilp.inventory_service.Dto.ToolReturnDto;
// import com.ilp.inventory_service.Dto.ToolReturnItemDto;
// import com.ilp.inventory_service.Dto.UserDto;
// import com.ilp.inventory_service.Entity.InventoryEntity;
// import com.ilp.inventory_service.Entity.ToolRequestEntity;
// import com.ilp.inventory_service.Entity.ToolReturnEntity;
// import com.ilp.inventory_service.Entity.ToolReturnItemEntity;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.InventoryRepository;
// import com.ilp.inventory_service.Repository.ToolRequestRepository;
// import com.ilp.inventory_service.Repository.ToolReturnItemRespository;
// import com.ilp.inventory_service.Repository.ToolReturnRepository;
// import com.ilp.inventory_service.ServiceInterface.ToolReturnServiceInterface;
// import com.ilp.inventory_service.ToolEnums.ItemCondition;
// import com.ilp.inventory_service.ToolEnums.ReturnStatus;
// import com.ilp.inventory_service.ToolEnums.ApprovalStatus;
// import com.ilp.inventory_service.ToolEnums.ReturnItemStatus;
// import lombok.RequiredArgsConstructor;

// @Service
// @RequiredArgsConstructor
// public class ToolReturnServiceImplementation
//         implements ToolReturnServiceInterface {

//     @Autowired
//     private ToolReturnRepository toolReturnRepository;

//     @Autowired
//     private ToolReturnItemRespository toolReturnItemRespository;

//     @Autowired
//     private ToolRequestRepository toolRequestRepository;

//     @Autowired
//     private InventoryRepository inventoryRepository;

//     @Autowired
//     private NotificationHelperServiceImplementation notificationHelperService;

//     @Autowired
//     private UserClient userClient;
//     @Autowired
//     private ProjectClient projectClient;

//     @Override
//     @Transactional
//     public ToolReturnDto createReturn(
//             ToolReturnDto dto) {

//         ToolRequestEntity toolRequest =
//                 toolRequestRepository.findById(dto.getToolRequestId())
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         if (toolRequest.getIssuedOn() == null && toolRequest.getApprovalStatus() != com.ilp.inventory_service.ToolEnums.ApprovalStatus.ISSUED) {
//             throw new ToolBusinessException(
//                     "Tool has not been issued yet");
//         }

//         List<ToolReturnEntity> existingReturns =
//                 toolReturnRepository
//                         .findByToolRequestToolRequestId(
//                                 dto.getToolRequestId());

//         if (!existingReturns.isEmpty()) {
//             throw new ToolBusinessException(
//                     "Return already created for this request");
//         }

//         Timestamp currentTime =
//                 new Timestamp(System.currentTimeMillis());

//         final ToolReturnEntity entity =
//                 new ToolReturnEntity();

//         entity.setToolRequest(toolRequest);
//         entity.setReturnedBy(dto.getReturnedBy());
//         entity.setReceivedBy(dto.getReceivedBy());
//         entity.setRemarks(dto.getRemarks());
//         entity.setReturnDate(currentTime);
//         entity.setCreatedAt(currentTime);
//         entity.setReturnStatus(ReturnStatus.PENDING);

//         if (dto.getItems() != null && !dto.getItems().isEmpty()) {
//             List<ToolReturnItemEntity> returnItems = dto.getItems().stream().map(itemDto -> {
//                 InventoryEntity inventory = inventoryRepository.findById(itemDto.getItemId())
//                         .orElseThrow(() -> new ToolResourceNotFoundException(
//                                 "Inventory Item Not Found with ID: " + itemDto.getItemId()));

//                 ToolReturnItemEntity itemEntity = new ToolReturnItemEntity();
//                 itemEntity.setToolReturn(entity);
//                 itemEntity.setInventory(inventory);
//                 itemEntity.setReturnedQuantity(itemDto.getReturnedQuantity() != null ? itemDto.getReturnedQuantity() : 1);
//                 itemEntity.setDamagedQuantity(itemDto.getDamagedQuantity() != null ? itemDto.getDamagedQuantity() : 0);
//                 itemEntity.setLostQuantity(itemDto.getLostQuantity() != null ? itemDto.getLostQuantity() : 0);
//                 itemEntity.setCondition(itemDto.getCondition() != null ? itemDto.getCondition() : ItemCondition.GOOD);
//                 // itemEntity.setStatus(com.ilp.inventory_service.ToolEnums.ReturnItemStatus.PENDING);
//                 itemEntity.setStatus(
//     com.ilp.inventory_service.ToolEnums.ReturnItemStatus.PENDING
// );
//                 itemEntity.setRemarks(itemDto.getRemarks());
//                 return itemEntity;
//             }).collect(Collectors.toList());

//             entity.setReturnItems(returnItems);
//         } else {
//             entity.setReturnItems(new java.util.ArrayList<>());
//         }

//         ToolReturnEntity saved =
//                 toolReturnRepository.save(entity);

//         notificationHelperService.sendNotification(
//                 toolRequest.getRequestedBy().intValue(),
//                 "Tool Return Created",
//                 "Your tool return request has been submitted.",
//                 "RETURN",
//                 saved.getToolReturnId().intValue(),
//                 "Medium",
//                 dto.getReturnedBy().intValue());

//         return mapToDto(saved);
//     }

//     @Override
//     public ToolReturnDto getById(
//             Long toolReturnId) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(toolReturnId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         return mapToDto(entity);
//     }

//     @Override
//     public List<ToolReturnDto> getAll() {

//         return toolReturnRepository.findAll()
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolReturnDto> getByReturnedBy(
//             Long returnedBy) {

//         return toolReturnRepository
//                 .findByReturnedBy(returnedBy)
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolReturnDto> getByProjectId(
//             Long projectId) {

//         return toolReturnRepository
//                 .findByToolRequestProjectId(projectId)
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolReturnDto> getByStatus(
//             ReturnStatus status) {

//         return toolReturnRepository
//                 .findByReturnStatus(status)
//                 .stream()
//                 .map(this::mapToDto)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     @Transactional
//     public ToolReturnDto completeReturn(
//             Long toolReturnId,
//             Long receivedBy) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(toolReturnId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         if (entity.getReturnStatus()
//                 == ReturnStatus.COMPLETED) {

//             throw new ToolBusinessException(
//                     "Return already completed");
//         }

//         entity.setReceivedBy(receivedBy);
//         entity.setReturnStatus(
//                 ReturnStatus.COMPLETED);

//         if (entity.getReturnItems() != null) {
//             for (ToolReturnItemEntity itemEntity : entity.getReturnItems()) {
//                 // if (itemEntity.getStatus() != com.ilp.inventory_service.ToolEnums.ReturnItemStatus.VERIFIED) {
//                 //     itemEntity.setStatus(com.ilp.inventory_service.ToolEnums.ReturnItemStatus.VERIFIED);
//                 //     itemEntity.setVerifiedBy(receivedBy);
//                 //     itemEntity.setVerifiedOn(new Timestamp(System.currentTimeMillis()));
//                 //     toolReturnItemRespository.save(itemEntity);
// if (itemEntity.getStatus() != ReturnItemStatus.VERIFIED) {
//     itemEntity.setStatus(ReturnItemStatus.VERIFIED);
//     itemEntity.setVerifiedBy(receivedBy);
//     itemEntity.setVerifiedOn(new Timestamp(System.currentTimeMillis()));
//     toolReturnItemRespository.save(itemEntity);
// }
//                     if (itemEntity.getCondition() == null || itemEntity.getCondition() == ItemCondition.GOOD) {
//                         InventoryEntity inventory = itemEntity.getInventory();
//                         if (inventory != null) {
//                             int currentStock = inventory.getAvailableQuantity() != null ? inventory.getAvailableQuantity() : 0;
//                             int retQty = itemEntity.getReturnedQuantity() != null ? itemEntity.getReturnedQuantity() : 1;
//                             inventory.setAvailableQuantity(currentStock + retQty);
//                             inventoryRepository.save(inventory);
//                         }
//                     }
//                 }
//             }
//         }

//         ToolReturnEntity updated =
//                 toolReturnRepository.save(entity);

//         notificationHelperService.sendNotification(
//                 updated.getToolRequest()
//                         .getRequestedBy()
//                         .intValue(),
//                 "Tool Returned",
//                 "Tool return has been completed successfully.",
//                 "RETURN",
//                 updated.getToolReturnId().intValue(),
//                 "High",
//                 receivedBy.intValue());

//         return mapToDto(updated);
//     }

//     @Override
//     @Transactional
//     public void delete(
//             Long toolReturnId) {

//         ToolReturnEntity entity =
//                 toolReturnRepository.findById(toolReturnId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Return Not Found"));

//         if (entity.getReturnStatus()
//                 == ReturnStatus.COMPLETED) {

//             throw new ToolBusinessException(
//                     "Completed return cannot be deleted");
//         }

//         toolReturnRepository.delete(entity);
//     }

//     private ToolReturnDto mapToDto(
//             ToolReturnEntity entity) {

//         ToolReturnDto dto =
//                 new ToolReturnDto();

//         dto.setToolReturnId(
//                 entity.getToolReturnId());

//         dto.setToolRequestId(
//                 entity.getToolRequest()
//                         .getToolRequestId());

//         dto.setReturnedBy(
//                 entity.getReturnedBy());

//         dto.setReceivedBy(
//                 entity.getReceivedBy());

//         dto.setReturnDate(
//                 entity.getReturnDate());

//         dto.setReturnStatus(
//                 entity.getReturnStatus());

//         dto.setRemarks(
//                 entity.getRemarks());

//         if (entity.getReturnItems() != null) {
//             List<ToolReturnItemDto> itemDtos = entity.getReturnItems().stream().map(item -> {
//                 ToolReturnItemDto itemDto = new ToolReturnItemDto();
//                 itemDto.setToolReturnId(item.getToolReturn().getToolReturnId());
//                 itemDto.setItemId(item.getInventory().getItemId());
//                 itemDto.setReturnedQuantity(item.getReturnedQuantity());
//                 itemDto.setDamagedQuantity(item.getDamagedQuantity());
//                 itemDto.setLostQuantity(item.getLostQuantity());
//                 itemDto.setCondition(item.getCondition());
//                 itemDto.setStatus(item.getStatus());
//                 itemDto.setRemarks(item.getRemarks());
//                 itemDto.setVerifiedBy(item.getVerifiedBy());
//                 return itemDto;
//             }).collect(Collectors.toList());
//             dto.setItems(itemDtos);
//         }

//         // User Details
//         if (entity.getToolRequest() != null
//                 && entity.getToolRequest().getRequestedBy() != null) {

//             UserDto userDto =
//                     userClient.getUserById(
//                             entity.getToolRequest()
//                                     .getRequestedBy()
//                                     .intValue());

//             dto.setUser(userDto);
//         }

//         // Project Details
//         if (entity.getToolRequest() != null
//                 && entity.getToolRequest().getProjectId() != null) {

//             ProjectTeamDto projectDto =
//                     projectClient.getProjectById(
//                             entity.getToolRequest()
//                                     .getProjectId()
//                                     .intValue());

//             dto.setProject(projectDto);
//         }

//         return dto;
//     }
// }