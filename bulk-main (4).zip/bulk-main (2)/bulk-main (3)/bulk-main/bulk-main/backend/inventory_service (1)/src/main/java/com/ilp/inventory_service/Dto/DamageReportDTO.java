package com.ilp.inventory_service.Dto;

import java.sql.Timestamp;

public class DamageReportDTO {

    private Long damageId;
    private String damageCode;
    private Long projectId;

    // Store only itemId instead of entire InventoryEntity
    private Long itemId;

    private Long equipmentId;
    private Long toolReturnItemId;
    private Long componentReturnItemId;
    private Long reportedBy;
    private Long assignedTo;
    private String damageType;
    private String priority;
    private String ticketStatus;
    private String damageDescription;
    private String resolutionNotes;
    private Long verifiedBy;
    private Timestamp verifiedOn;
    private Timestamp resolvedOn;
    private Timestamp closedOn;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public DamageReportDTO() {
    }

    public Long getDamageId() {
        return damageId;
    }

    public void setDamageId(Long damageId) {
        this.damageId = damageId;
    }

    public String getDamageCode() {
        return damageCode;
    }

    public void setDamageCode(String damageCode) {
        this.damageCode = damageCode;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Long getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(Long equipmentId) {
        this.equipmentId = equipmentId;
    }

    public Long getToolReturnItemId() {
        return toolReturnItemId;
    }

    public void setToolReturnItemId(Long toolReturnItemId) {
        this.toolReturnItemId = toolReturnItemId;
    }

    public Long getComponentReturnItemId() {
        return componentReturnItemId;
    }

    public void setComponentReturnItemId(Long componentReturnItemId) {
        this.componentReturnItemId = componentReturnItemId;
    }

    public Long getReportedBy() {
        return reportedBy;
    }

    public void setReportedBy(Long reportedBy) {
        this.reportedBy = reportedBy;
    }

    public Long getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(Long assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getDamageType() {
        return damageType;
    }

    public void setDamageType(String damageType) {
        this.damageType = damageType;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getTicketStatus() {
        return ticketStatus;
    }

    public void setTicketStatus(String ticketStatus) {
        this.ticketStatus = ticketStatus;
    }

    public String getDamageDescription() {
        return damageDescription;
    }

    public void setDamageDescription(String damageDescription) {
        this.damageDescription = damageDescription;
    }

    public String getResolutionNotes() {
        return resolutionNotes;
    }

    public void setResolutionNotes(String resolutionNotes) {
        this.resolutionNotes = resolutionNotes;
    }

    public Long getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(Long verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Timestamp getVerifiedOn() {
        return verifiedOn;
    }

    public void setVerifiedOn(Timestamp verifiedOn) {
        this.verifiedOn = verifiedOn;
    }

    public Timestamp getResolvedOn() {
        return resolvedOn;
    }

    public void setResolvedOn(Timestamp resolvedOn) {
        this.resolvedOn = resolvedOn;
    }

    public Timestamp getClosedOn() {
        return closedOn;
    }

    public void setClosedOn(Timestamp closedOn) {
        this.closedOn = closedOn;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}