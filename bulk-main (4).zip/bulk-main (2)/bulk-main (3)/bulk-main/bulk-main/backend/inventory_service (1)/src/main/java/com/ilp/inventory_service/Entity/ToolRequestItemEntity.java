package com.ilp.inventory_service.Entity;



import com.ilp.inventory_service.ToolEnums.ItemStatus;

import jakarta.persistence.*;

@Entity
@Table(name = "tool_request_item")
public class ToolRequestItemEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tool_request_item_id")
    private Long toolRequestItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tool_request_id")
    private ToolRequestEntity toolRequest;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id")
    private InventoryEntity inventory;

    @Column(name = "requested_quantity")
    private Integer requestedQuantity;

    @Column(name = "approved_quantity")
    private Integer approvedQuantity;

    @Column(name = "issued_quantity")
    private Integer issuedQuantity;

    @Enumerated(EnumType.STRING)
    @Column(name = "item_status")
    private ItemStatus itemStatus;

    public ToolRequestItemEntity() {
    }

    public Long getToolRequestItemId() {
        return toolRequestItemId;
    }

    public void setToolRequestItemId(Long toolRequestItemId) {
        this.toolRequestItemId = toolRequestItemId;
    }

    public ToolRequestEntity getToolRequest() {
        return toolRequest;
    }

    public void setToolRequest(ToolRequestEntity toolRequest) {
        this.toolRequest = toolRequest;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public Integer getRequestedQuantity() {
        return requestedQuantity;
    }

    public void setRequestedQuantity(Integer requestedQuantity) {
        this.requestedQuantity = requestedQuantity;
    }

    public Integer getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(Integer approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public ItemStatus getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(ItemStatus itemStatus) {
        this.itemStatus = itemStatus;
    }
}