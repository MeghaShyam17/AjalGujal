package com.ilp.inventory_service.Controller;



import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.ToolEnums.ReturnStatus;
import com.ilp.inventory_service.Dto.ToolReturnDto;
import com.ilp.inventory_service.ServiceInterface.ToolReturnServiceInterface;

import java.util.List;

@RestController
@RequestMapping("/api/tool-returns")

@RequiredArgsConstructor
public class ToolReturnController {
@Autowired
    private  ToolReturnServiceInterface toolReturnService;

    @PostMapping
    public ToolReturnDto createReturn(
            @RequestBody ToolReturnDto dto) {

        return toolReturnService.createReturn(dto);
    }

    @GetMapping("/{id}")
    public ToolReturnDto getById(
            @PathVariable Long id) {

        return toolReturnService.getById(id);
    }

    @GetMapping
    public List<ToolReturnDto> getAll() {

        return toolReturnService.getAll();
    }

    @GetMapping("/returnedBy/{returnedBy}")
    public List<ToolReturnDto> getByReturnedBy(
            @PathVariable Long returnedBy) {

        return toolReturnService.getByReturnedBy(returnedBy);
    }

    @GetMapping("/project/{projectId}")
    public List<ToolReturnDto> getByProjectId(
            @PathVariable Long projectId) {

        return toolReturnService.getByProjectId(projectId);
    }

    @GetMapping("/status/{status}")
    public List<ToolReturnDto> getByStatus(
            @PathVariable ReturnStatus status) {

        return toolReturnService.getByStatus(status);
    }

    @PutMapping("/{toolReturnId}/complete")
    public ToolReturnDto completeReturn(
            @PathVariable Long toolReturnId,
            @RequestParam Long receivedBy) {

        return toolReturnService.completeReturn(
                toolReturnId,
                receivedBy);
    }

    @PutMapping("/request/{toolRequestId}/complete")
    public ToolReturnDto completeReturnByRequestId(
            @PathVariable Long toolRequestId,
            @RequestParam Long receivedBy) {

        return toolReturnService.completeReturnByRequestId(
                toolRequestId,
                receivedBy);
    }

    @DeleteMapping("/{id}")
    public void delete(
            @PathVariable Long id) {

        toolReturnService.delete(id);
    }
}

