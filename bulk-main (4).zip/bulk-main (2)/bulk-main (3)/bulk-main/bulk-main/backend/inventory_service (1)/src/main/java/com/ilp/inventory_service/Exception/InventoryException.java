package com.ilp.inventory_service.Exception;

public class InventoryException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public InventoryException() {
        super();
    }

    public InventoryException(String message) {
        super(message);
    }

    public InventoryException(String message, Throwable cause) {
        super(message, cause);
    }

    public InventoryException(Throwable cause) {
        super(cause);
    }
}