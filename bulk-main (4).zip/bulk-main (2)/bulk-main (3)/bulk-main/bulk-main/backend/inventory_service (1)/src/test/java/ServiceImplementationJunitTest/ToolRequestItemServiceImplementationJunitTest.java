package ServiceImplementationJunitTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.ilp.inventory_service.Dto.ToolRequestItemDto;
import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Entity.ToolRequestEntity;
import com.ilp.inventory_service.Entity.ToolRequestItemEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.Repository.ToolRequestItemRepository;
import com.ilp.inventory_service.Repository.ToolRequestRepository;
import com.ilp.inventory_service.ServiceImplementation.ToolRequestItemServiceImplementation;
import com.ilp.inventory_service.ToolEnums.ItemStatus;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ToolRequestItemServiceImplementationJunitTest {

    @Mock
    private ToolRequestItemRepository toolRequestItemRepository;

    @Mock
    private ToolRequestRepository toolRequestRepository;

    @Mock
    private InventoryRepository inventoryRepository;

    @InjectMocks
    private ToolRequestItemServiceImplementation service;

    private ToolRequestItemDto dto;
    private ToolRequestEntity request;
    private InventoryEntity inventory;
    private ToolRequestItemEntity itemEntity;

    @BeforeEach
    void setUp() {

        request = new ToolRequestEntity();
        request.setToolRequestId(1L);

        inventory = new InventoryEntity();
        inventory.setItemId(100L);
        inventory.setAvailableQuantity(20);

        dto = new ToolRequestItemDto();
        dto.setToolRequestId(1L);
        dto.setItemId(100L);
        dto.setRequestedQuantity(5);

        itemEntity = new ToolRequestItemEntity();
        itemEntity.setToolRequestItemId(10L);
        itemEntity.setToolRequest(request);
        itemEntity.setInventory(inventory);
        itemEntity.setRequestedQuantity(5);
        itemEntity.setApprovedQuantity(0);
        itemEntity.setIssuedQuantity(0);
        itemEntity.setItemStatus(ItemStatus.PENDING);
    }

    // =================================
    // CREATE
    // =================================

    @Test
    void create_Success() {

        when(toolRequestRepository.findById(1L))
                .thenReturn(Optional.of(request));

        when(inventoryRepository.findById(100L))
                .thenReturn(Optional.of(inventory));

        when(toolRequestItemRepository.save(any()))
                .thenReturn(itemEntity);

        ToolRequestItemResponseDto response =
                service.create(dto);

        assertNotNull(response);
        assertEquals(5,
                response.getRequestedQuantity());

        verify(toolRequestItemRepository)
                .save(any());
    }

    @Test
    void create_RequestNotFound() {

        when(toolRequestRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.create(dto));
    }

    @Test
    void create_InventoryNotFound() {

        when(toolRequestRepository.findById(1L))
                .thenReturn(Optional.of(request));

        when(inventoryRepository.findById(100L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.create(dto));
    }

    @Test
    void create_InvalidQuantity() {

        dto.setRequestedQuantity(0);

        when(toolRequestRepository.findById(1L))
                .thenReturn(Optional.of(request));

        when(inventoryRepository.findById(100L))
                .thenReturn(Optional.of(inventory));

        assertThrows(
                ToolBusinessException.class,
                () -> service.create(dto));
    }

    // =================================
    // GET BY ID
    // =================================

    @Test
    void getById_Success() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        ToolRequestItemResponseDto response =
                service.getById(10L);

        assertEquals(
                10L,
                response.getToolRequestItemId());
    }

    @Test
    void getById_NotFound() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.getById(10L));
    }

    // =================================
    // GET ALL
    // =================================

    @Test
    void getAll_Success() {

        when(toolRequestItemRepository.findAll())
                .thenReturn(List.of(itemEntity));

        List<ToolRequestItemResponseDto> result =
                service.getAll();

        assertEquals(1, result.size());
    }

    @Test
    void getAll_EmptyList() {

        when(toolRequestItemRepository.findAll())
                .thenReturn(Collections.emptyList());

        List<ToolRequestItemResponseDto> result =
                service.getAll();

        assertTrue(result.isEmpty());
    }

    // =================================
    // GET BY TOOL REQUEST ID
    // =================================

    @Test
    void getByToolRequestId_Success() {

        when(toolRequestItemRepository
                .findByToolRequestToolRequestId(1L))
                .thenReturn(List.of(itemEntity));

        List<ToolRequestItemResponseDto> result =
                service.getByToolRequestId(1L);

        assertEquals(1, result.size());
    }

    @Test
    void getByToolRequestId_Empty() {

        when(toolRequestItemRepository
                .findByToolRequestToolRequestId(1L))
                .thenReturn(Collections.emptyList());

        List<ToolRequestItemResponseDto> result =
                service.getByToolRequestId(1L);

        assertTrue(result.isEmpty());
    }

    // =================================
    // APPROVE ITEM
    // =================================

    @Test
    void approveItem_Success() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        when(toolRequestItemRepository.save(any()))
                .thenReturn(itemEntity);

        ToolRequestItemResponseDto response =
                service.approveItem(10L, 5);

        assertNotNull(response);

        verify(toolRequestItemRepository)
                .save(any());
    }

    @Test
    void approveItem_NotFound() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.approveItem(10L, 5));
    }

    @Test
    void approveItem_NotPending() {

        itemEntity.setItemStatus(ItemStatus.APPROVED);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.approveItem(10L, 5));
    }

    @Test
    void approveItem_ZeroQuantity() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.approveItem(10L, 0));
    }

    @Test
    void approveItem_QuantityGreaterThanRequested() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.approveItem(10L, 10));
    }

    // =================================
    // ISSUE ITEM
    // =================================

    @Test
    void issueItem_Success() {

        itemEntity.setItemStatus(ItemStatus.APPROVED);
        itemEntity.setApprovedQuantity(5);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        when(toolRequestItemRepository.save(any()))
                .thenReturn(itemEntity);

        ToolRequestItemResponseDto response =
                service.issueItem(10L, 5);

        assertNotNull(response);

        verify(inventoryRepository)
                .save(any());

        verify(toolRequestItemRepository)
                .save(any());
    }

    @Test
    void issueItem_NotFound() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.issueItem(10L, 5));
    }

    @Test
    void issueItem_NotApproved() {

        itemEntity.setItemStatus(ItemStatus.PENDING);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.issueItem(10L, 2));
    }

    @Test
    void issueItem_ZeroQuantity() {

        itemEntity.setItemStatus(ItemStatus.APPROVED);
        itemEntity.setApprovedQuantity(5);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.issueItem(10L, 0));
    }

    @Test
    void issueItem_QuantityGreaterThanApproved() {

        itemEntity.setItemStatus(ItemStatus.APPROVED);
        itemEntity.setApprovedQuantity(5);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.issueItem(10L, 6));
    }

    @Test
    void issueItem_InsufficientStock() {

        itemEntity.setItemStatus(ItemStatus.APPROVED);
        itemEntity.setApprovedQuantity(5);

        inventory.setAvailableQuantity(2);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.issueItem(10L, 5));
    }

    // =================================
    // DELETE
    // =================================

    @Test
    void delete_Success() {

        itemEntity.setItemStatus(ItemStatus.APPROVED);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        service.delete(10L);

        verify(toolRequestItemRepository)
                .delete(itemEntity);
    }

    @Test
    void delete_NotFound() {

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.empty());

        assertThrows(
                ToolResourceNotFoundException.class,
                () -> service.delete(10L));
    }

    @Test
    void delete_IssuedItem() {

        itemEntity.setItemStatus(ItemStatus.ISSUED);

        when(toolRequestItemRepository.findById(10L))
                .thenReturn(Optional.of(itemEntity));

        assertThrows(
                ToolBusinessException.class,
                () -> service.delete(10L));
    }
}