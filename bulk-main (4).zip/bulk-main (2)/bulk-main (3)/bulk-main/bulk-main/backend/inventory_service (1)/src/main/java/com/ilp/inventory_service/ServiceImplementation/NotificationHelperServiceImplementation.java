package com.ilp.inventory_service.ServiceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.Client.NotificationFeignClient;
import com.ilp.inventory_service.Dto.NotificationRequestDto;

@Service
public class NotificationHelperServiceImplementation {

    @Autowired
    private NotificationFeignClient notificationFeignClient;

    public void sendNotification(
            Integer userId,
            String title,
            String message,
            String notificationType,
            Integer referenceId,
            String priority,
            Integer createdBy) {

        try {

            NotificationRequestDto notification =
                    new NotificationRequestDto();

            notification.setUserId(userId);
            notification.setTitle(title);
            notification.setMessage(message);
            notification.setNotificationType(notificationType);
            notification.setModuleName("INVENTORY");
            notification.setReferenceId(referenceId);
            notification.setPriority(priority);
            notification.setCreatedBy(createdBy);

            notificationFeignClient.createNotification(
                    notification);

        } catch (Exception e) {

            System.err.println(
                    "Failed to send notification: "
                            + e.getMessage());

            e.printStackTrace();
        }
    }
}