package ServiceImplementationJunitTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.inventory_service.Entity.DamageReportEntity;
import com.ilp.inventory_service.Exception.DamageReportException;
import com.ilp.inventory_service.Repository.DamageReportRepository;
import com.ilp.inventory_service.ServiceImplementation.DamageReportServiceImplementation;

@ExtendWith(MockitoExtension.class)
public class DamageReportServiceImplementationJunitTest {

    @Mock
    private DamageReportRepository damageReportRepository;

    @InjectMocks
    private DamageReportServiceImplementation damageReportService;

    private DamageReportEntity damageReport;

    @BeforeEach
    void setUp() {

        damageReport = new DamageReportEntity();

        damageReport.setDamageId(1L);
        damageReport.setDamageCode("DR001");
    }

    // ============================================
    // saveDamageReport()
    // ============================================

    @Test
    void saveDamageReportPositiveTestCase() {

        when(damageReportRepository.save(any()))
                .thenReturn(damageReport);

        DamageReportEntity result =
                damageReportService.saveDamageReport(
                        damageReport);

        assertNotNull(result);
        assertEquals("DR001",
                result.getDamageCode());
    }

    @Test
    void saveDamageReportNegativeTestCase() {

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .saveDamageReport(null));
    }

    @Test
    void saveDamageReportEdgeTestCase() {

        damageReport.setDamageCode("");

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .saveDamageReport(
                                damageReport));
    }

    // ============================================
    // getDamageReportById()
    // ============================================

    @Test
    void getDamageReportByIdPositiveTestCase() {

        when(damageReportRepository.findById(1L))
                .thenReturn(Optional.of(damageReport));

        DamageReportEntity result =
                damageReportService
                        .getDamageReportById(1L);

        assertNotNull(result);
    }

    @Test
    void getDamageReportByIdNegativeTestCase() {

        when(damageReportRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportById(1L));
    }

    @Test
    void getDamageReportByIdEdgeTestCase() {

        when(damageReportRepository.findById(0L))
                .thenReturn(Optional.empty());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportById(0L));
    }

    // ============================================
    // getAllDamageReports()
    // ============================================

    @Test
    void getAllDamageReportsPositiveTestCase() {

        when(damageReportRepository.findAll())
                .thenReturn(
                        Arrays.asList(damageReport));

        assertEquals(
                1,
                damageReportService
                        .getAllDamageReports()
                        .size());
    }

    @Test
    void getAllDamageReportsNegativeTestCase() {

        when(damageReportRepository.findAll())
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getAllDamageReports());
    }

    @Test
    void getAllDamageReportsEdgeTestCase() {

        when(damageReportRepository.findAll())
                .thenReturn(
                        Collections.singletonList(
                                damageReport));

        assertEquals(
                1,
                damageReportService
                        .getAllDamageReports()
                        .size());
    }

    // ============================================
    // getDamageReportsByTicketStatus()
    // ============================================

    @Test
    void getDamageReportsByTicketStatusPositiveTestCase() {

        when(damageReportRepository
                .findByTicketStatus("OPEN"))
                .thenReturn(
                        Arrays.asList(damageReport));

        assertEquals(
                1,
                damageReportService
                        .getDamageReportsByTicketStatus(
                                "OPEN")
                        .size());
    }

    @Test
    void getDamageReportsByTicketStatusNegativeTestCase() {

        when(damageReportRepository
                .findByTicketStatus("INVALID"))
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportsByTicketStatus(
                                "INVALID"));
    }

    @Test
    void getDamageReportsByTicketStatusEdgeTestCase() {

        when(damageReportRepository
                .findByTicketStatus(""))
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportsByTicketStatus(
                                ""));
    }

    // ============================================
    // getDamageReportsByPriority()
    // ============================================

    @Test
    void getDamageReportsByPriorityPositiveTestCase() {

        when(damageReportRepository
                .findByPriority("HIGH"))
                .thenReturn(
                        Arrays.asList(damageReport));

        assertFalse(
                damageReportService
                        .getDamageReportsByPriority(
                                "HIGH")
                        .isEmpty());
    }

    @Test
    void getDamageReportsByPriorityNegativeTestCase() {

        when(damageReportRepository
                .findByPriority("LOW"))
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportsByPriority(
                                "LOW"));
    }

    @Test
    void getDamageReportsByPriorityEdgeTestCase() {

        when(damageReportRepository
                .findByPriority(""))
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportsByPriority(
                                ""));
    }

    // ============================================
    // getDamageReportsByDamageType()
    // ============================================

    @Test
    void getDamageReportsByDamageTypePositiveTestCase() {

        when(damageReportRepository
                .findByDamageType("BROKEN"))
                .thenReturn(
                        Arrays.asList(damageReport));

        assertEquals(
                1,
                damageReportService
                        .getDamageReportsByDamageType(
                                "BROKEN")
                        .size());
    }

    @Test
    void getDamageReportsByDamageTypeNegativeTestCase() {

        when(damageReportRepository
                .findByDamageType("TEST"))
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportsByDamageType(
                                "TEST"));
    }

    @Test
    void getDamageReportsByDamageTypeEdgeTestCase() {

        when(damageReportRepository
                .findByDamageType(""))
                .thenReturn(
                        Collections.emptyList());

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .getDamageReportsByDamageType(
                                ""));
    }

    // ============================================
    // updateDamageReport()
    // ============================================

    @Test
    void updateDamageReportPositiveTestCase() {

        when(damageReportRepository.existsById(1L))
                .thenReturn(true);

        when(damageReportRepository.save(any()))
                .thenReturn(damageReport);

        DamageReportEntity result =
                damageReportService
                        .updateDamageReport(
                                damageReport);

        assertNotNull(result);
    }

    @Test
    void updateDamageReportNegativeTestCase() {

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .updateDamageReport(null));
    }

    @Test
    void updateDamageReportEdgeTestCase() {

        damageReport.setDamageId(null);

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .updateDamageReport(
                                damageReport));
    }

    // ============================================
    // deleteDamageReport()
    // ============================================

    @Test
    void deleteDamageReportPositiveTestCase() {

        when(damageReportRepository.existsById(1L))
                .thenReturn(true);

        damageReportService.deleteDamageReport(1L);

        verify(damageReportRepository)
                .deleteById(1L);
    }

    @Test
    void deleteDamageReportNegativeTestCase() {

        when(damageReportRepository.existsById(1L))
                .thenReturn(false);

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .deleteDamageReport(1L));
    }

    @Test
    void deleteDamageReportEdgeTestCase() {

        when(damageReportRepository.existsById(0L))
                .thenReturn(false);

        assertThrows(
                DamageReportException.class,
                () -> damageReportService
                        .deleteDamageReport(0L));
    }
}