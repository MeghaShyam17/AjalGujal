package com.ilp.inventory_service.Entity;


import jakarta.persistence.*;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import com.ilp.inventory_service.ToolEnums.ApprovalStatus;



@Entity
@Table(name = "tool_request")
public class ToolRequestEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tool_request_id")
    private Long toolRequestId;

    @Column(name = "project_id")
    private Long projectId;

    @Column(name = "requested_by")
    private Long requestedBy;

    @Column(name = "request_date")
    private Timestamp requestDate;

    @Column(name = "expected_return_date")
    private Date expectedReturnDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "approval_status")
    private ApprovalStatus approvalStatus;

    @Column(name = "approved_by")
    private Long approvedBy;

    @Column(name = "approved_on")
    private Timestamp approvedOn;

    @Column(name = "issued_by")
    private Long issuedBy;

    @Column(name = "issued_on")
    private Timestamp issuedOn;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @OneToMany(
            mappedBy = "toolRequest",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private List<ToolRequestItemEntity> requestItems;

    @OneToMany(
            mappedBy = "toolRequest",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY
    )
    private List<ToolReturnEntity> toolReturns;

    public ToolRequestEntity() {
    }

    public Long getToolRequestId() {
        return toolRequestId;
    }

    public void setToolRequestId(Long toolRequestId) {
        this.toolRequestId = toolRequestId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(Long requestedBy) {
        this.requestedBy = requestedBy;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public Date getExpectedReturnDate() {
        return expectedReturnDate;
    }

    public void setExpectedReturnDate(Date expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    public ApprovalStatus getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Long getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Long approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Timestamp getApprovedOn() {
        return approvedOn;
    }

    public void setApprovedOn(Timestamp approvedOn) {
        this.approvedOn = approvedOn;
    }

    public Long getIssuedBy() {
        return issuedBy;
    }

    public void setIssuedBy(Long issuedBy) {
        this.issuedBy = issuedBy;
    }

    public Timestamp getIssuedOn() {
        return issuedOn;
    }

    public void setIssuedOn(Timestamp issuedOn) {
        this.issuedOn = issuedOn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public List<ToolRequestItemEntity> getRequestItems() {
        return requestItems;
    }

    public void setRequestItems(List<ToolRequestItemEntity> requestItems) {
        this.requestItems = requestItems;
    }

    public List<ToolReturnEntity> getToolReturns() {
        return toolReturns;
    }

    public void setToolReturns(List<ToolReturnEntity> toolReturns) {
        this.toolReturns = toolReturns;
    }
}