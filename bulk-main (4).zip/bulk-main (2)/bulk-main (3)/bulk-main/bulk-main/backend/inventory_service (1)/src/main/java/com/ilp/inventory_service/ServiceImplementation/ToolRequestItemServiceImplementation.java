// package com.ilp.inventory_service.ServiceImplementation;

// import java.util.List;

// import java.util.stream.Collectors;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;
// import com.ilp.inventory_service.Client.UserClient;
// import com.ilp.inventory_service.Dto.ToolRequestItemDto;
// import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
// import com.ilp.inventory_service.Dto.ToolRequestItemApprovalDto;
// import com.ilp.inventory_service.Dto.ToolRequestItemRejectionDto;
// import com.ilp.inventory_service.Dto.UserDto;
// import com.ilp.inventory_service.Entity.InventoryEntity;
// import com.ilp.inventory_service.Entity.ToolRequestEntity;
// import com.ilp.inventory_service.Entity.ToolRequestItemEntity;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.InventoryRepository;
// import com.ilp.inventory_service.Repository.ToolRequestItemRepository;
// import com.ilp.inventory_service.Repository.ToolRequestRepository;
// import com.ilp.inventory_service.ServiceInterface.ToolRequestItemServiceInterface;
// import com.ilp.inventory_service.ToolEnums.ItemStatus;
// import com.ilp.inventory_service.ToolEnums.ApprovalStatus;
// import com.ilp.inventory_service.Client.ProjectClient;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;
// @Service
// public class ToolRequestItemServiceImplementation
//         implements ToolRequestItemServiceInterface {

//     @Autowired
//     private ToolRequestItemRepository toolRequestItemRepository;

//     @Autowired
//     private ToolRequestRepository toolRequestRepository;

//     @Autowired
//     private InventoryRepository inventoryRepository;

//     @Autowired
//     private UserClient userClient;
//     @Autowired
//     private ProjectClient projectClient;

//     @Autowired
//     private NotificationHelperServiceImplementation notificationHelperService;

//     @Override
//     public ToolRequestItemResponseDto create(
//             ToolRequestItemDto dto) {

//         ToolRequestEntity request =
//                 toolRequestRepository.findById(dto.getToolRequestId())
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         InventoryEntity inventory =
//                 inventoryRepository.findById(dto.getItemId())
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Inventory Item Not Found"));

//         if (dto.getRequestedQuantity() <= 0) {
//             throw new ToolBusinessException(
//                     "Requested quantity must be greater than zero");
//         }

//         ToolRequestItemEntity entity =
//                 new ToolRequestItemEntity();

//         entity.setToolRequest(request);
//         entity.setInventory(inventory);
//         entity.setRequestedQuantity(dto.getRequestedQuantity());
//         entity.setApprovedQuantity(0);
//         entity.setIssuedQuantity(0);
//         entity.setItemStatus(ItemStatus.PENDING);

//         ToolRequestItemEntity saved =
//                 toolRequestItemRepository.save(entity);

//         return mapToResponse(saved);
//     }

//     @Override
//     public ToolRequestItemResponseDto getById(Long id) {

//         ToolRequestItemEntity entity =
//                 toolRequestItemRepository.findById(id)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Item Not Found"));

//         return mapToResponse(entity);
//     }

//     @Override
//     public List<ToolRequestItemResponseDto> getAll() {

//         return toolRequestItemRepository.findAll()
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolRequestItemResponseDto> getByToolRequestId(
//             Long toolRequestId) {

//         return toolRequestItemRepository
//                 .findByToolRequestToolRequestId(toolRequestId)
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public ToolRequestItemResponseDto approveItem(
//             Long itemId,
//             Integer approvedQuantity) {

//         ToolRequestItemEntity entity =
//                 toolRequestItemRepository.findById(itemId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Item Not Found"));

//         if (entity.getItemStatus() != ItemStatus.PENDING) {
//             throw new ToolBusinessException(
//                     "Only pending items can be approved");
//         }

//         if (approvedQuantity <= 0) {
//             throw new ToolBusinessException(
//                     "Approved quantity must be greater than zero");
//         }

//         if (approvedQuantity > entity.getRequestedQuantity()) {
//             throw new ToolBusinessException(
//                     "Approved quantity cannot exceed requested quantity");
//         }

//         InventoryEntity inventory =
//                 entity.getInventory();

//         Integer availableQuantity =
//                 inventory.getAvailableQuantity() == null
//                         ? 0
//                         : inventory.getAvailableQuantity();

//         if (approvedQuantity > availableQuantity) {
//             throw new ToolBusinessException(
//                     "Approved quantity exceeds available stock");
//         }

//         entity.setApprovedQuantity(approvedQuantity);
//         entity.setItemStatus(ItemStatus.APPROVED);

//         ToolRequestItemEntity updated =
//                 toolRequestItemRepository.save(entity);

//         updateRequestHeaderStatus(updated.getToolRequest());

//         if (notificationHelperService != null && updated.getToolRequest() != null) {
//             Long reqBy = updated.getToolRequest().getRequestedBy();
//             notificationHelperService.sendNotification(
//                     reqBy != null ? reqBy.intValue() : 0,
//                     "Tool Request Approved",
//                     "Your tool request item has been approved.",
//                     "APPROVAL",
//                     updated.getToolRequestItemId().intValue(),
//                     "High",
//                     1);
//         }

//         return mapToResponse(updated);
//     }

//     @Override
//     @org.springframework.transaction.annotation.Transactional
//     public ToolRequestItemResponseDto rejectItem(Long itemId) {
//         ToolRequestItemEntity entity =
//                 toolRequestItemRepository.findById(itemId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Item Not Found"));

//         if (entity.getItemStatus() != ItemStatus.PENDING) {
//             throw new ToolBusinessException(
//                     "Only pending items can be rejected");
//         }

//         entity.setItemStatus(ItemStatus.REJECTED);
//         ToolRequestItemEntity updated = toolRequestItemRepository.save(entity);

//         updateRequestHeaderStatus(updated.getToolRequest());

//         return mapToResponse(updated);
//     }

//     @Override
//     @org.springframework.transaction.annotation.Transactional
//     public ToolRequestItemResponseDto approveItemPayload(ToolRequestItemApprovalDto dto) {
//         if (dto == null || dto.getToolRequestItemId() == null) {
//             throw new ToolBusinessException("Request payload or item ID cannot be null");
//         }
//         return approveItem(dto.getToolRequestItemId(), dto.getApprovedQuantity());
//     }

//     @Override
//     @org.springframework.transaction.annotation.Transactional
//     public ToolRequestItemResponseDto rejectItemPayload(ToolRequestItemRejectionDto dto) {
//         if (dto == null || dto.getToolRequestItemId() == null) {
//             throw new ToolBusinessException("Request payload or item ID cannot be null");
//         }
//         return rejectItem(dto.getToolRequestItemId());
//     }

//     @Override
//     @org.springframework.transaction.annotation.Transactional
//     public ToolRequestItemResponseDto issueItem(
//             Long itemId,
//             Integer issuedQuantity) {

//         ToolRequestItemEntity entity =
//                 toolRequestItemRepository.findById(itemId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Item Not Found"));

//         if (entity.getItemStatus() == ItemStatus.ISSUED) {
//             throw new ToolBusinessException(
//                     "Item already issued");
//         }

//         if (entity.getItemStatus() != ItemStatus.APPROVED) {
//             throw new ToolBusinessException(
//                     "Item must be approved before issuing");
//         }

//         if (issuedQuantity <= 0) {
//             throw new ToolBusinessException(
//                     "Issued quantity must be greater than zero");
//         }

//         if (issuedQuantity > entity.getApprovedQuantity()) {
//             throw new ToolBusinessException(
//                     "Issued quantity cannot exceed approved quantity");
//         }

//         InventoryEntity inventory =
//                 entity.getInventory();

//         Integer availableQuantity =
//                 inventory.getAvailableQuantity() == null
//                         ? 0
//                         : inventory.getAvailableQuantity();

//         if (availableQuantity < issuedQuantity) {
//             throw new ToolBusinessException(
//                     "Insufficient stock available");
//         }

//         inventory.setAvailableQuantity(
//                 availableQuantity - issuedQuantity);

//         inventoryRepository.save(inventory);

//         entity.setIssuedQuantity(issuedQuantity);
//         entity.setItemStatus(ItemStatus.ISSUED);

//         ToolRequestItemEntity updated =
//                 toolRequestItemRepository.save(entity);

//         updateRequestHeaderStatus(updated.getToolRequest());

//         if (notificationHelperService != null && updated.getToolRequest() != null) {
//             Long reqBy = updated.getToolRequest().getRequestedBy();
//             notificationHelperService.sendNotification(
//                     reqBy != null ? reqBy.intValue() : 0,
//                     "Tool Issued",
//                     "The requested tool has been issued successfully.",
//                     "ISSUE",
//                     updated.getToolRequestItemId().intValue(),
//                     "High",
//                     1);
//         }

//         return mapToResponse(updated);
//     }

//     private void updateRequestHeaderStatus(ToolRequestEntity request) {
//         List<ToolRequestItemEntity> items = request.getRequestItems();
//         if (items == null || items.isEmpty()) {
//             return;
//         }

//         boolean hasPending = false;
//         boolean hasApproved = false;
//         boolean hasRejected = false;
//         boolean hasIssued = false;

//         for (ToolRequestItemEntity item : items) {
//             if (item.getItemStatus() == ItemStatus.PENDING) {
//                 hasPending = true;
//             } else if (item.getItemStatus() == ItemStatus.APPROVED) {
//                 hasApproved = true;
//             } else if (item.getItemStatus() == ItemStatus.REJECTED) {
//                 hasRejected = true;
//             } else if (item.getItemStatus() == ItemStatus.ISSUED) {
//                 hasIssued = true;
//             }
//         }

//         if (hasPending) {
//             request.setApprovalStatus(ApprovalStatus.PENDING);
//         } else {
//             if (hasApproved) {
//                 request.setApprovalStatus(hasRejected ? ApprovalStatus.PARTIALLY_APPROVED : ApprovalStatus.APPROVED);
//             } else if (hasIssued) {
//                 request.setApprovalStatus(ApprovalStatus.ISSUED);
//             } else {
//                 request.setApprovalStatus(ApprovalStatus.REJECTED);
//             }
//         }
//         toolRequestRepository.save(request);
//     }

//     @Override
//     public void delete(Long id) {

//         ToolRequestItemEntity entity =
//                 toolRequestItemRepository.findById(id)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Item Not Found"));

//         if (entity.getItemStatus() == ItemStatus.ISSUED) {
//             throw new ToolBusinessException(
//                     "Issued item cannot be deleted");
//         }

//         toolRequestItemRepository.delete(entity);
//     }

//     private ToolRequestItemResponseDto mapToResponse(
//             ToolRequestItemEntity entity) {

//         ToolRequestItemResponseDto dto =
//                 new ToolRequestItemResponseDto();

//         dto.setToolRequestItemId(
//                 entity.getToolRequestItemId());

//         dto.setToolRequestId(
//                 entity.getToolRequest().getToolRequestId());

//         dto.setItemId(
//                 entity.getInventory().getItemId());

//         dto.setRequestedQuantity(
//                 entity.getRequestedQuantity());

//         dto.setApprovedQuantity(
//                 entity.getApprovedQuantity());

//         dto.setIssuedQuantity(
//                 entity.getIssuedQuantity());

//         dto.setItemStatus(
//                 entity.getItemStatus());

//         // User Details
//         if (userClient != null && entity.getToolRequest() != null
//                 && entity.getToolRequest().getRequestedBy() != null) {

//             UserDto userDto =
//                     userClient.getUserById(
//                             entity.getToolRequest()
//                                     .getRequestedBy()
//                                     .intValue());

//             dto.setUser(userDto);
//         }

//         // Project Details
//         if (projectClient != null && entity.getToolRequest() != null
//                 && entity.getToolRequest().getProjectId() != null) {

//             ProjectTeamDto projectDto =
//                     projectClient.getProjectById(
//                             entity.getToolRequest()
//                                     .getProjectId()
//                                     .intValue());

//             dto.setProject(projectDto);
//         }

//         return dto;
//     }
// }

package com.ilp.inventory_service.ServiceImplementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import com.ilp.inventory_service.Dto.ToolRequestItemApprovalDto;
import com.ilp.inventory_service.Dto.ToolRequestItemDto;
import com.ilp.inventory_service.Dto.ToolRequestItemRejectionDto;
import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Entity.ToolRequestEntity;
import com.ilp.inventory_service.Entity.ToolRequestItemEntity;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.Repository.ToolRequestItemRepository;
import com.ilp.inventory_service.Repository.ToolRequestRepository;
import com.ilp.inventory_service.ServiceInterface.ToolRequestItemServiceInterface;
import com.ilp.inventory_service.ToolEnums.ApprovalStatus;
import com.ilp.inventory_service.ToolEnums.ItemStatus;

@Service
public class ToolRequestItemServiceImplementation
        implements ToolRequestItemServiceInterface {

    @Autowired
    private ToolRequestItemRepository toolRequestItemRepository;

    @Autowired
    private ToolRequestRepository toolRequestRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private UserClient userClient;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private NotificationHelperServiceImplementation notificationHelperService;

    @Override
    public ToolRequestItemResponseDto create(
            ToolRequestItemDto dto) {

        ToolRequestEntity request =
                toolRequestRepository.findById(dto.getToolRequestId())
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Not Found"));

        InventoryEntity inventory =
                inventoryRepository.findById(dto.getItemId())
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Inventory Item Not Found"));

        if (dto.getRequestedQuantity() <= 0) {
            throw new ToolBusinessException(
                    "Requested quantity must be greater than zero");
        }

        ToolRequestItemEntity entity =
                new ToolRequestItemEntity();

        entity.setToolRequest(request);
        entity.setInventory(inventory);
        entity.setRequestedQuantity(dto.getRequestedQuantity());
        entity.setApprovedQuantity(0);
        entity.setIssuedQuantity(0);
        entity.setItemStatus(ItemStatus.PENDING);

        ToolRequestItemEntity saved =
                toolRequestItemRepository.save(entity);

        return mapToResponse(saved);
    }

    @Override
    public ToolRequestItemResponseDto getById(Long id) {

        ToolRequestItemEntity entity =
                toolRequestItemRepository.findById(id)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Item Not Found"));

        return mapToResponse(entity);
    }

    @Override
    public List<ToolRequestItemResponseDto> getAll() {

        return toolRequestItemRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolRequestItemResponseDto> getByToolRequestId(
            Long toolRequestId) {

        return toolRequestItemRepository
                .findByToolRequestToolRequestId(toolRequestId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ToolRequestItemResponseDto approveItem(
            Long itemId,
            Integer approvedQuantity) {

        ToolRequestItemEntity entity =
                toolRequestItemRepository.findById(itemId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Item Not Found"));

        if (entity.getItemStatus() != ItemStatus.PENDING) {
            throw new ToolBusinessException(
                    "Only pending items can be approved");
        }

        if (approvedQuantity <= 0) {
            throw new ToolBusinessException(
                    "Approved quantity must be greater than zero");
        }

        if (approvedQuantity > entity.getRequestedQuantity()) {
            throw new ToolBusinessException(
                    "Approved quantity cannot exceed requested quantity");
        }

        InventoryEntity inventory =
                entity.getInventory();

        Integer availableQuantity =
                inventory.getAvailableQuantity() == null
                        ? 0
                        : inventory.getAvailableQuantity();

        if (approvedQuantity > availableQuantity) {
            throw new ToolBusinessException(
                    "Approved quantity exceeds available stock");
        }

        entity.setApprovedQuantity(approvedQuantity);
        entity.setItemStatus(ItemStatus.APPROVED);

        ToolRequestItemEntity updated =
                toolRequestItemRepository.save(entity);

        updateRequestHeaderStatus(updated.getToolRequest());

        if (notificationHelperService != null
                && updated.getToolRequest() != null) {

            Long reqBy = updated.getToolRequest().getRequestedBy();

            notificationHelperService.sendNotification(
                    reqBy != null ? reqBy.intValue() : 0,
                    "Tool Request Approved",
                    "Your tool request item has been approved.",
                    "APPROVAL",
                    updated.getToolRequestItemId().intValue(),
                    "High",
                    1);
        }

        return mapToResponse(updated);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public ToolRequestItemResponseDto rejectItem(Long itemId) {

        ToolRequestItemEntity entity =
                toolRequestItemRepository.findById(itemId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Item Not Found"));

        if (entity.getItemStatus() != ItemStatus.PENDING) {
            throw new ToolBusinessException(
                    "Only pending items can be rejected");
        }

        entity.setItemStatus(ItemStatus.REJECTED);

        ToolRequestItemEntity updated =
                toolRequestItemRepository.save(entity);

        updateRequestHeaderStatus(updated.getToolRequest());

        return mapToResponse(updated);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public ToolRequestItemResponseDto approveItemPayload(
            ToolRequestItemApprovalDto dto) {

        if (dto == null || dto.getToolRequestItemId() == null) {
            throw new ToolBusinessException(
                    "Request payload or item ID cannot be null");
        }

        return approveItem(
                dto.getToolRequestItemId(),
                dto.getApprovedQuantity());
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public ToolRequestItemResponseDto rejectItemPayload(
            ToolRequestItemRejectionDto dto) {

        if (dto == null || dto.getToolRequestItemId() == null) {
            throw new ToolBusinessException(
                    "Request payload or item ID cannot be null");
        }

        return rejectItem(dto.getToolRequestItemId());
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public ToolRequestItemResponseDto issueItem(
            Long itemId,
            Integer issuedQuantity) {

        ToolRequestItemEntity entity =
                toolRequestItemRepository.findById(itemId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Item Not Found"));

        if (entity.getItemStatus() == ItemStatus.ISSUED) {
            throw new ToolBusinessException(
                    "Item already issued");
        }

        if (entity.getItemStatus() != ItemStatus.APPROVED) {
            throw new ToolBusinessException(
                    "Item must be approved before issuing");
        }

        if (issuedQuantity <= 0) {
            throw new ToolBusinessException(
                    "Issued quantity must be greater than zero");
        }

        if (issuedQuantity > entity.getApprovedQuantity()) {
            throw new ToolBusinessException(
                    "Issued quantity cannot exceed approved quantity");
        }

        InventoryEntity inventory =
                entity.getInventory();

        Integer availableQuantity =
                inventory.getAvailableQuantity() == null
                        ? 0
                        : inventory.getAvailableQuantity();

        if (availableQuantity < issuedQuantity) {
            throw new ToolBusinessException(
                    "Insufficient stock available");
        }

        inventory.setAvailableQuantity(
                availableQuantity - issuedQuantity);

        inventoryRepository.save(inventory);

        entity.setIssuedQuantity(issuedQuantity);
        entity.setItemStatus(ItemStatus.ISSUED);

        ToolRequestItemEntity updated =
                toolRequestItemRepository.save(entity);

        updateRequestHeaderStatus(updated.getToolRequest());

        if (notificationHelperService != null
                && updated.getToolRequest() != null) {

            Long reqBy = updated.getToolRequest().getRequestedBy();

            notificationHelperService.sendNotification(
                    reqBy != null ? reqBy.intValue() : 0,
                    "Tool Issued",
                    "The requested tool has been issued successfully.",
                    "ISSUE",
                    updated.getToolRequestItemId().intValue(),
                    "High",
                    1);
        }

        return mapToResponse(updated);
    }

    private void updateRequestHeaderStatus(ToolRequestEntity request) {

        if (request == null) {
            return;
        }

        List<ToolRequestItemEntity> items = request.getRequestItems();

        if (items == null || items.isEmpty()) {
            return;
        }

        boolean hasPending = false;
        boolean hasApproved = false;
        boolean hasRejected = false;
        boolean hasIssued = false;

        for (ToolRequestItemEntity item : items) {
            if (item.getItemStatus() == ItemStatus.PENDING) {
                hasPending = true;
            } else if (item.getItemStatus() == ItemStatus.APPROVED) {
                hasApproved = true;
            } else if (item.getItemStatus() == ItemStatus.REJECTED) {
                hasRejected = true;
            } else if (item.getItemStatus() == ItemStatus.ISSUED) {
                hasIssued = true;
            }
        }

        if (hasPending) {
            request.setApprovalStatus(ApprovalStatus.PENDING);
        } else {
            if (hasApproved) {
                request.setApprovalStatus(
                        hasRejected
                                ? ApprovalStatus.PARTIALLY_APPROVED
                                : ApprovalStatus.APPROVED);
            } else if (hasIssued) {
                request.setApprovalStatus(ApprovalStatus.ISSUED);
            } else {
                request.setApprovalStatus(ApprovalStatus.REJECTED);
            }
        }

        toolRequestRepository.save(request);
    }

    @Override
    public void delete(Long id) {

        ToolRequestItemEntity entity =
                toolRequestItemRepository.findById(id)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Item Not Found"));

        if (entity.getItemStatus() == ItemStatus.ISSUED) {
            throw new ToolBusinessException(
                    "Issued item cannot be deleted");
        }

        toolRequestItemRepository.delete(entity);
    }

    private ToolRequestItemResponseDto mapToResponse(
            ToolRequestItemEntity entity) {

        ToolRequestItemResponseDto dto =
                new ToolRequestItemResponseDto();

        dto.setToolRequestItemId(
                entity.getToolRequestItemId());

        if (entity.getToolRequest() != null) {
            dto.setToolRequestId(
                    entity.getToolRequest().getToolRequestId());
        }

        if (entity.getInventory() != null) {
            dto.setItemId(
                    entity.getInventory().getItemId());
        }

        dto.setRequestedQuantity(
                entity.getRequestedQuantity());

        dto.setApprovedQuantity(
                entity.getApprovedQuantity());

        dto.setIssuedQuantity(
                entity.getIssuedQuantity());

        dto.setItemStatus(
                entity.getItemStatus());

        // User Details safely
        if (userClient != null
                && entity.getToolRequest() != null
                && entity.getToolRequest().getRequestedBy() != null) {

            try {
                UserDto userDto =
                        userClient.getUserById(
                                entity.getToolRequest()
                                        .getRequestedBy()
                                        .intValue());

                dto.setUser(userDto);

            } catch (Exception e) {
                System.out.println("Failed to fetch user details for userId: "
                        + entity.getToolRequest().getRequestedBy());
                System.out.println("User fetch error: " + e.getMessage());

                dto.setUser(null);
            }
        }

        // Project Details safely
        if (projectClient != null
                && entity.getToolRequest() != null
                && entity.getToolRequest().getProjectId() != null) {

            try {
                ProjectTeamDto projectDto =
                        projectClient.getProjectById(
                                entity.getToolRequest()
                                        .getProjectId()
                                        .intValue());

                dto.setProject(projectDto);

            } catch (Exception e) {
                System.out.println("Failed to fetch project details for projectId: "
                        + entity.getToolRequest().getProjectId());
                System.out.println("Project fetch error: " + e.getMessage());

                dto.setProject(null);
            }
        }

        return dto;
    }
}