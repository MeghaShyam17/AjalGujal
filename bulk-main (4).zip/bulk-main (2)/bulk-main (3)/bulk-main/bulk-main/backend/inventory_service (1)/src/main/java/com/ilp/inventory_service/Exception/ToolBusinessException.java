package com.ilp.inventory_service.Exception;

import org.hibernate.boot.archive.spi.ArchiveException;

public class ToolBusinessException
extends RuntimeException {

    public ToolBusinessException(
            String message) {

        super(message);
    }
}