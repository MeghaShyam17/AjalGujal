package com.ilp.inventory_service.Exception;





import java.time.LocalDateTime;

public class ToolErrorResponseDTO {

    private String message;

    private int status;

    private LocalDateTime timestamp;

    public ToolErrorResponseDTO() {
    }

    public ToolErrorResponseDTO(
            String message,
            int status,
            LocalDateTime timestamp) {

        this.message = message;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(
            LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}

