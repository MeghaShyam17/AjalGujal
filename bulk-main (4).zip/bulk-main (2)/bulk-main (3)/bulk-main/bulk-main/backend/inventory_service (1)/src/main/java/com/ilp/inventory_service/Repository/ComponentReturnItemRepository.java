package com.ilp.inventory_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ilp.inventory_service.Entity.ComponentReturnItemEntity;

import java.util.List;

public interface ComponentReturnItemRepository
        extends JpaRepository<ComponentReturnItemEntity, Long> {

    @Query("""
            SELECT c
            FROM ComponentReturnItemEntity c
            WHERE c.componentReturn.componentReturnId = :returnId
           """)
    List<ComponentReturnItemEntity> getReturnItems(
            @Param("returnId") Long returnId);

    @Query("""
            SELECT c
            FROM ComponentReturnItemEntity c
            WHERE c.inventory.itemId = :itemId
           """)
    List<ComponentReturnItemEntity> getInventoryReturnHistory(
            @Param("itemId") Long itemId);

    @Query("""
            SELECT c
            FROM ComponentReturnItemEntity c
            WHERE c.damagedQuantity > 0
           """)
    List<ComponentReturnItemEntity> getDamagedItems();

    @Query("""
            SELECT c
            FROM ComponentReturnItemEntity c
            WHERE c.consumedQuantity > 0
           """)
    List<ComponentReturnItemEntity> getConsumedItems();

    List<ComponentReturnItemEntity>
            findByInventoryItemId(Long itemId);

    List<ComponentReturnItemEntity>
            findByCondition(String conditionStatus);
}