package com.ilp.inventory_service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ComponentRequestItemResponseDto;
import com.ilp.inventory_service.ServiceInterface.ComponentRequestItemServiceInterface;

@RestController
@RequestMapping("/api/component-request-item")

public class ComponentRequestItemController {

    @Autowired
    private ComponentRequestItemServiceInterface componentRequestItemService;

    @GetMapping("/{requestItemId}")
    public ComponentRequestItemResponseDto getById(
            @PathVariable Long requestItemId) {

        return componentRequestItemService
                .getById(requestItemId);
    }

    @GetMapping
    public List<ComponentRequestItemResponseDto> getRequestItems(
            @RequestParam(required = false) Long componentRequestId,
            @RequestParam(required = false) Long itemId,
            @RequestParam(required = false) String itemStatus,
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) Long requestedBy,
            @RequestParam(required = false) Long facultyId) {

        return componentRequestItemService
                .getRequestItems(componentRequestId, itemId, itemStatus, projectId, requestedBy, facultyId);
    }

    @GetMapping("/request/{componentRequestId}")
    public List<ComponentRequestItemResponseDto> getByComponentRequestId(
            @PathVariable Long componentRequestId) {

        return componentRequestItemService
                .getByComponentRequestId(componentRequestId);
    }

    @GetMapping("/item/{itemId}")
    public List<ComponentRequestItemResponseDto> getByItemId(
            @PathVariable Long itemId) {

        return componentRequestItemService
                .getByItemId(itemId);
    }

    @GetMapping("/status/{itemStatus}")
    public List<ComponentRequestItemResponseDto> getByItemStatus(
            @PathVariable String itemStatus) {

        return componentRequestItemService
                .getByItemStatus(itemStatus);
    }

    @GetMapping("/project/{projectId}")
    public List<ComponentRequestItemResponseDto> getByProjectId(
            @PathVariable Long projectId) {

        return componentRequestItemService
                .getByProjectId(projectId);
    }

    @GetMapping("/requested-by/{requestedBy}")
    public List<ComponentRequestItemResponseDto> getByRequestedBy(
            @PathVariable Long requestedBy) {

        return componentRequestItemService
                .getByRequestedBy(requestedBy);
    }

    @GetMapping("/faculty/{facultyId}")
    public List<ComponentRequestItemResponseDto> getByFacultyId(
            @PathVariable Long facultyId) {

        return componentRequestItemService
                .getByFacultyId(facultyId);
    }
}
