package com.ilp.inventory_service.Entity;


import jakarta.persistence.*;

import java.sql.Timestamp;

import com.ilp.inventory_service.ToolEnums.ItemCondition;
import com.ilp.inventory_service.Entity.ToolReturnEntity;



@Entity
@Table(name = "tool_return_item")
public class ToolReturnItemEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "return_item_id")
    private Long returnItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tool_return_id")
    private ToolReturnEntity toolReturn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id")
    private InventoryEntity inventory;

    @Column(name = "issued_quantity")
    private Integer issuedQuantity;

    @Column(name = "returned_quantity")
    private Integer returnedQuantity;

    @Column(name = "damaged_quantity")
    private Integer damagedQuantity;

    @Column(name = "lost_quantity")
    private Integer lostQuantity;

    @Enumerated(EnumType.STRING)
    @Column(name = "condition")
    private ItemCondition condition;

    @Column(name = "verified_by")
    private Long verifiedBy;

    @Column(name = "verified_on")
    private Timestamp verifiedOn;

    @Column(name = "remarks")
    private String remarks;

    public ToolReturnItemEntity() {
    }

    public Long getReturnItemId() {
        return returnItemId;
    }

    public void setReturnItemId(Long returnItemId) {
        this.returnItemId = returnItemId;
    }

    public ToolReturnEntity getToolReturn() {
        return toolReturn;
    }

    public void setToolReturn(ToolReturnEntity toolReturn) {
        this.toolReturn = toolReturn;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public Integer getReturnedQuantity() {
        return returnedQuantity;
    }

    public void setReturnedQuantity(Integer returnedQuantity) {
        this.returnedQuantity = returnedQuantity;
    }

    public Integer getDamagedQuantity() {
        return damagedQuantity;
    }

    public void setDamagedQuantity(Integer damagedQuantity) {
        this.damagedQuantity = damagedQuantity;
    }

    public Integer getLostQuantity() {
        return lostQuantity;
    }

    public void setLostQuantity(Integer lostQuantity) {
        this.lostQuantity = lostQuantity;
    }

    public ItemCondition getCondition() {
        return condition;
    }

    public void setCondition(ItemCondition condition) {
        this.condition = condition;
    }

    public Long getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(Long verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public Timestamp getVerifiedOn() {
        return verifiedOn;
    }

    public void setVerifiedOn(Timestamp verifiedOn) {
        this.verifiedOn = verifiedOn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}