package com.ilp.inventory_service.Entity;


import jakarta.persistence.*;

import java.sql.Timestamp;
import java.util.List;

import com.ilp.inventory_service.ToolEnums.ReturnStatus;



@Entity
@Table(name = "tool_return")
public class ToolReturnEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tool_return_id")
    private Long toolReturnId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tool_request_id")
    private ToolRequestEntity toolRequest;

    @Column(name = "returned_by")
    private Long returnedBy;

    @Column(name = "received_by")
    private Long receivedBy;

    @Column(name = "return_date")
    private Timestamp returnDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "return_status")
    private ReturnStatus returnStatus;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @OneToMany(
            mappedBy = "toolReturn",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private List<ToolReturnItemEntity> returnItems;

    public ToolReturnEntity() {
    }

    public Long getToolReturnId() {
        return toolReturnId;
    }

    public void setToolReturnId(Long toolReturnId) {
        this.toolReturnId = toolReturnId;
    }

    public ToolRequestEntity getToolRequest() {
        return toolRequest;
    }

    public void setToolRequest(ToolRequestEntity toolRequest) {
        this.toolRequest = toolRequest;
    }

    public Long getReturnedBy() {
        return returnedBy;
    }

    public void setReturnedBy(Long returnedBy) {
        this.returnedBy = returnedBy;
    }

    public Long getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Long receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Timestamp getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Timestamp returnDate) {
        this.returnDate = returnDate;
    }

    public ReturnStatus getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(ReturnStatus returnStatus) {
        this.returnStatus = returnStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public List<ToolReturnItemEntity> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(List<ToolReturnItemEntity> returnItems) {
        this.returnItems = returnItems;
    }
}