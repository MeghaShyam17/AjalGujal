// package ServiceImplementationJunitTest;

// import static org.junit.jupiter.api.Assertions.assertEquals;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.Arrays;
// import java.util.Collections;
// import java.util.List;
// import java.util.Optional;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import com.ilp.inventory_service.Client.NotificationFeignClient;
// import com.ilp.inventory_service.Client.ProjectClient;
// import com.ilp.inventory_service.Client.UserClient;
// import com.ilp.inventory_service.Dto.ComponentRequestDto;
// import com.ilp.inventory_service.Dto.ComponentRequestItemDto;
// import com.ilp.inventory_service.Dto.ComponentRequestResponseDto;
// import com.ilp.inventory_service.Dto.NotificationRequestDto;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;
// import com.ilp.inventory_service.Dto.UserDto;
// import com.ilp.inventory_service.Entity.ComponentRequestEntity;
// import com.ilp.inventory_service.Entity.ComponentRequestItemEntity;
// import com.ilp.inventory_service.Entity.InventoryEntity;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.ComponentRequestRepository;
// import com.ilp.inventory_service.Repository.InventoryRepository;
// import com.ilp.inventory_service.ServiceImplementation.ComponentRequestServiceImplementation;

// @ExtendWith(MockitoExtension.class)
// public class ComponentRequestTest {

//     @Mock
//     private ComponentRequestRepository componentRequestRepository;

//     @Mock
//     private InventoryRepository inventoryRepository;

//     @Mock
//     private ProjectClient projectClient;

//     @Mock
//     private UserClient userClient;

//     @Mock
//     private NotificationFeignClient notificationFeignClient;

//     @InjectMocks
//     private ComponentRequestServiceImplementation componentRequestService;

//     private ProjectTeamDto project;

//     private UserDto requestedUser;

//     private UserDto facultyUser;

//     private UserDto approverUser;

//     private InventoryEntity inventory;

//     private ComponentRequestDto requestDto;

//     private ComponentRequestEntity componentRequestEntity;

//     @BeforeEach
//     void setUp() {

//         project = new ProjectTeamDto();
//         project.setProjectId(1);
//         project.setProjectName("Inventory Management Project");
//         project.setFacultyId(2);
//         project.setProjectStatus("ACTIVE");

//         requestedUser = new UserDto(
//                 1L,
//                 "Student User",
//                 "student@example.com",
//                 "STUDENT",
//                 "9876543210"
//         );

//         facultyUser = new UserDto(
//                 2L,
//                 "Faculty User",
//                 "faculty@example.com",
//                 "FACULTY",
//                 "9876543211"
//         );

//         approverUser = new UserDto(
//                 3L,
//                 "Approver User",
//                 "approver@example.com",
//                 "ADMIN",
//                 "9876543212"
//         );

//         inventory = new InventoryEntity();
//         inventory.setItemId(10L);

//         ComponentRequestItemDto requestItemDto =
//                 new ComponentRequestItemDto();

//         requestItemDto.setItemId(10L);
//         requestItemDto.setRequestedQuantity(5);
//         requestItemDto.setFacultyComments(
//                 "Required for project");

//         requestDto = new ComponentRequestDto();
//         requestDto.setProjectId(1L);
//         requestDto.setRequestedBy(1L);
//         requestDto.setFacultyId(2L);
//         requestDto.setRemarks(
//                 "Components required for project");
//         requestDto.setRequestItems(
//                 Collections.singletonList(requestItemDto));

//         componentRequestEntity =
//                 createComponentRequestEntity(
//                         100L,
//                         "PENDING"
//                 );
//     }

//     @Test
//     void createComponentRequest_ShouldCreateRequestSuccessfully() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(userClient.getUserById(2))
//                 .thenReturn(facultyUser);

//         when(inventoryRepository.findById(10L))
//                 .thenReturn(Optional.of(inventory));

//         when(componentRequestRepository.save(
//                 any(ComponentRequestEntity.class)))
//                 .thenAnswer(invocation -> {

//                     ComponentRequestEntity entity =
//                             invocation.getArgument(0);

//                     entity.setComponentRequestId(100L);

//                     if (entity.getRequestItems() != null) {
//                         long requestItemId = 1L;

//                         for (ComponentRequestItemEntity item
//                                 : entity.getRequestItems()) {

//                             item.setRequestItemId(
//                                     requestItemId++);
//                         }
//                     }

//                     return entity;
//                 });

//         doNothing()
//                 .when(notificationFeignClient)
//                 .createNotification(
//                         any(NotificationRequestDto.class));

//         ComponentRequestResponseDto response =
//                 componentRequestService
//                         .createComponentRequest(requestDto);

//         assertNotNull(response);
//         assertEquals(
//                 100L,
//                 response.getComponentRequestId());
//         assertEquals(
//                 1L,
//                 response.getProjectId());
//         assertEquals(
//                 1L,
//                 response.getRequestedBy());
//         assertEquals(
//                 2L,
//                 response.getFacultyId());
//         assertEquals(
//                 "PENDING",
//                 response.getApprovalStatus());
//         assertEquals(
//                 "Components required for project",
//                 response.getRemarks());
//         assertNotNull(response.getRequestItems());
//         assertEquals(
//                 1,
//                 response.getRequestItems().size());
//         assertEquals(
//                 10L,
//                 response.getRequestItems()
//                         .get(0)
//                         .getItemId());
//         assertEquals(
//                 5,
//                 response.getRequestItems()
//                         .get(0)
//                         .getRequestedQuantity());

//         verify(projectClient, times(1))
//                 .getProjectById(1);

//         verify(userClient, times(1))
//                 .getUserById(1);

//         verify(userClient, times(1))
//                 .getUserById(2);

//         verify(inventoryRepository, times(1))
//                 .findById(10L);

//         verify(componentRequestRepository, times(1))
//                 .save(any(ComponentRequestEntity.class));

//         verify(notificationFeignClient, times(1))
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentRequest_ShouldThrowException_WhenProjectNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentRequestService
//                         .createComponentRequest(requestDto)
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentRequest_ShouldThrowException_WhenRequestedUserNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(1))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentRequestService
//                         .createComponentRequest(requestDto)
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void createComponentRequest_ShouldThrowException_WhenFacultyNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(userClient.getUserById(2))
//                 .thenReturn(null);

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentRequestService
//                         .createComponentRequest(requestDto)
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));
//     }

//     @Test
//     void createComponentRequest_ShouldThrowException_WhenRequestItemsAreEmpty() {

//         requestDto.setRequestItems(
//                 Collections.emptyList());

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(userClient.getUserById(2))
//                 .thenReturn(facultyUser);

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentRequestService
//                         .createComponentRequest(requestDto)
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));
//     }

//     @Test
//     void createComponentRequest_ShouldThrowException_WhenInventoryNotFound() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(userClient.getUserById(2))
//                 .thenReturn(facultyUser);

//         when(inventoryRepository.findById(10L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentRequestService
//                         .createComponentRequest(requestDto)
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));
//     }

//     @Test
//     void createComponentRequest_ShouldThrowException_WhenQuantityIsZero() {

//         requestDto.getRequestItems()
//                 .get(0)
//                 .setRequestedQuantity(0);

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(userClient.getUserById(2))
//                 .thenReturn(facultyUser);

//         when(inventoryRepository.findById(10L))
//                 .thenReturn(Optional.of(inventory));

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentRequestService
//                         .createComponentRequest(requestDto)
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));
//     }

//     @Test
//     void getById_ShouldReturnComponentRequest() {

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         ComponentRequestResponseDto response =
//                 componentRequestService.getById(100L);

//         assertNotNull(response);
//         assertEquals(
//                 100L,
//                 response.getComponentRequestId());
//         assertEquals(
//                 "PENDING",
//                 response.getApprovalStatus());

//         verify(componentRequestRepository, times(1))
//                 .findById(100L);
//     }

//     @Test
//     void getById_ShouldThrowException_WhenRequestNotFound() {

//         when(componentRequestRepository.findById(999L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentRequestService
//                         .getById(999L)
//         );
//     }

//     @Test
//     void getAll_ShouldReturnAllComponentRequests() {

//         ComponentRequestEntity secondEntity =
//                 createComponentRequestEntity(
//                         101L,
//                         "APPROVED"
//                 );

//         when(componentRequestRepository.findAll())
//                 .thenReturn(
//                         Arrays.asList(
//                                 componentRequestEntity,
//                                 secondEntity
//                         ));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService.getAll();

//         assertNotNull(responses);
//         assertEquals(2, responses.size());
//         assertEquals(
//                 100L,
//                 responses.get(0)
//                         .getComponentRequestId());
//         assertEquals(
//                 101L,
//                 responses.get(1)
//                         .getComponentRequestId());
//     }

//     @Test
//     void getByProjectId_ShouldValidateProjectAndReturnRequests() {

//         when(projectClient.getProjectById(1))
//                 .thenReturn(project);

//         when(componentRequestRepository.findByProjectId(1L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentRequestEntity));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService
//                         .getByProjectId(1L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());
//         assertEquals(
//                 1L,
//                 responses.get(0)
//                         .getProjectId());

//         verify(projectClient, times(1))
//                 .getProjectById(1);
//     }

//     @Test
//     void getByRequestedBy_ShouldValidateUserAndReturnRequests() {

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(componentRequestRepository
//                 .findByRequestedBy(1L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentRequestEntity));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService
//                         .getByRequestedBy(1L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());
//         assertEquals(
//                 1L,
//                 responses.get(0)
//                         .getRequestedBy());

//         verify(userClient, times(1))
//                 .getUserById(1);
//     }

//     @Test
//     void getByFacultyId_ShouldValidateUserAndReturnRequests() {

//         when(userClient.getUserById(2))
//                 .thenReturn(facultyUser);

//         when(componentRequestRepository
//                 .findByFacultyId(2L))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentRequestEntity));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService
//                         .getByFacultyId(2L);

//         assertNotNull(responses);
//         assertEquals(1, responses.size());
//         assertEquals(
//                 2L,
//                 responses.get(0)
//                         .getFacultyId());

//         verify(userClient, times(1))
//                 .getUserById(2);
//     }

//     @Test
//     void getPendingRequests_ShouldReturnPendingRequests() {

//         when(componentRequestRepository
//                 .findByApprovalStatus("PENDING"))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 componentRequestEntity));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService
//                         .getPendingRequests();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());
//         assertEquals(
//                 "PENDING",
//                 responses.get(0)
//                         .getApprovalStatus());
//     }

//     @Test
//     void getApprovedRequests_ShouldReturnApprovedRequests() {

//         ComponentRequestEntity approvedEntity =
//                 createComponentRequestEntity(
//                         100L,
//                         "APPROVED"
//                 );

//         when(componentRequestRepository
//                 .findByApprovalStatus("APPROVED"))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 approvedEntity));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService
//                         .getApprovedRequests();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());
//         assertEquals(
//                 "APPROVED",
//                 responses.get(0)
//                         .getApprovalStatus());
//     }

//     @Test
//     void getRejectedRequests_ShouldReturnRejectedRequests() {

//         ComponentRequestEntity rejectedEntity =
//                 createComponentRequestEntity(
//                         100L,
//                         "REJECTED"
//                 );

//         when(componentRequestRepository
//                 .findByApprovalStatus("REJECTED"))
//                 .thenReturn(
//                         Collections.singletonList(
//                                 rejectedEntity));

//         List<ComponentRequestResponseDto> responses =
//                 componentRequestService
//                         .getRejectedRequests();

//         assertNotNull(responses);
//         assertEquals(1, responses.size());
//         assertEquals(
//                 "REJECTED",
//                 responses.get(0)
//                         .getApprovalStatus());
//     }

//     @Test
//     void approveRequest_ShouldApproveRequestAndSendNotification() {

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         when(userClient.getUserById(3))
//                 .thenReturn(approverUser);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(componentRequestRepository.save(
//                 any(ComponentRequestEntity.class)))
//                 .thenAnswer(invocation ->
//                         invocation.getArgument(0));

//         doNothing()
//                 .when(notificationFeignClient)
//                 .createNotification(
//                         any(NotificationRequestDto.class));

//         ComponentRequestResponseDto response =
//                 componentRequestService
//                         .approveRequest(
//                                 100L,
//                                 3L
//                         );

//         assertNotNull(response);
//         assertEquals(
//                 "APPROVED",
//                 response.getApprovalStatus());
//         assertEquals(
//                 3L,
//                 response.getApprovedBy());
//         assertNotNull(response.getApprovedOn());

//         verify(componentRequestRepository, times(1))
//                 .save(componentRequestEntity);

//         verify(notificationFeignClient, times(1))
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void approveRequest_ShouldThrowException_WhenRequestAlreadyApproved() {

//         componentRequestEntity.setApprovalStatus(
//                 "APPROVED");

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentRequestService
//                         .approveRequest(
//                                 100L,
//                                 3L
//                         )
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void rejectRequest_ShouldRejectRequestAndSendNotification() {

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         when(userClient.getUserById(3))
//                 .thenReturn(approverUser);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(componentRequestRepository.save(
//                 any(ComponentRequestEntity.class)))
//                 .thenAnswer(invocation ->
//                         invocation.getArgument(0));

//         doNothing()
//                 .when(notificationFeignClient)
//                 .createNotification(
//                         any(NotificationRequestDto.class));

//         ComponentRequestResponseDto response =
//                 componentRequestService
//                         .rejectRequest(
//                                 100L,
//                                 3L,
//                                 "Insufficient details"
//                         );

//         assertNotNull(response);
//         assertEquals(
//                 "REJECTED",
//                 response.getApprovalStatus());
//         assertEquals(
//                 3L,
//                 response.getApprovedBy());
//         assertEquals(
//                 "Insufficient details",
//                 response.getRemarks());
//         assertNotNull(response.getApprovedOn());

//         verify(notificationFeignClient, times(1))
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void rejectRequest_ShouldThrowException_WhenRemarksAreEmpty() {

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentRequestService
//                         .rejectRequest(
//                                 100L,
//                                 3L,
//                                 " "
//                         )
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void issueRequest_ShouldIssueApprovedRequestAndSendNotification() {

//         componentRequestEntity.setApprovalStatus(
//                 "APPROVED");

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         when(userClient.getUserById(3))
//                 .thenReturn(approverUser);

//         when(userClient.getUserById(1))
//                 .thenReturn(requestedUser);

//         when(componentRequestRepository.save(
//                 any(ComponentRequestEntity.class)))
//                 .thenAnswer(invocation ->
//                         invocation.getArgument(0));

//         doNothing()
//                 .when(notificationFeignClient)
//                 .createNotification(
//                         any(NotificationRequestDto.class));

//         ComponentRequestResponseDto response =
//                 componentRequestService
//                         .issueRequest(
//                                 100L,
//                                 3L
//                         );

//         assertNotNull(response);
//         assertEquals(
//                 3L,
//                 response.getIssuedBy());
//         assertNotNull(response.getIssuedOn());

//         verify(componentRequestRepository, times(1))
//                 .save(componentRequestEntity);

//         verify(notificationFeignClient, times(1))
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void issueRequest_ShouldThrowException_WhenRequestIsPending() {

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> componentRequestService
//                         .issueRequest(
//                                 100L,
//                                 3L
//                         )
//         );

//         verify(componentRequestRepository, never())
//                 .save(any(ComponentRequestEntity.class));

//         verify(notificationFeignClient, never())
//                 .createNotification(
//                         any(NotificationRequestDto.class));
//     }

//     @Test
//     void delete_ShouldDeleteComponentRequest() {

//         when(componentRequestRepository.findById(100L))
//                 .thenReturn(
//                         Optional.of(componentRequestEntity));

//         doNothing()
//                 .when(componentRequestRepository)
//                 .delete(componentRequestEntity);

//         componentRequestService.delete(100L);

//         verify(componentRequestRepository, times(1))
//                 .findById(100L);

//         verify(componentRequestRepository, times(1))
//                 .delete(componentRequestEntity);
//     }

//     @Test
//     void delete_ShouldThrowException_WhenRequestNotFound() {

//         when(componentRequestRepository.findById(999L))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> componentRequestService
//                         .delete(999L)
//         );

//         verify(componentRequestRepository, never())
//                 .delete(any(ComponentRequestEntity.class));
//     }

//     private ComponentRequestEntity createComponentRequestEntity(
//             Long componentRequestId,
//             String approvalStatus) {

//         ComponentRequestEntity entity =
//                 new ComponentRequestEntity();

//         entity.setComponentRequestId(componentRequestId);
//         entity.setProjectId(1L);
//         entity.setRequestedBy(1L);
//         entity.setFacultyId(2L);
//         entity.setApprovalStatus(approvalStatus);
//         entity.setRemarks(
//                 "Components required for project");

//         ComponentRequestItemEntity item =
//                 new ComponentRequestItemEntity();

//         item.setRequestItemId(1L);
//         item.setComponentRequest(entity);
//         item.setInventory(inventory);
//         item.setRequestedQuantity(5);
//         item.setApprovedQuantity(0);
//         item.setIssuedQuantity(0);
//         item.setItemStatus("PENDING");
//         item.setFacultyComments(
//                 "Required for project");

//         entity.setRequestItems(
//                 Collections.singletonList(item));

//         return entity;
//     }
// }