package com.ilp.inventory_service.Dto;

public class ComponentRequestItemResponseDto {

    private Long requestItemId;

    private Long itemId;

    private Integer requestedQuantity;

    private Integer approvedQuantity;

    private Integer issuedQuantity;

    private String itemStatus;

    private String facultyComments;

    public ComponentRequestItemResponseDto() {
    }

    public ComponentRequestItemResponseDto(
            Long requestItemId,
            Long itemId,
            Integer requestedQuantity,
            Integer approvedQuantity,
            Integer issuedQuantity,
            String itemStatus,
            String facultyComments) {

        this.requestItemId = requestItemId;
        this.itemId = itemId;
        this.requestedQuantity = requestedQuantity;
        this.approvedQuantity = approvedQuantity;
        this.issuedQuantity = issuedQuantity;
        this.itemStatus = itemStatus;
        this.facultyComments = facultyComments;
    }

    public Long getRequestItemId() {
        return requestItemId;
    }

    public void setRequestItemId(Long requestItemId) {
        this.requestItemId = requestItemId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Integer getRequestedQuantity() {
        return requestedQuantity;
    }

    public void setRequestedQuantity(Integer requestedQuantity) {
        this.requestedQuantity = requestedQuantity;
    }

    public Integer getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(Integer approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }

    public Integer getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(Integer issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public String getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }

    public String getFacultyComments() {
        return facultyComments;
    }

    public void setFacultyComments(String facultyComments) {
        this.facultyComments = facultyComments;
    }
}