package com.ilp.inventory_service.Repository;

import com.ilp.inventory_service.Entity.InventoryEntity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository
        extends JpaRepository<InventoryEntity, Long> {

    InventoryEntity findByItemId(Long itemId);

    Optional<InventoryEntity> findByItemIdAndIsDeletedFalse(Long itemId);

    InventoryEntity findByItemCode(String itemCode);

    List<InventoryEntity> findByItemCategory(String itemCategory);

    List<InventoryEntity> findByItemNameContainingIgnoreCase(
            String itemName
    );

    List<InventoryEntity> findByStatus(String status);

    List<InventoryEntity> findByIsDeletedFalse();

    @Query("""
            SELECT i
            FROM InventoryEntity i
            WHERE i.availableQuantity < 10
            AND i.isDeleted = false
            """)
    List<InventoryEntity> findLowStockItems();

    @Query("""
            SELECT i
            FROM InventoryEntity i
            WHERE i.availableQuantity <= i.minimumStock
            AND i.isDeleted = false
            """)
    List<InventoryEntity> findMinimumStockItems();

    @Query("""
            SELECT i
            FROM InventoryEntity i
            WHERE LOWER(i.itemCategory) = LOWER(:category)
            AND i.isDeleted = false
            """)
    List<InventoryEntity> getInventoryByCategory(
            @Param("category") String category
    );

    @Query("""
            SELECT i
            FROM InventoryEntity i
            WHERE i.availableQuantity > 0
            AND i.isDeleted = false
            """)
    List<InventoryEntity> findAvailableItems();

    @Query("""
            SELECT i
            FROM InventoryEntity i
            WHERE i.availableQuantity = 0
            AND i.isDeleted = false
            """)
    List<InventoryEntity> findOutOfStockItems();

    @Query("""
            SELECT i
            FROM InventoryEntity i
            WHERE i.itemId = :itemId
            AND i.availableQuantity >= :requestedQuantity
            AND i.isDeleted = false
            """)
    InventoryEntity checkAvailableStock(
            @Param("itemId") Long itemId,
            @Param("requestedQuantity") Integer requestedQuantity
    );

    @Query("""
            SELECT COUNT(i)
            FROM InventoryEntity i
            WHERE i.availableQuantity <= i.minimumStock
            AND i.isDeleted = false
            """)
    Long countLowStockItems();

    @Query("""
            SELECT SUM(i.availableQuantity)
            FROM InventoryEntity i
            WHERE i.isDeleted = false
            """)
    Long getTotalAvailableStock();
}
