package com.ilp.inventory_service.Dto;



import java.sql.Date;

public class ToolRequestDto {

    private Long projectId;

    private Long requestedBy;

    private Date expectedReturnDate;

    private String remarks;

    private java.util.List<ToolRequestItemDto> items;

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(Long requestedBy) {
        this.requestedBy = requestedBy;
    }

    public Date getExpectedReturnDate() {
        return expectedReturnDate;
    }

    public void setExpectedReturnDate(Date expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public java.util.List<ToolRequestItemDto> getItems() {
        return items;
    }

    public void setItems(java.util.List<ToolRequestItemDto> items) {
        this.items = items;
    }
}
