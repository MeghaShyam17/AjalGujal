package com.ilp.inventory_service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ComponentReturnItemResponseDto;
import com.ilp.inventory_service.ServiceInterface.ComponentReturnItemServiceInterface;

@RestController
@RequestMapping("/api/component-return-item")

public class ComponentReturnItemController {

    @Autowired
    private ComponentReturnItemServiceInterface componentReturnItemService;

    @GetMapping("/{returnItemId}")
    public ComponentReturnItemResponseDto getById(
            @PathVariable Long returnItemId) {

        return componentReturnItemService
                .getById(returnItemId);
    }

    @GetMapping
    public List<ComponentReturnItemResponseDto> getReturnItems(
            @RequestParam(required = false) Long componentReturnId,
            @RequestParam(required = false) Long itemId,
            @RequestParam(required = false) String condition) {

        return componentReturnItemService
                .getReturnItems(componentReturnId, itemId, condition);
    }

    @GetMapping("/return/{componentReturnId}")
    public List<ComponentReturnItemResponseDto> getByComponentReturnId(
            @PathVariable Long componentReturnId) {

        return componentReturnItemService
                .getByComponentReturnId(componentReturnId);
    }

    @GetMapping("/item/{itemId}")
    public List<ComponentReturnItemResponseDto> getByItemId(
            @PathVariable Long itemId) {

        return componentReturnItemService
                .getByItemId(itemId);
    }

    @GetMapping("/condition/{condition}")
    public List<ComponentReturnItemResponseDto> getByCondition(
            @PathVariable String condition) {

        return componentReturnItemService
                .getByCondition(condition);
    }

    @GetMapping("/damaged")
    public List<ComponentReturnItemResponseDto> getDamagedItems() {

        return componentReturnItemService
                .getDamagedItems();
    }

    @GetMapping("/consumed")
    public List<ComponentReturnItemResponseDto> getConsumedItems() {

        return componentReturnItemService
                .getConsumedItems();
    }

    @GetMapping("/history/{itemId}")
    public List<ComponentReturnItemResponseDto> getInventoryReturnHistory(
            @PathVariable Long itemId) {

        return componentReturnItemService
                .getInventoryReturnHistory(itemId);
    }
}
