package com.ilp.inventory_service.Controller;

import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ToolReturnItemDto;
import com.ilp.inventory_service.ServiceInterface.ToolReturnItemServiceInterface;

import java.util.List;

@RestController
@RequestMapping("/api/tool-return-items")

@RequiredArgsConstructor
public class ToolReturnItemController {
@Autowired
    private ToolReturnItemServiceInterface toolReturnItemService ;

    @PostMapping
    public ToolReturnItemDto create(
            @RequestBody ToolReturnItemDto dto) {

        return toolReturnItemService.create(dto);
    }

    @GetMapping("/{id}")
    public ToolReturnItemDto getById(
            @PathVariable Long id) {

        return toolReturnItemService.getById(id);
    }

    @GetMapping
    public List<ToolReturnItemDto> getAll() {

        return toolReturnItemService.getAll();
    }

    @GetMapping("/toolReturn/{toolReturnId}")
    public List<ToolReturnItemDto> getByToolReturnId(
            @PathVariable Long toolReturnId) {

        return toolReturnItemService.getByToolReturnId(
                toolReturnId);
    }

    @PutMapping("/{returnItemId}/verify")
    public void verifyItem(
            @PathVariable Long returnItemId,
            @RequestParam Long verifiedBy) {

        toolReturnItemService.verifyItem(
                returnItemId,
                verifiedBy);
    }

    @DeleteMapping("/{id}")
    public void delete(
            @PathVariable Long id) {

        toolReturnItemService.delete(id);
    }
}