package com.ilp.inventory_service.Controller;

import com.ilp.inventory_service.Entity.DamageReportEntity;
import com.ilp.inventory_service.ServiceInterface.DamageReportServiceInterface;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/damage-report")

public class DamageReportController {

    @Autowired
    private DamageReportServiceInterface damageReportService;

    @PostMapping("/save")
    public DamageReportEntity saveDamageReport(
            @RequestBody DamageReportEntity damageReport) {

        return damageReportService.saveDamageReport(damageReport);
    }

    @GetMapping("/{damageId}")
    public DamageReportEntity getDamageReportById(
            @PathVariable Long damageId) {

        return damageReportService.getDamageReportById(damageId);
    }

    @GetMapping("/all")
    public List<DamageReportEntity> getAllDamageReports() {

        return damageReportService.getAllDamageReports();
    }

    @GetMapping("/status/{ticketStatus}")
    public List<DamageReportEntity> getDamageReportsByTicketStatus(
            @PathVariable String ticketStatus) {

        return damageReportService
                .getDamageReportsByTicketStatus(ticketStatus);
    }

    @GetMapping("/priority/{priority}")
    public List<DamageReportEntity> getDamageReportsByPriority(
            @PathVariable String priority) {

        return damageReportService
                .getDamageReportsByPriority(priority);
    }

    @GetMapping("/damage-type/{damageType}")
    public List<DamageReportEntity> getDamageReportsByDamageType(
            @PathVariable String damageType) {

        return damageReportService
                .getDamageReportsByDamageType(damageType);
    }

    @PutMapping("/update")
    public DamageReportEntity updateDamageReport(
            @RequestBody DamageReportEntity damageReport) {

        return damageReportService.updateDamageReport(damageReport);
    }

    @DeleteMapping("/delete/{damageId}")
    public String deleteDamageReport(
            @PathVariable Long damageId) {

        damageReportService.deleteDamageReport(damageId);

        return "Damage Report Deleted Successfully";
    }
}