package com.ilp.inventory_service.Controller;





import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.inventory_service.Dto.ToolRequestDto;
import com.ilp.inventory_service.Dto.ToolRequestResponseDto;
import com.ilp.inventory_service.ServiceInterface.ToolRequestServiceInterface;

import java.util.List;

@RestController
@RequestMapping("/api/tool-requests")

@RequiredArgsConstructor
public class ToolRequestController {
@Autowired
    private  ToolRequestServiceInterface toolRequestService;

    @PostMapping
    public ToolRequestResponseDto createToolRequest(
            @RequestBody ToolRequestDto dto) {
                System.out.println("controller reached");
                 

        return toolRequestService.createToolRequest(dto);
    }

    @GetMapping("/{id}")
    public ToolRequestResponseDto getById(
            @PathVariable Long id) {

        return toolRequestService.getById(id);
    }

    @GetMapping
    public List<ToolRequestResponseDto> getAll() {

        return toolRequestService.getAll();
    }

    @GetMapping("/project/{projectId}")
    public List<ToolRequestResponseDto> getByProjectId(
            @PathVariable Long projectId) {

        return toolRequestService.getByProjectId(projectId);
    }

    @GetMapping("/requestedBy/{requestedBy}")
    public List<ToolRequestResponseDto> getByRequestedBy(
            @PathVariable Long requestedBy) {

        return toolRequestService.getByRequestedBy(requestedBy);
    }

    @GetMapping("/pending")
    public List<ToolRequestResponseDto> getPendingRequests() {

        return toolRequestService.getPendingRequests();
    }

    @GetMapping("/approved")
    public List<ToolRequestResponseDto> getApprovedRequests() {

        return toolRequestService.getApprovedRequests();
    }

    @GetMapping("/due")
    public List<ToolRequestResponseDto> getDueRequests() {

        return toolRequestService.getDueRequests();
    }

    @PutMapping("/{id}/approve")
    public ToolRequestResponseDto approveRequest(
            @PathVariable Long id,
            @RequestParam Long approvedBy) {

        return toolRequestService.approveRequest(
                id,
                approvedBy);
    }

    @PutMapping("/{id}/reject")
    public ToolRequestResponseDto rejectRequest(
            @PathVariable Long id,
            @RequestParam Long approvedBy) {

        return toolRequestService.rejectRequest(
                id,
                approvedBy);
    }

    @PutMapping("/{id}/issue")
    public ToolRequestResponseDto issueRequest(
            @PathVariable Long id,
            @RequestParam Long issuedBy,
            @RequestBody List<com.ilp.inventory_service.Dto.IssueQuantityDto> itemsToIssue) {

        return toolRequestService.issueRequest(
                id,
                issuedBy,
                itemsToIssue);
    }

    @DeleteMapping("/{id}")
    public void delete(
            @PathVariable Long id) {

        toolRequestService.delete(id);
    }
}

