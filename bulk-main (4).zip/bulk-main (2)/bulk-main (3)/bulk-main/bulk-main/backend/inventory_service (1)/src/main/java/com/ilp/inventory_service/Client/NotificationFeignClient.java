package com.ilp.inventory_service.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ilp.inventory_service.Dto.NotificationRequestDto;

@FeignClient(
        name = "notification-service",
        url = "http://localhost:8081"
)
public interface NotificationFeignClient {

    @PostMapping("/api/notifications")
    void createNotification(
            @RequestBody NotificationRequestDto dto);
}