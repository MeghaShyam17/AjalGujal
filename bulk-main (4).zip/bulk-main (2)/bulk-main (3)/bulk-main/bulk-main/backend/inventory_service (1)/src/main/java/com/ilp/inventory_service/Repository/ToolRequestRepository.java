package com.ilp.inventory_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.inventory_service.ToolEnums.ApprovalStatus;
import com.ilp.inventory_service.Entity.ToolRequestEntity;

import java.util.List;

@Repository
public interface ToolRequestRepository
        extends JpaRepository<ToolRequestEntity, Long> {

    ToolRequestEntity findByToolRequestId(
            Long toolRequestId);

    List<ToolRequestEntity> findByProjectId(
            Long projectId);

    List<ToolRequestEntity> findByRequestedBy(
            Long requestedBy);

    List<ToolRequestEntity> findByApprovedBy(
            Long approvedBy);

    List<ToolRequestEntity> findByApprovalStatus(
            ApprovalStatus approvalStatus);

    List<ToolRequestEntity>
    findByProjectIdAndApprovalStatus(
            Long projectId,
            ApprovalStatus approvalStatus);

    List<ToolRequestEntity>
    findByRequestedByAndApprovalStatus(
            Long requestedBy,
            ApprovalStatus approvalStatus);
}