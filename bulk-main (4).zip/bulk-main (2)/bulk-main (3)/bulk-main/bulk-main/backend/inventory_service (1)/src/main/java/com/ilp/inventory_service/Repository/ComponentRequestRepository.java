package com.ilp.inventory_service.Repository;

import com.ilp.inventory_service.Entity.ComponentRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ComponentRequestRepository
        extends JpaRepository<ComponentRequestEntity, Long> {

    Optional<ComponentRequestEntity> findByComponentRequestId(
            Long componentRequestId);

    List<ComponentRequestEntity> findByProjectId(
            Long projectId);

    List<ComponentRequestEntity> findByRequestedBy(
            Long requestedBy);

    List<ComponentRequestEntity> findByFacultyId(
            Long facultyId);

    List<ComponentRequestEntity> findByApprovalStatus(
            String approvalStatus);

    List<ComponentRequestEntity> findByProjectIdAndApprovalStatus(
            Long projectId,
            String approvalStatus);
}