package com.ilp.inventory_service.Repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.inventory_service.ToolEnums.ReturnStatus;
import com.ilp.inventory_service.Entity.ToolReturnEntity;

import java.util.List;

@Repository
public interface ToolReturnRepository
        extends JpaRepository<ToolReturnEntity, Long> {

    ToolReturnEntity findByToolReturnId(
            Long toolReturnId);

    List<ToolReturnEntity>
    findByToolRequestToolRequestId(
            Long toolRequestId);

    List<ToolReturnEntity>
    findByReturnedBy(
            Long returnedBy);

    List<ToolReturnEntity>
    findByReceivedBy(
            Long receivedBy);

    List<ToolReturnEntity>
    findByReturnStatus(
            ReturnStatus returnStatus);

    List<ToolReturnEntity>
    findByToolRequestProjectId(
            Long projectId);
}
