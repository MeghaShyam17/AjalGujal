package com.ilp.inventory_service.Client;

import com.ilp.inventory_service.Config.FeignClientConfig;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Dto.UserServiceResponseDto;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
        name = "user-service",
        url = "http://localhost:8081",
        configuration = FeignClientConfig.class
)
public interface UserClient {

    @GetMapping("/api/users/{userId}")
    UserDto getUserById(
            @PathVariable("userId") Integer userId
    );

    @GetMapping("/api/users/{userId}")
    UserServiceResponseDto getUserResponseById(
            @PathVariable("userId") Integer userId
    );
}


