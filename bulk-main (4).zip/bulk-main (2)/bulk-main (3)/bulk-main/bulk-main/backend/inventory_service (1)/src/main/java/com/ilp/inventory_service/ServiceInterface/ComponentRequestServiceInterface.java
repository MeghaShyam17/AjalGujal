package com.ilp.inventory_service.ServiceInterface;

import com.ilp.inventory_service.Dto.ComponentRequestDto;
import com.ilp.inventory_service.Dto.ComponentRequestResponseDto;

import com.ilp.inventory_service.Dto.IssueQuantityDto;

import java.util.List;

public interface ComponentRequestServiceInterface {

    ComponentRequestResponseDto createComponentRequest(
            ComponentRequestDto dto);

    ComponentRequestResponseDto getById(
            Long componentRequestId);

    List<ComponentRequestResponseDto> getRequests(
            Long projectId,
            Long requestedBy,
            Long facultyId,
            String status);

    List<ComponentRequestResponseDto> getAll();

    List<ComponentRequestResponseDto> getByProjectId(
            Long projectId);

    List<ComponentRequestResponseDto> getByRequestedBy(
            Long requestedBy);

    List<ComponentRequestResponseDto> getByFacultyId(
            Long facultyId);

    List<ComponentRequestResponseDto> getPendingRequests();

    List<ComponentRequestResponseDto> getApprovedRequests();

    List<ComponentRequestResponseDto> getRejectedRequests();

    ComponentRequestResponseDto approveRequest(
            Long componentRequestId,
            Long approvedBy);

    ComponentRequestResponseDto rejectRequest(
            Long componentRequestId,
            Long approvedBy,
            String remarks);

    ComponentRequestResponseDto issueRequest(
            Long componentRequestId,
            Long issuedBy,
            List<IssueQuantityDto> itemsToIssue);

    void delete(
            Long componentRequestId);
}


