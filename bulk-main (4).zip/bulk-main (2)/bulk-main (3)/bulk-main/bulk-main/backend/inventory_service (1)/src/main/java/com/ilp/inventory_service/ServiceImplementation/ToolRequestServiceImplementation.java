// package com.ilp.inventory_service.ServiceImplementation;
// import com.ilp.inventory_service.Client.ProjectClient;
// import com.ilp.inventory_service.Dto.ProjectTeamDto;

// import java.sql.Date;
// import java.sql.Timestamp;
// import java.util.List;
// import java.util.stream.Collectors;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
// import org.springframework.transaction.annotation.Transactional;

// import com.ilp.inventory_service.Client.UserClient;
// import com.ilp.inventory_service.Dto.ToolRequestDto;
// import com.ilp.inventory_service.Dto.ToolRequestResponseDto;
// import com.ilp.inventory_service.Dto.UserDto;
// import com.ilp.inventory_service.Entity.ToolRequestEntity;
// import com.ilp.inventory_service.Entity.InventoryEntity;
// import com.ilp.inventory_service.Entity.ToolRequestItemEntity;
// import com.ilp.inventory_service.Repository.InventoryRepository;
// import com.ilp.inventory_service.ToolEnums.ItemStatus;
// import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
// import com.ilp.inventory_service.Dto.ToolRequestItemDto;
// import com.ilp.inventory_service.Exception.ToolBadRequestException;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.ToolRequestRepository;
// import com.ilp.inventory_service.ServiceInterface.ToolRequestServiceInterface;
// import com.ilp.inventory_service.ToolEnums.ApprovalStatus;

// import lombok.RequiredArgsConstructor;

// @Service
// @RequiredArgsConstructor
// public class ToolRequestServiceImplementation
//         implements ToolRequestServiceInterface {

//     @Autowired
//     private ToolRequestRepository toolRequestRepository;

//     @Autowired
//     private InventoryRepository inventoryRepository;

//     @Autowired
//     private NotificationHelperServiceImplementation notificationHelperService;

//     @Autowired
//     private UserClient userClient;
//     @Autowired
//     private ProjectClient projectClient;

//     @Override
//     @Transactional
//     public ToolRequestResponseDto createToolRequest(
//             ToolRequestDto dto) {

//         if (dto.getExpectedReturnDate() == null) {
//             throw new ToolBadRequestException(
//                     "Expected return date is required");
//         }

//         Date today = new Date(System.currentTimeMillis());

//         if (dto.getExpectedReturnDate().before(today)) {
//             throw new ToolBadRequestException(
//                     "Expected return date cannot be in the past");
//         }

//         List<ToolRequestEntity> existingRequests =
//                 toolRequestRepository
//                         .findByProjectIdAndApprovalStatus(
//                                 dto.getProjectId(),
//                                 ApprovalStatus.PENDING);

//         if (!existingRequests.isEmpty()) {
//             throw new ToolBusinessException(
//                     "Pending request already exists for this project");
//         }

//         // if ((dto.getItems() == null || dto.getItems().isEmpty()) && userClient != null) {
//         //     throw new ToolBadRequestException(
//         //             "At least one request item is required");
//         // }

//         if (dto.getItems() == null || dto.getItems().isEmpty()) {
//         throw new ToolBadRequestException(
//                 "At least one request item is required");
//         }

//         Timestamp currentTime =
//                 new Timestamp(System.currentTimeMillis());

//         final ToolRequestEntity entity =
//                 new ToolRequestEntity();

//         entity.setProjectId(dto.getProjectId());
//         entity.setRequestedBy(dto.getRequestedBy());
//         entity.setExpectedReturnDate(dto.getExpectedReturnDate());
//         entity.setRemarks(dto.getRemarks());
//         entity.setApprovalStatus(ApprovalStatus.PENDING);
//         entity.setRequestDate(currentTime);
//         entity.setCreatedAt(currentTime);

//         List<ToolRequestItemEntity> items = (dto.getItems() == null ? java.util.Collections.<com.ilp.inventory_service.Dto.ToolRequestItemDto>emptyList() : dto.getItems()).stream().map(itemDto -> {
//             InventoryEntity inventory = inventoryRepository.findById(itemDto.getItemId())
//                     .orElseThrow(() -> new ToolResourceNotFoundException(
//                             "Inventory Item Not Found with ID: " + itemDto.getItemId()));
//             if (itemDto.getRequestedQuantity() == null || itemDto.getRequestedQuantity() <= 0) {
//                 throw new ToolBusinessException("Requested quantity must be greater than zero");
//             }
//             ToolRequestItemEntity itemEntity = new ToolRequestItemEntity();
//             itemEntity.setToolRequest(entity);
//             itemEntity.setInventory(inventory);
//             itemEntity.setRequestedQuantity(itemDto.getRequestedQuantity());
//             itemEntity.setApprovedQuantity(0);
//             itemEntity.setIssuedQuantity(0);
//             itemEntity.setItemStatus(ItemStatus.PENDING);
//             return itemEntity;
//         }).collect(Collectors.toList());

//         entity.setRequestItems(items);

//         ToolRequestEntity saved =
//                 toolRequestRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     saved.getRequestedBy().intValue(),
//                     "Tool Request Created",
//                     "Your tool request has been submitted successfully.",
//                     "INFO",
//                     saved.getToolRequestId().intValue(),
//                     "Medium",
//                     saved.getRequestedBy().intValue());
//         }

//         return mapToResponse(saved);
//     }

//     @Override
//     public ToolRequestResponseDto getById(
//             Long toolRequestId) {

//         ToolRequestEntity entity =
//                 toolRequestRepository.findById(toolRequestId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         return mapToResponse(entity);
//     }

//     @Override
//     public List<ToolRequestResponseDto> getAll() {

//         return toolRequestRepository.findAll()
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolRequestResponseDto> getByProjectId(
//             Long projectId) {

//         return toolRequestRepository.findByProjectId(projectId)
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolRequestResponseDto> getByRequestedBy(
//             Long requestedBy) {

//         return toolRequestRepository.findByRequestedBy(requestedBy)
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolRequestResponseDto> getPendingRequests() {

//         return toolRequestRepository
//                 .findByApprovalStatus(ApprovalStatus.PENDING)
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolRequestResponseDto> getApprovedRequests() {

//         return toolRequestRepository
//                 .findByApprovalStatus(ApprovalStatus.APPROVED)
//                 .stream()
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     public List<ToolRequestResponseDto> getDueRequests() {

//         Date today = new Date(System.currentTimeMillis());

//         return toolRequestRepository.findAll()
//                 .stream()
//                 .filter(request ->
//                         request.getExpectedReturnDate() != null
//                                 && today.after(
//                                         request.getExpectedReturnDate())
//                                 && request.getApprovalStatus()
//                                         == ApprovalStatus.ISSUED)
//                 .map(this::mapToResponse)
//                 .collect(Collectors.toList());
//     }

//     @Override
//     @Transactional
//     public ToolRequestResponseDto approveRequest(
//             Long toolRequestId,
//             Long approvedBy) {

//         ToolRequestEntity entity =
//                 toolRequestRepository.findById(toolRequestId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         if (entity.getApprovalStatus()
//                 != ApprovalStatus.PENDING) {

//             throw new ToolBusinessException(
//                     "Request already processed");
//         }

//         entity.setApprovalStatus(
//                 ApprovalStatus.APPROVED);

//         entity.setApprovedBy(approvedBy);

//         entity.setApprovedOn(
//                 new Timestamp(System.currentTimeMillis()));

//         ToolRequestEntity updated =
//                 toolRequestRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     updated.getRequestedBy().intValue(),
//                     "Tool Request Approved",
//                     "Your tool request has been approved.",
//                     "APPROVAL",
//                     updated.getToolRequestId().intValue(),
//                     "High",
//                     approvedBy.intValue());
//         }

//         return mapToResponse(updated);
//     }

//     @Override
//     @Transactional
//     public ToolRequestResponseDto rejectRequest(
//             Long toolRequestId,
//             Long approvedBy) {

//         ToolRequestEntity entity =
//                 toolRequestRepository.findById(toolRequestId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         if (entity.getApprovalStatus()
//                 != ApprovalStatus.PENDING) {

//             throw new ToolBusinessException(
//                     "Only pending requests can be rejected");
//         }

//         entity.setApprovalStatus(
//                 ApprovalStatus.REJECTED);

//         entity.setApprovedBy(approvedBy);

//         entity.setApprovedOn(
//                 new Timestamp(System.currentTimeMillis()));

//         ToolRequestEntity updated =
//                 toolRequestRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     updated.getRequestedBy().intValue(),
//                     "Tool Request Rejected",
//                     "Your tool request has been rejected.",
//                     "REJECTION",
//                     updated.getToolRequestId().intValue(),
//                     "High",
//                     approvedBy.intValue());
//         }

//         return mapToResponse(updated);
//     }

//     @Override
//     @Transactional
//     public ToolRequestResponseDto issueRequest(
//             Long toolRequestId,
//             Long issuedBy) {

//         ToolRequestEntity entity =
//                 toolRequestRepository.findById(toolRequestId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         if (entity.getApprovalStatus() != ApprovalStatus.APPROVED 
//                 && entity.getApprovalStatus() != ApprovalStatus.PARTIALLY_APPROVED) {

//             throw new ToolBusinessException(
//                     "Request must be approved or partially approved before issuing");
//         }

//         if (entity.getIssuedOn() != null) {

//             throw new ToolBusinessException(
//                     "Tool already issued");
//         }

//         if (entity.getRequestItems() != null) {
//             for (ToolRequestItemEntity item : entity.getRequestItems()) {
//                 if (item.getItemStatus() == ItemStatus.APPROVED) {
//                     InventoryEntity inventory = item.getInventory();
//                     int approved = item.getApprovedQuantity() != null ? item.getApprovedQuantity() : 0;
//                     int available = inventory.getAvailableQuantity() != null ? inventory.getAvailableQuantity() : 0;
//                     if (available < approved) {
//                         throw new ToolBusinessException("Insufficient stock available for item ID: " + inventory.getItemId());
//                     }
//                     inventory.setAvailableQuantity(available - approved);
//                     inventoryRepository.save(inventory);

//                     item.setIssuedQuantity(approved);
//                     item.setItemStatus(ItemStatus.ISSUED);
//                 }
//             }
//         }

//         entity.setIssuedBy(issuedBy);

//         entity.setIssuedOn(
//                 new Timestamp(System.currentTimeMillis()));

//         entity.setApprovalStatus(
//                 ApprovalStatus.ISSUED);

//         ToolRequestEntity updated =
//                 toolRequestRepository.save(entity);

//         if (notificationHelperService != null) {
//             notificationHelperService.sendNotification(
//                     updated.getRequestedBy().intValue(),
//                     "Tool Issued",
//                     "The requested tool has been issued.",
//                     "ISSUE",
//                     updated.getToolRequestId().intValue(),
//                     "High",
//                     issuedBy.intValue());
//         }

//         return mapToResponse(updated);
//     }

//     @Override
//     @Transactional
//     public void delete(
//             Long toolRequestId) {

//         ToolRequestEntity entity =
//                 toolRequestRepository.findById(toolRequestId)
//                         .orElseThrow(() ->
//                                 new ToolResourceNotFoundException(
//                                         "Tool Request Not Found"));

//         if (entity.getApprovalStatus()
//                 == ApprovalStatus.APPROVED
//                 || entity.getApprovalStatus()
//                 == ApprovalStatus.ISSUED) {

//             throw new ToolBusinessException(
//                     "Approved or Issued requests cannot be deleted");
//         }

//         toolRequestRepository.delete(entity);
//     }

//     private ToolRequestResponseDto mapToResponse(
//             ToolRequestEntity entity) {

//         ToolRequestResponseDto dto =
//                 new ToolRequestResponseDto();

//         dto.setToolRequestId(entity.getToolRequestId());
//         dto.setProjectId(entity.getProjectId());
//         dto.setRequestedBy(entity.getRequestedBy());
//         dto.setRequestDate(entity.getRequestDate());
//         dto.setExpectedReturnDate(entity.getExpectedReturnDate());
//         dto.setApprovalStatus(entity.getApprovalStatus());
//         dto.setApprovedBy(entity.getApprovedBy());
//         dto.setApprovedOn(entity.getApprovedOn());
//         dto.setIssuedBy(entity.getIssuedBy());
//         dto.setIssuedOn(entity.getIssuedOn());
//         dto.setRemarks(entity.getRemarks());

//         if (entity.getRequestItems() != null) {
//             List<ToolRequestItemResponseDto> itemDtos = entity.getRequestItems().stream().map(item -> {
//                 ToolRequestItemResponseDto itemDto = new ToolRequestItemResponseDto();
//                 itemDto.setToolRequestItemId(item.getToolRequestItemId());
//                 itemDto.setToolRequestId(item.getToolRequest().getToolRequestId());
//                 itemDto.setItemId(item.getInventory().getItemId());
//                 itemDto.setRequestedQuantity(item.getRequestedQuantity());
//                 itemDto.setApprovedQuantity(item.getApprovedQuantity());
//                 itemDto.setIssuedQuantity(item.getIssuedQuantity());
//                 itemDto.setItemStatus(item.getItemStatus());
//                 return itemDto;
//             }).collect(Collectors.toList());
//             dto.setItems(itemDtos);
//         }

//         // Fetch User Details
//         // if (entity.getRequestedBy() != null && userClient != null) {

//         //     UserDto userDto =
//         //             userClient.getUserById(
//         //                     entity.getRequestedBy().intValue());

//         //     dto.setUser(userDto);
//         // }

//         // Fetch User Details safely
//         if (entity.getRequestedBy() != null && userClient != null) {
//         try {
//                 UserDto userDto =
//                         userClient.getUserById(entity.getRequestedBy().intValue());

//                 dto.setUser(userDto);

//         } catch (Exception e) {
//                 System.out.println("Failed to fetch user details for userId: "
//                         + entity.getRequestedBy());
//                 System.out.println("User fetch error: " + e.getMessage());

//                 dto.setUser(null);
//         }
//         }


//         // Fetch Project Details
//         // if (entity.getProjectId() != null && projectClient != null) {

//         //     ProjectTeamDto projectDto =
//         //             projectClient.getProjectById(
//         //                     entity.getProjectId().intValue());

//         //     dto.setProject(projectDto);
//         //     if (projectDto != null) {
//         //         dto.setProjectName(projectDto.getProjectName());
//         //         if (projectDto.getTeamLeaderId() != null) {
//         //             dto.setTeamLeaderId(projectDto.getTeamLeaderId().longValue());
//         //         }
//         //     }
//         // }

//         // Fetch Project Details safely
//         if (entity.getProjectId() != null && projectClient != null) {
//         try {
//                 ProjectTeamDto projectDto =
//                         projectClient.getProjectById(entity.getProjectId().intValue());

//                 dto.setProject(projectDto);

//                 if (projectDto != null) {
//                 dto.setProjectName(projectDto.getProjectName());

//                 if (projectDto.getTeamLeaderId() != null) {
//                         dto.setTeamLeaderId(projectDto.getTeamLeaderId().longValue());
//                 }
//                 }

//         } catch (Exception e) {
//                 System.out.println("Failed to fetch project details for projectId: "
//                         + entity.getProjectId());
//                 System.out.println("Project fetch error: " + e.getMessage());

//                 dto.setProject(null);
//         }
//         }

//         return dto;
//     }
// }
package com.ilp.inventory_service.ServiceImplementation;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ilp.inventory_service.Client.ProjectClient;
import com.ilp.inventory_service.Client.UserClient;
import com.ilp.inventory_service.Dto.ProjectTeamDto;
import com.ilp.inventory_service.Dto.ToolRequestDto;
import com.ilp.inventory_service.Dto.ToolRequestItemResponseDto;
import com.ilp.inventory_service.Dto.ToolRequestResponseDto;
import com.ilp.inventory_service.Dto.UserDto;
import com.ilp.inventory_service.Entity.InventoryEntity;
import com.ilp.inventory_service.Entity.ToolRequestEntity;
import com.ilp.inventory_service.Entity.ToolRequestItemEntity;
import com.ilp.inventory_service.Exception.ToolBadRequestException;
import com.ilp.inventory_service.Exception.ToolBusinessException;
import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
import com.ilp.inventory_service.Repository.InventoryRepository;
import com.ilp.inventory_service.Repository.ToolRequestRepository;
import com.ilp.inventory_service.ServiceInterface.ToolRequestServiceInterface;
import com.ilp.inventory_service.ToolEnums.ApprovalStatus;
import com.ilp.inventory_service.ToolEnums.ItemStatus;
import com.ilp.inventory_service.Dto.IssueQuantityDto;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ToolRequestServiceImplementation
        implements ToolRequestServiceInterface {

    @Autowired
    private ToolRequestRepository toolRequestRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private NotificationHelperServiceImplementation notificationHelperService;

    @Autowired
    private UserClient userClient;

    @Autowired
    private ProjectClient projectClient;

    @Override
    @Transactional
    public ToolRequestResponseDto createToolRequest(
            ToolRequestDto dto) {
                System.out.print("step 1 -entered servide");
        if (dto.getExpectedReturnDate() == null) {
            throw new ToolBadRequestException(
                    "Expected return date is required");
        }

        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        Date today = new Date(cal.getTimeInMillis());

        if (dto.getExpectedReturnDate().before(today)) {
            throw new ToolBadRequestException(
                    "Expected return date cannot be in the past");
        }

        Timestamp currentTime =
                new Timestamp(System.currentTimeMillis());

        final ToolRequestEntity entity =
                new ToolRequestEntity();

        entity.setProjectId(dto.getProjectId());
        entity.setRequestedBy(dto.getRequestedBy());
        entity.setRequestDate(currentTime);
        entity.setExpectedReturnDate(dto.getExpectedReturnDate());
        entity.setApprovalStatus(ApprovalStatus.PENDING);
        entity.setRemarks(dto.getRemarks());
        entity.setCreatedAt(currentTime);

        if (dto.getItems() != null && !dto.getItems().isEmpty()) {
            List<ToolRequestItemEntity> items = dto.getItems().stream().map(itemDto -> {
                InventoryEntity inventory = inventoryRepository.findById(itemDto.getItemId())
                        .orElseThrow(() -> new ToolResourceNotFoundException(
                                "Inventory Item Not Found with ID: " + itemDto.getItemId()));
                if (itemDto.getRequestedQuantity() == null || itemDto.getRequestedQuantity() <= 0) {
                    throw new ToolBusinessException("Requested quantity must be greater than zero");
                }
                ToolRequestItemEntity itemEntity = new ToolRequestItemEntity();
                itemEntity.setToolRequest(entity);
                itemEntity.setInventory(inventory);
                itemEntity.setRequestedQuantity(itemDto.getRequestedQuantity());
                itemEntity.setApprovedQuantity(0);
                itemEntity.setIssuedQuantity(0);
                itemEntity.setItemStatus(ItemStatus.PENDING);
                return itemEntity;
            }).collect(Collectors.toList());

            entity.setRequestItems(items);
        } else {
            entity.setRequestItems(new java.util.ArrayList<>());
        }

        ToolRequestEntity saved =
                toolRequestRepository.save(entity);

        if (notificationHelperService != null && saved.getRequestedBy() != null) {
            notificationHelperService.sendNotification(
                    saved.getRequestedBy().intValue(),
                    "Tool Request Created",
                    "Your tool request has been submitted successfully.",
                    "INFO",
                    saved.getToolRequestId().intValue(),
                    "Medium",
                    saved.getRequestedBy().intValue());
        }

        return mapToResponse(saved);
    }

    @Override
    public ToolRequestResponseDto getById(
            Long toolRequestId) {

        ToolRequestEntity entity =
                toolRequestRepository.findById(toolRequestId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                         "Tool Request Not Found"));

        return mapToResponse(entity);
    }

    @Override
    public List<ToolRequestResponseDto> getAll() {

        return toolRequestRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolRequestResponseDto> getByProjectId(
            Long projectId) {

        return toolRequestRepository.findByProjectId(projectId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolRequestResponseDto> getByRequestedBy(
            Long requestedBy) {

        return toolRequestRepository.findByRequestedBy(requestedBy)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolRequestResponseDto> getPendingRequests() {

        return toolRequestRepository
                .findByApprovalStatus(ApprovalStatus.PENDING)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolRequestResponseDto> getApprovedRequests() {

        return toolRequestRepository
                .findByApprovalStatus(ApprovalStatus.APPROVED)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ToolRequestResponseDto> getDueRequests() {

        Date today = new Date(System.currentTimeMillis());

        return toolRequestRepository.findAll()
                .stream()
                .filter(request ->
                        request.getExpectedReturnDate() != null
                                && today.after(
                                        request.getExpectedReturnDate())
                                && request.getApprovalStatus()
                                        == ApprovalStatus.ISSUED)
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ToolRequestResponseDto approveRequest(
            Long toolRequestId,
            Long approvedBy) {

        ToolRequestEntity entity =
                toolRequestRepository.findById(toolRequestId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Not Found"));

        if (entity.getApprovalStatus()
                != ApprovalStatus.PENDING) {

            throw new ToolBusinessException(
                    "Request already processed");
        }

        entity.setApprovalStatus(
                ApprovalStatus.APPROVED);

        entity.setApprovedBy(approvedBy);

        entity.setApprovedOn(
                new Timestamp(System.currentTimeMillis()));

        if (entity.getRequestItems() != null) {
            for (ToolRequestItemEntity item : entity.getRequestItems()) {
                item.setItemStatus(ItemStatus.APPROVED);
                if (item.getApprovedQuantity() == null || item.getApprovedQuantity() == 0) {
                    item.setApprovedQuantity(item.getRequestedQuantity() != null ? item.getRequestedQuantity() : 1);
                }
            }
        }

        ToolRequestEntity updated =
                toolRequestRepository.save(entity);

        if (notificationHelperService != null && updated.getRequestedBy() != null) {
            notificationHelperService.sendNotification(
                    updated.getRequestedBy().intValue(),
                    "Tool Request Approved",
                    "Your tool request has been approved.",
                    "APPROVAL",
                    updated.getToolRequestId().intValue(),
                    "High",
                    approvedBy != null ? approvedBy.intValue() : 1);
        }

        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public ToolRequestResponseDto rejectRequest(
            Long toolRequestId,
            Long approvedBy) {

        ToolRequestEntity entity =
                toolRequestRepository.findById(toolRequestId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Not Found"));

        if (entity.getApprovalStatus()
                != ApprovalStatus.PENDING) {

            throw new ToolBusinessException(
                    "Only pending requests can be rejected");
        }

        entity.setApprovalStatus(
                ApprovalStatus.REJECTED);

        entity.setApprovedBy(approvedBy);

        entity.setApprovedOn(
                new Timestamp(System.currentTimeMillis()));

        if (entity.getRequestItems() != null) {
            for (ToolRequestItemEntity item : entity.getRequestItems()) {
                item.setItemStatus(ItemStatus.REJECTED);
                item.setApprovedQuantity(0);
            }
        }

        ToolRequestEntity updated =
                toolRequestRepository.save(entity);

        if (notificationHelperService != null && updated.getRequestedBy() != null) {
            notificationHelperService.sendNotification(
                    updated.getRequestedBy().intValue(),
                    "Tool Request Rejected",
                    "Your tool request has been rejected.",
                    "REJECTION",
                    updated.getToolRequestId().intValue(),
                    "High",
                    approvedBy != null ? approvedBy.intValue() : 1);
        }

        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public ToolRequestResponseDto issueRequest(
            Long toolRequestId,
            Long issuedBy,
            List<IssueQuantityDto> itemsToIssue) {

        ToolRequestEntity entity =
                toolRequestRepository.findById(toolRequestId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Not Found"));

        if (entity.getApprovalStatus() != ApprovalStatus.APPROVED 
                && entity.getApprovalStatus() != ApprovalStatus.PARTIALLY_APPROVED
                && entity.getApprovalStatus() != ApprovalStatus.PENDING
                && entity.getApprovalStatus() != ApprovalStatus.ISSUED) {

            throw new ToolBusinessException(
                    "Request must be pending, approved, partially approved, or already issued before issuing more items");
        }

        boolean allAlreadyIssued = true;
        if (entity.getRequestItems() != null) {
            for (ToolRequestItemEntity item : entity.getRequestItems()) {
                if (item.getItemStatus() != ItemStatus.ISSUED) {
                    allAlreadyIssued = false;
                    break;
                }
            }
        }

        if (allAlreadyIssued) {
            throw new ToolBusinessException("Tool request is already fully issued");
        }

        if (entity.getRequestItems() != null && itemsToIssue != null) {
            for (IssueQuantityDto issueDto : itemsToIssue) {
                ToolRequestItemEntity matchedItem = null;
                for (ToolRequestItemEntity item : entity.getRequestItems()) {
                    if (item.getInventory() != null && item.getInventory().getItemId().equals(issueDto.getItemId())) {
                        matchedItem = item;
                        break;
                    }
                }

                if (matchedItem != null) {
                    int qtyToIssue = issueDto.getQty() != null ? issueDto.getQty() : 0;
                    if (qtyToIssue <= 0) {
                        continue;
                    }

                    int currentIssued = matchedItem.getIssuedQuantity() != null ? matchedItem.getIssuedQuantity() : 0;
                    int approvedQty = (matchedItem.getApprovedQuantity() != null && matchedItem.getApprovedQuantity() > 0)
                            ? matchedItem.getApprovedQuantity()
                            : (matchedItem.getRequestedQuantity() != null ? matchedItem.getRequestedQuantity() : 0);

                    if (currentIssued + qtyToIssue > approvedQty) {
                        throw new ToolBusinessException("Issued quantity cannot exceed approved quantity for item ID: " + issueDto.getItemId());
                    }

                    InventoryEntity inventory = matchedItem.getInventory();
                    int available = inventory.getAvailableQuantity() != null ? inventory.getAvailableQuantity() : 0;
                    if (available < qtyToIssue) {
                        throw new ToolBusinessException("Insufficient stock available for item ID: " + inventory.getItemId());
                    }
                    inventory.setAvailableQuantity(available - qtyToIssue);
                    inventoryRepository.save(inventory);

                    int newIssued = currentIssued + qtyToIssue;
                    matchedItem.setApprovedQuantity(approvedQty);
                    matchedItem.setIssuedQuantity(newIssued);

                    if (newIssued < approvedQty) {
                        matchedItem.setItemStatus(ItemStatus.PARTIALLY_ISSUED);
                    } else {
                        matchedItem.setItemStatus(ItemStatus.ISSUED);
                    }
                }
            }
        }

        boolean allNowIssued = true;
        if (entity.getRequestItems() != null) {
            for (ToolRequestItemEntity item : entity.getRequestItems()) {
                int issuedQty = item.getIssuedQuantity() != null ? item.getIssuedQuantity() : 0;
                int approvedQty = item.getApprovedQuantity() != null ? item.getApprovedQuantity() : 0;
                if (issuedQty < approvedQty) {
                    allNowIssued = false;
                }
            }
        }

        if (allNowIssued) {
            entity.setApprovalStatus(ApprovalStatus.ISSUED);
        } else {
            entity.setApprovalStatus(ApprovalStatus.PARTIALLY_APPROVED);
        }

        entity.setIssuedBy(issuedBy);
        entity.setIssuedOn(new Timestamp(System.currentTimeMillis()));

        ToolRequestEntity updated = toolRequestRepository.save(entity);

        if (notificationHelperService != null && updated.getRequestedBy() != null) {
            notificationHelperService.sendNotification(
                    updated.getRequestedBy().intValue(),
                    "Tool Issued",
                    "The requested tool has been issued.",
                    "ISSUE",
                    updated.getToolRequestId().intValue(),
                    "High",
                    issuedBy != null ? issuedBy.intValue() : 1);
        }

        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void delete(
            Long toolRequestId) {

        ToolRequestEntity entity =
                toolRequestRepository.findById(toolRequestId)
                        .orElseThrow(() ->
                                new ToolResourceNotFoundException(
                                        "Tool Request Not Found"));

        if (entity.getApprovalStatus()
                == ApprovalStatus.APPROVED
                || entity.getApprovalStatus()
                == ApprovalStatus.ISSUED) {

            throw new ToolBusinessException(
                    "Approved or Issued requests cannot be deleted");
        }

        toolRequestRepository.delete(entity);
    }

    private ToolRequestResponseDto mapToResponse(
            ToolRequestEntity entity) {

        ToolRequestResponseDto dto =
                new ToolRequestResponseDto();

        dto.setToolRequestId(entity.getToolRequestId());
        dto.setProjectId(entity.getProjectId());
        dto.setRequestedBy(entity.getRequestedBy());
        dto.setRequestDate(entity.getRequestDate());
        dto.setExpectedReturnDate(entity.getExpectedReturnDate());
        dto.setApprovalStatus(entity.getApprovalStatus());
        dto.setApprovedBy(entity.getApprovedBy());
        dto.setApprovedOn(entity.getApprovedOn());
        dto.setIssuedBy(entity.getIssuedBy());
        dto.setIssuedOn(entity.getIssuedOn());
        dto.setRemarks(entity.getRemarks());

        if (entity.getRequestItems() != null) {
            List<ToolRequestItemResponseDto> itemDtos = entity.getRequestItems().stream().map(item -> {
                ToolRequestItemResponseDto itemDto = new ToolRequestItemResponseDto();
                itemDto.setToolRequestItemId(item.getToolRequestItemId());
                if (item.getToolRequest() != null) {
                    itemDto.setToolRequestId(item.getToolRequest().getToolRequestId());
                }
                if (item.getInventory() != null) {
                    itemDto.setItemId(item.getInventory().getItemId());
                    itemDto.setItemName(item.getInventory().getItemName());
                }
                itemDto.setRequestedQuantity(item.getRequestedQuantity());
                itemDto.setApprovedQuantity(item.getApprovedQuantity());
                itemDto.setIssuedQuantity(item.getIssuedQuantity());
                itemDto.setItemStatus(item.getItemStatus());
                return itemDto;
            }).collect(Collectors.toList());
            dto.setItems(itemDtos);
        }

        // Fetch User Details safely
        if (entity.getRequestedBy() != null && userClient != null) {
            try {
                UserDto userDto =
                        userClient.getUserById(entity.getRequestedBy().intValue());

                dto.setUser(userDto);

            } catch (Exception e) {
                dto.setUser(null);
            }
        }

        // Fetch Project Details safely
        if (entity.getProjectId() != null && projectClient != null) {
            try {
                ProjectTeamDto projectDto =
                        projectClient.getProjectById(entity.getProjectId().intValue());

                dto.setProject(projectDto);

                if (projectDto != null) {
                    dto.setProjectName(projectDto.getProjectName());

                    if (projectDto.getTeamLeaderId() != null) {
                        dto.setTeamLeaderId(projectDto.getTeamLeaderId().longValue());
                    }
                }

            } catch (Exception e) {
                dto.setProject(null);
            }
        }

        return dto;
    }
}