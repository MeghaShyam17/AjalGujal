package com.ilp.inventory_service.Dto;

import com.ilp.inventory_service.ToolEnums.ItemCondition;

public class ToolReturnItemDto {

    private Long toolReturnId;

    private Long itemId;

    private String itemName;

    private Integer returnedQuantity;

    private Integer damagedQuantity;

    private Integer lostQuantity;

    private ItemCondition condition;

    private Long returnedBy;

    private Long verifiedBy;

    private String remarks;

    private UserDto user;

    private ProjectTeamDto project;

    public ToolReturnItemDto() {
    }

    public Long getToolReturnId() {
        return toolReturnId;
    }

    public void setToolReturnId(Long toolReturnId) {
        this.toolReturnId = toolReturnId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getReturnedQuantity() {
        return returnedQuantity;
    }

    public void setReturnedQuantity(Integer returnedQuantity) {
        this.returnedQuantity = returnedQuantity;
    }

    public Integer getDamagedQuantity() {
        return damagedQuantity;
    }

    public void setDamagedQuantity(Integer damagedQuantity) {
        this.damagedQuantity = damagedQuantity;
    }

    public Integer getLostQuantity() {
        return lostQuantity;
    }

    public void setLostQuantity(Integer lostQuantity) {
        this.lostQuantity = lostQuantity;
    }

    public ItemCondition getCondition() {
        return condition;
    }

    public void setCondition(ItemCondition condition) {
        this.condition = condition;
    }

    public Long getReturnedBy() {
        return returnedBy;
    }

    public void setReturnedBy(Long returnedBy) {
        this.returnedBy = returnedBy;
    }

    public Long getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(Long verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public ProjectTeamDto getProject() {
        return project;
    }

    public void setProject(ProjectTeamDto project) {
        this.project = project;
    }
}