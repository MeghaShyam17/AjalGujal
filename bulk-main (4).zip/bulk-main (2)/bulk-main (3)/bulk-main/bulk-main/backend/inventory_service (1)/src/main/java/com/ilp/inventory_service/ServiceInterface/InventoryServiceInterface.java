package com.ilp.inventory_service.ServiceInterface;

import com.ilp.inventory_service.Dto.BulkUploadResponseDto;
import com.ilp.inventory_service.Entity.InventoryEntity;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface InventoryServiceInterface {

    BulkUploadResponseDto bulkUpload(MultipartFile file);

    String uploadImage(Long itemId, MultipartFile file);

    InventoryEntity saveInventoryItem(InventoryEntity inventory);

    InventoryEntity getInventoryById(Long itemId);

    InventoryEntity getInventoryByCode(String itemCode);

    List<InventoryEntity> getAllInventoryItems();

    List<InventoryEntity> getInventoryByCategory(String category);

    List<InventoryEntity> searchInventoryByName(String itemName);

    List<InventoryEntity> getInventoryByStatus(String status);

    List<InventoryEntity> getLowStockItems();

    List<InventoryEntity> getMinimumStockItems();

    List<InventoryEntity> getAvailableItems();

    List<InventoryEntity> getOutOfStockItems();

    InventoryEntity checkAvailableStock(
            Long itemId,
            Integer requestedQuantity
    );

    Long countLowStockItems();

    Long getTotalAvailableStock();

    InventoryEntity updateInventoryItem(InventoryEntity inventory);

    void deleteInventoryItem(Long itemId);

    void softDeleteInventory(Long itemId);
}
