package com.ilp.inventory_service.ServiceInterface;


import java.util.List;

import com.ilp.inventory_service.Dto.ToolRequestDto;
import com.ilp.inventory_service.Dto.ToolRequestResponseDto;

import com.ilp.inventory_service.Dto.IssueQuantityDto;

public interface ToolRequestServiceInterface {

    ToolRequestResponseDto createToolRequest(
            ToolRequestDto dto);

    ToolRequestResponseDto getById(
            Long toolRequestId);

    List<ToolRequestResponseDto> getAll();

    List<ToolRequestResponseDto> getByProjectId(
            Long projectId);

    List<ToolRequestResponseDto> getByRequestedBy(
            Long requestedBy);

    List<ToolRequestResponseDto> getPendingRequests();

    List<ToolRequestResponseDto> getApprovedRequests();

    List<ToolRequestResponseDto> getDueRequests();

    ToolRequestResponseDto approveRequest(
            Long toolRequestId,
            Long approvedBy);

    ToolRequestResponseDto rejectRequest(
            Long toolRequestId,
            Long approvedBy);

    ToolRequestResponseDto issueRequest(
            Long toolRequestId,
            Long issuedBy,
            List<IssueQuantityDto> itemsToIssue);

    void delete(
            Long toolRequestId);
}