// package ServiceImplementationJunitTest;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.sql.Timestamp;
// import java.util.Collections;
// import java.util.List;
// import java.util.Optional;
// 
// import com.ilp.inventory_service.Dto.ToolReturnDto;
// import com.ilp.inventory_service.Entity.ToolRequestEntity;
// import com.ilp.inventory_service.Entity.ToolReturnEntity;
// import com.ilp.inventory_service.Exception.ToolBusinessException;
// import com.ilp.inventory_service.Exception.ToolResourceNotFoundException;
// import com.ilp.inventory_service.Repository.ToolRequestRepository;
// import com.ilp.inventory_service.Repository.ToolReturnRepository;
// import com.ilp.inventory_service.ServiceImplementation.ToolReturnServiceImplementation;
// import com.ilp.inventory_service.ToolEnums.ReturnStatus;
// 
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;
// 
// @ExtendWith(MockitoExtension.class)
// class ToolReturnServiceImplementationJunitTest {
// 
//     @Mock
//     private ToolReturnRepository toolReturnRepository;
// 
//     @Mock
//     private ToolRequestRepository toolRequestRepository;
// 
//     @InjectMocks
//     private ToolReturnServiceImplementation service;
// 
//     private ToolReturnDto dto;
//     private ToolRequestEntity toolRequest;
//     private ToolReturnEntity returnEntity;
// 
//     @BeforeEach
//     void setUp() {
// 
//         toolRequest = new ToolRequestEntity();
//         toolRequest.setToolRequestId(1L);
//         toolRequest.setIssuedOn(
//                 new Timestamp(System.currentTimeMillis()));
// 
//         dto = new ToolReturnDto();
//         dto.setToolRequestId(1L);
//         dto.setReturnedBy(100L);
//         dto.setReceivedBy(200L);
//         dto.setRemarks("Returning Tool");
// 
//         returnEntity = new ToolReturnEntity();
//         returnEntity.setToolReturnId(10L);
//         returnEntity.setToolRequest(toolRequest);
//         returnEntity.setReturnedBy(100L);
//         returnEntity.setReceivedBy(200L);
//         returnEntity.setRemarks("Returning Tool");
//         returnEntity.setReturnDate(
//                 new Timestamp(System.currentTimeMillis()));
//         returnEntity.setReturnStatus(ReturnStatus.PENDING);
//     }
// 
//     // ==========================================
//     // CREATE RETURN
//     // ==========================================
// 
//     @Test
//     void createReturn_Success() {
// 
//         when(toolRequestRepository.findById(1L))
//                 .thenReturn(Optional.of(toolRequest));
// 
//         when(toolReturnRepository
//                 .findByToolRequestToolRequestId(1L))
//                         .thenReturn(Collections.emptyList());
// 
//         when(toolReturnRepository.save(any()))
//                 .thenReturn(returnEntity);
// 
//         ToolReturnDto result =
//                 service.createReturn(dto);
// 
//         assertNotNull(result);
//         assertEquals(100L, result.getReturnedBy());
// 
//         verify(toolReturnRepository).save(any());
//     }
// 
//     @Test
//     void createReturn_RequestNotFound() {
// 
//         when(toolRequestRepository.findById(1L))
//                 .thenReturn(Optional.empty());
// 
//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> service.createReturn(dto));
//     }
// 
//     @Test
//     void createReturn_ToolNotIssued() {
// 
//         toolRequest.setIssuedOn(null);
// 
//         when(toolRequestRepository.findById(1L))
//                 .thenReturn(Optional.of(toolRequest));
// 
//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> service.createReturn(dto));
//     }
// 
//     @Test
//     void createReturn_AlreadyExists() {
// 
//         when(toolRequestRepository.findById(1L))
//                 .thenReturn(Optional.of(toolRequest));
// 
//         when(toolReturnRepository
//                 .findByToolRequestToolRequestId(1L))
//                         .thenReturn(List.of(returnEntity));
// 
//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> service.createReturn(dto));
//     }
// 
//     // ==========================================
//     // GET BY ID
//     // ==========================================
// 
//     @Test
//     void getById_Success() {
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.of(returnEntity));
// 
//         ToolReturnDto result =
//                 service.getById(10L);
// 
//         assertEquals(10L, result.getToolReturnId());
//     }
// 
//     @Test
//     void getById_NotFound() {
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.empty());
// 
//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> service.getById(10L));
//     }
// 
//     // ==========================================
//     // GET ALL
//     // ==========================================
// 
//     @Test
//     void getAll_Success() {
// 
//         when(toolReturnRepository.findAll())
//                 .thenReturn(List.of(returnEntity));
// 
//         List<ToolReturnDto> result =
//                 service.getAll();
// 
//         assertEquals(1, result.size());
//     }
// 
//     @Test
//     void getAll_EmptyList() {
// 
//         when(toolReturnRepository.findAll())
//                 .thenReturn(Collections.emptyList());
// 
//         assertTrue(service.getAll().isEmpty());
//     }
// 
//     // ==========================================
//     // GET BY RETURNED BY
//     // ==========================================
// 
//     @Test
//     void getByReturnedBy_Success() {
// 
//         when(toolReturnRepository
//                 .findByReturnedBy(100L))
//                         .thenReturn(List.of(returnEntity));
// 
//         List<ToolReturnDto> result =
//                 service.getByReturnedBy(100L);
// 
//         assertEquals(1, result.size());
//     }
// 
//     @Test
//     void getByReturnedBy_Empty() {
// 
//         when(toolReturnRepository
//                 .findByReturnedBy(100L))
//                         .thenReturn(Collections.emptyList());
// 
//         assertTrue(
//                 service.getByReturnedBy(100L).isEmpty());
//     }
// 
//     // ==========================================
//     // GET BY PROJECT ID
//     // ==========================================
// 
//     @Test
//     void getByProjectId_Success() {
// 
//         when(toolReturnRepository
//                 .findByToolRequestProjectId(1L))
//                         .thenReturn(List.of(returnEntity));
// 
//         List<ToolReturnDto> result =
//                 service.getByProjectId(1L);
// 
//         assertEquals(1, result.size());
//     }
// 
//     @Test
//     void getByProjectId_Empty() {
// 
//         when(toolReturnRepository
//                 .findByToolRequestProjectId(1L))
//                         .thenReturn(Collections.emptyList());
// 
//         assertTrue(
//                 service.getByProjectId(1L).isEmpty());
//     }
// 
//     // ==========================================
//     // GET BY STATUS
//     // ==========================================
// 
//     @Test
//     void getByStatus_Success() {
// 
//         when(toolReturnRepository
//                 .findByReturnStatus(ReturnStatus.PENDING))
//                         .thenReturn(List.of(returnEntity));
// 
//         List<ToolReturnDto> result =
//                 service.getByStatus(
//                         ReturnStatus.PENDING);
// 
//         assertEquals(1, result.size());
//     }
// 
//     @Test
//     void getByStatus_Empty() {
// 
//         when(toolReturnRepository
//                 .findByReturnStatus(ReturnStatus.PENDING))
//                         .thenReturn(Collections.emptyList());
// 
//         assertTrue(
//                 service.getByStatus(
//                         ReturnStatus.PENDING)
//                         .isEmpty());
//     }
// 
//     // ==========================================
//     // COMPLETE RETURN
//     // ==========================================
// 
//     @Test
//     void completeReturn_Success() {
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.of(returnEntity));
// 
//         when(toolReturnRepository.save(any()))
//                 .thenReturn(returnEntity);
// 
//         ToolReturnDto result =
//                 service.completeReturn(
//                         10L,
//                         300L);
// 
//         assertNotNull(result);
// 
//         verify(toolReturnRepository)
//                 .save(any());
//     }
// 
//     @Test
//     void completeReturn_NotFound() {
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.empty());
// 
//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> service.completeReturn(
//                         10L,
//                         300L));
//     }
// 
//     @Test
//     void completeReturn_AlreadyCompleted() {
// 
//         returnEntity.setReturnStatus(
//                 ReturnStatus.COMPLETED);
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.of(returnEntity));
// 
//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> service.completeReturn(
//                         10L,
//                         300L));
//     }
// 
//     // ==========================================
//     // DELETE
//     // ==========================================
// 
//     @Test
//     void delete_Success() {
// 
//         returnEntity.setReturnStatus(
//                 ReturnStatus.PENDING);
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.of(returnEntity));
// 
//         service.delete(10L);
// 
//         verify(toolReturnRepository)
//                 .delete(returnEntity);
//     }
// 
//     @Test
//     void delete_NotFound() {
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.empty());
// 
//         assertThrows(
//                 ToolResourceNotFoundException.class,
//                 () -> service.delete(10L));
//     }
// 
//     @Test
//     void delete_CompletedReturn() {
// 
//         returnEntity.setReturnStatus(
//                 ReturnStatus.COMPLETED);
// 
//         when(toolReturnRepository.findById(10L))
//                 .thenReturn(Optional.of(returnEntity));
// 
//         assertThrows(
//                 ToolBusinessException.class,
//                 () -> service.delete(10L));
//     }
// }
// 