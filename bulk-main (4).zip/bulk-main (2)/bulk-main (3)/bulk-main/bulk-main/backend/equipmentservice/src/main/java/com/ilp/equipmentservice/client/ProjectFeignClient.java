package com.ilp.equipmentservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ilp.equipmentservice.config.FeignClientConfig;
import com.ilp.equipmentservice.dto.response.ProjectResponseDTO;

@FeignClient(
        name = "project-service",
        url = "http://localhost:8081",
        configuration = FeignClientConfig.class)
public interface ProjectFeignClient {

    @GetMapping("/api/projects/{projectId}")
    ProjectResponseDTO getProjectById(
            @PathVariable Integer projectId);
}