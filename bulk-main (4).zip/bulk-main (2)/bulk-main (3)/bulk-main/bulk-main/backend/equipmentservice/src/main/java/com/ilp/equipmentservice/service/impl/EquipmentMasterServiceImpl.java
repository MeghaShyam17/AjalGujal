package com.ilp.equipmentservice.service.impl;

import java.time.LocalDateTime;

import java.util.List;
import java.util.stream.Collectors;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;

import com.ilp.equipmentservice.dto.request.EquipmentMasterRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMasterResponseDTO;
import com.ilp.equipmentservice.entity.EquipmentMaster;
import com.ilp.equipmentservice.exception.EquipmentMasterException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentMasterRepository;
import com.ilp.equipmentservice.service.EquipmentMasterService;
//import com.ilp.equipmentservice.dto.request.EquipmentRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.dto.response.BulkUploadResponseDTO;
import com.ilp.equipmentservice.repository.EquipmentRepository;

@Service
public class EquipmentMasterServiceImpl
        implements EquipmentMasterService {

    private final EquipmentMasterRepository equipmentMasterRepository;
    private final EquipmentRepository equipmentRepository;

    public EquipmentMasterServiceImpl(
            EquipmentMasterRepository equipmentMasterRepository,
            EquipmentRepository equipmentRepository) {

        this.equipmentMasterRepository = equipmentMasterRepository;

        this.equipmentRepository = equipmentRepository;
    }


    @Override
    public EquipmentMasterResponseDTO createEquipmentMaster(
            EquipmentMasterRequestDTO requestDTO) {

        if (equipmentMasterRepository.existsByEquipmentCode(
                requestDTO.getEquipmentCode())) {

            throw new EquipmentMasterException("Equipment code already exists");
        }

        EquipmentMaster equipmentMaster =new EquipmentMaster();

        equipmentMaster.setEquipmentCode(requestDTO.getEquipmentCode());

        equipmentMaster.setEquipmentName(requestDTO.getEquipmentName());

        equipmentMaster.setEquipmentType(requestDTO.getEquipmentType());

        equipmentMaster.setMake(requestDTO.getMake());

        equipmentMaster.setSpecification(requestDTO.getSpecification());

        equipmentMaster.setTotalQuantity(requestDTO.getTotalQuantity());

        equipmentMaster.setLab(requestDTO.getLab());

        equipmentMaster.setCost(requestDTO.getCost());

        equipmentMaster.setRemarks(requestDTO.getRemarks());

        equipmentMaster.setStatus(requestDTO.getStatus());

        equipmentMaster.setEquipmentImage(requestDTO.getEquipmentImage());

        equipmentMaster.setIsActive(true);

        equipmentMaster.setCreatedAt(LocalDateTime.now());

        if (requestDTO.getEquipments() != null
                && !requestDTO.getEquipments().isEmpty()) {

            List<Equipment> equipments =
                    requestDTO.getEquipments()
                            .stream()
                            .map(dto -> {

                                Equipment equipment =new Equipment();

                                equipment.setAssetCode(dto.getAssetCode());

                                equipment.setSerialNumber(dto.getSerialNumber());

                                equipment.setBookingStatus(dto.getBookingStatus());

                                equipment.setMaintenanceStatus(dto.getMaintenanceStatus());

                                equipment.setLocation(dto.getLocation());

                                equipment.setPurchaseDate(dto.getPurchaseDate());

                                equipment.setRemarks(dto.getRemarks());

                                equipment.setEquipmentMaster(equipmentMaster);

                                equipment.setIsActive(true);

                                equipment.setCreatedAt(LocalDateTime.now());

                                return equipment;

                            })
                            .toList();

            equipmentMaster.setEquipments(equipments);
        }

        EquipmentMaster savedEquipmentMaster =
                equipmentMasterRepository.save(
                        equipmentMaster);

        return mapToResponseDTO(savedEquipmentMaster);
    }

    @Override
    public EquipmentMasterResponseDTO updateEquipmentMaster(
            Long equipmentMasterId,
            EquipmentMasterRequestDTO requestDTO) {

        EquipmentMaster equipmentMaster =
                equipmentMasterRepository
                        .findByEquipmentMasterIdAndIsActiveTrue(
                                equipmentMasterId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment Master not found"));

        equipmentMaster.setEquipmentName(requestDTO.getEquipmentName());

        equipmentMaster.setEquipmentType(requestDTO.getEquipmentType());

        equipmentMaster.setMake(requestDTO.getMake());

        equipmentMaster.setSpecification(requestDTO.getSpecification());

        equipmentMaster.setTotalQuantity(requestDTO.getTotalQuantity());

        equipmentMaster.setLab(requestDTO.getLab());

        equipmentMaster.setCost(requestDTO.getCost());

        equipmentMaster.setRemarks(requestDTO.getRemarks());

        equipmentMaster.setStatus(requestDTO.getStatus());

        equipmentMaster.setUpdatedAt(LocalDateTime.now());
        
        equipmentMaster.setEquipmentImage(
                requestDTO.getEquipmentImage());

        EquipmentMaster updatedEquipmentMaster =
                equipmentMasterRepository.save(
                        equipmentMaster);

        return mapToResponseDTO(
                updatedEquipmentMaster);
    }

    @Override
    public EquipmentMasterResponseDTO getEquipmentMasterById(
            Long equipmentMasterId) {

        EquipmentMaster equipmentMaster =
                equipmentMasterRepository
                        .findByEquipmentMasterIdAndIsActiveTrue(
                                equipmentMasterId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment Master not found"));

        return mapToResponseDTO(
                equipmentMaster);
    }

    @Override
    public List<EquipmentMasterResponseDTO>
    getAllEquipmentMasters() {

        return equipmentMasterRepository
                .findByIsActiveTrue()
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public BulkUploadResponseDTO bulkUploadEquipments(
            MultipartFile file) {

        List<String> errors =
                new ArrayList<>();

        int totalRecords = 0;
        int successCount = 0;
        int failureCount = 0;

        try {

            Workbook workbook =
                    new XSSFWorkbook(
                            file.getInputStream());

            Sheet sheet =
                    workbook.getSheetAt(0);

            boolean header = true;

            for (Row row : sheet) {

                if (header) {
                    header = false;
                    continue;
                }

                totalRecords++;

                try {

                    String equipmentCode =
                            row.getCell(0)
                                    .getStringCellValue();

                    String equipmentName =
                            row.getCell(1)
                                    .getStringCellValue();

                    String equipmentType =
                            row.getCell(2)
                                    .getStringCellValue();

                    String make =
                            row.getCell(3)
                                    .getStringCellValue();

                    String specification =
                            row.getCell(4)
                                    .getStringCellValue();

                    String lab =
                            row.getCell(5)
                                    .getStringCellValue();

                    BigDecimal cost =
                            BigDecimal.valueOf(
                                    row.getCell(6)
                                            .getNumericCellValue());

                    String status =
                            row.getCell(7)
                                    .getStringCellValue();

                    String assetCode =
                            row.getCell(8)
                                    .getStringCellValue();

                    String serialNumber =
                            row.getCell(9)
                                    .getStringCellValue();

                    String bookingStatus =
                            row.getCell(10)
                                    .getStringCellValue();

                    String maintenanceStatus =
                            row.getCell(11)
                                    .getStringCellValue();

                    String location =
                            row.getCell(12)
                                    .getStringCellValue();

//                    LocalDate purchaseDate =
//                            row.getCell(13)
//                                    .getLocalDateTimeCellValue()
//                                    .toLocalDate();
                    
                    Cell purchaseDateCell =
                            row.getCell(13);

                    LocalDate purchaseDate;

                    if (purchaseDateCell.getCellType()
                            == CellType.NUMERIC) {

                        purchaseDate =
                                purchaseDateCell
                                        .getLocalDateTimeCellValue()
                                        .toLocalDate();

                    } else {

                        purchaseDate =
                                LocalDate.parse(
                                        purchaseDateCell
                                                .getStringCellValue()
                                                .trim());
                    }

                    String remarks =
                            row.getCell(14)
                                    .getStringCellValue();

                    EquipmentMaster equipmentMaster =
                            equipmentMasterRepository
                                    .findByEquipmentCodeAndIsActiveTrue(
                                            equipmentCode)
                                    .orElse(null);

                    if (equipmentMaster == null) {

                        equipmentMaster = new EquipmentMaster();

                        equipmentMaster.setEquipmentCode(equipmentCode);

                        equipmentMaster.setEquipmentName(equipmentName);

                        equipmentMaster.setEquipmentType(equipmentType);

                        equipmentMaster.setMake(make);

                        equipmentMaster.setSpecification(specification);

                        equipmentMaster.setLab(lab);

                        equipmentMaster.setCost(cost);

                        equipmentMaster.setStatus(status);

                        equipmentMaster.setTotalQuantity(0);

                        equipmentMaster.setCreatedAt(LocalDateTime.now());

                        equipmentMaster.setIsActive(true);

                        equipmentMaster =
                                equipmentMasterRepository
                                        .save(
                                                equipmentMaster);
                    }

                    if (equipmentRepository
                            .existsByAssetCode(
                                    assetCode)) {

                        throw new RuntimeException(
                                "Duplicate Asset Code");
                    }

                    if (equipmentRepository
                            .existsBySerialNumber(
                                    serialNumber)) {

                        throw new RuntimeException(
                                "Duplicate Serial Number");
                    }

                    Equipment equipment = new Equipment();

                    equipment.setEquipmentMaster(equipmentMaster);

                    equipment.setAssetCode(assetCode);

                    equipment.setSerialNumber(serialNumber);

                    equipment.setBookingStatus(bookingStatus);

                    equipment.setMaintenanceStatus(maintenanceStatus);

                    equipment.setLocation(location);

                    equipment.setPurchaseDate(purchaseDate);

                    equipment.setRemarks(remarks);

                    equipment.setIsActive(true);

                    equipment.setCreatedAt(LocalDateTime.now());

                    equipmentRepository.save(equipment);

                    successCount++;

                } catch (Exception e) {

                    failureCount++;

                    errors.add(
                            "Row "
                                    + (row.getRowNum() + 1)
                                    + " : "
                                    + e.getMessage());
                }
            }

            workbook.close();

        } catch (Exception e) {

            throw new EquipmentMasterException(
                    "Error reading Excel file");
        }

        BulkUploadResponseDTO response = new BulkUploadResponseDTO();

        response.setTotalRecords(totalRecords);

        response.setSuccessCount(successCount);

        response.setFailureCount(failureCount);

        response.setErrors(errors);

        return response;
    }

    @Override
    public void deleteEquipmentMaster(
            Long equipmentMasterId) {

        EquipmentMaster equipmentMaster =
                equipmentMasterRepository
                        .findByEquipmentMasterIdAndIsActiveTrue(
                                equipmentMasterId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment Master not found"));

        // Soft Delete
        equipmentMaster.setIsActive(false);

        equipmentMasterRepository.save(
                equipmentMaster);
    }

    private EquipmentMasterResponseDTO mapToResponseDTO(
            EquipmentMaster equipmentMaster) {

        EquipmentMasterResponseDTO responseDTO =
                new EquipmentMasterResponseDTO();
       

        responseDTO.setEquipmentMasterId(
                equipmentMaster.getEquipmentMasterId());

        responseDTO.setEquipmentCode(
                equipmentMaster.getEquipmentCode());

        responseDTO.setEquipmentName(
                equipmentMaster.getEquipmentName());

        responseDTO.setEquipmentType(
                equipmentMaster.getEquipmentType());

        responseDTO.setMake(
                equipmentMaster.getMake());

        responseDTO.setSpecification(
                equipmentMaster.getSpecification());

        responseDTO.setTotalQuantity(
                equipmentMaster.getTotalQuantity());

        responseDTO.setLab(
                equipmentMaster.getLab());

        responseDTO.setCost(
                equipmentMaster.getCost());

        responseDTO.setRemarks(
                equipmentMaster.getRemarks());

        responseDTO.setStatus(
                equipmentMaster.getStatus());

        responseDTO.setCreatedAt(
                equipmentMaster.getCreatedAt());

        responseDTO.setUpdatedAt(
                equipmentMaster.getUpdatedAt());
        
        responseDTO.setEquipmentImage(
                equipmentMaster.getEquipmentImage());
        
        if (equipmentMaster.getEquipments() != null) {

            responseDTO.setEquipments(

                    equipmentMaster.getEquipments()
                            .stream()
                            .map(equipment -> {

                                EquipmentResponseDTO dto =
                                        new EquipmentResponseDTO();

                                dto.setEquipmentId(
                                        equipment.getEquipmentId());

                                dto.setEquipmentMasterId(
                                        equipment.getEquipmentMaster()
                                                .getEquipmentMasterId());

                                dto.setEquipmentCode(
                                        equipment.getEquipmentMaster()
                                                .getEquipmentCode());

                                dto.setEquipmentName(
                                        equipment.getEquipmentMaster()
                                                .getEquipmentName());

                                dto.setAssetCode(
                                        equipment.getAssetCode());

                                dto.setSerialNumber(
                                        equipment.getSerialNumber());

                                dto.setBookingStatus(
                                        equipment.getBookingStatus());

                                dto.setMaintenanceStatus(
                                        equipment.getMaintenanceStatus());

                                dto.setLocation(
                                        equipment.getLocation());

                                dto.setPurchaseDate(
                                        equipment.getPurchaseDate());

                                dto.setRemarks(
                                        equipment.getRemarks());

                                dto.setCreatedAt(
                                        equipment.getCreatedAt());

                                return dto;

                            })
                            .toList()
            );
        }

        return responseDTO;
    }
}