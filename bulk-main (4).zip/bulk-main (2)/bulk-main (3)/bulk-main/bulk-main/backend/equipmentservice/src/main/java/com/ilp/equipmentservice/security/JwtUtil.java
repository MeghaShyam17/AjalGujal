package com.ilp.equipmentservice.security;

import java.security.Key;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

    private static final String SECRET_KEY =
            "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXphYmNkZWY=";

    private Key getSigningKey() {

        byte[] keyBytes =
                Decoders.BASE64.decode(
                        SECRET_KEY);

        return Keys.hmacShaKeyFor(
                keyBytes);
    }

    public String extractUsername(
            String token) {

        return Jwts.parserBuilder()
                .setSigningKey(
                        getSigningKey())
                .build()
                .parseClaimsJws(
                        token)
                .getBody()
                .getSubject();
    }

    public boolean validateToken(
            String token) {

        try {

            Jwts.parserBuilder()
                    .setSigningKey(
                            getSigningKey())
                    .build()
                    .parseClaimsJws(
                            token);

            return true;

        } catch (Exception e) {

            return false;
        }
    }
}