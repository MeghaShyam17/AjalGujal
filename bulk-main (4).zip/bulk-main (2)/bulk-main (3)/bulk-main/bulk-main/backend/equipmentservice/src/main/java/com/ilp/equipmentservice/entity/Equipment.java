package com.ilp.equipmentservice.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "equipment")
public class Equipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "equipment_id")
    private Long equipmentId;

    @Column(name = "asset_code", unique = true, length = 30)
    private String assetCode;

    @Column(name = "serial_number", unique = true, length = 100)
    private String serialNumber;

    @Column(name = "booking_status", length = 20)
    private String bookingStatus;

    @Column(name = "maintenance_status", length = 20)
    private String maintenanceStatus;

    @Column(name = "location", length = 100)
    private String location;

    @Column(name = "purchase_date")
    private LocalDate purchaseDate;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    //soft delete
    @Column(name = "is_active")
    private Boolean isActive = true;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "equipment_master_id",
            referencedColumnName = "equipment_master_id"
    )
    private EquipmentMaster equipmentMaster;

    @OneToMany(mappedBy = "equipment",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<EquipmentBooking> equipmentBookings;

    @OneToMany(mappedBy = "equipment",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<EquipmentMaintenance> equipmentMaintenances;

    // Temporarily removed until DamageReport service is available
    // private List<DamageReport> damageReports;

    public Equipment() {
    }

    public Long getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(Long equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getAssetCode() {
        return assetCode;
    }

    public void setAssetCode(String assetCode) {
        this.assetCode = assetCode;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public String getMaintenanceStatus() {
        return maintenanceStatus;
    }

    public void setMaintenanceStatus(String maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public EquipmentMaster getEquipmentMaster() {
        return equipmentMaster;
    }

    public void setEquipmentMaster(EquipmentMaster equipmentMaster) {
        this.equipmentMaster = equipmentMaster;
    }

    public List<EquipmentBooking> getEquipmentBookings() {
        return equipmentBookings;
    }

    public void setEquipmentBookings(List<EquipmentBooking> equipmentBookings) {
        this.equipmentBookings = equipmentBookings;
    }

    public List<EquipmentMaintenance> getEquipmentMaintenances() {
        return equipmentMaintenances;
    }

    public void setEquipmentMaintenances(List<EquipmentMaintenance> equipmentMaintenances) {
        this.equipmentMaintenances = equipmentMaintenances;
    }
    

    //soft delete
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
}