package com.ilp.equipmentservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.equipmentservice.entity.EquipmentMaster;

@Repository
public interface EquipmentMasterRepository
        extends JpaRepository<EquipmentMaster, Long> {

    Optional<EquipmentMaster> findByEquipmentCode(
            String equipmentCode);

    Optional<EquipmentMaster> findByEquipmentName(
            String equipmentName);

    List<EquipmentMaster> findByEquipmentType(
            String equipmentType);

    List<EquipmentMaster> findByLab(
            String lab);

    List<EquipmentMaster> findByStatus(
            String status);

    boolean existsByEquipmentCode(
            String equipmentCode);

    boolean existsByEquipmentName(
            String equipmentName);

    // Soft Delete

    List<EquipmentMaster> findByIsActiveTrue();

    Optional<EquipmentMaster>
    findByEquipmentMasterIdAndIsActiveTrue(
            Long equipmentMasterId);

    Optional<EquipmentMaster>
    findByEquipmentCodeAndIsActiveTrue(
            String equipmentCode);
}