package com.ilp.equipmentservice.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.equipmentservice.entity.EquipmentBooking;

@Repository
public interface EquipmentBookingRepository
        extends JpaRepository<EquipmentBooking, Long> {

    /**
     * Find all bookings for an equipment.
     */
    List<EquipmentBooking> findByEquipmentEquipmentId(
            Long equipmentId);

    /**
     * Find all bookings for a project.
     */
    List<EquipmentBooking> findByProjectId(
            Long projectId);

    /**
     * Find all bookings made by a user.
     */
    List<EquipmentBooking> findByRequestedBy(
            Long requestedBy);

    /**
     * Find all bookings approved by a user.
     */
    List<EquipmentBooking> findByApprovedBy(
            Long approvedBy);

    /**
     * Find bookings by approval status.
     */
    List<EquipmentBooking> findByApprovalStatus(
            String approvalStatus);

    /**
     * Find bookings for a specific date.
     */
    List<EquipmentBooking> findByBookingDate(
            LocalDate bookingDate);

    /**
     * Find bookings for an equipment with a specific status.
     */
    List<EquipmentBooking> findByEquipmentEquipmentIdAndApprovalStatus(
            Long equipmentId,
            String approvalStatus);

    /**
     * Find bookings for an equipment on a specific date.
     */
    List<EquipmentBooking> findByEquipmentEquipmentIdAndBookingDate(
            Long equipmentId,
            LocalDate bookingDate);

    /**
     * Find bookings excluding a specific status.
     */
    List<EquipmentBooking>
    findByEquipmentEquipmentIdAndBookingDateAndApprovalStatusNot(
            Long equipmentId,
            LocalDate bookingDate,
            String approvalStatus);

    /**
     * Find bookings with a specific status
     * on a specific date for an equipment.
     */
    List<EquipmentBooking>
    findByEquipmentEquipmentIdAndBookingDateAndApprovalStatus(
            Long equipmentId,
            LocalDate bookingDate,
            String approvalStatus);
}
