package com.ilp.equipmentservice.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.ilp.equipmentservice.dto.request.EquipmentRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentMaster;
import com.ilp.equipmentservice.exception.EquipmentException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentMasterRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.EquipmentService;

@Service
public class EquipmentServiceImpl
        implements EquipmentService {

    private final EquipmentRepository equipmentRepository;

    private final EquipmentMasterRepository equipmentMasterRepository;

    public EquipmentServiceImpl(
            EquipmentRepository equipmentRepository,
            EquipmentMasterRepository equipmentMasterRepository) {

        this.equipmentRepository = equipmentRepository;
        this.equipmentMasterRepository = equipmentMasterRepository;
    }

    @Override
    public EquipmentResponseDTO createEquipment(
            EquipmentRequestDTO requestDTO) {

        EquipmentMaster equipmentMaster =
                equipmentMasterRepository
                        .findByEquipmentMasterIdAndIsActiveTrue(
                                requestDTO.getEquipmentMasterId())
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment Master not found"));

        if (equipmentRepository.existsByAssetCode(
                requestDTO.getAssetCode())) {

            throw new EquipmentException(
                    "Asset code already exists");
        }

        if (equipmentRepository.existsBySerialNumber(
                requestDTO.getSerialNumber())) {

            throw new EquipmentException(
                    "Serial number already exists");
        }

        Equipment equipment = new Equipment();

        equipment.setEquipmentMaster(
                equipmentMaster);

        equipment.setAssetCode(
                requestDTO.getAssetCode());

        equipment.setSerialNumber(
                requestDTO.getSerialNumber());

        equipment.setBookingStatus(
                requestDTO.getBookingStatus());

        equipment.setMaintenanceStatus(
                requestDTO.getMaintenanceStatus());

        equipment.setLocation(
                requestDTO.getLocation());

        equipment.setPurchaseDate(
                requestDTO.getPurchaseDate());

        equipment.setRemarks(
                requestDTO.getRemarks());

        equipment.setIsActive(true);

        equipment.setCreatedAt(
                LocalDateTime.now());

        Equipment savedEquipment =
                equipmentRepository.save(
                        equipment);

        return mapToResponse(savedEquipment);
    }

    @Override
    public EquipmentResponseDTO getEquipmentById(
            Long equipmentId) {

        Equipment equipment =
                equipmentRepository
                        .findByEquipmentIdAndIsActiveTrue(
                                equipmentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment not found"));

        return mapToResponse(equipment);
    }

    @Override
    public List<EquipmentResponseDTO> getAllEquipments() {

        return equipmentRepository
                .findByIsActiveTrue()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public EquipmentResponseDTO updateEquipment(
            Long equipmentId,
            EquipmentRequestDTO requestDTO) {

        Equipment equipment =
                equipmentRepository
                        .findByEquipmentIdAndIsActiveTrue(
                                equipmentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment not found"));

        EquipmentMaster equipmentMaster =
                equipmentMasterRepository
                        .findByEquipmentMasterIdAndIsActiveTrue(
                                requestDTO.getEquipmentMasterId())
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment Master not found"));

        equipment.setEquipmentMaster(
                equipmentMaster);

        equipment.setAssetCode(
                requestDTO.getAssetCode());

        equipment.setSerialNumber(
                requestDTO.getSerialNumber());

        equipment.setBookingStatus(
                requestDTO.getBookingStatus());

        equipment.setMaintenanceStatus(
                requestDTO.getMaintenanceStatus());

        equipment.setLocation(
                requestDTO.getLocation());

        equipment.setPurchaseDate(
                requestDTO.getPurchaseDate());

        equipment.setRemarks(
                requestDTO.getRemarks());

        Equipment updatedEquipment =
                equipmentRepository.save(
                        equipment);

        return mapToResponse(updatedEquipment);
    }

    @Override
    public void deleteEquipment(
            Long equipmentId) {

        Equipment equipment =
                equipmentRepository
                        .findByEquipmentIdAndIsActiveTrue(
                                equipmentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Equipment not found"));

        // Soft Delete
        equipment.setIsActive(false);

        equipmentRepository.save(
                equipment);
    }

    private EquipmentResponseDTO mapToResponse(
            Equipment equipment) {

        EquipmentResponseDTO dto =
                new EquipmentResponseDTO();

        dto.setEquipmentId(
                equipment.getEquipmentId());

        dto.setEquipmentMasterId(
                equipment.getEquipmentMaster()
                        .getEquipmentMasterId());

        dto.setEquipmentCode(
                equipment.getEquipmentMaster()
                        .getEquipmentCode());

        dto.setEquipmentName(
                equipment.getEquipmentMaster()
                        .getEquipmentName());

        dto.setAssetCode(
                equipment.getAssetCode());

        dto.setSerialNumber(
                equipment.getSerialNumber());

        dto.setBookingStatus(
                equipment.getBookingStatus());

        dto.setMaintenanceStatus(
                equipment.getMaintenanceStatus());

        dto.setLocation(
                equipment.getLocation());

        dto.setPurchaseDate(
                equipment.getPurchaseDate());

        dto.setRemarks(
                equipment.getRemarks());

        dto.setCreatedAt(
                equipment.getCreatedAt());

        return dto;
    }
}