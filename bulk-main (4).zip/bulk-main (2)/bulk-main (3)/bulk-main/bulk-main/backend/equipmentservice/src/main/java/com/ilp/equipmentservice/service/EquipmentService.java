package com.ilp.equipmentservice.service;

import java.util.List;

import com.ilp.equipmentservice.dto.request.EquipmentRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentResponseDTO;

public interface EquipmentService {

    EquipmentResponseDTO createEquipment(
            EquipmentRequestDTO requestDTO);

    EquipmentResponseDTO getEquipmentById(
            Long equipmentId);

    List<EquipmentResponseDTO> getAllEquipments();

    EquipmentResponseDTO updateEquipment(
            Long equipmentId,
            EquipmentRequestDTO requestDTO);

    void deleteEquipment(
            Long equipmentId);
}
