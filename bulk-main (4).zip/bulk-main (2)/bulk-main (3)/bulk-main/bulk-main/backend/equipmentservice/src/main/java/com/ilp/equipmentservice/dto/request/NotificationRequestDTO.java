package com.ilp.equipmentservice.dto.request;

public class NotificationRequestDTO {

    private Integer userId;

    private String title;

    private String message;

    private String notificationType;

    private String moduleName;

    private Integer referenceId;

    private String priority;

    private Integer createdBy;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(
            Integer userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(
            String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(
            String message) {
        this.message = message;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(
            String notificationType) {
        this.notificationType = notificationType;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(
            String moduleName) {
        this.moduleName = moduleName;
    }

    public Integer getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(
            Integer referenceId) {
        this.referenceId = referenceId;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(
            String priority) {
        this.priority = priority;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(
            Integer createdBy) {
        this.createdBy = createdBy;
    }
}