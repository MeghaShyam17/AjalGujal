package com.ilp.equipmentservice.exception;

public class EquipmentException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EquipmentException() {
        super();
    }

    public EquipmentException(String message) {
        super(message);
    }

    public EquipmentException(String message, Throwable cause) {
        super(message, cause);
    }
}