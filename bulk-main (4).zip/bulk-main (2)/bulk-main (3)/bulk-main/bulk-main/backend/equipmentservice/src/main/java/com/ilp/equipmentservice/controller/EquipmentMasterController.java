package com.ilp.equipmentservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.equipmentservice.dto.request.EquipmentMasterRequestDTO;
import com.ilp.equipmentservice.dto.response.BulkUploadResponseDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMasterResponseDTO;
import com.ilp.equipmentservice.service.EquipmentMasterService;

@RestController
@RequestMapping("/api/equipment-masters")
public class EquipmentMasterController {

    private final EquipmentMasterService equipmentMasterService;

    public EquipmentMasterController(
            EquipmentMasterService equipmentMasterService) {

        this.equipmentMasterService = equipmentMasterService;
    }

    @PostMapping
    public ResponseEntity<EquipmentMasterResponseDTO>
    createEquipmentMaster(
            @RequestBody EquipmentMasterRequestDTO requestDTO) {

        return new ResponseEntity<>(
                equipmentMasterService.createEquipmentMaster(
                        requestDTO),
                HttpStatus.CREATED);
    }

    @PostMapping(
            value = "/bulk-upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<BulkUploadResponseDTO>
    bulkUploadEquipments(
            @RequestParam("file") MultipartFile file) {

        return ResponseEntity.ok(
                equipmentMasterService
                        .bulkUploadEquipments(file));
    }

    @PutMapping("/{equipmentMasterId}")
    public ResponseEntity<EquipmentMasterResponseDTO>
    updateEquipmentMaster(
            @PathVariable Long equipmentMasterId,
            @RequestBody EquipmentMasterRequestDTO requestDTO) {

        return ResponseEntity.ok(
                equipmentMasterService.updateEquipmentMaster(
                        equipmentMasterId,
                        requestDTO));
    }

    @GetMapping("/{equipmentMasterId}")
    public ResponseEntity<EquipmentMasterResponseDTO>
    getEquipmentMasterById(
            @PathVariable Long equipmentMasterId) {

        return ResponseEntity.ok(
                equipmentMasterService.getEquipmentMasterById(
                        equipmentMasterId));
    }

    @GetMapping
    public ResponseEntity<List<EquipmentMasterResponseDTO>>
    getAllEquipmentMasters() {

        return ResponseEntity.ok(
                equipmentMasterService.getAllEquipmentMasters());
    }

    @DeleteMapping("/{equipmentMasterId}")
    public ResponseEntity<String>
    deleteEquipmentMaster(
            @PathVariable Long equipmentMasterId) {

        equipmentMasterService.deleteEquipmentMaster(
                equipmentMasterId);

        return ResponseEntity.ok(
                "Equipment Master deleted successfully");
    }
}