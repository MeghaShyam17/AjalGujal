package com.ilp.equipmentservice.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ilp.equipmentservice.dto.request.EquipmentMasterRequestDTO;
import com.ilp.equipmentservice.dto.response.BulkUploadResponseDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMasterResponseDTO;

public interface EquipmentMasterService {

    EquipmentMasterResponseDTO createEquipmentMaster(
            EquipmentMasterRequestDTO requestDTO);

    EquipmentMasterResponseDTO updateEquipmentMaster(
            Long equipmentMasterId,
            EquipmentMasterRequestDTO requestDTO);

    EquipmentMasterResponseDTO getEquipmentMasterById(
            Long equipmentMasterId);

    List<EquipmentMasterResponseDTO> getAllEquipmentMasters();
    
    BulkUploadResponseDTO bulkUploadEquipments(MultipartFile file);

    void deleteEquipmentMaster(Long equipmentMasterId);
}