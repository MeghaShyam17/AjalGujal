package com.ilp.equipmentservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.equipmentservice.entity.EquipmentMaintenance;

@Repository
public interface EquipmentMaintenanceRepository
        extends JpaRepository<EquipmentMaintenance, Long> {

    List<EquipmentMaintenance> findByEquipmentEquipmentId(Long equipmentId);

    List<EquipmentMaintenance> findByMaintenanceStatus(String maintenanceStatus);

    List<EquipmentMaintenance> findByEquipmentEquipmentIdAndMaintenanceStatus(
    		Long equipmentId,
            String maintenanceStatus
    );
}