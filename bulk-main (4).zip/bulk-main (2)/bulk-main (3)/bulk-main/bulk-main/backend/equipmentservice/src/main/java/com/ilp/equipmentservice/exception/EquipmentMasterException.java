package com.ilp.equipmentservice.exception;

public class EquipmentMasterException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EquipmentMasterException(String message) {
        super(message);
    }
}