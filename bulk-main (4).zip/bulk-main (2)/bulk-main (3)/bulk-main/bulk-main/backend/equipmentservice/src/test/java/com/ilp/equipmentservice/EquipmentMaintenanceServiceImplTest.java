package com.ilp.equipmentservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.FeignException;

import com.ilp.equipmentservice.client.NotificationFeignClient;
import com.ilp.equipmentservice.client.UserFeignClient;
import com.ilp.equipmentservice.dto.request.EquipmentMaintenanceRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMaintenanceResponseDTO;
import com.ilp.equipmentservice.dto.response.UserResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentBooking;
import com.ilp.equipmentservice.entity.EquipmentMaintenance;
import com.ilp.equipmentservice.exception.EquipmentMaintenanceException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentBookingRepository;
import com.ilp.equipmentservice.repository.EquipmentMaintenanceRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.impl.EquipmentMaintenanceServiceImpl;

@ExtendWith(MockitoExtension.class)
class EquipmentMaintenanceServiceImplTest {

    @Mock
    private EquipmentMaintenanceRepository maintenanceRepository;

    @Mock
    private EquipmentRepository equipmentRepository;

    @Mock
    private UserFeignClient userFeignClient;

    @Mock
    private EquipmentBookingRepository equipmentBookingRepository;

    @Mock
    private NotificationFeignClient notificationFeignClient;

    @InjectMocks
    private EquipmentMaintenanceServiceImpl service;

    private EquipmentMaintenanceRequestDTO requestDTO;
    private Equipment equipment;
    private UserResponseDTO user;

    @BeforeEach
    void setUp() {

        requestDTO = new EquipmentMaintenanceRequestDTO();

        requestDTO.setEquipmentId(1L);
        requestDTO.setMaintenanceType("Corrective");
        requestDTO.setMaintenanceReason("Testing");
        requestDTO.setMaintenanceStatus("Scheduled");
        requestDTO.setStartDate(
                LocalDate.now().plusDays(1));
        requestDTO.setEndDate(
                LocalDate.now().plusDays(2));
        requestDTO.setMaintainedBy(10L);
        requestDTO.setRemarks("Test");

        equipment = new Equipment();
        equipment.setEquipmentId(1L);
        equipment.setAssetCode("AST001");

        user = new UserResponseDTO();
    }

    @Test
    void createMaintenanceSuccess() {

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        when(maintenanceRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of());

        EquipmentMaintenance saved =
                new EquipmentMaintenance();

        saved.setMaintenanceId(1L);
        saved.setEquipment(equipment);
        saved.setCreatedAt(LocalDateTime.now());

        when(maintenanceRepository.save(any()))
                .thenReturn(saved);

        when(equipmentBookingRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of());

        EquipmentMaintenanceResponseDTO response =
                service.createMaintenanceSchedule(
                        requestDTO);

        assertNotNull(response);
        assertEquals(
                1L,
                response.getMaintenanceId());
    }

    @Test
    void createMaintenanceUserNotFound() {

        when(userFeignClient.getUserById(10))
                .thenThrow(FeignException.NotFound.class);

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.createMaintenanceSchedule(
                        requestDTO));
    }

    @Test
    void createMaintenanceEquipmentNotFound() {

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.createMaintenanceSchedule(
                        requestDTO));
    }

    @Test
    void createMaintenancePastDate() {

        requestDTO.setStartDate(
                LocalDate.now().minusDays(1));

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        assertThrows(
                EquipmentMaintenanceException.class,
                () -> service.createMaintenanceSchedule(
                        requestDTO));
    }

    @Test
    void createMaintenanceEndDateBeforeStartDate() {

        requestDTO.setEndDate(
                requestDTO.getStartDate()
                        .minusDays(1));

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        assertThrows(
                EquipmentMaintenanceException.class,
                () -> service.createMaintenanceSchedule(
                        requestDTO));
    }

    @Test
    void createMaintenanceOverlap() {

        EquipmentMaintenance existing =
                new EquipmentMaintenance();

        existing.setMaintenanceId(99L);

        existing.setStartDate(
                requestDTO.getStartDate());

        existing.setEndDate(
                requestDTO.getEndDate());

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        when(maintenanceRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of(existing));

        assertThrows(
                EquipmentMaintenanceException.class,
                () -> service.createMaintenanceSchedule(
                        requestDTO));
    }

    @Test
    void getMaintenanceByIdSuccess() {

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setMaintenanceId(1L);
        maintenance.setEquipment(equipment);

        when(maintenanceRepository.findById(1L))
                .thenReturn(Optional.of(maintenance));

        EquipmentMaintenanceResponseDTO response =
                service.getMaintenanceById(1L);

        assertEquals(
                1L,
                response.getMaintenanceId());
    }

    @Test
    void getMaintenanceByIdNotFound() {

        when(maintenanceRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getMaintenanceById(
                        1L));
    }

    @Test
    void getAllMaintenanceSchedules() {

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setMaintenanceId(1L);
        maintenance.setEquipment(equipment);

        when(maintenanceRepository.findAll())
                .thenReturn(List.of(maintenance));

        List<EquipmentMaintenanceResponseDTO> result =
                service.getAllMaintenanceSchedules();

        assertEquals(
                1,
                result.size());
    }

    @Test
    void getMaintenanceByEquipmentId() {

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setMaintenanceId(1L);
        maintenance.setEquipment(equipment);

        when(maintenanceRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of(maintenance));

        List<EquipmentMaintenanceResponseDTO> result =
                service.getMaintenanceByEquipmentId(1L);

        assertEquals(
                1,
                result.size());
    }

    @Test
    void updateMaintenanceSuccess() {

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setMaintenanceId(1L);
        maintenance.setEquipment(equipment);

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(maintenanceRepository.findById(1L))
                .thenReturn(Optional.of(maintenance));

        when(maintenanceRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of());

        when(maintenanceRepository.save(any()))
                .thenReturn(maintenance);

        EquipmentMaintenanceResponseDTO response =
                service.updateMaintenanceSchedule(
                        1L,
                        requestDTO);

        assertNotNull(response);
    }

    @Test
    void updateMaintenanceUserNotFound() {

        when(userFeignClient.getUserById(10))
                .thenThrow(FeignException.NotFound.class);

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateMaintenanceSchedule(
                        1L,
                        requestDTO));
    }

    @Test
    void updateMaintenanceNotFound() {

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(maintenanceRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateMaintenanceSchedule(
                        1L,
                        requestDTO));
    }

    @Test
    void deleteMaintenanceSuccess() {

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setMaintenanceId(1L);

        when(maintenanceRepository.findById(1L))
                .thenReturn(Optional.of(maintenance));

        service.deleteMaintenanceSchedule(1L);

        verify(maintenanceRepository)
                .delete(maintenance);
    }

    @Test
    void deleteMaintenanceNotFound() {

        when(maintenanceRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.deleteMaintenanceSchedule(
                        1L));
    }

    @Test
    void createMaintenanceCancelsBookings() {

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setRequestedBy(20L);
        booking.setApprovalStatus("Approved");
        booking.setBookingDate(
                requestDTO.getStartDate());
        booking.setEquipment(equipment);

        when(userFeignClient.getUserById(10))
                .thenReturn(user);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        when(maintenanceRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of());

        EquipmentMaintenance saved =
                new EquipmentMaintenance();

        saved.setMaintenanceId(1L);
        saved.setEquipment(equipment);
        saved.setMaintainedBy(10L);
        saved.setStartDate(
                requestDTO.getStartDate());
        saved.setEndDate(
                requestDTO.getEndDate());

        when(maintenanceRepository.save(any()))
                .thenReturn(saved);

        when(equipmentBookingRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of(booking));

        service.createMaintenanceSchedule(
                requestDTO);

        verify(equipmentBookingRepository,
                atLeastOnce())
                .save(any());

        verify(notificationFeignClient)
                .createNotification(any());
    }
}