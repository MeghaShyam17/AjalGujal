package com.ilp.equipmentservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.mock.web.MockMultipartFile;

import com.ilp.equipmentservice.dto.request.EquipmentMasterRequestDTO;
import com.ilp.equipmentservice.dto.request.EquipmentRequestDTO;
import com.ilp.equipmentservice.dto.response.BulkUploadResponseDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMasterResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentMaster;
import com.ilp.equipmentservice.exception.EquipmentMasterException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentMasterRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.impl.EquipmentMasterServiceImpl;

@ExtendWith(MockitoExtension.class)
class EquipmentMasterServiceImplTest {

    @Mock
    private EquipmentMasterRepository equipmentMasterRepository;

    @Mock
    private EquipmentRepository equipmentRepository;

    @InjectMocks
    private EquipmentMasterServiceImpl service;

    private EquipmentMasterRequestDTO requestDTO;

    @BeforeEach
    void setUp() {

        requestDTO = new EquipmentMasterRequestDTO();

        requestDTO.setEquipmentCode("EQP001");
        requestDTO.setEquipmentName("Laptop");
        requestDTO.setEquipmentType("Laptop");
        requestDTO.setMake("Dell");
        requestDTO.setSpecification("i7");
        requestDTO.setTotalQuantity(2);
        requestDTO.setLab("Lab A");
        requestDTO.setCost(BigDecimal.valueOf(1000));
        requestDTO.setStatus("AVAILABLE");

        EquipmentRequestDTO equipment =
                new EquipmentRequestDTO();

        equipment.setAssetCode("AST001");
        equipment.setSerialNumber("SN001");
        equipment.setBookingStatus("AVAILABLE");
        equipment.setMaintenanceStatus("GOOD");
        equipment.setLocation("Lab");
        equipment.setPurchaseDate(
                LocalDate.now());

        requestDTO.setEquipments(
                List.of(equipment));
    }

    @Test
    void createEquipmentMasterSuccess() {

        when(equipmentMasterRepository
                .existsByEquipmentCode("EQP001"))
                .thenReturn(false);

        EquipmentMaster master =
                new EquipmentMaster();

        master.setEquipmentMasterId(1L);
        master.setEquipmentCode("EQP001");

        when(equipmentMasterRepository.save(any()))
                .thenReturn(master);

        EquipmentMasterResponseDTO response =
                service.createEquipmentMaster(
                        requestDTO);

        assertNotNull(response);
        assertEquals(
                "EQP001",
                response.getEquipmentCode());
    }

    @Test
    void createEquipmentMasterDuplicateCode() {

        when(equipmentMasterRepository
                .existsByEquipmentCode("EQP001"))
                .thenReturn(true);

        assertThrows(
                EquipmentMasterException.class,
                () -> service.createEquipmentMaster(
                        requestDTO));
    }

    @Test
    void updateEquipmentMasterSuccess() {

        EquipmentMaster master =
                new EquipmentMaster();

        master.setEquipmentMasterId(1L);

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(
                        1L))
                .thenReturn(Optional.of(master));

        when(equipmentMasterRepository.save(any()))
                .thenReturn(master);

        EquipmentMasterResponseDTO response =
                service.updateEquipmentMaster(
                        1L,
                        requestDTO);

        assertNotNull(response);
    }

    @Test
    void updateEquipmentMasterNotFound() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(
                        1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateEquipmentMaster(
                        1L,
                        requestDTO));
    }

    @Test
    void getEquipmentMasterByIdSuccess() {

        EquipmentMaster master =
                new EquipmentMaster();

        master.setEquipmentMasterId(1L);
        master.setEquipmentCode("EQP001");

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(
                        1L))
                .thenReturn(Optional.of(master));

        EquipmentMasterResponseDTO response =
                service.getEquipmentMasterById(1L);

        assertEquals(
                "EQP001",
                response.getEquipmentCode());
    }

    @Test
    void getEquipmentMasterByIdNotFound() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(
                        1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getEquipmentMasterById(
                        1L));
    }

    @Test
    void getAllEquipmentMasters() {

        EquipmentMaster master =
                new EquipmentMaster();

        master.setEquipmentMasterId(1L);
        master.setEquipmentCode("EQP001");

        when(equipmentMasterRepository
                .findByIsActiveTrue())
                .thenReturn(List.of(master));

        List<EquipmentMasterResponseDTO> result =
                service.getAllEquipmentMasters();

        assertEquals(
                1,
                result.size());
    }

    @Test
    void deleteEquipmentMasterSuccess() {

        EquipmentMaster master =
                new EquipmentMaster();

        master.setEquipmentMasterId(1L);
        master.setIsActive(true);

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(
                        1L))
                .thenReturn(Optional.of(master));

        service.deleteEquipmentMaster(1L);

        verify(equipmentMasterRepository)
                .save(master);

        assertFalse(master.getIsActive());
    }

    @Test
    void deleteEquipmentMasterNotFound() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(
                        1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.deleteEquipmentMaster(
                        1L));
    }

    @Test
    void bulkUploadSuccess() throws Exception {

        Workbook workbook =
                new XSSFWorkbook();

        var sheet =
                workbook.createSheet();

        Row header =
                sheet.createRow(0);

        for (int i = 0; i < 15; i++) {
            header.createCell(i)
                    .setCellValue("H");
        }

        Row row =
                sheet.createRow(1);

        row.createCell(0)
                .setCellValue("EQP001");
        row.createCell(1)
                .setCellValue("Laptop");
        row.createCell(2)
                .setCellValue("Laptop");
        row.createCell(3)
                .setCellValue("Dell");
        row.createCell(4)
                .setCellValue("i7");
        row.createCell(5)
                .setCellValue("Lab");
        row.createCell(6)
                .setCellValue(1000);
        row.createCell(7)
                .setCellValue("AVAILABLE");
        row.createCell(8)
                .setCellValue("AST001");
        row.createCell(9)
                .setCellValue("SN001");
        row.createCell(10)
                .setCellValue("AVAILABLE");
        row.createCell(11)
                .setCellValue("GOOD");
        row.createCell(12)
                .setCellValue("Lab");
        row.createCell(13)
                .setCellValue("2026-08-05");
        row.createCell(14)
                .setCellValue("Test");

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        workbook.write(output);

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.xlsx",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        output.toByteArray());

        when(equipmentMasterRepository
                .findByEquipmentCodeAndIsActiveTrue(any()))
                .thenReturn(Optional.empty());

        when(equipmentMasterRepository.save(any()))
                .thenReturn(new EquipmentMaster());

        when(equipmentRepository.existsByAssetCode(any()))
                .thenReturn(false);

        when(equipmentRepository.existsBySerialNumber(any()))
                .thenReturn(false);

        when(equipmentRepository.save(any(Equipment.class)))
                .thenReturn(new Equipment());

        BulkUploadResponseDTO response =
                service.bulkUploadEquipments(file);
        
        System.out.println(response.getErrors());

        assertEquals(
                1,
                response.getSuccessCount());
    }

    @Test
    void bulkUploadDuplicateAssetCode() throws Exception {

        Workbook workbook =
                new XSSFWorkbook();

        workbook.createSheet()
                .createRow(0);

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        workbook.write(output);

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.xlsx",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        output.toByteArray());

        BulkUploadResponseDTO response =
                service.bulkUploadEquipments(file);

        assertNotNull(response);
    }

    @Test
    void bulkUploadInvalidFile() {

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "invalid.xlsx",
                        "application/octet-stream",
                        "invalid".getBytes());

        assertThrows(
                EquipmentMasterException.class,
                () -> service.bulkUploadEquipments(
                        file));
    }
}