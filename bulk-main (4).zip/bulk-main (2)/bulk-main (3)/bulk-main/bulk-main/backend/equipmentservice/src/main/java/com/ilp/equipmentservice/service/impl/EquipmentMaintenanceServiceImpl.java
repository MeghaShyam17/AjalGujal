package com.ilp.equipmentservice.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import feign.FeignException;

import com.ilp.equipmentservice.client.NotificationFeignClient;
import com.ilp.equipmentservice.client.UserFeignClient;
import com.ilp.equipmentservice.dto.request.EquipmentMaintenanceRequestDTO;
import com.ilp.equipmentservice.dto.request.NotificationRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMaintenanceResponseDTO;
import com.ilp.equipmentservice.dto.response.UserResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentBooking;
import com.ilp.equipmentservice.entity.EquipmentMaintenance;
import com.ilp.equipmentservice.exception.EquipmentMaintenanceException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentBookingRepository;
import com.ilp.equipmentservice.repository.EquipmentMaintenanceRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.EquipmentMaintenanceService;

@Service
public class EquipmentMaintenanceServiceImpl
        implements EquipmentMaintenanceService {

    private static final String STATUS_SCHEDULED = "Scheduled";
    private static final String STATUS_IN_PROGRESS = "In Progress";
    private static final String STATUS_COMPLETED = "Completed";

    private final EquipmentMaintenanceRepository maintenanceRepository;
    private final EquipmentRepository equipmentRepository;
    private final UserFeignClient userFeignClient;
    private final EquipmentBookingRepository equipmentBookingRepository;
    private final NotificationFeignClient notificationFeignClient;

    public EquipmentMaintenanceServiceImpl(
            EquipmentMaintenanceRepository maintenanceRepository,
            EquipmentRepository equipmentRepository,
            UserFeignClient userFeignClient,
            EquipmentBookingRepository equipmentBookingRepository,
            NotificationFeignClient notificationFeignClient) {

        this.maintenanceRepository = maintenanceRepository;
        this.equipmentRepository = equipmentRepository;
        this.userFeignClient = userFeignClient;
        this.equipmentBookingRepository = equipmentBookingRepository;
        this.notificationFeignClient = notificationFeignClient;
    }

    @Override
    public EquipmentMaintenanceResponseDTO createMaintenanceSchedule(
            EquipmentMaintenanceRequestDTO requestDTO) {

        validateMaintenanceUser(requestDTO.getMaintainedBy());

        Equipment equipment = equipmentRepository
                .findById(requestDTO.getEquipmentId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Equipment not found"));

        if (requestDTO.getStartDate().isBefore(LocalDate.now())) {
            throw new EquipmentMaintenanceException(
                    "Maintenance start date cannot be in the past");
        }

        if (requestDTO.getEndDate().isBefore(
                requestDTO.getStartDate())) {
            throw new EquipmentMaintenanceException(
                    "Maintenance end date cannot be before start date");
        }

        validateMaintenanceOverlap(
                requestDTO.getEquipmentId(),
                null,
                requestDTO.getStartDate(),
                requestDTO.getEndDate());

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setEquipment(equipment);
        maintenance.setMaintenanceType(
                requestDTO.getMaintenanceType());
        maintenance.setMaintenanceReason(
                requestDTO.getMaintenanceReason());
        maintenance.setStartDate(
                requestDTO.getStartDate());
        maintenance.setEndDate(
                requestDTO.getEndDate());
        maintenance.setMaintainedBy(
                requestDTO.getMaintainedBy());
        maintenance.setRemarks(
                requestDTO.getRemarks());
        maintenance.setCreatedAt(
                LocalDateTime.now());

        maintenance.setMaintenanceStatus(
                calculateMaintenanceStatus(
                        requestDTO.getStartDate(),
                        requestDTO.getEndDate()));

        EquipmentMaintenance saved =
                maintenanceRepository.save(maintenance);

        synchronizeEquipmentMaintenanceStatus(saved);
        cancelAffectedBookings(saved);

        return mapToDTO(saved);
    }

    @Override
    public EquipmentMaintenanceResponseDTO updateMaintenanceSchedule(
            Long maintenanceId,
            EquipmentMaintenanceRequestDTO requestDTO) {

        validateMaintenanceUser(requestDTO.getMaintainedBy());

        if (requestDTO.getEndDate().isBefore(
                requestDTO.getStartDate())) {
            throw new EquipmentMaintenanceException(
                    "Maintenance end date cannot be before start date");
        }

        EquipmentMaintenance maintenance =
                maintenanceRepository.findById(maintenanceId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Maintenance record not found"));

        Equipment equipment = equipmentRepository
                .findById(requestDTO.getEquipmentId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Equipment not found"));

        validateMaintenanceOverlap(
                requestDTO.getEquipmentId(),
                maintenanceId,
                requestDTO.getStartDate(),
                requestDTO.getEndDate());

        maintenance.setEquipment(equipment);
        maintenance.setMaintenanceType(
                requestDTO.getMaintenanceType());
        maintenance.setMaintenanceReason(
                requestDTO.getMaintenanceReason());
        maintenance.setStartDate(
                requestDTO.getStartDate());
        maintenance.setEndDate(
                requestDTO.getEndDate());
        maintenance.setMaintainedBy(
                requestDTO.getMaintainedBy());
        maintenance.setRemarks(
                requestDTO.getRemarks());

        maintenance.setMaintenanceStatus(
                calculateMaintenanceStatus(
                        requestDTO.getStartDate(),
                        requestDTO.getEndDate()));

        EquipmentMaintenance updated =
                maintenanceRepository.save(maintenance);

        synchronizeEquipmentMaintenanceStatus(updated);

        return mapToDTO(updated);
    }

    @Override
    public EquipmentMaintenanceResponseDTO getMaintenanceById(
            Long maintenanceId) {

        EquipmentMaintenance maintenance =
                maintenanceRepository.findById(maintenanceId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Maintenance record not found"));

        refreshAndSaveMaintenanceStatus(maintenance);

        return mapToDTO(maintenance);
    }

    @Override
    public List<EquipmentMaintenanceResponseDTO>
    getAllMaintenanceSchedules() {

        List<EquipmentMaintenance> maintenanceRecords =
                maintenanceRepository.findAll();

        refreshAndSaveMaintenanceStatuses(maintenanceRecords);

        return maintenanceRecords.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<EquipmentMaintenanceResponseDTO>
    getMaintenanceByEquipmentId(Long equipmentId) {

        List<EquipmentMaintenance> maintenanceRecords =
                maintenanceRepository
                        .findByEquipmentEquipmentId(equipmentId);

        refreshAndSaveMaintenanceStatuses(maintenanceRecords);

        return maintenanceRecords.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteMaintenanceSchedule(
            Long maintenanceId) {

        EquipmentMaintenance maintenance =
                maintenanceRepository.findById(maintenanceId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Maintenance record not found"));

        maintenanceRepository.delete(maintenance);

        Equipment equipment = maintenance.getEquipment();
        if (equipment != null
                && !hasCurrentInProgressMaintenance(
                        equipment.getEquipmentId(),
                        maintenanceId)) {
            equipment.setMaintenanceStatus("OK");
            equipmentRepository.save(equipment);
        }
    }

    private void validateMaintenanceUser(Long maintainedBy) {
        try {
            UserResponseDTO user = userFeignClient.getUserById(
                    maintainedBy.intValue());

            if (user == null) {
                throw new ResourceNotFoundException(
                        "Maintenance user not found");
            }
        } catch (FeignException.NotFound ex) {
            throw new ResourceNotFoundException(
                    "Maintenance user not found");
        }
    }

    private String calculateMaintenanceStatus(
            LocalDate startDate,
            LocalDate endDate) {

        LocalDate today = LocalDate.now();

        if (today.isBefore(startDate)) {
            return STATUS_SCHEDULED;
        }

        if (!today.isAfter(endDate)) {
            return STATUS_IN_PROGRESS;
        }

        return STATUS_COMPLETED;
    }

    private boolean refreshMaintenanceStatus(
            EquipmentMaintenance maintenance) {

        if (maintenance == null
                || maintenance.getStartDate() == null
                || maintenance.getEndDate() == null) {
            return false;
        }

        String calculatedStatus = calculateMaintenanceStatus(
                maintenance.getStartDate(),
                maintenance.getEndDate());

        String currentStatus = maintenance.getMaintenanceStatus();

        if (!calculatedStatus.equalsIgnoreCase(
                currentStatus == null ? "" : currentStatus.trim())) {
            maintenance.setMaintenanceStatus(calculatedStatus);
            return true;
        }

        return false;
    }

    private void refreshAndSaveMaintenanceStatus(
            EquipmentMaintenance maintenance) {

        boolean changed = refreshMaintenanceStatus(maintenance);

        if (changed) {
            maintenanceRepository.save(maintenance);
        }

        synchronizeEquipmentMaintenanceStatus(maintenance);
    }

    private void refreshAndSaveMaintenanceStatuses(
            List<EquipmentMaintenance> maintenanceRecords) {

        boolean hasChanges = false;

        for (EquipmentMaintenance maintenance : maintenanceRecords) {
            if (refreshMaintenanceStatus(maintenance)) {
                hasChanges = true;
            }
        }

        if (hasChanges) {
            maintenanceRepository.saveAll(maintenanceRecords);
        }

        for (EquipmentMaintenance maintenance : maintenanceRecords) {
            synchronizeEquipmentMaintenanceStatus(maintenance);
        }
    }

    private void synchronizeEquipmentMaintenanceStatus(
            EquipmentMaintenance maintenance) {

        Equipment equipment = maintenance.getEquipment();

        if (equipment == null) {
            return;
        }

        String maintenanceStatus =
                maintenance.getMaintenanceStatus();

        if (STATUS_IN_PROGRESS.equalsIgnoreCase(
                maintenanceStatus)) {

            if (!"UNDER_MAINTENANCE".equalsIgnoreCase(
                    equipment.getMaintenanceStatus())) {
                equipment.setMaintenanceStatus(
                        "UNDER_MAINTENANCE");
                equipmentRepository.save(equipment);
            }

            return;
        }

        if (STATUS_COMPLETED.equalsIgnoreCase(
                maintenanceStatus)
                && !hasCurrentInProgressMaintenance(
                        equipment.getEquipmentId(),
                        maintenance.getMaintenanceId())) {

            if (!"OK".equalsIgnoreCase(
                    equipment.getMaintenanceStatus())) {
                equipment.setMaintenanceStatus("OK");
                equipmentRepository.save(equipment);
            }
        }
    }

    private boolean hasCurrentInProgressMaintenance(
            Long equipmentId,
            Long excludedMaintenanceId) {

        LocalDate today = LocalDate.now();

        return maintenanceRepository
                .findByEquipmentEquipmentId(equipmentId)
                .stream()
                .filter(record ->
                        excludedMaintenanceId == null
                                || !record.getMaintenanceId()
                                        .equals(excludedMaintenanceId))
                .anyMatch(record ->
                        record.getStartDate() != null
                                && record.getEndDate() != null
                                && !today.isBefore(
                                        record.getStartDate())
                                && !today.isAfter(
                                        record.getEndDate()));
    }

    private void validateMaintenanceOverlap(
            Long equipmentId,
            Long maintenanceId,
            LocalDate startDate,
            LocalDate endDate) {

        List<EquipmentMaintenance> schedules =
                maintenanceRepository
                        .findByEquipmentEquipmentId(equipmentId);

        for (EquipmentMaintenance maintenance : schedules) {

            if (maintenanceId != null
                    && maintenance.getMaintenanceId()
                            .equals(maintenanceId)) {
                continue;
            }

            boolean overlap =
                    !endDate.isBefore(
                            maintenance.getStartDate())
                    && !startDate.isAfter(
                            maintenance.getEndDate());

            if (overlap) {
                throw new EquipmentMaintenanceException(
                        "Maintenance schedule overlaps with an existing maintenance schedule");
            }
        }
    }

    private void cancelAffectedBookings(
            EquipmentMaintenance maintenance) {

        List<EquipmentBooking> bookings =
                equipmentBookingRepository
                        .findByEquipmentEquipmentId(
                                maintenance.getEquipment()
                                        .getEquipmentId());

        for (EquipmentBooking booking : bookings) {

            if ("Rejected".equalsIgnoreCase(
                    booking.getApprovalStatus())) {
                continue;
            }

            boolean overlap =
                    !booking.getBookingDate()
                            .isBefore(maintenance.getStartDate())
                    && !booking.getBookingDate()
                            .isAfter(maintenance.getEndDate());

            if (overlap) {
                booking.setApprovalStatus("Rejected");
                booking.setApprovedBy(
                        maintenance.getMaintainedBy());
                booking.setApprovedOn(LocalDateTime.now());

                String remarks = booking.getRemarks() == null
                        ? ""
                        : booking.getRemarks() + " | ";

                booking.setRemarks(
                        remarks
                                + "Automatically cancelled due to scheduled maintenance.");

                equipmentBookingRepository.save(booking);

                NotificationRequestDTO notification =
                        new NotificationRequestDTO();

                notification.setUserId(
                        booking.getRequestedBy().intValue());
                notification.setTitle(
                        "Equipment Booking Cancelled");
                notification.setMessage(
                        "Your booking for equipment "
                                + booking.getEquipment().getAssetCode()
                                + " on "
                                + booking.getBookingDate()
                                + " has been cancelled because the equipment has been scheduled for maintenance.");
                notification.setNotificationType(
                        "MAINTENANCE");
                notification.setModuleName("EQUIPMENT");
                notification.setReferenceId(
                        booking.getBookingId().intValue());
                notification.setPriority("High");
                notification.setCreatedBy(
                        maintenance.getMaintainedBy().intValue());

                notificationFeignClient.createNotification(
                        notification);
            }
        }
    }

    private EquipmentMaintenanceResponseDTO mapToDTO(
            EquipmentMaintenance maintenance) {

        EquipmentMaintenanceResponseDTO dto =
                new EquipmentMaintenanceResponseDTO();

        dto.setMaintenanceId(
                maintenance.getMaintenanceId());
        dto.setEquipmentId(
                maintenance.getEquipment().getEquipmentId());
        dto.setAssetCode(
                maintenance.getEquipment().getAssetCode());
        dto.setMaintenanceType(
                maintenance.getMaintenanceType());
        dto.setMaintenanceReason(
                maintenance.getMaintenanceReason());
        dto.setMaintenanceStatus(
                maintenance.getMaintenanceStatus());
        dto.setStartDate(
                maintenance.getStartDate());
        dto.setEndDate(
                maintenance.getEndDate());
        dto.setMaintainedBy(
                maintenance.getMaintainedBy());
        dto.setRemarks(
                maintenance.getRemarks());
        dto.setCreatedAt(
                maintenance.getCreatedAt());

        return dto;
    }
}
