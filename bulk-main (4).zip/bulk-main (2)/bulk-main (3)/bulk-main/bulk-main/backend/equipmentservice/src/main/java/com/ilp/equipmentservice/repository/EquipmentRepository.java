package com.ilp.equipmentservice.repository;

import com.ilp.equipmentservice.entity.Equipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EquipmentRepository extends JpaRepository<Equipment, Long> {

    Optional<Equipment> findByAssetCode(String assetCode);

    Optional<Equipment> findBySerialNumber(String serialNumber);

    List<Equipment> findByBookingStatus(String bookingStatus);

    List<Equipment> findByMaintenanceStatus(String maintenanceStatus);

    List<Equipment> findByLocation(String location);
    
    //soft delete
    List<Equipment> findByIsActiveTrue();
    
    Optional<Equipment> findByEquipmentIdAndIsActiveTrue(Long equipmentId);

    boolean existsByAssetCode(String assetCode);

    boolean existsBySerialNumber(String serialNumber);
}