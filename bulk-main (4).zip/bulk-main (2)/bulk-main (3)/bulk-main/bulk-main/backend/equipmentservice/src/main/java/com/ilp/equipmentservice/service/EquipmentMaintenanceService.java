package com.ilp.equipmentservice.service;

import java.util.List;

import com.ilp.equipmentservice.dto.request.EquipmentMaintenanceRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMaintenanceResponseDTO;

public interface EquipmentMaintenanceService {

    EquipmentMaintenanceResponseDTO createMaintenanceSchedule(
            EquipmentMaintenanceRequestDTO requestDTO);

    EquipmentMaintenanceResponseDTO updateMaintenanceSchedule(
    		Long maintenanceId,
            EquipmentMaintenanceRequestDTO requestDTO);

    EquipmentMaintenanceResponseDTO getMaintenanceById(
    		Long maintenanceId);

    List<EquipmentMaintenanceResponseDTO> getAllMaintenanceSchedules();

    List<EquipmentMaintenanceResponseDTO> getMaintenanceByEquipmentId(
            Long equipmentId);

    void deleteMaintenanceSchedule(
    		Long maintenanceId);
}