package com.ilp.equipmentservice.service.impl;

import java.time.DayOfWeek;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import feign.FeignException;

import com.ilp.equipmentservice.dto.request.EquipmentBookingRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentBookingResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentBooking;
import com.ilp.equipmentservice.exception.EquipmentBookingException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentBookingRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.EquipmentBookingService;
import com.ilp.equipmentservice.entity.EquipmentMaintenance;
import com.ilp.equipmentservice.repository.EquipmentMaintenanceRepository;
import com.ilp.equipmentservice.client.NotificationFeignClient;
import com.ilp.equipmentservice.dto.request.NotificationRequestDTO;
import com.ilp.equipmentservice.client.UserFeignClient;
import com.ilp.equipmentservice.dto.response.UserResponseDTO;
import com.ilp.equipmentservice.client.ProjectFeignClient;
import com.ilp.equipmentservice.dto.response.ProjectResponseDTO;

@Service
public class EquipmentBookingServiceImpl implements EquipmentBookingService {

    private static final LocalTime BOOKING_START_TIME = LocalTime.of(9, 0);
    private static final LocalTime BOOKING_END_TIME = LocalTime.of(17, 0);
    private static final int MAX_WORKING_DAYS = 7;

    private final EquipmentBookingRepository equipmentBookingRepository;
    private final EquipmentRepository equipmentRepository;
    private final EquipmentMaintenanceRepository maintenanceRepository;
    private final NotificationFeignClient notificationFeignClient;
    private final UserFeignClient userFeignClient;
    private final ProjectFeignClient projectFeignClient;
    
    
    
    public EquipmentBookingServiceImpl(
            EquipmentBookingRepository equipmentBookingRepository,
            EquipmentRepository equipmentRepository,
            EquipmentMaintenanceRepository maintenanceRepository,
            NotificationFeignClient notificationFeignClient,
            UserFeignClient userFeignClient,
            ProjectFeignClient projectFeignClient) {

        this.equipmentBookingRepository = equipmentBookingRepository;

        this.equipmentRepository = equipmentRepository;

        this.maintenanceRepository = maintenanceRepository;

        this.notificationFeignClient = notificationFeignClient;

        this.userFeignClient = userFeignClient;
        
        this.projectFeignClient = projectFeignClient;
    }


    @Override
    public EquipmentBookingResponseDTO createEquipmentBooking(
            EquipmentBookingRequestDTO requestDTO) {
    	
    	UserResponseDTO user;

    	try {

    	    user = userFeignClient.getUserById(
    	            requestDTO.getRequestedBy()
    	                    .intValue());

    	} catch (FeignException.NotFound ex) {

    	    throw new ResourceNotFoundException(
    	            "Requested user not found");
    	}

    	
    	ProjectResponseDTO project;

    	try {

    	    project = projectFeignClient.getProjectById(
    	            requestDTO.getProjectId()
    	                    .intValue());

    	} catch (FeignException.NotFound ex) {

    	    throw new ResourceNotFoundException(
    	            "Project not found");
    	}
    	
    	if ("COMPLETED".equalsIgnoreCase(
    	        project.getProjectStatus())) {

    	    throw new EquipmentBookingException(
    	            "Equipment cannot be booked for a completed project");
    	}


        Equipment equipment = equipmentRepository
                .findById(requestDTO.getEquipmentId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Equipment not found"));


        validateBookingRequest(requestDTO);
        
        validateMaintenanceSchedule(
                requestDTO.getEquipmentId(),
                requestDTO.getBookingDate());


        validateBookingOverlap(
                requestDTO.getEquipmentId(),
                null,
                requestDTO.getBookingDate(),
                requestDTO.getFromTime(),
                requestDTO.getToTime());

        EquipmentBooking booking = new EquipmentBooking();

        booking.setEquipment(equipment);
        booking.setProjectId(requestDTO.getProjectId());
        booking.setRequestedBy(requestDTO.getRequestedBy());
        booking.setBookingDate(requestDTO.getBookingDate());
        booking.setFromTime(requestDTO.getFromTime());
        booking.setToTime(requestDTO.getToTime());
        booking.setPurpose(requestDTO.getPurpose());
        booking.setRemarks(requestDTO.getRemarks());
        booking.setApprovalStatus("Pending");
        booking.setCreatedAt(LocalDateTime.now());

        EquipmentBooking savedBooking =
                equipmentBookingRepository.save(booking);
        
        NotificationRequestDTO notification =
                new NotificationRequestDTO();

        notification.setUserId(
                5001); // Lab In-charge User Id

        notification.setTitle(
                "Equipment Booking Request Created");

        notification.setMessage(
                "A new equipment booking request has been submitted for "
                        + equipment.getAssetCode()
                        + " and is awaiting approval.");

        notification.setNotificationType(
                "BOOKING_REQUEST");

        notification.setModuleName(
                "EQUIPMENT");

        notification.setReferenceId(
                savedBooking.getBookingId().intValue());

        notification.setPriority(
                "Medium");

        notification.setCreatedBy(
                requestDTO.getRequestedBy().intValue());

        notificationFeignClient.createNotification(notification);

        return mapToResponse(savedBooking);
    }

    @Override
    public EquipmentBookingResponseDTO getEquipmentBookingById(
            Long bookingId) {

        EquipmentBooking booking =
                equipmentBookingRepository.findById(bookingId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Booking not found"));

        return mapToResponse(booking);
    }

    @Override
    public List<EquipmentBookingResponseDTO> getAllEquipmentBookings() {

        return equipmentBookingRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<EquipmentBookingResponseDTO> getBookingsByUser(
            Long userId) {

        return equipmentBookingRepository.findByRequestedBy(userId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<EquipmentBookingResponseDTO> getBookingsByProject(
            Long projectId) {

        return equipmentBookingRepository.findByProjectId(projectId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public EquipmentBookingResponseDTO updateEquipmentBooking(
            Long bookingId,
            EquipmentBookingRequestDTO requestDTO) {
    	
    	UserResponseDTO user;

    	try {

    	    user = userFeignClient.getUserById(
    	            requestDTO.getRequestedBy()
    	                    .intValue());

    	} catch (FeignException.NotFound ex) {

    	    throw new ResourceNotFoundException(
    	            "Requested user not found");
    	}

    	
    	ProjectResponseDTO project;

    	try {

    	    project = projectFeignClient.getProjectById(
    	            requestDTO.getProjectId()
    	                    .intValue());

    	} catch (FeignException.NotFound ex) {

    	    throw new ResourceNotFoundException(
    	            "Project not found");
    	}
    	
    	if ("COMPLETED".equalsIgnoreCase(
    	        project.getProjectStatus())) {

    	    throw new EquipmentBookingException(
    	            "Equipment cannot be booked for a completed project");
    	}


        EquipmentBooking booking =
                equipmentBookingRepository.findById(bookingId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Booking not found"));

        Equipment equipment = equipmentRepository
                .findById(requestDTO.getEquipmentId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Equipment not found"));

        
        validateBookingRequest(requestDTO);

        validateMaintenanceSchedule(
                requestDTO.getEquipmentId(),
                requestDTO.getBookingDate());

        validateBookingOverlap(
                requestDTO.getEquipmentId(),
                bookingId,
                requestDTO.getBookingDate(),
                requestDTO.getFromTime(),
                requestDTO.getToTime()); 

        booking.setEquipment(equipment);
        booking.setProjectId(requestDTO.getProjectId());
        booking.setRequestedBy(requestDTO.getRequestedBy());
        booking.setBookingDate(requestDTO.getBookingDate());
        booking.setFromTime(requestDTO.getFromTime());
        booking.setToTime(requestDTO.getToTime());
        booking.setPurpose(requestDTO.getPurpose());
        booking.setRemarks(requestDTO.getRemarks());

        EquipmentBooking updatedBooking =
                equipmentBookingRepository.save(booking);

        return mapToResponse(updatedBooking);
    }
    
    
    @Override
    public EquipmentBookingResponseDTO approveBooking(
            Long bookingId,
            Long approvedBy) {
    	
    	UserResponseDTO approver =
    	        userFeignClient.getUserById(
    	                approvedBy.intValue());

    	if (approver == null) {

    	    throw new ResourceNotFoundException(
    	            "Approver not found");
    	}


        EquipmentBooking booking =
                equipmentBookingRepository.findById(
                        bookingId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Booking not found"));

        List<EquipmentBooking> approvedBookings =
                equipmentBookingRepository
                        .findByEquipmentEquipmentIdAndBookingDateAndApprovalStatus(
                                booking.getEquipment()
                                        .getEquipmentId(),
                                booking.getBookingDate(),
                                "Approved");

        for (EquipmentBooking existing : approvedBookings) {

            if (existing.getBookingId().equals(
                    booking.getBookingId())) {

                continue;
            }

            boolean overlap =
                    booking.getFromTime()
                            .isBefore(
                                    existing.getToTime())
                            &&
                    booking.getToTime()
                            .isAfter(
                                    existing.getFromTime());

            if (overlap) {

                throw new EquipmentBookingException(
                        "Cannot approve booking because an overlapping booking is already approved");
            }
        }

        if ("Approved".equalsIgnoreCase(
                booking.getApprovalStatus())) {

            throw new EquipmentBookingException(
                    "Booking is already approved");
        }

        if ("Rejected".equalsIgnoreCase(
                booking.getApprovalStatus())) {

            throw new EquipmentBookingException(
                    "Rejected booking cannot be approved");
        }

        booking.setApprovalStatus(
                "Approved");

        booking.setApprovedBy(
                approvedBy);

        booking.setApprovedOn(
                LocalDateTime.now());

        EquipmentBooking approvedBooking =
                equipmentBookingRepository.save(
                        booking);

        NotificationRequestDTO notification =
                new NotificationRequestDTO();

        notification.setUserId(
                booking.getRequestedBy().intValue());

        notification.setTitle(
                "Equipment Booking Approved");

        notification.setMessage(
                "Your booking for equipment "
                        + booking.getEquipment()
                                .getAssetCode()
                        + " has been approved.");

        notification.setNotificationType(
                "APPROVAL");

        notification.setModuleName(
                "EQUIPMENT");

        notification.setReferenceId(
                booking.getBookingId().intValue());

        notification.setPriority(
                "High");

        notification.setCreatedBy(
                approvedBy.intValue());

        notificationFeignClient.createNotification(
                notification);

        List<EquipmentBooking> bookings =
                equipmentBookingRepository
                        .findByEquipmentEquipmentIdAndBookingDate(
                                booking.getEquipment()
                                        .getEquipmentId(),
                                booking.getBookingDate());

        for (EquipmentBooking existing : bookings) {

            if (existing.getBookingId().equals(
                    booking.getBookingId())) {

                continue;
            }

            if (!"Pending".equalsIgnoreCase(
                    existing.getApprovalStatus())) {

                continue;
            }

            boolean overlap =
                    booking.getFromTime()
                            .isBefore(
                                    existing.getToTime())
                            &&
                    booking.getToTime()
                            .isAfter(
                                    existing.getFromTime());

            if (overlap) {

                existing.setApprovalStatus(
                        "Rejected");

                existing.setApprovedBy(
                        approvedBy);

                existing.setApprovedOn(
                        LocalDateTime.now());

                equipmentBookingRepository.save(
                        existing);

                NotificationRequestDTO rejectionNotification =
                        new NotificationRequestDTO();

                rejectionNotification.setUserId(
                        existing.getRequestedBy().intValue());

                rejectionNotification.setTitle(
                        "Equipment Booking Rejected");

                rejectionNotification.setMessage(
                        "Your booking was automatically rejected because another overlapping booking was approved.");

                rejectionNotification.setNotificationType(
                        "REJECTION");

                rejectionNotification.setModuleName(
                        "EQUIPMENT");

                rejectionNotification.setReferenceId(
                        existing.getBookingId().intValue());

                rejectionNotification.setPriority(
                        "High");

                rejectionNotification.setCreatedBy(
                        approvedBy.intValue());

                notificationFeignClient.createNotification(
                        rejectionNotification);
            }
        }

        return mapToResponse(
                approvedBooking);
    }
    
    @Override
    public EquipmentBookingResponseDTO rejectBooking(
            Long bookingId,
            Long approvedBy) {
    	
    	UserResponseDTO approver =
    	        userFeignClient.getUserById(
    	                approvedBy.intValue());

    	if (approver == null) {

    	    throw new ResourceNotFoundException(
    	            "Approver not found");
    	}

        EquipmentBooking booking =
                equipmentBookingRepository.findById(
                        bookingId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Booking not found"));

        booking.setApprovalStatus(
                "Rejected");

        booking.setApprovedBy(
                approvedBy);

        booking.setApprovedOn(
                LocalDateTime.now());

        EquipmentBooking rejectedBooking =
                equipmentBookingRepository.save(
                        booking);
        
        
        NotificationRequestDTO notification =
                new NotificationRequestDTO();

        notification.setUserId(
                booking.getRequestedBy().intValue());

        notification.setTitle(
                "Equipment Booking Rejected");

        notification.setMessage(
                "Your booking for equipment "
                        + booking.getEquipment()
                                .getAssetCode()
                        + " has been rejected.");

        notification.setNotificationType(
                "REJECTION");

        notification.setModuleName(
                "EQUIPMENT");

        notification.setReferenceId(
                booking.getBookingId().intValue());

        notification.setPriority(
                "High");

        notification.setCreatedBy(
                approvedBy.intValue());

        notificationFeignClient.createNotification(
                notification);

        return mapToResponse(
                rejectedBooking);
    }

    @Override
    public void deleteEquipmentBooking(Long bookingId) {

        EquipmentBooking booking =
                equipmentBookingRepository.findById(bookingId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Booking not found"));

        equipmentBookingRepository.delete(booking);
    }
    
    

    private void validateBookingRequest(
            EquipmentBookingRequestDTO requestDTO) {

        LocalDate bookingDate = requestDTO.getBookingDate();
        LocalTime fromTime = requestDTO.getFromTime();
        LocalTime toTime = requestDTO.getToTime();

        if (bookingDate.isBefore(LocalDate.now())) {

            throw new EquipmentBookingException(
                    "Booking date cannot be in the past");
        }

        if (!fromTime.isBefore(toTime)) {

            throw new EquipmentBookingException(
                    "From time must be before To time");
        }

        if (fromTime.isBefore(BOOKING_START_TIME)
                || toTime.isAfter(BOOKING_END_TIME)) {

            throw new EquipmentBookingException(
                    "Equipment can only be booked between 09:00 AM and 05:00 PM");
        }

        DayOfWeek dayOfWeek = bookingDate.getDayOfWeek();

        if (dayOfWeek == DayOfWeek.SATURDAY
                || dayOfWeek == DayOfWeek.SUNDAY) {

            throw new EquipmentBookingException(
                    "Equipment cannot be booked on weekends");
        }

        LocalDate maxAllowedDate = getMaxBookingDate();

        if (bookingDate.isAfter(maxAllowedDate)) {

            throw new EquipmentBookingException(
                    "Equipment can only be booked within the next 7 working days");
        }
    }

    private LocalDate getMaxBookingDate() {

        LocalDate currentDate = LocalDate.now();
        int workingDays = 0;

        while (workingDays < MAX_WORKING_DAYS) {

            currentDate = currentDate.plusDays(1);

            DayOfWeek dayOfWeek = currentDate.getDayOfWeek();

            if (dayOfWeek != DayOfWeek.SATURDAY
                    && dayOfWeek != DayOfWeek.SUNDAY) {

                workingDays++;
            }
        }

        return currentDate;
    }
    
    private void validateMaintenanceSchedule(
            Long equipmentId,
            LocalDate bookingDate) {

        List<EquipmentMaintenance> schedules =
                maintenanceRepository
                        .findByEquipmentEquipmentId(
                                equipmentId);

        for (EquipmentMaintenance maintenance : schedules) {

            boolean overlap =
                    !bookingDate.isBefore(
                            maintenance.getStartDate())
                    &&
                    !bookingDate.isAfter(
                            maintenance.getEndDate());

            if (overlap) {

                throw new EquipmentBookingException(
                        "Equipment is scheduled for maintenance on the selected date");
            }
        }
    }

    
    private void validateBookingOverlap(
            Long equipmentId,
            Long bookingId,
            LocalDate bookingDate,
            LocalTime fromTime,
            LocalTime toTime) {

        List<EquipmentBooking> existingBookings =
                equipmentBookingRepository
                        .findByEquipmentEquipmentIdAndBookingDateAndApprovalStatus(
                                equipmentId,
                                bookingDate,
                                "Approved");

        for (EquipmentBooking existing : existingBookings) {

            if (bookingId != null
                    && existing.getBookingId()
                            .equals(bookingId)) {

                continue;
            }

            boolean overlap =
                    fromTime.isBefore(
                            existing.getToTime())
                            &&
                    toTime.isAfter(
                            existing.getFromTime());

            if (overlap) {

                throw new EquipmentBookingException(
                        "Equipment already booked for the selected time slot");
            }
        }
    }

    private EquipmentBookingResponseDTO mapToResponse(
            EquipmentBooking booking) {

        EquipmentBookingResponseDTO dto =
                new EquipmentBookingResponseDTO();

        dto.setBookingId(booking.getBookingId());

        dto.setEquipmentId(
                booking.getEquipment().getEquipmentId());

        dto.setAssetCode(
                booking.getEquipment().getAssetCode());

        dto.setProjectId(
                booking.getProjectId());

        dto.setRequestedBy(
                booking.getRequestedBy());

        dto.setBookingDate(
                booking.getBookingDate());

        dto.setFromTime(
                booking.getFromTime());

        dto.setToTime(
                booking.getToTime());

        dto.setPurpose(
                booking.getPurpose());

        dto.setApprovalStatus(
                booking.getApprovalStatus());

        dto.setApprovedBy(
                booking.getApprovedBy());

        dto.setApprovedOn(
                booking.getApprovedOn());

        dto.setRemarks(
                booking.getRemarks());

        dto.setCreatedAt(
                booking.getCreatedAt());

        return dto;
    }
}