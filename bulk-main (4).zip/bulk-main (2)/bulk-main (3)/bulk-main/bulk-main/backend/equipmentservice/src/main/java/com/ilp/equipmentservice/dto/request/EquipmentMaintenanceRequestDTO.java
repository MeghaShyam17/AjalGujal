package com.ilp.equipmentservice.dto.request;

import java.time.LocalDate;

public class EquipmentMaintenanceRequestDTO {

    private Long equipmentId;
    private String maintenanceType;
    private String maintenanceReason;
    private String maintenanceStatus;
    private LocalDate startDate;
    private LocalDate endDate;
    private Long maintainedBy;
    private String remarks;

    public EquipmentMaintenanceRequestDTO() {
    }

    public Long getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(Long equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getMaintenanceType() {
        return maintenanceType;
    }

    public void setMaintenanceType(String maintenanceType) {
        this.maintenanceType = maintenanceType;
    }

    public String getMaintenanceReason() {
        return maintenanceReason;
    }

    public void setMaintenanceReason(String maintenanceReason) {
        this.maintenanceReason = maintenanceReason;
    }

    public String getMaintenanceStatus() {
        return maintenanceStatus;
    }

    public void setMaintenanceStatus(String maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Long getMaintainedBy() {
        return maintainedBy;
    }

    public void setMaintainedBy(Long maintainedBy) {
        this.maintainedBy = maintainedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}