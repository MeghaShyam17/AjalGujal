package com.ilp.equipmentservice.exception;

public class EquipmentMaintenanceException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EquipmentMaintenanceException(String message) {
        super(message);
    }
}