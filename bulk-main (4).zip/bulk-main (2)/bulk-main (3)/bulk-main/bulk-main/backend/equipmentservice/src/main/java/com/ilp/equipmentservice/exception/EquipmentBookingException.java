package com.ilp.equipmentservice.exception;

public class EquipmentBookingException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EquipmentBookingException() {
        super();
    }

    public EquipmentBookingException(String message) {
        super(message);
    }

    public EquipmentBookingException(String message, Throwable cause) {
        super(message, cause);
    }
}