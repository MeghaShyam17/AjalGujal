package com.ilp.equipmentservice.dto.request;

import java.time.LocalDate;

public class EquipmentRequestDTO {

    private Long equipmentMasterId;
    private String assetCode;
    private String serialNumber;
    private String bookingStatus;
    private String maintenanceStatus;
    private String location;
    private LocalDate purchaseDate;
    private String remarks;

    public EquipmentRequestDTO() {
    }

    public Long getEquipmentMasterId() {
        return equipmentMasterId;
    }

    public void setEquipmentMasterId(Long equipmentMasterId) {
        this.equipmentMasterId = equipmentMasterId;
    }

    public String getAssetCode() {
        return assetCode;
    }

    public void setAssetCode(String assetCode) {
        this.assetCode = assetCode;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public String getMaintenanceStatus() {
        return maintenanceStatus;
    }

    public void setMaintenanceStatus(String maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}