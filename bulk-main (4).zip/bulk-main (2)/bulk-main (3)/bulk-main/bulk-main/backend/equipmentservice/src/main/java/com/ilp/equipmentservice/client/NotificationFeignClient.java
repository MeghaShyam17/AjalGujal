package com.ilp.equipmentservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ilp.equipmentservice.config.FeignClientConfig;
import com.ilp.equipmentservice.dto.request.NotificationRequestDTO;

@FeignClient(
        name = "notification-service",
        url = "http://localhost:8081",
        configuration = FeignClientConfig.class)
public interface NotificationFeignClient {

    @PostMapping("/api/notifications")
    Object createNotification(
            @RequestBody NotificationRequestDTO dto);
}