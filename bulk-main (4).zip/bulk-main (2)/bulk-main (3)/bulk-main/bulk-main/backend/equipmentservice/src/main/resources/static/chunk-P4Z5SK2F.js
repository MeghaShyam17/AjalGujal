var t={production:!0,apiBaseUrl:"http://localhost:8081"};export{t as a};
