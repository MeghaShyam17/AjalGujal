package com.ilp.equipmentservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilp.equipmentservice.dto.request.EquipmentBookingRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentBookingResponseDTO;
import com.ilp.equipmentservice.service.EquipmentBookingService;

@RestController
@RequestMapping("/equipment-bookings")
public class EquipmentBookingController {

    private final EquipmentBookingService equipmentBookingService;

    public EquipmentBookingController(
            EquipmentBookingService equipmentBookingService) {

        this.equipmentBookingService = equipmentBookingService;
    }

    /**
     * Create Equipment Booking
     */
    @PostMapping
    public ResponseEntity<EquipmentBookingResponseDTO>
    createEquipmentBooking(
            @RequestBody EquipmentBookingRequestDTO requestDTO) {

        EquipmentBookingResponseDTO responseDTO =
                equipmentBookingService.createEquipmentBooking(
                        requestDTO);

        return new ResponseEntity<>(
                responseDTO,
                HttpStatus.CREATED);
    }

    /**
     * Get Equipment Booking By Id
     */
    @GetMapping("/{bookingId}")
    public ResponseEntity<EquipmentBookingResponseDTO>
    getEquipmentBookingById(
            @PathVariable Long bookingId) {

        EquipmentBookingResponseDTO responseDTO =
                equipmentBookingService.getEquipmentBookingById(
                        bookingId);

        return ResponseEntity.ok(
                responseDTO);
    }

    /**
     * Get All Equipment Bookings
     */
    @GetMapping
    public ResponseEntity<List<EquipmentBookingResponseDTO>>
    getAllEquipmentBookings() {

        List<EquipmentBookingResponseDTO> responseDTOList =
                equipmentBookingService
                        .getAllEquipmentBookings();

        return ResponseEntity.ok(
                responseDTOList);
    }

    /**
     * Get Bookings By User
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<EquipmentBookingResponseDTO>>
    getBookingsByUser(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                equipmentBookingService.getBookingsByUser(
                        userId));
    }

    /**
     * Get Bookings By Project
     */
    @GetMapping("/project/{projectId}")
    public ResponseEntity<List<EquipmentBookingResponseDTO>>
    getBookingsByProject(
            @PathVariable Long projectId) {

        return ResponseEntity.ok(
                equipmentBookingService.getBookingsByProject(
                        projectId));
    }

    /**
     * Update Equipment Booking
     */
    @PutMapping("/{bookingId}")
    public ResponseEntity<EquipmentBookingResponseDTO>
    updateEquipmentBooking(
            @PathVariable Long bookingId,
            @RequestBody EquipmentBookingRequestDTO requestDTO) {

        EquipmentBookingResponseDTO responseDTO =
                equipmentBookingService.updateEquipmentBooking(
                        bookingId,
                        requestDTO);

        return ResponseEntity.ok(
                responseDTO);
    }

    /**
     * Approve Equipment Booking
     */
    @PutMapping("/{bookingId}/approve")
    public ResponseEntity<EquipmentBookingResponseDTO>
    approveBooking(
            @PathVariable Long bookingId,
            @RequestParam Long approvedBy) {

        return ResponseEntity.ok(
                equipmentBookingService.approveBooking(
                        bookingId,
                        approvedBy));
    }

    /**
     * Reject Equipment Booking
     */
    @PutMapping("/{bookingId}/reject")
    public ResponseEntity<EquipmentBookingResponseDTO>
    rejectBooking(
            @PathVariable Long bookingId,
            @RequestParam Long approvedBy) {

        return ResponseEntity.ok(
                equipmentBookingService.rejectBooking(
                        bookingId,
                        approvedBy));
    }

    /**
     * Delete Equipment Booking
     */
    @DeleteMapping("/{bookingId}")
    public ResponseEntity<String>
    deleteEquipmentBooking(
            @PathVariable Long bookingId) {

        equipmentBookingService.deleteEquipmentBooking(
                bookingId);

        return ResponseEntity.ok(
                "Equipment booking deleted successfully.");
    }
}