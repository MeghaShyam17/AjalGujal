package com.ilp.equipmentservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.equipmentservice.dto.request.EquipmentRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentMaster;
import com.ilp.equipmentservice.exception.EquipmentException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentMasterRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.impl.EquipmentServiceImpl;

@ExtendWith(MockitoExtension.class)
class EquipmentServiceImplTest {

    @Mock
    private EquipmentRepository equipmentRepository;

    @Mock
    private EquipmentMasterRepository equipmentMasterRepository;

    @InjectMocks
    private EquipmentServiceImpl service;

    private EquipmentRequestDTO requestDTO;
    private Equipment equipment;
    private EquipmentMaster equipmentMaster;

    @BeforeEach
    void setUp() {

        requestDTO = new EquipmentRequestDTO();

        requestDTO.setEquipmentMasterId(1L);
        requestDTO.setAssetCode("AST001");
        requestDTO.setSerialNumber("SN001");
        requestDTO.setBookingStatus("AVAILABLE");
        requestDTO.setMaintenanceStatus("GOOD");
        requestDTO.setLocation("Lab A");
        requestDTO.setPurchaseDate(LocalDate.now());
        requestDTO.setRemarks("Test Equipment");

        equipmentMaster = new EquipmentMaster();

        equipmentMaster.setEquipmentMasterId(1L);
        equipmentMaster.setEquipmentCode("EQP001");
        equipmentMaster.setEquipmentName("Laptop");

        equipment = new Equipment();

        equipment.setEquipmentId(1L);
        equipment.setEquipmentMaster(equipmentMaster);
        equipment.setAssetCode("AST001");
        equipment.setSerialNumber("SN001");
        equipment.setBookingStatus("AVAILABLE");
        equipment.setMaintenanceStatus("GOOD");
        equipment.setLocation("Lab A");
        equipment.setPurchaseDate(LocalDate.now());
        equipment.setRemarks("Test");
        equipment.setCreatedAt(LocalDateTime.now());
        equipment.setIsActive(true);
    }

    @Test
    void createEquipmentSuccess() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipmentMaster));

        when(equipmentRepository.existsByAssetCode("AST001"))
                .thenReturn(false);

        when(equipmentRepository.existsBySerialNumber("SN001"))
                .thenReturn(false);

        when(equipmentRepository.save(any(Equipment.class)))
                .thenReturn(equipment);

        EquipmentResponseDTO response =
                service.createEquipment(requestDTO);

        assertNotNull(response);

        assertEquals(
                1L,
                response.getEquipmentId());

        assertEquals(
                1L,
                response.getEquipmentMasterId());

        assertEquals(
                "EQP001",
                response.getEquipmentCode());

        assertEquals(
                "Laptop",
                response.getEquipmentName());

        assertEquals(
                "AST001",
                response.getAssetCode());

        verify(equipmentRepository)
                .save(any(Equipment.class));
    }

    @Test
    void createEquipmentMasterNotFound() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(1L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(
                        ResourceNotFoundException.class,
                        () -> service.createEquipment(
                                requestDTO));

        assertEquals(
                "Equipment Master not found",
                exception.getMessage());
    }

    @Test
    void createEquipmentDuplicateAssetCode() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipmentMaster));

        when(equipmentRepository.existsByAssetCode("AST001"))
                .thenReturn(true);

        EquipmentException exception =
                assertThrows(
                        EquipmentException.class,
                        () -> service.createEquipment(
                                requestDTO));

        assertEquals(
                "Asset code already exists",
                exception.getMessage());
    }

    @Test
    void createEquipmentDuplicateSerialNumber() {

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipmentMaster));

        when(equipmentRepository.existsByAssetCode("AST001"))
                .thenReturn(false);

        when(equipmentRepository.existsBySerialNumber("SN001"))
                .thenReturn(true);

        EquipmentException exception =
                assertThrows(
                        EquipmentException.class,
                        () -> service.createEquipment(
                                requestDTO));

        assertEquals(
                "Serial number already exists",
                exception.getMessage());
    }

    @Test
    void getEquipmentByIdSuccess() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipment));

        EquipmentResponseDTO response =
                service.getEquipmentById(1L);

        assertNotNull(response);

        assertEquals(
                1L,
                response.getEquipmentId());

        assertEquals(
                1L,
                response.getEquipmentMasterId());

        assertEquals(
                "EQP001",
                response.getEquipmentCode());

        assertEquals(
                "Laptop",
                response.getEquipmentName());

        assertEquals(
                "AST001",
                response.getAssetCode());

        assertEquals(
                "SN001",
                response.getSerialNumber());

        verify(equipmentRepository)
                .findByEquipmentIdAndIsActiveTrue(1L);
    }

    @Test
    void getEquipmentByIdNotFound() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(
                        ResourceNotFoundException.class,
                        () -> service.getEquipmentById(
                                1L));

        assertEquals(
                "Equipment not found",
                exception.getMessage());
    }

    @Test
    void getAllEquipmentsSuccess() {

        when(equipmentRepository
                .findByIsActiveTrue())
                .thenReturn(List.of(equipment));

        List<EquipmentResponseDTO> result =
                service.getAllEquipments();

        assertEquals(
                1,
                result.size());

        assertEquals(
                "AST001",
                result.get(0).getAssetCode());
    }

    @Test
    void getAllEquipmentsEmptyList() {

        when(equipmentRepository
                .findByIsActiveTrue())
                .thenReturn(List.of());

        List<EquipmentResponseDTO> result =
                service.getAllEquipments();

        assertTrue(result.isEmpty());
    }

    @Test
    void updateEquipmentSuccess() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipment));

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipmentMaster));

        when(equipmentRepository.save(any(Equipment.class)))
                .thenReturn(equipment);

        EquipmentResponseDTO response =
                service.updateEquipment(
                        1L,
                        requestDTO);

        assertNotNull(response);

        assertEquals(
                "AST001",
                response.getAssetCode());

        verify(equipmentRepository)
                .save(any(Equipment.class));
    }

    @Test
    void updateEquipmentNotFound() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(
                        ResourceNotFoundException.class,
                        () -> service.updateEquipment(
                                1L,
                                requestDTO));

        assertEquals(
                "Equipment not found",
                exception.getMessage());
    }

    @Test
    void updateEquipmentMasterNotFound() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipment));

        when(equipmentMasterRepository
                .findByEquipmentMasterIdAndIsActiveTrue(1L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(
                        ResourceNotFoundException.class,
                        () -> service.updateEquipment(
                                1L,
                                requestDTO));

        assertEquals(
                "Equipment Master not found",
                exception.getMessage());
    }

    @Test
    void deleteEquipmentSuccess() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipment));

        service.deleteEquipment(1L);

        verify(equipmentRepository)
                .save(equipment);

        assertFalse(equipment.getIsActive());
    }

    @Test
    void deleteEquipmentNotFound() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(
                        ResourceNotFoundException.class,
                        () -> service.deleteEquipment(
                                1L));

        assertEquals(
                "Equipment not found",
                exception.getMessage());
    }
    
    @Test
    void mapToResponseFieldsCovered() {

        when(equipmentRepository
                .findByEquipmentIdAndIsActiveTrue(1L))
                .thenReturn(Optional.of(equipment));

        EquipmentResponseDTO response =
                service.getEquipmentById(1L);

        assertAll(
                () -> assertEquals(
                        1L,
                        response.getEquipmentId()),
                () -> assertEquals(
                        1L,
                        response.getEquipmentMasterId()),
                () -> assertEquals(
                        "EQP001",
                        response.getEquipmentCode()),
                () -> assertEquals(
                        "Laptop",
                        response.getEquipmentName()),
                () -> assertEquals(
                        "AST001",
                        response.getAssetCode()),
                () -> assertEquals(
                        "SN001",
                        response.getSerialNumber()),
                () -> assertEquals(
                        "AVAILABLE",
                        response.getBookingStatus()),
                () -> assertEquals(
                        "GOOD",
                        response.getMaintenanceStatus()),
                () -> assertEquals(
                        "Lab A",
                        response.getLocation()));
    }
}