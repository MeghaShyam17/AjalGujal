package com.ilp.equipmentservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilp.equipmentservice.dto.request.EquipmentRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentResponseDTO;
import com.ilp.equipmentservice.service.EquipmentService;

@RestController
@RequestMapping("/api/equipment")
public class EquipmentController {

    private final EquipmentService equipmentService;

    public EquipmentController(
            EquipmentService equipmentService) {

        this.equipmentService = equipmentService;
    }

    @PostMapping
    public ResponseEntity<EquipmentResponseDTO> createEquipment(
            @RequestBody EquipmentRequestDTO requestDTO) {

        EquipmentResponseDTO response =
                equipmentService.createEquipment(
                        requestDTO);

        return new ResponseEntity<>(
                response,
                HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EquipmentResponseDTO> getEquipmentById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                equipmentService.getEquipmentById(id));
    }

    @GetMapping
    public ResponseEntity<List<EquipmentResponseDTO>>
    getAllEquipments() {

        return ResponseEntity.ok(
                equipmentService.getAllEquipments());
    }

    @PutMapping("/{id}")
    public ResponseEntity<EquipmentResponseDTO> updateEquipment(
            @PathVariable Long id,
            @RequestBody EquipmentRequestDTO requestDTO) {

        return ResponseEntity.ok(
                equipmentService.updateEquipment(
                        id,
                        requestDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEquipment(
            @PathVariable Long id) {

        equipmentService.deleteEquipment(id);

        return ResponseEntity.ok(
                "Equipment deleted successfully");
    }
}