package com.ilp.equipmentservice.dto.request;

import java.math.BigDecimal;
import java.util.List;

public class EquipmentMasterRequestDTO {

    private String equipmentCode;
    private String equipmentName;
    private String equipmentType;
    private String make;
    private String specification;
    private Integer totalQuantity;
    private String lab;
    private BigDecimal cost;
    private String remarks;
    private String status;
    private byte[] equipmentImage;

    // New field
    private List<EquipmentRequestDTO> equipments;

    public EquipmentMasterRequestDTO() {
    }

    public String getEquipmentCode() {
        return equipmentCode;
    }

    public void setEquipmentCode(String equipmentCode) {
        this.equipmentCode = equipmentCode;
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    public String getEquipmentType() {
        return equipmentType;
    }

    public void setEquipmentType(String equipmentType) {
        this.equipmentType = equipmentType;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public String getLab() {
        return lab;
    }

    public void setLab(String lab) {
        this.lab = lab;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public byte[] getEquipmentImage() {
        return equipmentImage;
    }

    public void setEquipmentImage(byte[] equipmentImage) {
        this.equipmentImage = equipmentImage;
    }

    public List<EquipmentRequestDTO> getEquipments() {
        return equipments;
    }

    public void setEquipments(List<EquipmentRequestDTO> equipments) {
        this.equipments = equipments;
    }
}