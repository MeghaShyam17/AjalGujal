package com.ilp.equipmentservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilp.equipmentservice.dto.request.EquipmentMaintenanceRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMaintenanceResponseDTO;
import com.ilp.equipmentservice.service.EquipmentMaintenanceService;

@RestController
@RequestMapping("/api/maintenance")
public class EquipmentMaintenanceController {

    private final EquipmentMaintenanceService equipmentMaintenanceService;

    public EquipmentMaintenanceController(
            EquipmentMaintenanceService equipmentMaintenanceService) {

        this.equipmentMaintenanceService = equipmentMaintenanceService;
    }

    @PostMapping
    public ResponseEntity<EquipmentMaintenanceResponseDTO>
    createMaintenanceSchedule(
            @RequestBody EquipmentMaintenanceRequestDTO requestDTO) {

        return new ResponseEntity<>(
                equipmentMaintenanceService
                        .createMaintenanceSchedule(requestDTO),
                HttpStatus.CREATED);
    }

    @PutMapping("/{maintenanceId}")
    public ResponseEntity<EquipmentMaintenanceResponseDTO>
    updateMaintenanceSchedule(
            @PathVariable Long maintenanceId,
            @RequestBody EquipmentMaintenanceRequestDTO requestDTO) {

        return ResponseEntity.ok(
                equipmentMaintenanceService
                        .updateMaintenanceSchedule(
                                maintenanceId,
                                requestDTO));
    }

    @GetMapping("/{maintenanceId}")
    public ResponseEntity<EquipmentMaintenanceResponseDTO>
    getMaintenanceById(
            @PathVariable Long maintenanceId) {

        return ResponseEntity.ok(
                equipmentMaintenanceService
                        .getMaintenanceById(
                                maintenanceId));
    }

    @GetMapping
    public ResponseEntity<List<EquipmentMaintenanceResponseDTO>>
    getAllMaintenanceSchedules() {

        return ResponseEntity.ok(
                equipmentMaintenanceService
                        .getAllMaintenanceSchedules());
    }

    @GetMapping("/equipment/{equipmentId}")
    public ResponseEntity<List<EquipmentMaintenanceResponseDTO>>
    getMaintenanceByEquipmentId(
            @PathVariable Long equipmentId) {

        return ResponseEntity.ok(
                equipmentMaintenanceService
                        .getMaintenanceByEquipmentId(
                                equipmentId));
    }

    @DeleteMapping("/{maintenanceId}")
    public ResponseEntity<String>
    deleteMaintenanceSchedule(
            @PathVariable Long maintenanceId) {

        equipmentMaintenanceService
                .deleteMaintenanceSchedule(
                        maintenanceId);

        return ResponseEntity.ok(
                "Maintenance schedule deleted successfully");
    }
}