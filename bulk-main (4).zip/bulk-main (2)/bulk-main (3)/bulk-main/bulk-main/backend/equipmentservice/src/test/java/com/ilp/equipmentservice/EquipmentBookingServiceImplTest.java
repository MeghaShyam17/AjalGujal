package com.ilp.equipmentservice;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.equipmentservice.client.NotificationFeignClient;
import com.ilp.equipmentservice.client.ProjectFeignClient;
import com.ilp.equipmentservice.client.UserFeignClient;
import com.ilp.equipmentservice.dto.request.EquipmentBookingRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentBookingResponseDTO;
import com.ilp.equipmentservice.dto.response.ProjectResponseDTO;
import com.ilp.equipmentservice.dto.response.UserResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentBooking;
import com.ilp.equipmentservice.entity.EquipmentMaintenance;
import com.ilp.equipmentservice.exception.EquipmentBookingException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentBookingRepository;
import com.ilp.equipmentservice.repository.EquipmentMaintenanceRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.impl.EquipmentBookingServiceImpl;

@ExtendWith(MockitoExtension.class)
class EquipmentBookingServiceImplTest {

    @Mock
    private EquipmentBookingRepository equipmentBookingRepository;

    @Mock
    private EquipmentRepository equipmentRepository;

    @Mock
    private EquipmentMaintenanceRepository maintenanceRepository;

    @Mock
    private NotificationFeignClient notificationFeignClient;

    @Mock
    private UserFeignClient userFeignClient;

    @Mock
    private ProjectFeignClient projectFeignClient;

    @InjectMocks
    private EquipmentBookingServiceImpl service;

    private EquipmentBookingRequestDTO requestDTO;
    private Equipment equipment;
    private UserResponseDTO user;
    private ProjectResponseDTO project;

    @BeforeEach
    void setUp() {

        requestDTO = new EquipmentBookingRequestDTO();

        requestDTO.setEquipmentId(1L);
        requestDTO.setProjectId(100L);
        requestDTO.setRequestedBy(200L);
        requestDTO.setBookingDate(
                LocalDate.now().plusDays(1));
        requestDTO.setFromTime(
                LocalTime.of(10, 0));
        requestDTO.setToTime(
                LocalTime.of(12, 0));

        equipment = new Equipment();
        equipment.setEquipmentId(1L);
        equipment.setAssetCode("EQ001");

        user = new UserResponseDTO();

        project = new ProjectResponseDTO();
        project.setProjectId(100);
        project.setProjectStatus("ACTIVE");
    }

    @Test
    void createBookingSuccess() {

        when(userFeignClient.getUserById(200))
                .thenReturn(user);

        when(projectFeignClient.getProjectById(100))
                .thenReturn(project);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setEquipment(equipment);
        booking.setProjectId(100L);
        booking.setRequestedBy(200L);
        booking.setCreatedAt(
                LocalDateTime.now());

        when(equipmentBookingRepository.save(
                any(EquipmentBooking.class)))
                .thenReturn(booking);

        EquipmentBookingResponseDTO response =
                service.createEquipmentBooking(
                        requestDTO);

        assertNotNull(response);

        verify(notificationFeignClient)
                .createNotification(any());
    }

    @Test
    void createBookingCompletedProject() {

        when(userFeignClient.getUserById(200))
                .thenReturn(user);

        project.setProjectStatus("COMPLETED");

        when(projectFeignClient.getProjectById(100))
                .thenReturn(project);

        assertThrows(
                EquipmentBookingException.class,
                () -> service.createEquipmentBooking(
                        requestDTO));
    }

    @Test
    void getBookingByIdSuccess() {

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setEquipment(equipment);

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.of(booking));

        EquipmentBookingResponseDTO response =
                service.getEquipmentBookingById(1L);

        assertEquals(
                1L,
                response.getBookingId());
    }

    @Test
    void getBookingByIdNotFound() {

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getEquipmentBookingById(
                        1L));
    }

    @Test
    void approveBookingAlreadyApproved() {

        UserResponseDTO user =
                new UserResponseDTO();

        Equipment equipment =
                new Equipment();

        equipment.setEquipmentId(1L);
        equipment.setAssetCode("EQ001");

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setEquipment(equipment);
        booking.setBookingDate(
                LocalDate.now().plusDays(1));
        booking.setApprovalStatus("Approved");

        when(userFeignClient.getUserById(1))
                .thenReturn(user);

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.of(booking));

        when(equipmentBookingRepository
                .findByEquipmentEquipmentIdAndBookingDateAndApprovalStatus(
                        1L,
                        booking.getBookingDate(),
                        "Approved"))
                                .thenReturn(List.of());

        EquipmentBookingException exception =
                assertThrows(
                        EquipmentBookingException.class,
                        () -> service.approveBooking(
                                1L,
                                1L));

        assertEquals(
                "Booking is already approved",
                exception.getMessage());
    }

    @Test
    void rejectBookingSuccess() {

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setEquipment(equipment);
        booking.setRequestedBy(10L);

        when(userFeignClient.getUserById(1))
                .thenReturn(user);

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.of(booking));

        when(equipmentBookingRepository.save(any()))
                .thenReturn(booking);

        EquipmentBookingResponseDTO response =
                service.rejectBooking(
                        1L,
                        1L);

        assertNotNull(response);

        verify(notificationFeignClient)
                .createNotification(any());
    }
    
    @Test
    void createBookingEquipmentNotFound() {
        when(userFeignClient.getUserById(200))
                .thenReturn(user);

        when(projectFeignClient.getProjectById(100))
                .thenReturn(project);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.createEquipmentBooking(
                        requestDTO));
    }
    
    @Test
    void createBookingPastDate() {

        requestDTO.setBookingDate(
                LocalDate.now().minusDays(1));

        when(userFeignClient.getUserById(200))
                .thenReturn(user);

        when(projectFeignClient.getProjectById(100))
                .thenReturn(project);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        assertThrows(
                EquipmentBookingException.class,
                () -> service.createEquipmentBooking(
                        requestDTO));
    }
    
    @Test
    void createBookingInvalidTimeRange() {

        requestDTO.setFromTime(
                LocalTime.of(14, 0));

        requestDTO.setToTime(
                LocalTime.of(12, 0));

        when(userFeignClient.getUserById(200))
                .thenReturn(user);

        when(projectFeignClient.getProjectById(100))
                .thenReturn(project);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        assertThrows(
                EquipmentBookingException.class,
                () -> service.createEquipmentBooking(
                        requestDTO));
    }
    
    @Test
    void deleteBookingSuccess() {

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.of(booking));

        service.deleteEquipmentBooking(1L);

        verify(equipmentBookingRepository)
                .delete(booking);
    }
    
    @Test
    void deleteBookingNotFound() {

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.deleteEquipmentBooking(
                        1L));
    }
    
    @Test
    void approveBookingRejectedBooking() {

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setEquipment(equipment);
        booking.setBookingDate(
                LocalDate.now().plusDays(1));
        booking.setApprovalStatus(
                "Rejected");

        when(userFeignClient.getUserById(1))
                .thenReturn(user);

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.of(booking));

        when(equipmentBookingRepository
                .findByEquipmentEquipmentIdAndBookingDateAndApprovalStatus(
                        anyLong(),
                        any(),
                        eq("Approved")))
                .thenReturn(List.of());

        assertThrows(
                EquipmentBookingException.class,
                () -> service.approveBooking(
                        1L,
                        1L));
    }
    
    @Test
    void approveBookingSuccess() {

        EquipmentBooking booking =
                new EquipmentBooking();

        booking.setBookingId(1L);
        booking.setEquipment(equipment);
        booking.setRequestedBy(10L);
        booking.setApprovalStatus("Pending");
        booking.setBookingDate(
                LocalDate.now().plusDays(1));
        booking.setFromTime(
                LocalTime.of(10, 0));
        booking.setToTime(
                LocalTime.of(12, 0));

        when(userFeignClient.getUserById(1))
                .thenReturn(user);

        when(equipmentBookingRepository.findById(1L))
                .thenReturn(Optional.of(booking));

        when(equipmentBookingRepository
                .findByEquipmentEquipmentIdAndBookingDateAndApprovalStatus(
                        anyLong(),
                        any(),
                        eq("Approved")))
                .thenReturn(List.of());

        when(equipmentBookingRepository
                .findByEquipmentEquipmentIdAndBookingDate(
                        anyLong(),
                        any()))
                .thenReturn(List.of());

        when(equipmentBookingRepository.save(any()))
                .thenReturn(booking);

        EquipmentBookingResponseDTO response =
                service.approveBooking(
                        1L,
                        1L);

        assertNotNull(response);

        verify(notificationFeignClient)
                .createNotification(any());
    }
    
    @Test
    void createBookingDuringMaintenance() {

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setStartDate(
                requestDTO.getBookingDate());

        maintenance.setEndDate(
                requestDTO.getBookingDate());

        when(userFeignClient.getUserById(200))
                .thenReturn(user);

        when(projectFeignClient.getProjectById(100))
                .thenReturn(project);

        when(equipmentRepository.findById(1L))
                .thenReturn(Optional.of(equipment));

        when(maintenanceRepository
                .findByEquipmentEquipmentId(1L))
                .thenReturn(List.of(maintenance));

        assertThrows(
                EquipmentBookingException.class,
                () -> service.createEquipmentBooking(
                        requestDTO));
    }
}