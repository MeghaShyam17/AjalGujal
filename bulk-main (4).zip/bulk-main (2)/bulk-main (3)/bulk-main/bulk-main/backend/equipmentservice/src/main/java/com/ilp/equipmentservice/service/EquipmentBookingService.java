package com.ilp.equipmentservice.service;

import java.util.List;

import com.ilp.equipmentservice.dto.request.EquipmentBookingRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentBookingResponseDTO;

public interface EquipmentBookingService {

    EquipmentBookingResponseDTO createEquipmentBooking(
            EquipmentBookingRequestDTO requestDTO);

    EquipmentBookingResponseDTO getEquipmentBookingById(
            Long bookingId);

    List<EquipmentBookingResponseDTO> getAllEquipmentBookings();

    List<EquipmentBookingResponseDTO> getBookingsByUser(
            Long userId);

    List<EquipmentBookingResponseDTO> getBookingsByProject(
            Long projectId);

    EquipmentBookingResponseDTO updateEquipmentBooking(
            Long bookingId,
            EquipmentBookingRequestDTO requestDTO);

    /**
     * Approve a booking by Lab Technician
     */
    EquipmentBookingResponseDTO approveBooking(
            Long bookingId,
            Long approvedBy);

    /**
     * Reject a booking by Lab Technician
     */
    EquipmentBookingResponseDTO rejectBooking(
            Long bookingId,
            Long approvedBy);

    void deleteEquipmentBooking(
            Long bookingId);
}