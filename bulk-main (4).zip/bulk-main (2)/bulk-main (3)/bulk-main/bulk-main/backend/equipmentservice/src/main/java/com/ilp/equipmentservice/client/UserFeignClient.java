package com.ilp.equipmentservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ilp.equipmentservice.config.FeignClientConfig;
import com.ilp.equipmentservice.dto.response.UserResponseDTO;

@FeignClient(
        name = "user-service",
        url = "http://localhost:8081",
        configuration = FeignClientConfig.class)
public interface UserFeignClient {

    @GetMapping("/api/users/{userId}")
    UserResponseDTO getUserById(
            @PathVariable Integer userId);
}