package com.ilp.projectservice.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.projectservice.Entity.BatchStageEntity;

@Repository
public interface BatchStageRepository
        extends JpaRepository<BatchStageEntity, Long> {

    List<BatchStageEntity>
        findByBatchIdOrderByStageNoAsc(
            Integer batchId
        );

    Optional<BatchStageEntity>
        findByBatchIdAndStageNo(
            Integer batchId,
            Integer stageNo
        );

    boolean existsByBatchIdAndStageNo(
        Integer batchId,
        Integer stageNo
    );

    boolean existsByBatchIdAndStage_StageId(
        Integer batchId,
        Long stageId
    );

    boolean existsByBatchIdAndStageNoAndBatchStageIdNot(
        Integer batchId,
        Integer stageNo,
        Long batchStageId
    );

    boolean existsByBatchIdAndStage_StageIdAndBatchStageIdNot(
        Integer batchId,
        Long stageId,
        Long batchStageId
    );

    long countByBatchId(Integer batchId);
}