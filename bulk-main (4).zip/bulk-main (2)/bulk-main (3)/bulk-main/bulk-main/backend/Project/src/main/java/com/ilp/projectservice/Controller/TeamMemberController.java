package com.ilp.projectservice.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.Entity.TeamMember;
import com.ilp.projectservice.Service.TeamMemberService;

@RestController
@RequestMapping("/api/team-members")
public class TeamMemberController {

    private final TeamMemberService teamMemberService;

    public TeamMemberController(TeamMemberService teamMemberService) {
        this.teamMemberService = teamMemberService;
    }

    @PostMapping
    public ResponseEntity<TeamMember> saveTeamMember(
            @RequestBody TeamMember teamMember) {
        TeamMember savedTeamMember =
                teamMemberService.saveTeamMember(teamMember);
        
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedTeamMember);
    }

    @GetMapping
    public ResponseEntity<List<TeamMember>> getAllTeamMembers() {
        return ResponseEntity.ok(
                teamMemberService.getAllTeamMembers());
    }

    @GetMapping("/{teamMemberId}")
    public ResponseEntity<TeamMember> getTeamMemberById(
            @PathVariable Integer teamMemberId) {
        return ResponseEntity.ok(
                teamMemberService.getTeamMemberById(teamMemberId));
    }

    @PutMapping("/{teamMemberId}")
    public ResponseEntity<TeamMember> updateTeamMember(
            @PathVariable Integer teamMemberId,
            @RequestBody TeamMember teamMember) {
        return ResponseEntity.ok(
                teamMemberService.updateTeamMember(
                        teamMemberId,
                        teamMember));
    }

    @PutMapping("/soft-delete/{teamMemberId}")
    public String softDeleteTeamMember(
            @PathVariable Integer teamMemberId) {

        teamMemberService.deleteTeamMember(teamMemberId);

        return "Team member soft deleted successfully";
    }
    
    @DeleteMapping("/hard-delete/{teamMemberId}")
    public String hardDeleteTeamMember(
            @PathVariable Integer teamMemberId) {

        teamMemberService.hardDeleteTeamMember(teamMemberId);

        return "Team member permanently deleted";
    }
    
    @PostMapping(
            value = "/upload",
            consumes = "multipart/form-data")
    public ResponseEntity<String> uploadExcel(
            @RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(
                teamMemberService.uploadExcel(file));
    }

    @PutMapping("/change-scrum")
    public ResponseEntity<String> changeScrum(
            @RequestParam Integer projectId,
            @RequestParam Integer oldScrumId,
            @RequestParam Integer newScrumId) {
        return ResponseEntity.ok(
                teamMemberService.changeScrum(
                        projectId,
                        oldScrumId,
                        newScrumId));
    }

    @GetMapping("/project/{projectId}")
    public ResponseEntity<List<TeamMember>> getTeamMembersByProjectId(
            @PathVariable Integer projectId) {
        return ResponseEntity.ok(
                teamMemberService.getTeamMembersByProjectId(projectId));
    }
}

