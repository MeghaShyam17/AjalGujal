package com.ilp.projectservice.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import com.ilp.projectservice.DTO.DocumentRequestDto;
import com.ilp.projectservice.DTO.DocumentResponseDto;
import com.ilp.projectservice.DTO.KnowledgeBaseRequestDto;

@FeignClient(
        name = "document-service",
        url = "http://localhost:8081"
)
public interface DocumentClient {

    @PostMapping("/api/documents")
    void createDocument(
            @RequestBody DocumentRequestDto request);

    @GetMapping("/api/documents/project-stage/{projectStageId}")
    List<DocumentResponseDto> getDocumentsByProjectStageId(
            @PathVariable("projectStageId") Long projectStageId);

    @PostMapping("/api/knowledge-base")
    void createKnowledgeBase(
            @RequestBody KnowledgeBaseRequestDto request);
}