package com.ilp.projectservice.ServiceImplementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import com.ilp.projectservice.Client.DocumentClient;
import com.ilp.projectservice.DTO.DocumentRequestDto;
import com.ilp.projectservice.Entity.Project_Stage_Entity;
import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Repository.Project_Stage_Repository;
import com.ilp.projectservice.Repository.Stage_Master_Repository;

@ExtendWith(MockitoExtension.class)
class Project_Stage_Service_ImplementationTest {

    @Mock
    private Project_Stage_Repository repository;

    @Mock
    private Stage_Master_Repository stageMasterRepository;

    @Mock
    private DocumentClient documentClient;

    @InjectMocks
    private Project_Stage_Service_Implementation service;

    @Test
    void shouldInitializeProjectStagesSuccessfully() {

        Stage_Master_Entity stage1 = new Stage_Master_Entity();
        stage1.setStageNo(1);

        Stage_Master_Entity stage2 = new Stage_Master_Entity();
        stage2.setStageNo(2);

        when(repository.findByProjectId(1))
                .thenReturn(Collections.emptyList());

        when(stageMasterRepository.findAllByOrderByStageNoAsc())
                .thenReturn(Arrays.asList(stage1, stage2));

        service.initializeProjectStages(1);

        verify(repository, times(2))
                .save(any(Project_Stage_Entity.class));
    }

    @Test
    void shouldThrowExceptionWhenStagesAlreadyInitialized() {

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        when(repository.findByProjectId(1))
                .thenReturn(List.of(stage));

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.initializeProjectStages(1));

        assertEquals(
                "Stages already initialized for this project",
                exception.getMessage());
    }

    @Test
    void shouldHandleNoStageMasterRecords() {

        when(repository.findByProjectId(1))
                .thenReturn(Collections.emptyList());

        when(stageMasterRepository.findAllByOrderByStageNoAsc())
                .thenReturn(Collections.emptyList());

        service.initializeProjectStages(1);

        verify(repository, never())
                .save(any(Project_Stage_Entity.class));
    }

    @Test
    void shouldSaveProjectStageSuccessfully() {

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setSubmissionStatus("IN_PROGRESS");
        stage.setStageDeadline(LocalDate.now().plusDays(5));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(stage);

        Project_Stage_Entity result =
                service.saveProjectStage(stage);

        assertNotNull(result);
        assertFalse(Boolean.TRUE.equals(result.getIsOverdue()));
    }

    @Test
    void shouldMarkProjectStageAsOverdue() {

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setSubmissionStatus("IN_PROGRESS");
        stage.setStageDeadline(LocalDate.now().minusDays(1));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(stage);

        Project_Stage_Entity result =
                service.saveProjectStage(stage);

        assertTrue(result.getIsOverdue());
    }

    @Test
    void shouldNotMarkApprovedStageAsOverdue() {

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setSubmissionStatus("APPROVED");
        stage.setStageDeadline(LocalDate.now().minusDays(3));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(stage);

        Project_Stage_Entity result =
                service.saveProjectStage(stage);

        assertFalse(Boolean.TRUE.equals(result.getIsOverdue()));
    }

    @Test
    void shouldReturnProjectStageById() {

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setProjectStageId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(stage));

        Project_Stage_Entity result =
                service.getProjectStageById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getProjectStageId());
    }

    @Test
    void shouldReturnNullWhenStageNotFound() {

        when(repository.findById(10L))
                .thenReturn(Optional.empty());

        Project_Stage_Entity result =
                service.getProjectStageById(10L);

        assertNull(result);
    }

    @Test
    void shouldReturnAllProjectStages() {

        when(repository.findAll())
                .thenReturn(List.of(new Project_Stage_Entity()));

        List<Project_Stage_Entity> result =
                service.getAllProjectStages();

        assertEquals(1, result.size());
    }

    @Test
    void shouldReturnEmptyListWhenNoStagesExist() {

        when(repository.findAll())
                .thenReturn(Collections.emptyList());

        List<Project_Stage_Entity> result =
                service.getAllProjectStages();

        assertTrue(result.isEmpty());
    }

    @Test
    void shouldDeleteProjectStage() {

        service.deleteProjectStage(1L);

        verify(repository, times(1))
                .deleteById(1L);
    }

    @Test
    void shouldUpdateProjectStageSuccessfully() {

        Stage_Master_Entity stageMaster =
                new Stage_Master_Entity();

        stageMaster.setStageNo(1);

        Project_Stage_Entity existing =
                new Project_Stage_Entity();

        existing.setProjectStageId(1L);
        existing.setProjectId(10);
        existing.setVersionNo(1);
        existing.setSubmissionStatus("IN_PROGRESS");
        existing.setStageMaster(stageMaster);

        Project_Stage_Entity update =
                new Project_Stage_Entity();

        update.setSubmissionStatus("APPROVED");
        update.setRemarks("Approved");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.findByProjectId(10))
                .thenReturn(Collections.emptyList());

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(existing);

        Project_Stage_Entity result =
                service.updateProjectStage(1L, update);

        assertNotNull(result);
        assertEquals("APPROVED", result.getSubmissionStatus());
        assertEquals("Approved", result.getRemarks());
        assertFalse(Boolean.TRUE.equals(result.getCurrentStage()));

        verify(repository)
                .save(existing);
    }

    @Test
    void shouldReturnNullWhenUpdatingNonExistingStage() {

        when(repository.findById(100L))
                .thenReturn(Optional.empty());

        Project_Stage_Entity result =
                service.updateProjectStage(
                        100L,
                        new Project_Stage_Entity());

        assertNull(result);
    }

    @Test
    void shouldIncrementVersionWhenReopened() {

        Project_Stage_Entity existing =
                new Project_Stage_Entity();

        existing.setVersionNo(1);
        existing.setSubmissionStatus("APPROVED");

        Project_Stage_Entity update =
                new Project_Stage_Entity();

        update.setSubmissionStatus("IN_PROGRESS");
        update.setCurrentStage(true);

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(existing);

        service.updateProjectStage(1L, update);

        assertEquals(2, existing.getVersionNo());
    }

    @Test
    void shouldIncrementVersionWhenRejectedFirstTime() {

        Project_Stage_Entity existing =
                new Project_Stage_Entity();

        existing.setVersionNo(1);
        existing.setSubmissionStatus("SUBMITTED");
        existing.setCurrentStage(true);

        Project_Stage_Entity update =
                new Project_Stage_Entity();

        update.setSubmissionStatus("REJECTED");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(existing);

        service.updateProjectStage(1L, update);

        assertEquals("REJECTED", existing.getSubmissionStatus());
        assertEquals(2, existing.getVersionNo());
        assertTrue(Boolean.TRUE.equals(existing.getCurrentStage()));
    }

    @Test
    void shouldNotIncrementVersionAgainWhenAlreadyRejected() {

        Project_Stage_Entity existing =
                new Project_Stage_Entity();

        existing.setVersionNo(2);
        existing.setSubmissionStatus("REJECTED");
        existing.setCurrentStage(true);

        Project_Stage_Entity update =
                new Project_Stage_Entity();

        update.setSubmissionStatus("REJECTED");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(existing);

        service.updateProjectStage(1L, update);

        assertEquals("REJECTED", existing.getSubmissionStatus());
        assertEquals(2, existing.getVersionNo());
        assertTrue(Boolean.TRUE.equals(existing.getCurrentStage()));
    }

    @Test
    void shouldMarkOverdueDuringUpdate() {

        Project_Stage_Entity existing =
                new Project_Stage_Entity();

        existing.setVersionNo(1);
        existing.setSubmissionStatus("IN_PROGRESS");

        Project_Stage_Entity update =
                new Project_Stage_Entity();

        update.setSubmissionStatus("IN_PROGRESS");
        update.setStageDeadline(LocalDate.now().minusDays(1));
        update.setCurrentStage(true);

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(existing);

        service.updateProjectStage(1L, update);

        assertTrue(existing.getIsOverdue());
    }

    @Test
    void shouldNotMarkApprovedStageAsOverdueDuringUpdate() {

        Stage_Master_Entity stageMaster =
                new Stage_Master_Entity();

        stageMaster.setStageNo(1);

        Project_Stage_Entity existing =
                new Project_Stage_Entity();

        existing.setProjectId(10);
        existing.setVersionNo(1);
        existing.setStageMaster(stageMaster);

        Project_Stage_Entity update =
                new Project_Stage_Entity();

        update.setSubmissionStatus("APPROVED");
        update.setStageDeadline(LocalDate.now().minusDays(2));

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.findByProjectId(10))
                .thenReturn(Collections.emptyList());

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(existing);

        service.updateProjectStage(1L, update);

        assertFalse(existing.getIsOverdue());
    }

    @Test
    void uploadDocument_Success() throws Exception {

        Long projectStageId = 1L;
        Integer uploadedBy = 101;
        Integer versionNo = 2;

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.pdf",
                        "application/pdf",
                        "sample data".getBytes());

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setProjectStageId(projectStageId);
        stage.setVersionNo(1);
        stage.setCurrentStage(true);
        stage.setSubmissionStatus("REJECTED");

        when(repository.findById(projectStageId))
                .thenReturn(Optional.of(stage));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(stage);

        service.uploadDocument(
                projectStageId,
                uploadedBy,
                file,
                "Test Document",
                versionNo);

        ArgumentCaptor<DocumentRequestDto> captor =
                ArgumentCaptor.forClass(DocumentRequestDto.class);

        verify(documentClient)
                .createDocument(captor.capture());

        DocumentRequestDto documentRequest =
                captor.getValue();

        assertEquals(projectStageId.intValue(),
                documentRequest.getProjectStageId());

        assertEquals(uploadedBy,
                documentRequest.getUploadedBy());

        assertEquals(versionNo,
                documentRequest.getVersionNo());

        assertEquals("Submission",
                documentRequest.getDocumentType());

        assertEquals("test.pdf",
                documentRequest.getTitle());

        assertEquals("test.pdf",
                documentRequest.getFileName());

        assertEquals("test.pdf",
                documentRequest.getOriginalFileName());

        assertEquals("Test Document",
                documentRequest.getDescription());

        assertEquals("SUBMITTED",
                stage.getSubmissionStatus());

        assertEquals(uploadedBy,
                stage.getSubmittedBy());

        assertNotNull(stage.getSubmittedOn());

        assertEquals(versionNo,
                stage.getVersionNo());

        verify(repository)
                .save(stage);
    }

    @Test
    void uploadDocument_UsesStageVersionWhenVersionNoIsNull() throws Exception {

        Long projectStageId = 1L;
        Integer uploadedBy = 101;

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.pdf",
                        "application/pdf",
                        "sample data".getBytes());

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setProjectStageId(projectStageId);
        stage.setVersionNo(3);
        stage.setCurrentStage(true);
        stage.setSubmissionStatus("IN_PROGRESS");

        when(repository.findById(projectStageId))
                .thenReturn(Optional.of(stage));

        when(repository.save(any(Project_Stage_Entity.class)))
                .thenReturn(stage);

        service.uploadDocument(
                projectStageId,
                uploadedBy,
                file,
                "Test Document",
                null);

        ArgumentCaptor<DocumentRequestDto> captor =
                ArgumentCaptor.forClass(DocumentRequestDto.class);

        verify(documentClient)
                .createDocument(captor.capture());

        assertEquals(3,
                captor.getValue().getVersionNo());

        assertEquals(3,
                stage.getVersionNo());
    }

    @Test
    void uploadDocument_ProjectStageNotFound() {

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.pdf",
                        "application/pdf",
                        "sample data".getBytes());

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.uploadDocument(
                                1L,
                                101,
                                file,
                                "Test Document",
                                1));

        assertEquals(
                "Failed to upload document",
                exception.getMessage());
    }

    @Test
    void uploadDocument_ShouldFailWhenStageIsNotCurrent() {

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.pdf",
                        "application/pdf",
                        "sample data".getBytes());

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setVersionNo(1);
        stage.setCurrentStage(false);
        stage.setSubmissionStatus("IN_PROGRESS");

        when(repository.findById(1L))
                .thenReturn(Optional.of(stage));

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.uploadDocument(
                                1L,
                                101,
                                file,
                                "Test Document",
                                1));

        assertEquals(
                "Failed to upload document",
                exception.getMessage());

        verify(documentClient, never())
                .createDocument(any(DocumentRequestDto.class));
    }

    @Test
    void uploadDocument_ShouldFailWhenStageIsApproved() {

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "test.pdf",
                        "application/pdf",
                        "sample data".getBytes());

        Project_Stage_Entity stage =
                new Project_Stage_Entity();

        stage.setVersionNo(1);
        stage.setCurrentStage(true);
        stage.setSubmissionStatus("APPROVED");

        when(repository.findById(1L))
                .thenReturn(Optional.of(stage));

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.uploadDocument(
                                1L,
                                101,
                                file,
                                "Test Document",
                                1));

        assertEquals(
                "Failed to upload document",
                exception.getMessage());

        verify(documentClient, never())
                .createDocument(any(DocumentRequestDto.class));
    }
}