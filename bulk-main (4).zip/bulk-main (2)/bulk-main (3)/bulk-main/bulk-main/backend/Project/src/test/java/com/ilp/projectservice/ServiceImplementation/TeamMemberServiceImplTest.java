package com.ilp.projectservice.ServiceImplementation;

import static org.junit.jupiter.api.Assertions.*;

import com.ilp.projectservice.Client.UserClient;
import com.ilp.projectservice.DTO.UserResponseDto;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import com.ilp.projectservice.Entity.TeamMember;
import com.ilp.projectservice.Exception.BadRequestException;
import com.ilp.projectservice.Exception.BusinessException;
import com.ilp.projectservice.Exception.ResourceNotFoundException;
import com.ilp.projectservice.Repository.TeamMemberRepository;

@ExtendWith(MockitoExtension.class)
class TeamMemberServiceImplTest {

    @Mock
    private TeamMemberRepository teamMemberRepository;

    @InjectMocks
    private TeamMemberServiceImpl service;
    
    @Mock
    private UserClient userClient;

    @Test
    void shouldSaveTeamMemberSuccessfully() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(101);
        member.setMemberRole("Member");

        when(teamMemberRepository
                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(1, 101))
                .thenReturn(false);

        when(teamMemberRepository.save(any(TeamMember.class)))
                .thenReturn(member);

        TeamMember result = service.saveTeamMember(member);

        assertNotNull(result);
        verify(teamMemberRepository).save(member);
    }

    @Test
    void shouldThrowExceptionWhenDuplicateMemberExists() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(101);
        member.setMemberRole("Member");

        when(teamMemberRepository
                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(1, 101))
                .thenReturn(true);

        assertThrows(
                BusinessException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldReturnAllTeamMembers() {

        when(teamMemberRepository.findByIsDeletedFalse())
                .thenReturn(List.of(new TeamMember()));

        List<TeamMember> result =
                service.getAllTeamMembers();

        assertEquals(1, result.size());
    }

    @Test
    void shouldReturnTeamMemberById() {

        TeamMember member = new TeamMember();
        member.setTeamMemberId(1);

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(member));

        TeamMember result =
                service.getTeamMemberById(1);

        assertEquals(1, result.getTeamMemberId());
    }

    @Test
    void shouldThrowExceptionWhenMemberNotFound() {

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getTeamMemberById(1));
    }

    @Test
    void shouldUpdateTeamMemberSuccessfully() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember existing = new TeamMember();
        existing.setTeamMemberId(1);
        existing.setProjectId(1);
        existing.setTraineeId(100);
        existing.setMemberRole("Member");

        TeamMember update = new TeamMember();
        update.setProjectId(2);
        update.setTraineeId(200);
        update.setMemberRole("Scrum");

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(existing));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(2, 200))
                .thenReturn(Optional.empty());

        when(teamMemberRepository.save(any(TeamMember.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        TeamMember result =
                service.updateTeamMember(1, update);

        assertEquals(2, result.getProjectId());
        assertEquals(200, result.getTraineeId());
        assertEquals("Scrum", result.getMemberRole());
    }

    @Test
    void shouldThrowExceptionWhenUpdatingDuplicateMember() {

    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember existing = new TeamMember();
        existing.setTeamMemberId(1);

        TeamMember duplicate = new TeamMember();
        duplicate.setTeamMemberId(2);

        TeamMember update = new TeamMember();
        update.setProjectId(1);
        update.setTraineeId(100);
        update.setMemberRole("Member");

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(existing));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(Optional.of(duplicate));

        assertThrows(
                BusinessException.class,
                () -> service.updateTeamMember(1, update));
    }

    @Test
    void shouldSoftDeleteTeamMember() {

        TeamMember member = new TeamMember();
        member.setTeamMemberId(1);
        member.setIsDeleted(false);

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(member));

        service.deleteTeamMember(1);

        assertTrue(member.getIsDeleted());

        verify(teamMemberRepository)
                .save(member);
    }

    @Test
    void shouldReturnUploadInstructionMessage() {

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        "sample.xlsx",
                        "application/vnd.ms-excel",
                        "data".getBytes());

        String result = service.uploadExcel(file);

        assertTrue(result.contains(
                "/api/projects/bulk-upload"));
    }

    @Test
    void shouldThrowExceptionWhenExcelFileMissing() {

        MockMultipartFile file =
                new MockMultipartFile(
                        "file",
                        new byte[0]);

        assertThrows(
                BadRequestException.class,
                () -> service.uploadExcel(file));
    }

    @Test
    void shouldChangeScrumSuccessfully() {

        TeamMember oldScrum = new TeamMember();
        oldScrum.setMemberRole("Scrum");

        TeamMember newScrum = new TeamMember();
        newScrum.setMemberRole("Member");

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 101))
                .thenReturn(Optional.of(oldScrum));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 202))
                .thenReturn(Optional.of(newScrum));

        String result =
                service.changeScrum(1, 101, 202);

        assertEquals("Member",
                oldScrum.getMemberRole());

        assertEquals("Scrum",
                newScrum.getMemberRole());

        verify(teamMemberRepository, times(2))
                .save(any(TeamMember.class));

        verify(teamMemberRepository)
                .flush();

        assertTrue(result.contains(
                "Scrum changed successfully"));
    }

    @Test
    void shouldThrowExceptionWhenOldScrumNotFound() {

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.changeScrum(1, 100, 200));
    }

    @Test
    void shouldThrowExceptionWhenOldScrumIsNotScrum() {

        TeamMember oldScrum = new TeamMember();
        oldScrum.setMemberRole("Member");

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(Optional.of(oldScrum));

        assertThrows(
                BusinessException.class,
                () -> service.changeScrum(1, 100, 200));
    }

    @Test
    void shouldThrowExceptionWhenNewScrumNotFound() {

        TeamMember oldScrum = new TeamMember();
        oldScrum.setMemberRole("Scrum");

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(Optional.of(oldScrum));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 200))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.changeScrum(1, 100, 200));
    }

    @Test
    void shouldThrowExceptionWhenNewScrumNotMember() {

        TeamMember oldScrum = new TeamMember();
        oldScrum.setMemberRole("Scrum");

        TeamMember newScrum = new TeamMember();
        newScrum.setMemberRole("Scrum");

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(Optional.of(oldScrum));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 200))
                .thenReturn(Optional.of(newScrum));

        assertThrows(
                BusinessException.class,
                () -> service.changeScrum(1, 100, 200));
    }

    @Test
    void shouldThrowExceptionWhenProjectIdNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.changeScrum(
                        null, 100, 200));
    }

    @Test
    void shouldThrowExceptionWhenSameScrumIdsProvided() {

        assertThrows(
                BadRequestException.class,
                () -> service.changeScrum(
                        1, 100, 100));
    }

    @Test
    void shouldThrowExceptionWhenRoleInvalid() {

        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("Leader");

        assertThrows(
                BadRequestException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldThrowExceptionWhenProjectIdMissing() {

        TeamMember member = new TeamMember();
        member.setTraineeId(100);
        member.setMemberRole("Member");

        assertThrows(
                BadRequestException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldThrowExceptionWhenTraineeIdMissing() {

        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setMemberRole("Member");

        assertThrows(
                BadRequestException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldThrowExceptionWhenMemberIdNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.getTeamMemberById(null));
    }
    
    @Test
    void shouldThrowExceptionWhenOldScrumIdIsNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.changeScrum(
                        1,
                        null,
                        200));
    }

    @Test
    void shouldThrowExceptionWhenNewScrumIdIsNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.changeScrum(
                        1,
                        100,
                        null));
    }

    @Test
    void shouldThrowExceptionWhenMemberRoleNull() {

        TeamMember member = new TeamMember();

        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole(null);

        assertThrows(
                BadRequestException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldThrowExceptionWhenMemberRoleBlank() {

        TeamMember member = new TeamMember();

        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("  ");

        assertThrows(
                BadRequestException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldThrowExceptionWhenTeamMemberObjectNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.saveTeamMember(null));
    }

    @Test
    void shouldThrowExceptionWhenUpdatingWithNullObject() {

        assertThrows(
                BadRequestException.class,
                () -> service.updateTeamMember(
                        1,
                        null));
    }

    @Test
    void shouldThrowExceptionWhenUpdatingMissingMember() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember update = new TeamMember();

        update.setProjectId(1);
        update.setTraineeId(100);
        update.setMemberRole("Member");

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateTeamMember(
                        1,
                        update));
    }

    @Test
    void shouldThrowExceptionWhenDeletingMissingMember() {

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.deleteTeamMember(1));
    }

    @Test
    void shouldAllowUpdatingSameProjectAndTraineeCombination() {

    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember existing = new TeamMember();

        existing.setTeamMemberId(1);
        existing.setProjectId(1);
        existing.setTraineeId(100);
        existing.setMemberRole("Member");

        TeamMember update = new TeamMember();

        update.setProjectId(1);
        update.setTraineeId(100);
        update.setMemberRole("Scrum");

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(existing));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(
                        1,
                        100))
                .thenReturn(Optional.of(existing));

        when(teamMemberRepository.save(any(TeamMember.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        TeamMember result =
                service.updateTeamMember(1, update);

        assertEquals(
                "Scrum",
                result.getMemberRole());
    }

    @Test
    void shouldThrowExceptionWhenGetMemberByIdNotFound() {

        when(teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(99))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getTeamMemberById(99));
    }
    
    @Test
    void shouldVerifyRepositoryFlushCalled() {

        TeamMember oldScrum = new TeamMember();
        oldScrum.setMemberRole("Scrum");

        TeamMember newScrum = new TeamMember();
        newScrum.setMemberRole("Member");

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 1))
                .thenReturn(Optional.of(oldScrum));

        when(teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(1, 2))
                .thenReturn(Optional.of(newScrum));

        service.changeScrum(1, 1, 2);

        verify(teamMemberRepository).flush();
    }
    
    @Test
    void shouldThrowExceptionWhenUpdatingNullMemberId() {

        UserResponseDto user = new UserResponseDto();

        when(userClient.getUserById(anyInt()))
                .thenReturn(user);

        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("Member");

        assertThrows(
                BadRequestException.class,
                () -> service.updateTeamMember(null, member));
    }
    
    @Test
    void shouldNormalizeRoleToScrum() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("scrum");

        when(teamMemberRepository
                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(false);

        when(teamMemberRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        TeamMember result =
                service.saveTeamMember(member);

        assertEquals("Scrum",
                result.getMemberRole());
    }
    
    @Test
    void shouldNormalizeRoleToMember() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("member");

        when(teamMemberRepository
                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(false);

        when(teamMemberRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        TeamMember result =
                service.saveTeamMember(member);

        assertEquals("Member",
                result.getMemberRole());
    }
    
    @Test
    void shouldThrowExceptionWhenExcelFileIsNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.uploadExcel(null));
    }
    
    @Test
    void shouldAcceptLowerCaseScrum() {

    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("scrum");

        when(teamMemberRepository
                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(false);

        when(teamMemberRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        TeamMember result =
                service.saveTeamMember(member);

        assertEquals("Scrum",
                result.getMemberRole());
    }
    
    @Test
    void shouldAcceptLowerCaseMember() {
    	
    	UserResponseDto user = new UserResponseDto();

    	when(userClient.getUserById(anyInt()))
    	        .thenReturn(user);
    	
        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("member");

        when(teamMemberRepository
                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(1, 100))
                .thenReturn(false);

        when(teamMemberRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        TeamMember result =
                service.saveTeamMember(member);

        assertEquals("Member",
                result.getMemberRole());
    }
    
    @Test
    void shouldHardDeleteTeamMemberSuccessfully() {

        TeamMember member = new TeamMember();
        member.setTeamMemberId(1);

        when(teamMemberRepository.findById(1))
                .thenReturn(Optional.of(member));

        service.hardDeleteTeamMember(1);

        verify(teamMemberRepository)
                .delete(member);
    }

    @Test
    void shouldThrowExceptionWhenHardDeleteMemberNotFound() {

        when(teamMemberRepository.findById(1))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.hardDeleteTeamMember(1));
    }

    @Test
    void shouldThrowExceptionWhenHardDeleteMemberIdNull() {

        assertThrows(
                BadRequestException.class,
                () -> service.hardDeleteTeamMember(null));
    }

    @Test
    void shouldThrowExceptionWhenUserNotFoundDuringSave() {

        TeamMember member = new TeamMember();
        member.setProjectId(1);
        member.setTraineeId(100);
        member.setMemberRole("Member");

        when(userClient.getUserById(100))
                .thenReturn(null);

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.saveTeamMember(member));
    }

    @Test
    void shouldThrowExceptionWhenUserNotFoundDuringUpdate() {

        TeamMember update = new TeamMember();
        update.setProjectId(1);
        update.setTraineeId(100);
        update.setMemberRole("Member");

        when(userClient.getUserById(100))
                .thenReturn(null);

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateTeamMember(1, update));
    }
}