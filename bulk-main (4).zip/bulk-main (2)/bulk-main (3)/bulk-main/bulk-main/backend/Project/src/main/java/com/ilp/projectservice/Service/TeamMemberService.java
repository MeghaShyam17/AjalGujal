package com.ilp.projectservice.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.Entity.TeamMember;

public interface TeamMemberService {

    TeamMember saveTeamMember(TeamMember teamMember);

    List<TeamMember> getAllTeamMembers();

    TeamMember getTeamMemberById(Integer teamMemberId);

    TeamMember updateTeamMember(
            Integer teamMemberId,
            TeamMember teamMember
    );
    
    void hardDeleteTeamMember(Integer teamMemberId);
    
    void deleteTeamMember(Integer teamMemberId);

    String uploadExcel(MultipartFile file);

    String changeScrum(
            Integer projectId,
            Integer oldScrumId,
            Integer newScrumId
    );

    List<TeamMember> getTeamMembersByProjectId(Integer projectId);
}

