package com.ilp.projectservice.Exception;

import java.util.List;

import com.ilp.projectservice.DTO.BulkUploadError;

public class BulkUploadException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final List<BulkUploadError> errors;

    public BulkUploadException(String message, List<BulkUploadError> errors) {
        super(message);
        this.errors = List.copyOf(errors);
    }

    public List<BulkUploadError> getErrors() {
        return errors;
    }
}