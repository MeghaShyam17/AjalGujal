package com.ilp.projectservice.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BulkUploadResult;
import com.ilp.projectservice.Entity.ProjectTeam;


public interface ProjectTeamService {

    ProjectTeam createProject(ProjectTeam projectTeam);

    List<ProjectTeam> getAllProjects();

    ProjectTeam getProjectById(Integer projectId);

    ProjectTeam updateProject(Integer projectId, ProjectTeam projectTeam);

    ProjectTeam updateProjectStatus(Integer projectId, String projectStatus);

    void deleteProject(Integer projectId);

    List<ProjectTeam> getProjectsByStatus(String projectStatus);

    List<ProjectTeam> getProjectsByTeamLeader(Integer teamLeaderId);

    List<ProjectTeam> getProjectsByFaculty(Integer facultyId);

    List<ProjectTeam> getProjectsByBatch(Integer batchId);

    List<ProjectTeam> getProjectsByYear(Integer year);

    List<ProjectTeam> searchProjectsByName(String projectName);

    BulkUploadResult uploadProjectTeamsAndMembers(MultipartFile file);
    
    void hardDeleteProject(Integer projectId);
}

