package com.ilp.projectservice.DTO;

import java.time.LocalDate;

public record ProjectImportRowDto(
        int rowNumber,
        String projectReference,
        String projectName,
        String description,
        Integer teamLeaderId,
        Integer facultyId,
        Integer batchId,
        Integer year,
        LocalDate deadline,
        String projectStatus) {}