package com.ilp.projectservice.Entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "project_team")
public class ProjectTeam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "project_id")
    private Integer projectId;

    @Column(name = "project_name", nullable = false, length = 200)
    private String projectName;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    // Logical foreign key: users.user_id
    @Column(name = "team_leader_id")
    private Integer teamLeaderId;

    // Logical foreign key: users.user_id
    @Column(name = "faculty_id")
    private Integer facultyId;

    // Logical foreign key: batch_master.batch_id
    @Column(name = "batch_id")
    private Integer batchId;

    @Column(name = "\"year\"")
    private Integer year;

    @Column(name = "project_start_date")
    private LocalDate projectStartDate;

    @Column(name = "deadline")
    private LocalDate deadline;

    // Valid values: Pending, Ongoing, Completed
    @Column(name = "project_status", length = 30)
    private String projectStatus = "Pending";

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "is_deleted", nullable = false)
    private Boolean isDeleted = false;

    /*
     * Request/response helper only. Team members remain stored in the
     * team_member table and are not persisted through this field.
     */
    @Transient
    private List<TeamMember> teamMembers;

    public ProjectTeam() {
    }

    public ProjectTeam(
            String projectName,
            String description,
            Integer teamLeaderId,
            Integer facultyId,
            Integer batchId,
            Integer year,
            LocalDate projectStartDate,
            LocalDate deadline) {

        this.projectName = projectName;
        this.description = description;
        this.teamLeaderId = teamLeaderId;
        this.facultyId = facultyId;
        this.batchId = batchId;
        this.year = year;
        this.projectStartDate = projectStartDate;
        this.deadline = deadline;
    }

    @PrePersist
    private void applyDefaults() {
        if (projectStatus == null || projectStatus.isBlank()) {
            projectStatus = "Pending";
        }

        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }

        if (projectStartDate == null) {
            projectStartDate = LocalDate.now();
        }

        if (isDeleted == null) {
            isDeleted = false;
        }
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTeamLeaderId() {
        return teamLeaderId;
    }

    public void setTeamLeaderId(Integer teamLeaderId) {
        this.teamLeaderId = teamLeaderId;
    }

    public Integer getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Integer facultyId) {
        this.facultyId = facultyId;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public LocalDate getProjectStartDate() {
        return projectStartDate;
    }

    public void setProjectStartDate(LocalDate projectStartDate) {
        this.projectStartDate = projectStartDate;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public List<TeamMember> getTeamMembers() {
        return teamMembers;
    }

    public void setTeamMembers(List<TeamMember> teamMembers) {
        this.teamMembers = teamMembers;
    }

    @Override
    public String toString() {
        return "ProjectTeam{" +
                "projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", teamLeaderId=" + teamLeaderId +
                ", facultyId=" + facultyId +
                ", batchId=" + batchId +
                ", year=" + year +
                ", projectStartDate=" + projectStartDate +
                ", deadline=" + deadline +
                ", projectStatus='" + projectStatus + '\'' +
                ", createdAt=" + createdAt +
                ", isDeleted=" + isDeleted +
                '}';
    }
}
