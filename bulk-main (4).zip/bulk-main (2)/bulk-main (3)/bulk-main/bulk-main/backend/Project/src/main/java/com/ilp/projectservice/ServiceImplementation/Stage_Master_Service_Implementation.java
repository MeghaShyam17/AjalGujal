package com.ilp.projectservice.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Exception.StageMappedException;
import com.ilp.projectservice.Repository.Project_Stage_Repository;
import com.ilp.projectservice.Repository.Stage_Master_Repository;
import com.ilp.projectservice.Service.Stage_Master_Service;

@Service
public class Stage_Master_Service_Implementation
        implements Stage_Master_Service {

    @Autowired
    private Stage_Master_Repository repository;

    @Autowired
    private Project_Stage_Repository projectStageRepository;    @Override
    public Stage_Master_Entity saveStage(Stage_Master_Entity stage) {
        if (stage.getBatchId() != null) {
            if (repository.findByBatchIdAndStageNo(stage.getBatchId(), stage.getStageNo()).isPresent()) {
                throw new RuntimeException("Stage number already exists for this batch");
            }
        } else {
            List<Stage_Master_Entity> defaults = repository.findByBatchIdIsNullOrderByStageNoAsc();
            boolean exists = defaults.stream().anyMatch(s -> s.getStageNo().equals(stage.getStageNo()));
            if (exists) {
                throw new RuntimeException("Stage number already exists for default workflow");
            }
        }
        return repository.save(stage);
    }

    @Override
    public List<Stage_Master_Entity> getAllStages() {
        return repository.findByBatchIdIsNullOrderByStageNoAsc();
    }

    @Override
    public Stage_Master_Entity getStageById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Stage not found"));
    }

    @Override
    public Stage_Master_Entity updateStage(Long id, Stage_Master_Entity stage) {
        Stage_Master_Entity existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Stage not found"));

        if (!existing.getStageNo().equals(stage.getStageNo()) || 
            (existing.getBatchId() == null && stage.getBatchId() != null) ||
            (existing.getBatchId() != null && !existing.getBatchId().equals(stage.getBatchId()))) {
            
            if (stage.getBatchId() != null) {
                if (repository.findByBatchIdAndStageNo(stage.getBatchId(), stage.getStageNo()).isPresent()) {
                    throw new RuntimeException("Stage number already exists for this batch");
                }
            } else {
                List<Stage_Master_Entity> defaults = repository.findByBatchIdIsNullOrderByStageNoAsc();
                boolean exists = defaults.stream().anyMatch(s -> s.getStageNo().equals(stage.getStageNo()));
                if (exists) {
                    throw new RuntimeException("Stage number already exists for default workflow");
                }
            }
        }

        existing.setBatchId(stage.getBatchId());
        existing.setStageNo(stage.getStageNo());
        existing.setStageName(stage.getStageName());
        existing.setDescription(stage.getDescription());

        return repository.save(existing);
    }

    @Override
    public void deleteStage(Long id) {

        Stage_Master_Entity stage =
                repository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Stage not found"));

        boolean stageMapped =
                projectStageRepository.existsByStageMaster_StageId(
                        stage.getStageId());

        if (stageMapped) {

            throw new StageMappedException(
                    "Cannot delete stage. Stage is already mapped to one or more projects.");
        }

        repository.delete(stage);
    }

    @Override
    public List<Stage_Master_Entity> getStagesByBatchId(Integer batchId) {
        return repository.findByBatchIdOrderByStageNoAsc(batchId);
    }
} 