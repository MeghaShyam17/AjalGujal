package com.ilp.projectservice.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.projectservice.Entity.ProjectTeam;

@Repository
public interface ProjectTeamRepository
        extends JpaRepository<ProjectTeam, Integer> {

    List<ProjectTeam> findByProjectStatus(String projectStatus);

    List<ProjectTeam> findByTeamLeaderId(Integer teamLeaderId);

    List<ProjectTeam> findByFacultyId(Integer facultyId);

    List<ProjectTeam> findByBatchId(Integer batchId);

    List<ProjectTeam> findByYear(Integer year);

    List<ProjectTeam> findByProjectNameContainingIgnoreCase(
            String projectName);

    // Soft Delete Methods

    List<ProjectTeam> findByIsDeletedFalse();

    Optional<ProjectTeam> findByProjectIdAndIsDeletedFalse(
            Integer projectId);

    List<ProjectTeam> findByProjectStatusAndIsDeletedFalse(
            String projectStatus);

    List<ProjectTeam> findByTeamLeaderIdAndIsDeletedFalse(
            Integer teamLeaderId);

    List<ProjectTeam> findByFacultyIdAndIsDeletedFalse(
            Integer facultyId);

    List<ProjectTeam> findByBatchIdAndIsDeletedFalse(
            Integer batchId);

    List<ProjectTeam> findByYearAndIsDeletedFalse(
            Integer year);

    List<ProjectTeam>
    findByProjectNameContainingIgnoreCaseAndIsDeletedFalse(
            String projectName);
}