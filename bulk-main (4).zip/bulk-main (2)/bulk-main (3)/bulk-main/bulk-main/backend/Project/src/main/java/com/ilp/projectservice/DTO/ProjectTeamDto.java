package com.ilp.projectservice.DTO;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ProjectTeamDto {

    private Integer projectId;
    private String projectName;
    private String description;
    private Integer teamLeaderId;
    private Integer facultyId;
    private Integer batchId;
    private Integer year;
    private LocalDate projectStartDate;
    private LocalDate deadline;
    private String projectStatus;
    private LocalDateTime createdAt;

    public ProjectTeamDto() {
    }

    public ProjectTeamDto(
            Integer projectId,
            String projectName,
            String description,
            Integer teamLeaderId,
            Integer facultyId,
            Integer batchId,
            Integer year,
            LocalDate projectStartDate,
            LocalDate deadline,
            String projectStatus,
            LocalDateTime createdAt) {

        this.projectId = projectId;
        this.projectName = projectName;
        this.description = description;
        this.teamLeaderId = teamLeaderId;
        this.facultyId = facultyId;
        this.batchId = batchId;
        this.year = year;
        this.projectStartDate = projectStartDate;
        this.deadline = deadline;
        this.projectStatus = projectStatus;
        this.createdAt = createdAt;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTeamLeaderId() {
        return teamLeaderId;
    }

    public void setTeamLeaderId(Integer teamLeaderId) {
        this.teamLeaderId = teamLeaderId;
    }

    public Integer getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Integer facultyId) {
        this.facultyId = facultyId;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public LocalDate getProjectStartDate() {
        return projectStartDate;
    }

    public void setProjectStartDate(LocalDate projectStartDate) {
        this.projectStartDate = projectStartDate;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "ProjectTeamDto{" +
                "projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", description='" + description + '\'' +
                ", teamLeaderId=" + teamLeaderId +
                ", facultyId=" + facultyId +
                ", batchId=" + batchId +
                ", year=" + year +
                ", projectStartDate=" + projectStartDate +
                ", deadline=" + deadline +
                ", projectStatus='" + projectStatus + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
