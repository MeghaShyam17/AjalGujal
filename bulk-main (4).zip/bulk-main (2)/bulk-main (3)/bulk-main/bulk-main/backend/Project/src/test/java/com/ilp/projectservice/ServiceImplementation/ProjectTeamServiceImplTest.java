package com.ilp.projectservice.ServiceImplementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Exception.BadRequestException;
import com.ilp.projectservice.Exception.ResourceNotFoundException;
import com.ilp.projectservice.Repository.ProjectTeamRepository;
import com.ilp.projectservice.Repository.TeamMemberRepository;

@ExtendWith(MockitoExtension.class)
class ProjectTeamServiceImplTest {

    @Mock
    private ProjectTeamRepository projectTeamRepository;

    @Mock
    private TeamMemberRepository teamMemberRepository;

    @InjectMocks
    private ProjectTeamServiceImpl service;

    @Test
    void shouldCreateProjectSuccessfully() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectName("Project A");
        project.setDeadline(LocalDate.now().plusDays(10));

        when(projectTeamRepository.save(any(ProjectTeam.class)))
                .thenReturn(project);

        ProjectTeam result = service.createProject(project);

        assertNotNull(result);
        assertEquals("Project A", result.getProjectName());
    }

    @Test
    void shouldDefaultStatusToPending() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectName("Project A");
        project.setDeadline(LocalDate.now().plusDays(5));

        when(projectTeamRepository.save(any(ProjectTeam.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ProjectTeam result = service.createProject(project);

        assertEquals("Pending", result.getProjectStatus());
    }

    @Test
    void shouldThrowExceptionWhenProjectNameMissing() {

        ProjectTeam project = new ProjectTeam();
        project.setDeadline(LocalDate.now().plusDays(5));

        assertThrows(
                BadRequestException.class,
                () -> service.createProject(project));
    }

    @Test
    void shouldThrowExceptionWhenDeadlineMissing() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectName("Project");

        assertThrows(
                BadRequestException.class,
                () -> service.createProject(project));
    }

    @Test
    void shouldThrowExceptionWhenDeadlineInPast() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectName("Project");
        project.setDeadline(LocalDate.now().minusDays(1));

        assertThrows(
                BadRequestException.class,
                () -> service.createProject(project));
    }

    @Test
    void shouldReturnAllProjects() {

        when(projectTeamRepository.findByIsDeletedFalse())
                .thenReturn(List.of(new ProjectTeam()));

        List<ProjectTeam> result =
                service.getAllProjects();

        assertEquals(1, result.size());
    }

    @Test
    void shouldReturnEmptyProjectList() {

        when(projectTeamRepository.findByIsDeletedFalse())
                .thenReturn(Collections.emptyList());

        assertTrue(service.getAllProjects().isEmpty());
    }

    @Test
    void shouldReturnProjectById() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectId(1);

        when(projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(project));

        ProjectTeam result =
                service.getProjectById(1);

        assertEquals(1, result.getProjectId());
    }

    @Test
    void shouldThrowExceptionWhenProjectNotFound() {

        when(projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(1))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getProjectById(1));
    }

    @Test
    void shouldUpdateProjectSuccessfully() {

        ProjectTeam existing = new ProjectTeam();
        existing.setProjectId(1);
        existing.setProjectName("Old");
        existing.setDeadline(LocalDate.now().plusDays(5));
        existing.setProjectStatus("Pending");

        ProjectTeam update = new ProjectTeam();
        update.setProjectName("New");
        update.setDeadline(LocalDate.now().plusDays(20));
        update.setProjectStatus("Ongoing");

        when(projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(existing));

        when(projectTeamRepository.save(any(ProjectTeam.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ProjectTeam result =
                service.updateProject(1, update);

        assertEquals("New", result.getProjectName());
        assertEquals("Ongoing", result.getProjectStatus());
    }

    @Test
    void shouldUpdateProjectStatusSuccessfully() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectStatus("Pending");

        when(projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(project));

        when(projectTeamRepository.save(any(ProjectTeam.class)))
                .thenReturn(project);

        service.updateProjectStatus(1, "Completed");

        assertEquals(
                "Completed",
                project.getProjectStatus());
    }

    @Test
    void shouldThrowExceptionForInvalidProjectStatus() {

        ProjectTeam project = new ProjectTeam();

        when(projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(project));

        assertThrows(
                BadRequestException.class,
                () -> service.updateProjectStatus(1, "ABC"));
    }

    @Test
    void shouldSoftDeleteProject() {

        ProjectTeam project = new ProjectTeam();
        project.setProjectId(1);
        project.setIsDeleted(false);

        when(projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(1))
                .thenReturn(Optional.of(project));

        service.deleteProject(1);

        assertTrue(project.getIsDeleted());

        verify(projectTeamRepository)
                .save(project);
    }

    @Test
    void shouldSearchByProjectName() {

        when(projectTeamRepository
                .findByProjectNameContainingIgnoreCaseAndIsDeletedFalse(
                        "AI"))
                .thenReturn(List.of(new ProjectTeam()));

        List<ProjectTeam> result =
                service.searchProjectsByName("AI");

        assertEquals(1, result.size());
    }

    @Test
    void shouldReturnAllProjectsWhenSearchBlank() {

        when(projectTeamRepository.findByIsDeletedFalse())
                .thenReturn(List.of(new ProjectTeam()));

        List<ProjectTeam> result =
                service.searchProjectsByName("");

        assertEquals(1, result.size());
    }

    @Test
    void shouldGetProjectsByStatus() {

        when(projectTeamRepository
                .findByProjectStatusAndIsDeletedFalse(
                        "Pending"))
                .thenReturn(List.of(new ProjectTeam()));

        List<ProjectTeam> result =
                service.getProjectsByStatus("Pending");

        assertEquals(1, result.size());
    }
}