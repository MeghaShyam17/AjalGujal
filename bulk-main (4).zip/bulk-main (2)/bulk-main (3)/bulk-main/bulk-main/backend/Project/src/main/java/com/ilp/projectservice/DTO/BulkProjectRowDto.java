package com.ilp.projectservice.DTO;

import java.time.LocalDate;

/**
 * Represents one row in the Teams Excel sheet.
 * projectKey is used only to group Excel rows and is not stored in the database.
 */
public record BulkProjectRowDto(
        int rowNumber,
        String projectKey,
        String projectName,
        String description,
        Integer year,
        Integer batchId,
        Integer teamLeaderId,
        Integer facultyId,
        LocalDate deadline,
        String projectStatus,
        Integer traineeId,
        String memberRole
) {
}
