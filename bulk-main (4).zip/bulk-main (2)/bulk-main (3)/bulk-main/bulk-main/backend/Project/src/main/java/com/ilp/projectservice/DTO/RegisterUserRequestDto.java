package com.ilp.projectservice.DTO;

public class RegisterUserRequestDto {
    private Integer userId;
    private java.time.LocalDate dob;
    private String name;
    private String email;
    private String phone;
    private String gender;
    private Integer year;
    private Integer batchId;
    private String password;

    public RegisterUserRequestDto() {}

    public RegisterUserRequestDto(Integer userId, java.time.LocalDate dob, String name, String email, String phone, String gender, Integer year, Integer batchId, String password) {
        this.userId = userId;
        this.dob = dob;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.year = year;
        this.batchId = batchId;
        this.password = password;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public java.time.LocalDate getDob() {
        return dob;
    }

    public void setDob(java.time.LocalDate dob) {
        this.dob = dob;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
