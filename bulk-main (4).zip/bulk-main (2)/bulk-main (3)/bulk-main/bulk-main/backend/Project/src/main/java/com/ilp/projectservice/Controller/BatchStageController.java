package com.ilp.projectservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BatchStageBulkUploadResult;
import com.ilp.projectservice.DTO.BatchStageRequest;
import com.ilp.projectservice.Entity.BatchStageEntity;
import com.ilp.projectservice.Service.BatchStageService;

@CrossOrigin(origins = {
    "http://localhost:4200",
    "http://127.0.0.1:4200"
})
@RestController
@RequestMapping("/batch-stages")
public class BatchStageController {

    @Autowired
    private BatchStageService batchStageService;

    @PostMapping
    public ResponseEntity<BatchStageEntity> createBatchStage(
            @RequestBody BatchStageRequest request) {

        BatchStageEntity created =
            batchStageService.createBatchStage(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PostMapping(
        value = "/upload",
        consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<BatchStageBulkUploadResult> uploadBatchStages(
            @RequestParam Integer batchId,
            @RequestParam("file") MultipartFile file) {

        BatchStageBulkUploadResult result =
            batchStageService.uploadBatchStages(batchId, file);

        return result.isSuccess()
            ? ResponseEntity.ok(result)
            : ResponseEntity.badRequest().body(result);
    }

    @GetMapping
    public ResponseEntity<List<BatchStageEntity>> getAllBatchStages() {
        return ResponseEntity.ok(batchStageService.getAllBatchStages());
    }

    @GetMapping("/batch/{batchId}")
    public ResponseEntity<List<BatchStageEntity>> getStagesByBatchId(
            @PathVariable Integer batchId) {

        return ResponseEntity.ok(
            batchStageService.getStagesByBatchId(batchId)
        );
    }

    @GetMapping("/{batchStageId}")
    public ResponseEntity<BatchStageEntity> getBatchStageById(
            @PathVariable Long batchStageId) {

        return ResponseEntity.ok(
            batchStageService.getBatchStageById(batchStageId)
        );
    }

    @PutMapping("/{batchStageId}")
    public ResponseEntity<BatchStageEntity> updateBatchStage(
            @PathVariable Long batchStageId,
            @RequestBody BatchStageRequest request) {

        return ResponseEntity.ok(
            batchStageService.updateBatchStage(batchStageId, request)
        );
    }

    @DeleteMapping("/{batchStageId}")
    public ResponseEntity<String> deleteBatchStage(
            @PathVariable Long batchStageId) {

        batchStageService.deleteBatchStage(batchStageId);
        return ResponseEntity.ok("Batch stage deleted successfully");
    }
}
