package com.ilp.projectservice.DTO;

import java.time.LocalDate;

public class BatchStageRequest {

    private Integer batchId;
    private Long stageId;
    private Integer stageNo;
    private LocalDate stageDeadline;

    public BatchStageRequest() {
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public Integer getStageNo() {
        return stageNo;
    }

    public void setStageNo(Integer stageNo) {
        this.stageNo = stageNo;
    }

    public LocalDate getStageDeadline() {
        return stageDeadline;
    }

    public void setStageDeadline(LocalDate stageDeadline) {
        this.stageDeadline = stageDeadline;
    }
}
