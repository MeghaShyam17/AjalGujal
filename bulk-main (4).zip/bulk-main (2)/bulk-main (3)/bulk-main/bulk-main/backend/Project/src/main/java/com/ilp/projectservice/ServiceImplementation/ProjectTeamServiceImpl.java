package com.ilp.projectservice.ServiceImplementation;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.Client.UserClient;
import com.ilp.projectservice.DTO.BatchDto;
import com.ilp.projectservice.DTO.BulkUploadError;
import com.ilp.projectservice.DTO.BulkUploadResult;
import com.ilp.projectservice.DTO.RegisterUserRequestDto;
import com.ilp.projectservice.DTO.UserResponseDto;
import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Entity.Project_Stage_Entity;
import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Entity.TeamMember;
import com.ilp.projectservice.Exception.BadRequestException;
import com.ilp.projectservice.Exception.BulkUploadException;
import com.ilp.projectservice.Exception.BusinessException;
import com.ilp.projectservice.Exception.ResourceNotFoundException;
import com.ilp.projectservice.Repository.ProjectTeamRepository;
import com.ilp.projectservice.Repository.Project_Stage_Repository;
import com.ilp.projectservice.Repository.Stage_Master_Repository;
import com.ilp.projectservice.Repository.TeamMemberRepository;
import com.ilp.projectservice.Service.ProjectTeamService;

@Service
@Transactional
public class ProjectTeamServiceImpl implements ProjectTeamService {

    private static final String PROJECTS_SHEET = "Teams";
    private static final int MAX_MEMBERS_PER_PROJECT = 15;

    private static final Set<String> VALID_STATUSES =
            Set.of("Pending", "Ongoing", "Completed");

    private static final Set<String> VALID_MEMBER_ROLES =
            Set.of("Member");

    private static final String[] REQUIRED_EXCEL_HEADERS = {
            "Project Key",
            "Project Name",
            "Year",
            "Batch Name",
            "Leader ID",
            "Leader Name",
            "Leader Email",
            "Leader Phone",
            "Leader Gender",
            "Leader DOB",
            "Leader Password",
            "Faculty Email",
            "Project Deadline",
            "Trainee ID",
            "Trainee Name",
            "Trainee Email",
            "Trainee Phone",
            "Trainee Gender",
            "Trainee DOB",
            "Trainee Password",
            "Member Role"
    };

    private final ProjectTeamRepository projectTeamRepository;
    private final TeamMemberRepository teamMemberRepository;
    private final UserClient userClient;
    private final Stage_Master_Repository stageMasterRepository;
    private final Project_Stage_Repository projectStageRepository;

    private final DataFormatter formatter =
            new DataFormatter(Locale.ENGLISH);

    public ProjectTeamServiceImpl(
            ProjectTeamRepository projectTeamRepository,
            TeamMemberRepository teamMemberRepository,
            UserClient userClient,
            Stage_Master_Repository stageMasterRepository,
            Project_Stage_Repository projectStageRepository) {

        this.projectTeamRepository = projectTeamRepository;
        this.teamMemberRepository = teamMemberRepository;
        this.userClient = userClient;
        this.stageMasterRepository = stageMasterRepository;
        this.projectStageRepository = projectStageRepository;
    }

    /*
     * ============================================================
     * NORMAL PROJECT CRUD OPERATIONS
     * ============================================================
     */

    @Override
    public ProjectTeam createProject(ProjectTeam projectTeam) {

        validateProject(projectTeam);

        projectTeam.setProjectId(null);

        String status = projectTeam.getProjectStatus();

        projectTeam.setProjectStatus(
                isBlank(status)
                        ? "Pending"
                        : normalizeRequiredStatus(status));

        ProjectTeam savedProject =
                projectTeamRepository.save(projectTeam);

        List<TeamMember> members =
                projectTeam.getTeamMembers();

        if (members == null || members.isEmpty()) {
            return savedProject;
        }

        if (members.size() > MAX_MEMBERS_PER_PROJECT) {
            throw new BadRequestException(
                    "Maximum 15 team members are allowed");
        }

        Set<Integer> traineeIds =
                new HashSet<>();

        for (TeamMember member : members) {

            if (member.getTraineeId() == null) {
                throw new BadRequestException(
                        "Trainee ID is required");
            }

            if (!traineeIds.add(member.getTraineeId())) {
                throw new BadRequestException(
                        "Duplicate trainee ID: "
                                + member.getTraineeId());
            }

            checkTraineeAvailability(
                    member.getTraineeId(),
                    null);

            member.setTeamMemberId(null);
            member.setProjectId(
                    savedProject.getProjectId());

            member.setMemberRole(
                    isBlank(member.getMemberRole())
                            ? "Member"
                            : member.getMemberRole().trim());

            member.setIsDeleted(false);

            teamMemberRepository.save(member);
        }

        savedProject.setTeamMembers(members);

        return savedProject;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getAllProjects() {
        return projectTeamRepository.findByIsDeletedFalse();
    }

    @Override
    @Transactional(readOnly = true)
    public ProjectTeam getProjectById(Integer projectId) {
        return findProjectById(projectId);
    }

    @Override
    public ProjectTeam updateProject(
            Integer projectId,
            ProjectTeam projectTeam) {

        validateProject(projectTeam);

        ProjectTeam existingProject =
                findProjectById(projectId);

        String status =
                projectTeam.getProjectStatus();

        if (isBlank(status)) {
            status = existingProject.getProjectStatus();
        }

        existingProject.setProjectName(
                projectTeam.getProjectName().trim());

        existingProject.setDescription(
                projectTeam.getDescription());

        existingProject.setTeamLeaderId(
                projectTeam.getTeamLeaderId());

        existingProject.setFacultyId(
                projectTeam.getFacultyId());

        existingProject.setBatchId(
                projectTeam.getBatchId());

        existingProject.setYear(
                projectTeam.getYear());

        existingProject.setDeadline(
                projectTeam.getDeadline());

        existingProject.setProjectStatus(
                normalizeRequiredStatus(status));

        return projectTeamRepository.save(existingProject);
    }

    @Override
    public ProjectTeam updateProjectStatus(
            Integer projectId,
            String projectStatus) {

        ProjectTeam existingProject =
                findProjectById(projectId);

        existingProject.setProjectStatus(
                normalizeRequiredStatus(projectStatus));

        return projectTeamRepository.save(existingProject);
    }

    @Override
    public void deleteProject(Integer projectId) {

        ProjectTeam project =
                findProjectById(projectId);

        project.setIsDeleted(true);

        projectTeamRepository.save(project);
    }

    @Override
    public void hardDeleteProject(Integer projectId) {

        if (projectId == null) {
            throw new BadRequestException(
                    "Project ID is required");
        }

        ProjectTeam project =
                projectTeamRepository
                        .findById(projectId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Project",
                                        projectId));

        projectTeamRepository.delete(project);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByStatus(
            String projectStatus) {

        return projectTeamRepository
                .findByProjectStatusAndIsDeletedFalse(
                        normalizeRequiredStatus(projectStatus));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByTeamLeader(
            Integer teamLeaderId) {

        if (teamLeaderId == null) {
            throw new BadRequestException(
                    "Team Leader ID is required");
        }

        return projectTeamRepository
                .findByTeamLeaderIdAndIsDeletedFalse(
                        teamLeaderId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByFaculty(
            Integer facultyId) {

        if (facultyId == null) {
            throw new BadRequestException(
                    "Faculty ID is required");
        }

        return projectTeamRepository
                .findByFacultyIdAndIsDeletedFalse(
                        facultyId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByBatch(
            Integer batchId) {

        if (batchId == null) {
            throw new BadRequestException(
                    "Batch ID is required");
        }

        return projectTeamRepository
                .findByBatchIdAndIsDeletedFalse(
                        batchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByYear(
            Integer year) {

        if (year == null) {
            throw new BadRequestException(
                    "Year is required");
        }

        return projectTeamRepository
                .findByYearAndIsDeletedFalse(year);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> searchProjectsByName(
            String projectName) {

        if (isBlank(projectName)) {
            return projectTeamRepository
                    .findByIsDeletedFalse();
        }

        return projectTeamRepository
                .findByProjectNameContainingIgnoreCaseAndIsDeletedFalse(
                        projectName.trim());
    }

    /*
     * ============================================================
     * EXCEL SUPPORT CLASSES
     * ============================================================
     */

    private static class RowData {

        int excelRowNumber;

        String projectKey;
        String projectName;
        String description;
        Integer year;

        String batchName;
        LocalDate batchStartDate;
        LocalDate batchEndDate;

        /*
         * Leader details exist once in the project metadata row.
         */
        Integer leaderId;
        String leaderName;
        String leaderEmail;
        String leaderPhone;
        String leaderGender;
        LocalDate leaderDob;
        String leaderPassword;

        String facultyEmail;
        LocalDate projectDeadline;

        /*
         * Remaining member details.
         */
        Integer traineeId;
        String traineeName;
        String traineeEmail;
        String traineePhone;
        String traineeGender;
        LocalDate traineeDob;
        String traineePassword;
        String memberRole;

        Map<Integer, StageData> stages =
                new LinkedHashMap<>();
    }

    private static class StageData {
        String name;
        String description;
        LocalDate batchDeadline;
        LocalDate projectDeadline;
    }

    /*
     * ============================================================
     * BULK EXCEL UPLOAD
     * ============================================================
     */

    @Override
    @Transactional(rollbackFor = Exception.class)
    public BulkUploadResult uploadProjectTeamsAndMembers(
            MultipartFile file) {

        validateExcelFile(file);

        List<RowData> parsedRows =
                new ArrayList<>();

        List<BulkUploadError> errors =
                new ArrayList<>();

        /*
         * --------------------------------------------------------
         * 1. Read Excel
         * --------------------------------------------------------
         */
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook =
                     WorkbookFactory.create(inputStream)) {

            if (workbook.getNumberOfSheets() == 0) {
                throw new BadRequestException(
                        "The uploaded workbook does not contain any sheets");
            }

            Sheet sheet =
                    workbook.getSheetAt(0);

            Row headerRow =
                    sheet.getRow(0);

            if (headerRow == null) {
                throw new BadRequestException(
                        "Header row is missing in the Excel sheet");
            }

            Map<String, Integer> headerMap =
                    buildHeaderMap(headerRow);

            validateRequiredHeaders(headerMap);

            for (int rowIndex = 1;
                 rowIndex <= sheet.getLastRowNum();
                 rowIndex++) {

                Row row =
                        sheet.getRow(rowIndex);

                if (row == null) {
                    continue;
                }

                String projectKey =
                        getStringValue(
                                row,
                                headerMap,
                                "Project Key");

                String traineeEmail =
                        getStringValue(
                                row,
                                headerMap,
                                "Trainee Email");

                /*
                 * Skip completely empty rows.
                 */
                if (projectKey.isBlank()
                        && traineeEmail.isBlank()) {
                    continue;
                }

                RowData rowData =
                        parseExcelRow(
                                row,
                                rowIndex + 1,
                                headerMap);

                parsedRows.add(rowData);

                validateParsedRow(
                        rowData,
                        errors);
            }

        } catch (IOException exception) {
            throw new BadRequestException(
                    "Unable to read workbook",
                    exception);
        }

        if (parsedRows.isEmpty()) {
            errors.add(
                    new BulkUploadError(
                            PROJECTS_SHEET,
                            0,
                            "The workbook does not contain any team data"));
        }

        if (!errors.isEmpty()) {
            throw new BulkUploadException(
                    "Excel validation failed. "
                            + "No records were inserted.",
                    errors);
        }

        /*
         * --------------------------------------------------------
         * 2. Group rows by Project Key
         * --------------------------------------------------------
         */
        Map<String, List<RowData>> groupedProjects =
                new LinkedHashMap<>();

        for (RowData rowData : parsedRows) {

            groupedProjects
                    .computeIfAbsent(
                            rowData.projectKey,
                            ignored -> new ArrayList<>())
                    .add(rowData);
        }

        /*
         * --------------------------------------------------------
         * 3. Resolve and propagate project metadata
         * --------------------------------------------------------
         */
        for (Map.Entry<String, List<RowData>> entry
                : groupedProjects.entrySet()) {

            String projectKey =
                    entry.getKey();

            List<RowData> groupRows =
                    entry.getValue();

            RowData metadataRow =
                    groupRows.stream()
                            .filter(row ->
                                    !isBlank(row.projectName))
                            .findFirst()
                            .orElse(null);

            if (metadataRow == null) {
                errors.add(
                        new BulkUploadError(
                                PROJECTS_SHEET,
                                groupRows.get(0).excelRowNumber,
                                "Project metadata is missing for Project Key "
                                        + projectKey));
                continue;
            }

            /*
             * Leader is automatically inserted as Scrum.
             * Therefore, only 14 normal trainee rows are allowed.
             */
            if (groupRows.size()
                    > MAX_MEMBERS_PER_PROJECT - 1) {

                errors.add(
                        new BulkUploadError(
                                PROJECTS_SHEET,
                                metadataRow.excelRowNumber,
                                "Project Key "
                                        + projectKey
                                        + " can contain a maximum of 14 "
                                        + "trainee rows because the leader "
                                        + "is added automatically as Scrum"));
            }

            Set<Integer> traineeIds =
                    new HashSet<>();

            Set<String> traineeEmails =
                    new HashSet<>();

            for (RowData rowData : groupRows) {

                if (rowData.traineeId != null
                        && !traineeIds.add(
                                rowData.traineeId)) {

                    errors.add(
                            new BulkUploadError(
                                    PROJECTS_SHEET,
                                    rowData.excelRowNumber,
                                    "Duplicate Trainee ID "
                                            + rowData.traineeId
                                            + " for Project Key "
                                            + projectKey));
                }

                if (!isBlank(rowData.traineeEmail)) {

                    String normalizedEmail =
                            normalizeEmail(
                                    rowData.traineeEmail);

                    if (!traineeEmails.add(
                            normalizedEmail)) {

                        errors.add(
                                new BulkUploadError(
                                        PROJECTS_SHEET,
                                        rowData.excelRowNumber,
                                        "Duplicate Trainee Email "
                                                + rowData.traineeEmail
                                                + " for Project Key "
                                                + projectKey));
                    }
                }

                propagateProjectMetadata(
                        metadataRow,
                        rowData);
            }
        }

        if (!errors.isEmpty()) {
            throw new BulkUploadException(
                    "Excel metadata validation failed. "
                            + "No records were inserted.",
                    errors);
        }

        /*
         * --------------------------------------------------------
         * 4. Resolve existing batches
         * --------------------------------------------------------
         */
        Map<String, Integer> batchNameToIdMap =
                new HashMap<>();

        List<BatchDto> existingBatches =
                userClient.getBatches();

        if (existingBatches != null) {

            for (BatchDto batch : existingBatches) {

                if (batch.getBatchName() != null
                        && batch.getBatchId() != null) {

                    batchNameToIdMap.put(
                            batch.getBatchName()
                                    .trim()
                                    .toLowerCase(Locale.ENGLISH),
                            batch.getBatchId());
                }
            }
        }

        Map<String, Integer> generatedProjectIds =
                new LinkedHashMap<>();

        int projectsInserted = 0;
        int membersInserted = 0;

        /*
         * --------------------------------------------------------
         * 5. Process each project
         * --------------------------------------------------------
         */
        for (Map.Entry<String, List<RowData>> entry
                : groupedProjects.entrySet()) {

            String projectKey =
                    entry.getKey();

            List<RowData> projectRows =
                    entry.getValue();

            RowData firstRow =
                    projectRows.get(0);

            /*
             * 5.1 Resolve or create batch
             */
            Integer batchId =
                    resolveOrCreateBatch(
                            firstRow,
                            batchNameToIdMap);

            /*
             * 5.2 Resolve or create stage masters
             */
            createOrUpdateStageMasters(
                    batchId,
                    firstRow.stages);

            /*
             * 5.3 Resolve faculty
             */
            UserResponseDto faculty =
                    findUserByEmailSafely(
                            firstRow.facultyEmail);

            if (faculty == null
                    || faculty.getUserId() == null) {

                throw new BadRequestException(
                        "Faculty guide with email '"
                                + firstRow.facultyEmail
                                + "' was not found in User Service");
            }

            /*
             * 5.4 Resolve or create leader
             */
            UserResponseDto leader =
                    resolveOrCreateLeader(
                            firstRow,
                            batchId,
                            projectKey);

            Integer leaderUserId =
                    leader.getUserId().intValue();

            checkTraineeAvailability(
                    leaderUserId,
                    null);

            /*
             * Leader must not be repeated as a trainee.
             */
            validateLeaderNotRepeated(
                    projectRows,
                    firstRow,
                    leaderUserId);

            /*
             * 5.5 Create the project.
             */
            ProjectTeam project =
                    new ProjectTeam();

            project.setProjectId(null);
            project.setProjectName(
                    firstRow.projectName.trim());

            project.setDescription(
                    firstRow.description);

            project.setYear(
                    firstRow.year);

            project.setBatchId(
                    batchId);

            project.setTeamLeaderId(
                    leaderUserId);

            project.setFacultyId(
                    faculty.getUserId().intValue());

            project.setDeadline(
                    firstRow.projectDeadline);

            project.setProjectStartDate(
                    LocalDate.now());

            project.setProjectStatus(
                    "Ongoing");

            project.setIsDeleted(false);

            project =
                    projectTeamRepository.save(project);

            Integer generatedProjectId =
                    project.getProjectId();

            /*
             * 5.6 Automatically add leader as Scrum.
             */
            TeamMember scrumLeader =
                    new TeamMember();

            scrumLeader.setTeamMemberId(null);
            scrumLeader.setProjectId(
                    generatedProjectId);

            scrumLeader.setTraineeId(
                    leaderUserId);

            scrumLeader.setMemberRole(
                    "Scrum");

            scrumLeader.setIsDeleted(false);

            teamMemberRepository.save(
                    scrumLeader);

            membersInserted++;

            /*
             * 5.7 Resolve/create the remaining trainees.
             */
            for (RowData memberRow : projectRows) {

                UserResponseDto trainee =
                        resolveOrCreateTrainee(
                                memberRow,
                                batchId);

                Integer traineeUserId =
                        trainee.getUserId().intValue();

                if (!memberRow.traineeId.equals(
                        traineeUserId)) {

                    throw new BadRequestException(
                            "Excel row "
                                    + memberRow.excelRowNumber
                                    + ": Trainee ID "
                                    + memberRow.traineeId
                                    + " does not match User Service ID "
                                    + traineeUserId
                                    + " for email "
                                    + memberRow.traineeEmail);
                }

                checkTraineeAvailability(
                        traineeUserId,
                        null);

                boolean alreadyAdded =
                        teamMemberRepository
                                .existsByProjectIdAndTraineeIdAndIsDeletedFalse(
                                        generatedProjectId,
                                        traineeUserId);

                if (alreadyAdded) {
                    throw new BadRequestException(
                            "Trainee "
                                    + traineeUserId
                                    + " is already added to Project Key "
                                    + projectKey);
                }

                TeamMember member =
                        new TeamMember();

                member.setTeamMemberId(null);
                member.setProjectId(
                        generatedProjectId);

                member.setTraineeId(
                        traineeUserId);

                member.setMemberRole(
                        "Member");

                member.setIsDeleted(false);

                teamMemberRepository.save(member);

                membersInserted++;
            }

            /*
             * 5.8 Create project stage timelines.
             */
            createProjectStages(
                    generatedProjectId,
                    batchId,
                    firstRow);

            generatedProjectIds.put(
                    projectKey,
                    generatedProjectId);

            projectsInserted++;
        }

        /*
         * Force database errors before exiting the transaction.
         */
        projectTeamRepository.flush();
        teamMemberRepository.flush();
        projectStageRepository.flush();

        return new BulkUploadResult(
                true,
                projectsInserted,
                membersInserted,
                projectsInserted
                        + " projects and "
                        + membersInserted
                        + " team members uploaded successfully",
                Map.copyOf(generatedProjectIds));
    }

    /*
     * ============================================================
     * EXCEL PARSING METHODS
     * ============================================================
     */

    private Map<String, Integer> buildHeaderMap(
            Row headerRow) {

        Map<String, Integer> headerMap =
                new HashMap<>();

        for (int index = 0;
             index < headerRow.getLastCellNum();
             index++) {

            String header =
                    text(headerRow.getCell(index));

            if (!header.isBlank()) {
                headerMap.put(
                        header.toLowerCase(Locale.ENGLISH).trim(),
                        index);
            }
        }

        return headerMap;
    }

    private void validateRequiredHeaders(
            Map<String, Integer> headerMap) {

        for (String requiredHeader
                : REQUIRED_EXCEL_HEADERS) {

            String normalizedHeader =
                    requiredHeader
                            .toLowerCase(Locale.ENGLISH)
                            .trim();

            if (!headerMap.containsKey(
                    normalizedHeader)) {

                throw new BadRequestException(
                        "Required Excel column is missing: "
                                + requiredHeader);
            }
        }
    }

    private RowData parseExcelRow(
            Row row,
            int excelRowNumber,
            Map<String, Integer> headerMap) {

        RowData rowData =
                new RowData();

        rowData.excelRowNumber =
                excelRowNumber;

        rowData.projectKey =
                getStringValue(
                        row,
                        headerMap,
                        "Project Key").trim();

        rowData.projectName =
                getStringValue(
                        row,
                        headerMap,
                        "Project Name");

        rowData.description =
                getNullableStringValue(
                        row,
                        headerMap,
                        "Description");

        rowData.year =
                getIntValue(
                        row,
                        headerMap,
                        "Year");

        rowData.batchName =
                getStringValue(
                        row,
                        headerMap,
                        "Batch Name");

        rowData.batchStartDate =
                getDateValue(
                        row,
                        headerMap,
                        "Batch Start Date");

        rowData.batchEndDate =
                getDateValue(
                        row,
                        headerMap,
                        "Batch End Date");

        /*
         * Leader fields.
         */
        rowData.leaderId =
                getIntValue(
                        row,
                        headerMap,
                        "Leader ID");

        rowData.leaderName =
                getStringValue(
                        row,
                        headerMap,
                        "Leader Name");

        rowData.leaderEmail =
                normalizeEmail(
                        getStringValue(
                                row,
                                headerMap,
                                "Leader Email"));

        rowData.leaderPhone =
                getNullableStringValue(
                        row,
                        headerMap,
                        "Leader Phone");

        rowData.leaderGender =
                getStringValue(
                        row,
                        headerMap,
                        "Leader Gender");

        rowData.leaderDob =
                getDateValue(
                        row,
                        headerMap,
                        "Leader DOB");

        rowData.leaderPassword =
                getStringValue(
                        row,
                        headerMap,
                        "Leader Password");

        /*
         * Faculty and project deadline.
         */
        rowData.facultyEmail =
                normalizeEmail(
                        getStringValue(
                                row,
                                headerMap,
                                "Faculty Email"));

        rowData.projectDeadline =
                getDateValue(
                        row,
                        headerMap,
                        "Project Deadline");

        /*
         * Normal trainee fields.
         */
        rowData.traineeId =
                getIntValue(
                        row,
                        headerMap,
                        "Trainee ID");

        rowData.traineeName =
                getStringValue(
                        row,
                        headerMap,
                        "Trainee Name");

        rowData.traineeEmail =
                normalizeEmail(
                        getStringValue(
                                row,
                                headerMap,
                                "Trainee Email"));

        rowData.traineePhone =
                getNullableStringValue(
                        row,
                        headerMap,
                        "Trainee Phone");

        rowData.traineeGender =
                getStringValue(
                        row,
                        headerMap,
                        "Trainee Gender");

        rowData.traineeDob =
                getDateValue(
                        row,
                        headerMap,
                        "Trainee DOB");

        rowData.traineePassword =
                getStringValue(
                        row,
                        headerMap,
                        "Trainee Password");

        rowData.memberRole =
                getStringValue(
                        row,
                        headerMap,
                        "Member Role");

        /*
         * Read up to 15 stages.
         */
        for (int stageNumber = 1;
             stageNumber <= 15;
             stageNumber++) {

            String stageName =
                    getStringValue(
                            row,
                            headerMap,
                            "Stage "
                                    + stageNumber
                                    + " Name");

            if (stageName.isBlank()) {
                break;
            }

            StageData stageData =
                    new StageData();

            stageData.name =
                    stageName.trim();

            stageData.description =
                    getNullableStringValue(
                            row,
                            headerMap,
                            "Stage "
                                    + stageNumber
                                    + " Description");

            stageData.projectDeadline =
                    getDateValue(
                            row,
                            headerMap,
                            "Stage "
                                    + stageNumber
                                    + " Deadline");

            if (stageData.projectDeadline == null) {
                stageData.projectDeadline =
                        getDateValue(
                                row,
                                headerMap,
                                "Stage "
                                        + stageNumber
                                        + " Project Deadline");
            }

            stageData.batchDeadline =
                    getDateValue(
                            row,
                            headerMap,
                            "Stage "
                                    + stageNumber
                                    + " Batch Deadline");

            rowData.stages.put(
                    stageNumber,
                    stageData);
        }

        return rowData;
    }

    private void validateParsedRow(
            RowData rowData,
            List<BulkUploadError> errors) {

        int rowNumber =
                rowData.excelRowNumber;

        if (isBlank(rowData.projectKey)) {
            addError(
                    errors,
                    rowNumber,
                    "Project Key is required");
        }

        /*
         * Every Excel data row represents one normal member.
         */
        if (rowData.traineeId == null
                || rowData.traineeId <= 0) {

            addError(
                    errors,
                    rowNumber,
                    "Trainee ID is required and must be a positive integer");
        }

        if (isBlank(rowData.traineeName)) {
            addError(
                    errors,
                    rowNumber,
                    "Trainee Name is required");
        }

        if (isBlank(rowData.traineeEmail)) {
            addError(
                    errors,
                    rowNumber,
                    "Trainee Email is required");
        }

        if (isBlank(rowData.traineePhone)) {
            addError(
                    errors,
                    rowNumber,
                    "Trainee Phone is required");
        }

        if (isBlank(rowData.traineeGender)) {
            addError(
                    errors,
                    rowNumber,
                    "Trainee Gender is required");
        }

        if (rowData.traineeDob == null) {
            addError(
                    errors,
                    rowNumber,
                    "Trainee DOB is required and must use yyyy-MM-dd");
        }

        if (isBlank(rowData.traineePassword)) {
            addError(
                    errors,
                    rowNumber,
                    "Trainee Password is required");
        }

        if (!isBlank(rowData.memberRole)
                && normalizeValue(
                        rowData.memberRole,
                        VALID_MEMBER_ROLES) == null) {

            addError(
                    errors,
                    rowNumber,
                    "Member Role must be Member. "
                            + "The project leader is automatically assigned Scrum");
        }

        /*
         * Validate project-level metadata only when Project Name
         * exists on this row.
         */
        if (isBlank(rowData.projectName)) {
            return;
        }

        if (rowData.projectName.trim().length() > 200) {
            addError(
                    errors,
                    rowNumber,
                    "Project Name cannot exceed 200 characters");
        }

        if (rowData.year == null
                || rowData.year < 2000
                || rowData.year > 2100) {

            addError(
                    errors,
                    rowNumber,
                    "Year must be a valid four-digit year");
        }

        if (isBlank(rowData.batchName)) {
            addError(
                    errors,
                    rowNumber,
                    "Batch Name is required");
        }

        if (rowData.leaderId == null
                || rowData.leaderId <= 0) {

            addError(
                    errors,
                    rowNumber,
                    "Leader ID is required and must be a positive integer");
        }

        if (isBlank(rowData.leaderName)) {
            addError(
                    errors,
                    rowNumber,
                    "Leader Name is required");
        }

        if (isBlank(rowData.leaderEmail)) {
            addError(
                    errors,
                    rowNumber,
                    "Leader Email is required");
        }

        if (isBlank(rowData.leaderPhone)) {
            addError(
                    errors,
                    rowNumber,
                    "Leader Phone is required");
        }

        if (isBlank(rowData.leaderGender)) {
            addError(
                    errors,
                    rowNumber,
                    "Leader Gender is required");
        }

        if (rowData.leaderDob == null) {
            addError(
                    errors,
                    rowNumber,
                    "Leader DOB is required and must use yyyy-MM-dd");
        }

        if (isBlank(rowData.leaderPassword)) {
            addError(
                    errors,
                    rowNumber,
                    "Leader Password is required");
        }

        if (isBlank(rowData.facultyEmail)) {
            addError(
                    errors,
                    rowNumber,
                    "Faculty Email is required");
        }

        if (rowData.projectDeadline == null) {
            addError(
                    errors,
                    rowNumber,
                    "Project Deadline is required");
        } else if (!rowData.projectDeadline
                .isAfter(LocalDate.now())) {

            addError(
                    errors,
                    rowNumber,
                    "Project Deadline must be greater than current date");
        }
    }

    private void propagateProjectMetadata(
            RowData metadataRow,
            RowData targetRow) {

        targetRow.projectName =
                metadataRow.projectName;

        targetRow.description =
                metadataRow.description;

        targetRow.year =
                metadataRow.year;

        targetRow.batchName =
                metadataRow.batchName;

        targetRow.batchStartDate =
                metadataRow.batchStartDate;

        targetRow.batchEndDate =
                metadataRow.batchEndDate;

        targetRow.leaderId =
                metadataRow.leaderId;

        targetRow.leaderName =
                metadataRow.leaderName;

        targetRow.leaderEmail =
                metadataRow.leaderEmail;

        targetRow.leaderPhone =
                metadataRow.leaderPhone;

        targetRow.leaderGender =
                metadataRow.leaderGender;

        targetRow.leaderDob =
                metadataRow.leaderDob;

        targetRow.leaderPassword =
                metadataRow.leaderPassword;

        targetRow.facultyEmail =
                metadataRow.facultyEmail;

        targetRow.projectDeadline =
                metadataRow.projectDeadline;

        targetRow.stages =
                metadataRow.stages;
    }

    /*
     * ============================================================
     * USER AND BATCH RESOLUTION
     * ============================================================
     */

    private Integer resolveOrCreateBatch(
            RowData firstRow,
            Map<String, Integer> batchNameToIdMap) {

        String normalizedBatchName =
                firstRow.batchName
                        .trim()
                        .toLowerCase(Locale.ENGLISH);

        Integer batchId =
                batchNameToIdMap.get(
                        normalizedBatchName);

        if (batchId != null) {
            return batchId;
        }

        BatchDto newBatch =
                new BatchDto();

        newBatch.setBatchName(
                firstRow.batchName.trim());

        newBatch.setYear(
                firstRow.year);

        newBatch.setStartDate(
                firstRow.batchStartDate != null
                        ? firstRow.batchStartDate
                        : LocalDate.of(
                                firstRow.year,
                                8,
                                1));

        newBatch.setEndDate(
                firstRow.batchEndDate != null
                        ? firstRow.batchEndDate
                        : LocalDate.of(
                                firstRow.year,
                                12,
                                20));

        BatchDto createdBatch =
                userClient.createBatch(newBatch);

        if (createdBatch == null
                || createdBatch.getBatchId() == null) {

            throw new BadRequestException(
                    "Unable to create batch '"
                            + firstRow.batchName
                            + "'");
        }

        batchId =
                createdBatch.getBatchId();

        batchNameToIdMap.put(
                normalizedBatchName,
                batchId);

        return batchId;
    }

    private UserResponseDto resolveOrCreateLeader(
            RowData firstRow,
            Integer batchId,
            String projectKey) {

        String normalizedEmail =
                normalizeEmail(firstRow.leaderEmail);

        UserResponseDto leader =
                findUserByEmailSafely(
                        normalizedEmail);

        if (leader == null) {

            RegisterUserRequestDto request =
                    new RegisterUserRequestDto(
                            firstRow.leaderId,
                            firstRow.leaderDob,
                            firstRow.leaderName.trim(),
                            normalizedEmail,
                            firstRow.leaderPhone.trim(),
                            firstRow.leaderGender.trim(),
                            firstRow.year,
                            batchId,
                            isBlank(firstRow.leaderPassword)
                                    ? "Temp@123"
                                    : firstRow.leaderPassword.trim());

            try {
                leader =
                        userClient.autoRegisterUser(
                                request);
            } catch (Exception exception) {
                throw new BadRequestException(
                        "Unable to create leader '"
                                + normalizedEmail
                                + "' for Project Key "
                                + projectKey
                                + ". Reason: "
                                + extractExceptionMessage(exception),
                        exception);
            }
        }

        if (leader == null
                || leader.getUserId() == null) {

            throw new BadRequestException(
                    "Unable to resolve or create leader '"
                            + normalizedEmail
                            + "' for Project Key "
                            + projectKey);
        }

        Integer resolvedLeaderId =
                leader.getUserId().intValue();

        if (!firstRow.leaderId.equals(
                resolvedLeaderId)) {

            throw new BadRequestException(
                    "Leader ID "
                            + firstRow.leaderId
                            + " does not match User Service ID "
                            + resolvedLeaderId
                            + " for email "
                            + normalizedEmail);
        }

        return leader;
    }

    private UserResponseDto resolveOrCreateTrainee(
            RowData memberRow,
            Integer batchId) {

        String normalizedEmail =
                normalizeEmail(
                        memberRow.traineeEmail);

        UserResponseDto trainee =
                findUserByEmailSafely(
                        normalizedEmail);

        if (trainee == null) {

            RegisterUserRequestDto request =
                    new RegisterUserRequestDto(
                            memberRow.traineeId,
                            memberRow.traineeDob,
                            memberRow.traineeName.trim(),
                            normalizedEmail,
                            memberRow.traineePhone,
                            memberRow.traineeGender,
                            memberRow.year,
                            batchId,
                            isBlank(memberRow.traineePassword)
                                    ? "Temp@123"
                                    : memberRow.traineePassword.trim());

            try {
                trainee =
                        userClient.autoRegisterUser(
                                request);
            } catch (Exception exception) {
                throw new BadRequestException(
                        "Unable to create trainee '"
                                + normalizedEmail
                                + "' from Excel row "
                                + memberRow.excelRowNumber
                                + ". Reason: "
                                + extractExceptionMessage(exception),
                        exception);
            }
        }

        if (trainee == null
                || trainee.getUserId() == null) {

            throw new BadRequestException(
                    "Unable to resolve or create trainee '"
                            + normalizedEmail
                            + "' from Excel row "
                            + memberRow.excelRowNumber);
        }

        return trainee;
    }

    private UserResponseDto findUserByEmailSafely(
            String email) {

        if (isBlank(email)) {
            return null;
        }

        try {
            return userClient.getUserByEmail(
                    normalizeEmail(email));
        } catch (Exception exception) {
            return null;
        }
    }

    private void validateLeaderNotRepeated(
            List<RowData> projectRows,
            RowData firstRow,
            Integer leaderUserId) {

        String normalizedLeaderEmail =
                normalizeEmail(
                        firstRow.leaderEmail);

        for (RowData memberRow : projectRows) {

            boolean sameId =
                    memberRow.traineeId != null
                            && memberRow.traineeId.equals(
                                    leaderUserId);

            boolean sameEmail =
                    !isBlank(memberRow.traineeEmail)
                            && normalizeEmail(
                            memberRow.traineeEmail)
                            .equals(normalizedLeaderEmail);

            if (sameId || sameEmail) {
                throw new BadRequestException(
                        "Excel row "
                                + memberRow.excelRowNumber
                                + ": Leader must not be repeated in "
                                + "Trainee ID or Trainee Email. "
                                + "The leader is automatically added as Scrum");
            }
        }
    }

    /*
     * ============================================================
     * STAGE PROCESSING
     * ============================================================
     */

    private void createOrUpdateStageMasters(
            Integer batchId,
            Map<Integer, StageData> stages) {

        for (Map.Entry<Integer, StageData> entry
                : stages.entrySet()) {

            Integer stageNumber =
                    entry.getKey();

            StageData stageData =
                    entry.getValue();

            Optional<Stage_Master_Entity> existingOptional =
                    stageMasterRepository
                            .findByBatchIdAndStageNo(
                                    batchId,
                                    stageNumber);

            if (existingOptional.isPresent()) {

                Stage_Master_Entity existing =
                        existingOptional.get();

                existing.setStageName(
                        stageData.name);

                existing.setDescription(
                        stageData.description != null
                                ? stageData.description
                                : stageData.name);

                stageMasterRepository.save(existing);

            } else {

                Stage_Master_Entity newStage =
                        new Stage_Master_Entity();

                newStage.setBatchId(batchId);
                newStage.setStageNo(stageNumber);
                newStage.setStageName(stageData.name);

                newStage.setDescription(
                        stageData.description != null
                                ? stageData.description
                                : stageData.name);

                stageMasterRepository.save(newStage);
            }
        }

        stageMasterRepository.flush();
    }

    private void createProjectStages(
            Integer generatedProjectId,
            Integer batchId,
            RowData firstRow) {

        List<Stage_Master_Entity> stages =
                stageMasterRepository
                        .findByBatchIdOrderByStageNoAsc(
                                batchId);

        if (stages.isEmpty()) {
            stages =
                    stageMasterRepository
                            .findByBatchIdIsNullOrderByStageNoAsc();
        }

        for (Stage_Master_Entity stageMaster : stages) {

            Project_Stage_Entity projectStage =
                    new Project_Stage_Entity();

            projectStage.setProjectId(
                    generatedProjectId);

            projectStage.setStageMaster(
                    stageMaster);

            projectStage.setVersionNo(1);
            projectStage.setIsOverdue(false);
            projectStage.setIsAcknowledged(false);

            if (Integer.valueOf(1).equals(
                    stageMaster.getStageNo())) {

                projectStage.setSubmissionStatus(
                        "IN_PROGRESS");

                projectStage.setCurrentStage(true);

            } else {

                projectStage.setSubmissionStatus(
                        "NOT_STARTED");

                projectStage.setCurrentStage(false);
            }

            StageData stageData =
                    firstRow.stages.get(
                            stageMaster.getStageNo());

            if (stageData != null
                    && stageData.projectDeadline != null) {

                projectStage.setStageDeadline(
                        stageData.projectDeadline);

            } else if (stageData != null
                    && stageData.batchDeadline != null) {

                projectStage.setStageDeadline(
                        stageData.batchDeadline);

            } else {

                projectStage.setStageDeadline(
                        firstRow.projectDeadline);
            }

            projectStageRepository.save(
                    projectStage);
        }
    }

    /*
     * ============================================================
     * VALIDATION AND GENERAL HELPERS
     * ============================================================
     */

    private void checkTraineeAvailability(
            Integer traineeId,
            Integer targetProjectId) {

        List<TeamMember> activeAssignments =
                teamMemberRepository
                        .findByTraineeIdAndIsDeletedFalse(
                                traineeId);

        for (TeamMember assignment
                : activeAssignments) {

            if (targetProjectId != null
                    && targetProjectId.equals(
                    assignment.getProjectId())) {

                continue;
            }

            projectTeamRepository
                    .findByProjectIdAndIsDeletedFalse(
                            assignment.getProjectId())
                    .ifPresent(project -> {

                        if (!"Completed".equalsIgnoreCase(
                                project.getProjectStatus())) {

                            throw new BusinessException(
                                    "Trainee with ID "
                                            + traineeId
                                            + " is already assigned to "
                                            + "active project '"
                                            + project.getProjectName()
                                            + "' and cannot join a new "
                                            + "project until it is completed");
                        }
                    });
        }
    }

    private ProjectTeam findProjectById(
            Integer projectId) {

        if (projectId == null) {
            throw new BadRequestException(
                    "Project ID is required");
        }

        return projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(
                        projectId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Project",
                                projectId));
    }

    private void validateProject(
            ProjectTeam projectTeam) {

        if (projectTeam == null) {
            throw new BadRequestException(
                    "Project details are required");
        }

        if (isBlank(projectTeam.getProjectName())) {
            throw new BadRequestException(
                    "Project name is required");
        }

        String projectName =
                projectTeam.getProjectName().trim();

        if (projectName.length() > 200) {
            throw new BadRequestException(
                    "Project name cannot exceed 200 characters");
        }

        projectTeam.setProjectName(projectName);

        if (projectTeam.getDeadline() == null) {
            throw new BadRequestException(
                    "Project deadline is required");
        }

        if (!projectTeam.getDeadline()
                .isAfter(LocalDate.now())) {

            throw new BadRequestException(
                    "Deadline must be greater than current date");
        }
    }

    private void validateExcelFile(
            MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new BadRequestException(
                    "Excel file is required");
        }

        String fileName =
                file.getOriginalFilename();

        if (fileName == null
                || !fileName
                .toLowerCase(Locale.ROOT)
                .endsWith(".xlsx")) {

            throw new BadRequestException(
                    "Only .xlsx files are allowed");
        }
    }

    private String normalizeRequiredStatus(
            String projectStatus) {

        String normalized =
                normalizeValue(
                        projectStatus,
                        VALID_STATUSES);

        if (normalized == null) {
            throw new BadRequestException(
                    "Project status must be "
                            + "Pending, Ongoing, or Completed");
        }

        return normalized;
    }

    private String normalizeValue(
            String value,
            Set<String> allowedValues) {

        if (isBlank(value)) {
            return null;
        }

        String trimmed =
                value.trim();

        return allowedValues
                .stream()
                .filter(item ->
                        item.equalsIgnoreCase(trimmed))
                .findFirst()
                .orElse(null);
    }

    private String normalizeEmail(
            String email) {

        if (email == null) {
            return "";
        }

        return email
                .trim()
                .toLowerCase(Locale.ENGLISH);
    }

    private String extractExceptionMessage(
            Exception exception) {

        if (exception == null) {
            return "Unknown error";
        }

        String message =
                exception.getMessage();

        return isBlank(message)
                ? exception.getClass().getSimpleName()
                : message;
    }

    private void addError(
            List<BulkUploadError> errors,
            int row,
            String message) {

        errors.add(
                new BulkUploadError(
                        PROJECTS_SHEET,
                        row,
                        message));
    }

    private String getStringValue(
            Row row,
            Map<String, Integer> headerMap,
            String headerName) {

        Integer index =
                headerMap.get(
                        headerName
                                .toLowerCase(Locale.ENGLISH)
                                .trim());

        if (index == null) {
            return "";
        }

        return text(row.getCell(index));
    }

    private String getNullableStringValue(
            Row row,
            Map<String, Integer> headerMap,
            String headerName) {

        String value =
                getStringValue(
                        row,
                        headerMap,
                        headerName);

        return value.isBlank()
                ? null
                : value;
    }

    private Integer getIntValue(
            Row row,
            Map<String, Integer> headerMap,
            String headerName) {

        Integer index =
                headerMap.get(
                        headerName
                                .toLowerCase(Locale.ENGLISH)
                                .trim());

        if (index == null) {
            return null;
        }

        return integer(row.getCell(index));
    }

    private LocalDate getDateValue(
            Row row,
            Map<String, Integer> headerMap,
            String headerName) {

        Integer index =
                headerMap.get(
                        headerName
                                .toLowerCase(Locale.ENGLISH)
                                .trim());

        if (index == null) {
            return null;
        }

        return date(row.getCell(index));
    }

    private String text(Cell cell) {

        return cell == null
                ? ""
                : formatter
                .formatCellValue(cell)
                .trim();
    }

    private Integer integer(Cell cell) {

        if (cell == null
                || cell.getCellType()
                == CellType.BLANK) {

            return null;
        }

        try {

            if (cell.getCellType()
                    == CellType.NUMERIC) {

                double value =
                        cell.getNumericCellValue();

                if (value != Math.rint(value)) {
                    return null;
                }

                return Math.toIntExact(
                        (long) value);
            }

            String value =
                    text(cell);

            if (value.endsWith(".0")) {
                value =
                        value.substring(
                                0,
                                value.length() - 2);
            }

            return Integer.valueOf(value);

        } catch (Exception exception) {
            return null;
        }
    }

    private LocalDate date(Cell cell) {

        if (cell == null
                || cell.getCellType()
                == CellType.BLANK) {

            return null;
        }

        try {

            if (cell.getCellType()
                    == CellType.NUMERIC
                    && DateUtil.isCellDateFormatted(cell)) {

                return cell
                        .getLocalDateTimeCellValue()
                        .toLocalDate();
            }

            return LocalDate.parse(
                    text(cell));

        } catch (DateTimeParseException
                 | IllegalStateException exception) {

            return null;
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}