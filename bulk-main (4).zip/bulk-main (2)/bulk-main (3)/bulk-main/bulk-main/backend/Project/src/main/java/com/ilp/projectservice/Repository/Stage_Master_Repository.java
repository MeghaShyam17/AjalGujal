package com.ilp.projectservice.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.projectservice.Entity.Stage_Master_Entity;

@Repository
public interface Stage_Master_Repository
        extends JpaRepository<Stage_Master_Entity, Long> {

    List<Stage_Master_Entity> findAllByOrderByStageNoAsc();

    Optional<Stage_Master_Entity> findByStageNo(
        Integer stageNo
    );

    List<Stage_Master_Entity> findByBatchIdOrderByStageNoAsc(Integer batchId);

    List<Stage_Master_Entity> findByBatchIdIsNullOrderByStageNoAsc();

    Optional<Stage_Master_Entity> findByBatchIdAndStageNo(Integer batchId, Integer stageNo);

    Optional<Stage_Master_Entity> findByBatchIdAndStageNameIgnoreCase(Integer batchId, String stageName);

    Optional<Stage_Master_Entity> findByBatchIdIsNullAndStageNameIgnoreCase(String stageName);
}