package com.ilp.projectservice.ServiceImplementation;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BatchStageBulkUploadResult;
import com.ilp.projectservice.DTO.BatchStageImportRowDto;
import com.ilp.projectservice.DTO.BatchStageRequest;
import com.ilp.projectservice.DTO.BatchStageUploadError;
import com.ilp.projectservice.Entity.BatchStageEntity;
import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Repository.BatchStageRepository;
import com.ilp.projectservice.Repository.Stage_Master_Repository;
import com.ilp.projectservice.Service.BatchStageService;

@Service
@Transactional
public class BatchStageServiceImpl implements BatchStageService {

    private static final String EXPECTED_MASTER_STAGE_NO = "Master Stage No";
    private static final String EXPECTED_BATCH_STAGE_NO = "Batch Stage No";
    private static final String EXPECTED_DEADLINE = "Stage Deadline";
    private static final DateTimeFormatter ISO_DATE =
        DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Autowired
    private BatchStageRepository batchStageRepository;

    @Autowired
    private Stage_Master_Repository stageMasterRepository;

    @Override
    public BatchStageEntity createBatchStage(BatchStageRequest request) {
        validateRequest(request);
        validateNoDuplicateMapping(
            request.getBatchId(),
            request.getStageId(),
            request.getStageNo(),
            null
        );

        Stage_Master_Entity stage = findStage(request.getStageId());
        BatchStageEntity entity = new BatchStageEntity();
        mapRequest(entity, request, stage);
        return batchStageRepository.save(entity);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BatchStageEntity> getAllBatchStages() {
        return batchStageRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<BatchStageEntity> getStagesByBatchId(Integer batchId) {
        validateBatchId(batchId);
        return batchStageRepository.findByBatchIdOrderByStageNoAsc(batchId);
    }

    @Override
    @Transactional(readOnly = true)
    public BatchStageEntity getBatchStageById(Long batchStageId) {
        if (batchStageId == null || batchStageId <= 0) {
            throw new IllegalArgumentException("A valid batch stage ID is required.");
        }

        return batchStageRepository.findById(batchStageId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Batch stage not found with ID: " + batchStageId
            ));
    }

    @Override
    public BatchStageEntity updateBatchStage(
            Long batchStageId,
            BatchStageRequest request) {

        validateRequest(request);
        BatchStageEntity existing = getBatchStageById(batchStageId);

        validateNoDuplicateMapping(
            request.getBatchId(),
            request.getStageId(),
            request.getStageNo(),
            batchStageId
        );

        Stage_Master_Entity stage = findStage(request.getStageId());
        mapRequest(existing, request, stage);
        return batchStageRepository.save(existing);
    }

    @Override
    public void deleteBatchStage(Long batchStageId) {
        BatchStageEntity existing = getBatchStageById(batchStageId);
        batchStageRepository.delete(existing);
    }

    @Override
    public BatchStageBulkUploadResult uploadBatchStages(
            Integer batchId,
            MultipartFile file) {

        validateBatchId(batchId);
        validateExcelFile(file);

        List<BatchStageUploadError> errors = new ArrayList<>();
        List<BatchStageImportRowDto> rows = readExcelRows(file, errors);

        Set<Integer> masterStageNumbersInFile = new HashSet<>();
        Set<Integer> stageNumbersInFile = new HashSet<>();
        List<BatchStageEntity> entitiesToInsert = new ArrayList<>();

        for (BatchStageImportRowDto row : rows) {
            validateImportRow(
                batchId,
                row,
                masterStageNumbersInFile,
                stageNumbersInFile,
                entitiesToInsert,
                errors
            );
        }

        if (!errors.isEmpty()) {
            return createUploadResult(
                false,
                "Upload validation failed. No batch stages were inserted.",
                batchId,
                rows.size(),
                0,
                rows.size(),
                errors
            );
        }

        List<BatchStageEntity> inserted =
            batchStageRepository.saveAll(entitiesToInsert);

        return createUploadResult(
            true,
            inserted.size() + " stages uploaded successfully to batch " + batchId + ".",
            batchId,
            rows.size(),
            inserted.size(),
            0,
            List.of()
        );
    }

    private List<BatchStageImportRowDto> readExcelRows(
            MultipartFile file,
            List<BatchStageUploadError> errors) {

        List<BatchStageImportRowDto> rows = new ArrayList<>();
        DataFormatter formatter = new DataFormatter();

        try (
            InputStream inputStream = file.getInputStream();
            Workbook workbook = new XSSFWorkbook(inputStream)
        ) {
            if (workbook.getNumberOfSheets() == 0) {
                throw new IllegalArgumentException("The Excel workbook has no sheets.");
            }

            Sheet sheet = workbook.getSheet("BatchStages");
            if (sheet == null) {
                sheet = workbook.getSheetAt(0);
            }

            validateHeaders(sheet.getRow(0), formatter);

            for (int index = 1; index <= sheet.getLastRowNum(); index++) {
                Row excelRow = sheet.getRow(index);
                int displayRowNumber = index + 1;

                if (isEmptyRow(excelRow, formatter)) {
                    continue;
                }

                try {
                    Integer masterStageNo = readInteger(
                        excelRow.getCell(0),
                        "Master Stage No"
                    );
                    Integer batchStageNo = readInteger(
                        excelRow.getCell(1),
                        "Batch Stage No"
                    );
                    LocalDate deadline = readDate(
                        excelRow.getCell(2),
                        formatter,
                        "Stage Deadline"
                    );

                    rows.add(new BatchStageImportRowDto(
                        displayRowNumber,
                        masterStageNo,
                        batchStageNo,
                        deadline
                    ));
                } catch (IllegalArgumentException exception) {
                    errors.add(new BatchStageUploadError(
                        displayRowNumber,
                        "Row",
                        exception.getMessage()
                    ));
                }
            }
        } catch (IOException exception) {
            throw new IllegalArgumentException(
                "Unable to read the Excel file.",
                exception
            );
        }

        if (rows.isEmpty() && errors.isEmpty()) {
            throw new IllegalArgumentException(
                "The Excel file contains no Batch Stage data rows."
            );
        }

        return rows;
    }

    private void validateImportRow(
            Integer batchId,
            BatchStageImportRowDto row,
            Set<Integer> masterStageNumbersInFile,
            Set<Integer> stageNumbersInFile,
            List<BatchStageEntity> entitiesToInsert,
            List<BatchStageUploadError> errors) {

        boolean valid = true;

        if (row.getMasterStageNo() == null || row.getMasterStageNo() <= 0) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Master Stage No",
                "A valid Master Stage No is required."
            ));
            valid = false;
        }

        if (row.getBatchStageNo() == null || row.getBatchStageNo() <= 0) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Batch Stage No",
                "Batch Stage No must be greater than zero."
            ));
            valid = false;
        }

        if (row.getStageDeadline() == null) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Stage Deadline",
                "Stage Deadline is required."
            ));
            valid = false;
        }

        if (!valid) {
            return;
        }

        if (!masterStageNumbersInFile.add(row.getMasterStageNo())) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Master Stage No",
                "Master Stage No " + row.getMasterStageNo() +
                " is duplicated in the Excel file."
            ));
            valid = false;
        }

        if (!stageNumbersInFile.add(row.getBatchStageNo())) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Batch Stage No",
                "Batch Stage No " + row.getBatchStageNo() +
                " is duplicated in the Excel file."
            ));
            valid = false;
        }

        if (batchStageRepository.existsByBatchIdAndStageNo(
                batchId, row.getBatchStageNo())) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Batch Stage No",
                "Batch Stage No " + row.getBatchStageNo() +
                " is already configured for batch " + batchId + "."
            ));
            valid = false;
        }

        Stage_Master_Entity stage = stageMasterRepository
            .findByStageNo(row.getMasterStageNo())
            .orElse(null);

        if (stage == null) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Master Stage No",
                "Stage Master record does not exist for Master Stage No " +
                row.getMasterStageNo() + "."
            ));
            valid = false;
        } else if (batchStageRepository.existsByBatchIdAndStage_StageId(
                batchId, stage.getStageId())) {
            errors.add(new BatchStageUploadError(
                row.getRowNumber(),
                "Master Stage No",
                "Master Stage No " + row.getMasterStageNo() +
                " is already configured for batch " + batchId + "."
            ));
            valid = false;
        }

        if (valid) {
            BatchStageEntity entity = new BatchStageEntity();
            entity.setBatchId(batchId);
            entity.setStage(stage);
            entity.setStageNo(row.getBatchStageNo());
            entity.setStageDeadline(row.getStageDeadline());
            entitiesToInsert.add(entity);
        }
    }

    private void validateHeaders(Row headerRow, DataFormatter formatter) {
        if (headerRow == null) {
            throw new IllegalArgumentException("The Excel header row is missing.");
        }

        String masterStageNoHeader = formatter
            .formatCellValue(headerRow.getCell(0)).trim();
        String batchStageNoHeader = formatter
            .formatCellValue(headerRow.getCell(1)).trim();
        String deadlineHeader = formatter.formatCellValue(headerRow.getCell(2)).trim();

        if (!EXPECTED_MASTER_STAGE_NO.equalsIgnoreCase(masterStageNoHeader)
                || !EXPECTED_BATCH_STAGE_NO.equalsIgnoreCase(batchStageNoHeader)
                || !EXPECTED_DEADLINE.equalsIgnoreCase(deadlineHeader)) {
            throw new IllegalArgumentException(
                "Invalid Excel headers. Expected: Master Stage No, Batch Stage No, Stage Deadline."
            );
        }
    }

    private boolean isEmptyRow(Row row, DataFormatter formatter) {
        if (row == null) {
            return true;
        }

        for (int index = 0; index < 3; index++) {
            if (!formatter.formatCellValue(row.getCell(index)).trim().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private Long readLong(Cell cell, String fieldName) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }

        try {
            if (cell.getCellType() == CellType.NUMERIC) {
                return (long) cell.getNumericCellValue();
            }
            return Long.valueOf(cell.getStringCellValue().trim());
        } catch (RuntimeException exception) {
            throw new IllegalArgumentException(fieldName + " must be a whole number.");
        }
    }

    private Integer readInteger(Cell cell, String fieldName) {
        Long value = readLong(cell, fieldName);
        if (value > Integer.MAX_VALUE) {
            throw new IllegalArgumentException(fieldName + " is too large.");
        }
        return value.intValue();
    }

    private LocalDate readDate(
            Cell cell,
            DataFormatter formatter,
            String fieldName) {

        if (cell == null || cell.getCellType() == CellType.BLANK) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }

        if (cell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(cell)) {
            return cell.getDateCellValue()
                .toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        }

        String value = formatter.formatCellValue(cell).trim();
        try {
            return LocalDate.parse(value, ISO_DATE);
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException(
                fieldName + " must use yyyy-MM-dd format."
            );
        }
    }

    private void validateExcelFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Select a non-empty Excel file.");
        }

        String fileName = file.getOriginalFilename();
        if (fileName == null || !fileName.toLowerCase().endsWith(".xlsx")) {
            throw new IllegalArgumentException("Only .xlsx Excel files are supported.");
        }
    }

    private void validateNoDuplicateMapping(
            Integer batchId,
            Long stageId,
            Integer stageNo,
            Long excludedBatchStageId) {

        boolean duplicateNumber = excludedBatchStageId == null
            ? batchStageRepository.existsByBatchIdAndStageNo(batchId, stageNo)
            : batchStageRepository.existsByBatchIdAndStageNoAndBatchStageIdNot(
                batchId,
                stageNo,
                excludedBatchStageId
            );

        if (duplicateNumber) {
            throw new IllegalArgumentException(
                "Stage number " + stageNo +
                " is already configured for batch " + batchId + "."
            );
        }

        boolean duplicateStage = excludedBatchStageId == null
            ? batchStageRepository.existsByBatchIdAndStage_StageId(batchId, stageId)
            : batchStageRepository
                .existsByBatchIdAndStage_StageIdAndBatchStageIdNot(
                    batchId,
                    stageId,
                    excludedBatchStageId
                );

        if (duplicateStage) {
            throw new IllegalArgumentException(
                "The selected stage is already configured for batch " + batchId + "."
            );
        }
    }

    private Stage_Master_Entity findStage(Long stageId) {
        return stageMasterRepository.findById(stageId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Stage Master record not found with ID: " + stageId
            ));
    }

    private void mapRequest(
            BatchStageEntity entity,
            BatchStageRequest request,
            Stage_Master_Entity stage) {

        entity.setBatchId(request.getBatchId());
        entity.setStage(stage);
        entity.setStageNo(request.getStageNo());
        entity.setStageDeadline(request.getStageDeadline());
    }

    private void validateRequest(BatchStageRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Batch stage details are required.");
        }

        validateBatchId(request.getBatchId());

        if (request.getStageId() == null || request.getStageId() <= 0) {
            throw new IllegalArgumentException("A valid stage ID is required.");
        }

        if (request.getStageNo() == null || request.getStageNo() <= 0) {
            throw new IllegalArgumentException(
                "Stage number must be greater than zero."
            );
        }

        if (request.getStageDeadline() == null) {
            throw new IllegalArgumentException("Stage deadline is required.");
        }
    }

    private void validateBatchId(Integer batchId) {
        if (batchId == null || batchId <= 0) {
            throw new IllegalArgumentException("A valid batch ID is required.");
        }
    }

    private BatchStageBulkUploadResult createUploadResult(
            boolean success,
            String message,
            Integer batchId,
            int rowsProcessed,
            int stagesInserted,
            int stagesSkipped,
            List<BatchStageUploadError> errors) {

        return new BatchStageBulkUploadResult(
            success,
            message,
            batchId,
            rowsProcessed,
            stagesInserted,
            stagesSkipped,
            errors
        );
    }
}
