package com.ilp.projectservice.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BatchStageBulkUploadResult;
import com.ilp.projectservice.DTO.BatchStageRequest;
import com.ilp.projectservice.Entity.BatchStageEntity;

public interface BatchStageService {

    BatchStageEntity createBatchStage(BatchStageRequest request);

    List<BatchStageEntity> getAllBatchStages();

    List<BatchStageEntity> getStagesByBatchId(Integer batchId);

    BatchStageEntity getBatchStageById(Long batchStageId);

    BatchStageEntity updateBatchStage(
        Long batchStageId,
        BatchStageRequest request
    );

    void deleteBatchStage(Long batchStageId);

    BatchStageBulkUploadResult uploadBatchStages(
        Integer batchId,
        MultipartFile file
    );
}
