package com.ilp.projectservice.DTO;

/**
 * Describes a validation or processing error for one Excel row.
 */
public class BatchStageUploadError {

    private Integer rowNumber;
    private String field;
    private String message;

    public BatchStageUploadError() {
    }

    public BatchStageUploadError(
            Integer rowNumber,
            String field,
            String message) {
        this.rowNumber = rowNumber;
        this.field = field;
        this.message = message;
    }

    public Integer getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(Integer rowNumber) {
        this.rowNumber = rowNumber;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
