package com.ilp.projectservice.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BulkUploadResult;
import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Service.ProjectTeamService;


@RestController
@RequestMapping("/api/projects")
public class ProjectTeamController {

    private final ProjectTeamService projectTeamService;

    public ProjectTeamController(ProjectTeamService projectTeamService) {
        this.projectTeamService = projectTeamService;
    }

    @PostMapping
    public ResponseEntity<ProjectTeam> createProject(
            @RequestBody ProjectTeam projectTeam) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(projectTeamService.createProject(projectTeam));
    }

    @GetMapping
    public ResponseEntity<List<ProjectTeam>> getAllProjects() {
        return ResponseEntity.ok(projectTeamService.getAllProjects());
    }

    @GetMapping("/{projectId}")
    public ResponseEntity<ProjectTeam> getProjectById(
            @PathVariable Integer projectId) {
        return ResponseEntity.ok(
                projectTeamService.getProjectById(projectId));
    }

    @PutMapping("/{projectId}")
    public ResponseEntity<ProjectTeam> updateProject(
            @PathVariable Integer projectId,
            @RequestBody ProjectTeam projectTeam) {
        return ResponseEntity.ok(
                projectTeamService.updateProject(projectId, projectTeam));
    }

    @PatchMapping("/{projectId}/status")
    public ResponseEntity<ProjectTeam> updateProjectStatus(
            @PathVariable Integer projectId,
            @RequestParam String status) {
        return ResponseEntity.ok(
                projectTeamService.updateProjectStatus(projectId, status));
    }

    @PutMapping("/soft-delete/{projectId}")
    public String softDeleteProject(
            @PathVariable Integer projectId) {

        projectTeamService.deleteProject(projectId);

        return "Project soft deleted successfully";
    }
    
    @DeleteMapping("/hard-delete/{projectId}")
    public String hardDeleteProject(
            @PathVariable Integer projectId) {

        projectTeamService.hardDeleteProject(projectId);

        return "Project permanently deleted";
    }
    
    

    @GetMapping("/status/{projectStatus}")
    public ResponseEntity<List<ProjectTeam>> getProjectsByStatus(
            @PathVariable String projectStatus) {
        return ResponseEntity.ok(
                projectTeamService.getProjectsByStatus(projectStatus));
    }

    @GetMapping("/team-leader/{teamLeaderId}")
    public ResponseEntity<List<ProjectTeam>> getProjectsByTeamLeader(
            @PathVariable Integer teamLeaderId) {
        return ResponseEntity.ok(
                projectTeamService.getProjectsByTeamLeader(teamLeaderId));
    }

    @GetMapping("/faculty/{facultyId}")
    public ResponseEntity<List<ProjectTeam>> getProjectsByFaculty(
            @PathVariable Integer facultyId) {
        return ResponseEntity.ok(
                projectTeamService.getProjectsByFaculty(facultyId));
    }

    @GetMapping("/batch/{batchId}")
    public ResponseEntity<List<ProjectTeam>> getProjectsByBatch(
            @PathVariable Integer batchId) {
        return ResponseEntity.ok(
                projectTeamService.getProjectsByBatch(batchId));
    }

    @GetMapping("/year/{year}")
    public ResponseEntity<List<ProjectTeam>> getProjectsByYear(
            @PathVariable Integer year) {
        return ResponseEntity.ok(
                projectTeamService.getProjectsByYear(year));
    }

    @GetMapping("/search")
    public ResponseEntity<List<ProjectTeam>> searchProjectsByName(
            @RequestParam String name) {
        return ResponseEntity.ok(
                projectTeamService.searchProjectsByName(name));
    }

    @PostMapping(
            value = "/bulk-upload",
            consumes = "multipart/form-data")
    public ResponseEntity<BulkUploadResult> bulkUpload(
            @RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(
                projectTeamService.uploadProjectTeamsAndMembers(file));
    }

}
