package com.ilp.projectservice.ServiceImplementation;

import java.util.List;

import com.ilp.projectservice.Client.UserClient;
import com.ilp.projectservice.DTO.UserResponseDto;

import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.Entity.TeamMember;
import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Exception.BadRequestException;
import com.ilp.projectservice.Exception.BusinessException;
import com.ilp.projectservice.Exception.ResourceNotFoundException;
import com.ilp.projectservice.Repository.TeamMemberRepository;
import com.ilp.projectservice.Repository.ProjectTeamRepository;
import com.ilp.projectservice.Service.TeamMemberService;

@Service
@Transactional
public class TeamMemberServiceImpl implements TeamMemberService {

    private static final Set<String> VALID_MEMBER_ROLES =
            Set.of("Scrum", "Member");

    private final TeamMemberRepository teamMemberRepository;
    private final UserClient userClient;
    private final ProjectTeamRepository projectTeamRepository;

    public TeamMemberServiceImpl(
            TeamMemberRepository teamMemberRepository,
            UserClient userClient,
            ProjectTeamRepository projectTeamRepository) {

        this.teamMemberRepository = teamMemberRepository;
        this.userClient = userClient;
        this.projectTeamRepository = projectTeamRepository;
    }
    
    private void validateUser(Integer userId) {

        UserResponseDto user =
                userClient.getUserById(userId);

        if (user == null) {
            throw new ResourceNotFoundException(
                    "User",
                    userId);
        }
    }

    private void checkTraineeAvailability(Integer traineeId, Integer targetProjectId) {
        List<TeamMember> activeAssignments = teamMemberRepository.findByTraineeIdAndIsDeletedFalse(traineeId);
        for (TeamMember assignment : activeAssignments) {
            if (targetProjectId != null && targetProjectId.equals(assignment.getProjectId())) {
                continue;
            }
            projectTeamRepository.findByProjectIdAndIsDeletedFalse(assignment.getProjectId())
                    .ifPresent(project -> {
                        if (!"Completed".equalsIgnoreCase(project.getProjectStatus())) {
                            throw new BusinessException("Trainee with ID " + traineeId +
                                    " is already assigned to an active project '" + project.getProjectName() +
                                    "' and cannot join a new project until the current one is completed.");
                        }
                    });
        }
    }

    @Override
    public void hardDeleteTeamMember(
            Integer teamMemberId) {

        if (teamMemberId == null) {
            throw new BadRequestException(
                    "Team member ID is required"
            );
        }

        TeamMember member =
                teamMemberRepository.findById(teamMemberId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Team member",
                                        teamMemberId
                                ));

        teamMemberRepository.delete(member);
    }
    
    @Override
    public TeamMember saveTeamMember(
            TeamMember teamMember) {

        validateTeamMember(teamMember);

        validateUser(
                teamMember.getTraineeId());

        checkTraineeAvailability(teamMember.getTraineeId(), teamMember.getProjectId());

        boolean memberAlreadyExists =
                teamMemberRepository
                        .existsByProjectIdAndTraineeIdAndIsDeletedFalse(
                                teamMember.getProjectId(),
                                teamMember.getTraineeId()
                        );

        if (memberAlreadyExists) {
            throw new BusinessException(
                    "The trainee is already assigned "
                            + "to this project"
            );
        }

        /*
         * The database generates team_member_id.
         */
        teamMember.setTeamMemberId(null);

        return teamMemberRepository.save(teamMember);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TeamMember> getAllTeamMembers() {

    	return teamMemberRepository.findByIsDeletedFalse();
    }

    @Override
    @Transactional(readOnly = true)
    public TeamMember getTeamMemberById(
            Integer teamMemberId) {

        return findTeamMemberById(teamMemberId);
    }

    @Override
    public TeamMember updateTeamMember(
            Integer teamMemberId,
            TeamMember teamMember) {

        validateTeamMember(teamMember);

        validateUser(
                teamMember.getTraineeId());

        checkTraineeAvailability(teamMember.getTraineeId(), teamMember.getProjectId());

        TeamMember existingMember =
                findTeamMemberById(teamMemberId);


        /*
         * Check whether another record already uses the same
         * projectId and traineeId combination.
         */
        teamMemberRepository
        .findByProjectIdAndTraineeIdAndIsDeletedFalse(
                teamMember.getProjectId(),
                teamMember.getTraineeId()
        )
                .filter(foundMember ->
                        !foundMember.getTeamMemberId()
                                .equals(teamMemberId)
                )
                .ifPresent(foundMember -> {
                    throw new BusinessException(
                            "The trainee is already assigned "
                                    + "to this project"
                    );
                });

        existingMember.setProjectId(
                teamMember.getProjectId()
        );

        existingMember.setTraineeId(
                teamMember.getTraineeId()
        );

        existingMember.setMemberRole(
                teamMember.getMemberRole()
        );

        return teamMemberRepository.save(existingMember);
    }
    
    
    @Override
    public void deleteTeamMember(
            Integer teamMemberId) {

        TeamMember existingMember =
                findTeamMemberById(teamMemberId);

        existingMember.setIsDeleted(true);

        teamMemberRepository.save(existingMember);
    }

    @Override
    public String uploadExcel(
            MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new BadRequestException(
                    "Excel file is required"
            );
        }

        /*
         * The combined Project Team and Team Member Excel
         * upload is handled by ProjectTeamServiceImpl.
         */
        return "Use POST /api/projects/bulk-upload "
                + "to upload project teams and members.";
    }

    /**
     * Changes the Scrum responsibility between two existing
     * trainees in the same project.
     *
     * The old Scrum becomes Member.
     * The selected Member becomes Scrum.
     */
    @Override
    public String changeScrum(
            Integer projectId,
            Integer oldScrumId,
            Integer newScrumId) {

        validateChangeScrumRequest(
                projectId,
                oldScrumId,
                newScrumId
        );

        TeamMember oldScrumMember =
                teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(
                        projectId,
                        oldScrumId
                )
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Trainee "
                                                + oldScrumId
                                                + " was not found "
                                                + "in project "
                                                + projectId
                                )
                        );

        if (!"Scrum".equalsIgnoreCase(
                oldScrumMember.getMemberRole())) {

            throw new BusinessException(
                    "Trainee "
                            + oldScrumId
                            + " is not assigned as Scrum "
                            + "in project "
                            + projectId
            );
        }

        TeamMember newScrumMember =
                teamMemberRepository
                .findByProjectIdAndTraineeIdAndIsDeletedFalse(
                        projectId,
                        newScrumId
                )
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Trainee "
                                                + newScrumId
                                                + " is not a member "
                                                + "of project "
                                                + projectId
                                )
                        );

        if (!"Member".equalsIgnoreCase(
                newScrumMember.getMemberRole())) {

            throw new BusinessException(
                    "Trainee "
                            + newScrumId
                            + " must currently have "
                            + "the Member role"
            );
        }

        /*
         * Swap only the roles.
         * Do not change either trainee ID.
         */
        oldScrumMember.setMemberRole("Member");
        newScrumMember.setMemberRole("Scrum");

        teamMemberRepository.save(oldScrumMember);
        teamMemberRepository.save(newScrumMember);

        /*
         * Flush now so database errors occur inside this
         * transactional method and trigger a full rollback.
         */
        teamMemberRepository.flush();

        return "Scrum changed successfully from trainee "
                + oldScrumId
                + " to trainee "
                + newScrumId
                + " for project "
                + projectId;
    }

    private TeamMember findTeamMemberById(
            Integer teamMemberId) {

        if (teamMemberId == null) {
            throw new BadRequestException(
                    "Team member ID is required"
            );
        }

        return teamMemberRepository
                .findByTeamMemberIdAndIsDeletedFalse(
                        teamMemberId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Team member",
                                teamMemberId
                        )
                );
    }

    private void validateTeamMember(
            TeamMember teamMember) {

        if (teamMember == null) {
            throw new BadRequestException(
                    "Team member details are required"
            );
        }

        if (teamMember.getProjectId() == null) {
            throw new BadRequestException(
                    "Project ID is required"
            );
        }

        if (teamMember.getTraineeId() == null) {
            throw new BadRequestException(
                    "Trainee ID is required"
            );
        }

        String normalizedRole =
                normalizeMemberRole(
                        teamMember.getMemberRole()
                );

        teamMember.setMemberRole(normalizedRole);
    }

    private void validateChangeScrumRequest(
            Integer projectId,
            Integer oldScrumId,
            Integer newScrumId) {

        if (projectId == null) {
            throw new BadRequestException(
                    "Project ID is required"
            );
        }

        if (oldScrumId == null) {
            throw new BadRequestException(
                    "Old Scrum ID is required"
            );
        }

        if (newScrumId == null) {
            throw new BadRequestException(
                    "New Scrum ID is required"
            );
        }

        if (oldScrumId.equals(newScrumId)) {
            throw new BadRequestException(
                    "Old Scrum ID and new Scrum ID "
                            + "cannot be the same"
            );
        }
    }

    private String normalizeMemberRole(
            String memberRole) {

        if (memberRole == null
                || memberRole.isBlank()) {

            throw new BadRequestException(
                    "Member role is required"
            );
        }

        String trimmedRole = memberRole.trim();

        return VALID_MEMBER_ROLES
                .stream()
                .filter(validRole ->
                        validRole.equalsIgnoreCase(
                                trimmedRole
                        )
                )
                .findFirst()
                .orElseThrow(() ->
                        new BadRequestException(
                                "Member role must be "
                                        + "Scrum or Member"
                        )
                );
    }

    @Override
    @Transactional(readOnly = true)
    public List<TeamMember> getTeamMembersByProjectId(Integer projectId) {
        if (projectId == null) {
            throw new BadRequestException("Project ID is required");
        }
        return teamMemberRepository.findByProjectIdAndIsDeletedFalse(projectId);
    }
}