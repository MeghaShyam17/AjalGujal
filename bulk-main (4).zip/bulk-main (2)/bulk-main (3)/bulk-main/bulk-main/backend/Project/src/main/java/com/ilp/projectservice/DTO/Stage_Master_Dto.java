package com.ilp.projectservice.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class Stage_Master_Dto {

    private Long stageId;

    @NotNull(message = "Stage Number is required")
    @Positive(message = "Stage Number must be greater than 0")
    private Integer stageNo;

    @NotBlank(message = "Stage Name is required")
    private String stageName;

    private String description;

    // Getters and Setters

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public Integer getStageNo() {
        return stageNo;
    }

    public void setStageNo(Integer stageNo) {
        this.stageNo = stageNo;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}