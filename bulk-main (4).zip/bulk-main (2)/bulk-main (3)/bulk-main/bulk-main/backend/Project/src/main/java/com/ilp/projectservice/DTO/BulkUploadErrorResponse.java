package com.ilp.projectservice.DTO;

import java.time.LocalDateTime;
import java.util.List;

public record BulkUploadErrorResponse(
        LocalDateTime timestamp,
        int status,
        String error,
        String message,
        String path,
        List<BulkUploadError> validationErrors) {
}