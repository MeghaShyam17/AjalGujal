package com.ilp.projectservice.DTO;

public record TeamMemberImportRowDto(
        int rowNumber,
        String projectReference,
        Integer traineeId,
        String memberRole) {
}
