package com.ilp.projectservice.Service;

import java.util.List;

import com.ilp.projectservice.Entity.Stage_Master_Entity;

public interface Stage_Master_Service {

    Stage_Master_Entity saveStage(
            Stage_Master_Entity stage);

    List<Stage_Master_Entity> getAllStages();

    Stage_Master_Entity getStageById(Long id);

    Stage_Master_Entity updateStage(
            Long id,
            Stage_Master_Entity stage);

    List<Stage_Master_Entity> getStagesByBatchId(Integer batchId);

    void deleteStage(Long id);
}