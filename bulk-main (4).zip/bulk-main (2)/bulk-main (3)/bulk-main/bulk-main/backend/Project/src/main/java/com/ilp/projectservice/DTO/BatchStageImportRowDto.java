package com.ilp.projectservice.DTO;

import java.time.LocalDate;

/**
 * Represents one row from the Batch Stage Excel upload.
 * The batch ID is supplied separately as a request parameter.
 */
public class BatchStageImportRowDto {

    private Integer rowNumber;
    private Integer masterStageNo;
    private Integer batchStageNo;
    private LocalDate stageDeadline;

    public BatchStageImportRowDto() {
    }

    public BatchStageImportRowDto(
            Integer rowNumber,
            Integer masterStageNo,
            Integer batchStageNo,
            LocalDate stageDeadline) {

        this.rowNumber = rowNumber;
        this.masterStageNo = masterStageNo;
        this.batchStageNo = batchStageNo;
        this.stageDeadline = stageDeadline;
    }

    public Integer getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(Integer rowNumber) {
        this.rowNumber = rowNumber;
    }

    public Integer getMasterStageNo() {
        return masterStageNo;
    }

    public void setMasterStageNo(Integer masterStageNo) {
        this.masterStageNo = masterStageNo;
    }

    public Integer getBatchStageNo() {
        return batchStageNo;
    }

    public void setBatchStageNo(Integer batchStageNo) {
        this.batchStageNo = batchStageNo;
    }

    public LocalDate getStageDeadline() {
        return stageDeadline;
    }

    public void setStageDeadline(LocalDate stageDeadline) {
        this.stageDeadline = stageDeadline;
    }
}