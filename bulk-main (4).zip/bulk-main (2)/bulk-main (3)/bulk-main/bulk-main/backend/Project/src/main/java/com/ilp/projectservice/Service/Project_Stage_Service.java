package com.ilp.projectservice.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.Entity.Project_Stage_Entity;

public interface Project_Stage_Service {

    void initializeProjectStages(Integer projectId);

    Project_Stage_Entity saveProjectStage(
            Project_Stage_Entity projectStage);

    List<Project_Stage_Entity> getAllProjectStages();

    Project_Stage_Entity getProjectStageById(Long id);

    void deleteProjectStage(Long id);

    Project_Stage_Entity updateProjectStage(
            Long id,
            Project_Stage_Entity projectStage);

    void uploadDocument(
            Long projectStageId,
            Integer uploadedBy,
            MultipartFile file,
            String description,
            Integer versionNo);
}