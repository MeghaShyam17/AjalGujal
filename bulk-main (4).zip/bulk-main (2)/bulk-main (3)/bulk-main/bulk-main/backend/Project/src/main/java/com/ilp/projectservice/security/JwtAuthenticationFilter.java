package com.ilp.projectservice.security;

import java.io.IOException;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter
        extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * Stage Master is currently configured as permitAll().
     * Therefore, JWT validation is not required for these requests.
     *
     * OPTIONS requests are browser CORS preflight requests and
     * must also bypass JWT validation.
     */
    @Override
    protected boolean shouldNotFilter(
            HttpServletRequest request) {

        String requestPath = request.getServletPath();
        String requestMethod = request.getMethod();

        return requestPath.startsWith("/stage-master")
            || "OPTIONS".equalsIgnoreCase(requestMethod);
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        String authHeader =
            request.getHeader("Authorization");

        /*
         * Do not reject requests that do not contain a token.
         * Spring Security will later determine whether the
         * requested endpoint needs authentication.
         */
        if (
            authHeader == null ||
            !authHeader.startsWith("Bearer ")
        ) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authHeader.substring(7);

        try {
            if (
                jwtUtil.validateToken(token) &&
                SecurityContextHolder
                    .getContext()
                    .getAuthentication() == null
            ) {
                String username =
                    jwtUtil.extractUsername(token);

                UsernamePasswordAuthenticationToken
                    authentication =
                        new UsernamePasswordAuthenticationToken(
                            username,
                            null,
                            Collections.emptyList()
                        );

                authentication.setDetails(
                    new WebAuthenticationDetailsSource()
                        .buildDetails(request)
                );

                SecurityContextHolder
                    .getContext()
                    .setAuthentication(authentication);
            }
        } catch (Exception exception) {
            /*
             * Clear invalid authentication, but do not send
             * a response directly from this filter.
             *
             * Spring Security will decide whether the requested
             * endpoint requires authentication.
             */
            SecurityContextHolder.clearContext();
        }

        filterChain.doFilter(request, response);
    }
}