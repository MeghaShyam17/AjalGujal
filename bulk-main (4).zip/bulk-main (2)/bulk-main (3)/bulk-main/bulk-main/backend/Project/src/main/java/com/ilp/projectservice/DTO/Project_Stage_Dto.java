package com.ilp.projectservice.DTO;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class Project_Stage_Dto {

    private Long projectStageId;

    @NotNull(message = "Project Id is required")
    private Integer projectId;

    @NotNull(message = "Stage Id is required")
    private Integer stageId;

    @Positive(message = "Version Number must be greater than 0")
    private Double versionNo;

    private String submissionStatus;

    private Integer submittedBy;

    private LocalDateTime submittedOn;

    private LocalDate stageDeadline;

    private Integer reviewedBy;

    private LocalDateTime reviewedOn;

    private Boolean currentStage;

    private String remarks;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    // Getters and Setters

    public Long getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Long projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public Double getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(Double versionNo) {
        this.versionNo = versionNo;
    }

    public String getSubmissionStatus() {
        return submissionStatus;
    }

    public void setSubmissionStatus(String submissionStatus) {
        this.submissionStatus = submissionStatus;
    }

    public Integer getSubmittedBy() {
        return submittedBy;
    }

    public void setSubmittedBy(Integer submittedBy) {
        this.submittedBy = submittedBy;
    }

    public LocalDateTime getSubmittedOn() {
        return submittedOn;
    }

    public void setSubmittedOn(LocalDateTime submittedOn) {
        this.submittedOn = submittedOn;
    }

    public LocalDate getStageDeadline() {
        return stageDeadline;
    }

    public void setStageDeadline(LocalDate stageDeadline) {
        this.stageDeadline = stageDeadline;
    }

    public Integer getReviewedBy() {
        return reviewedBy;
    }

    public void setReviewedBy(Integer reviewedBy) {
        this.reviewedBy = reviewedBy;
    }

    public LocalDateTime getReviewedOn() {
        return reviewedOn;
    }

    public void setReviewedOn(LocalDateTime reviewedOn) {
        this.reviewedOn = reviewedOn;
    }

    public Boolean getCurrentStage() {
        return currentStage;
    }

    public void setCurrentStage(Boolean currentStage) {
        this.currentStage = currentStage;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}