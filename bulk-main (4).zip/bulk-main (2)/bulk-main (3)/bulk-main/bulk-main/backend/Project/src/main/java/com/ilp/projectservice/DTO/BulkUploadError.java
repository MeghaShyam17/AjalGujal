package com.ilp.projectservice.DTO;

public record BulkUploadError(
        String sheetName,
        int rowNumber,
        String message) {
}
