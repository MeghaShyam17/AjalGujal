package com.ilp.projectservice.DTO;

import java.util.Map;

public record BulkUploadResult(
        boolean success,
        int projectsInserted,
        int membersInserted,
        String message,
        Map<String, Integer> generatedProjectIds) {
}
