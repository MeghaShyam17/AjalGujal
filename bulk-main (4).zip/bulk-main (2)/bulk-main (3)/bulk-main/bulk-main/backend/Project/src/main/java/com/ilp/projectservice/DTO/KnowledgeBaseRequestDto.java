package com.ilp.projectservice.DTO;

public class KnowledgeBaseRequestDto {
    private Integer projectStageId;
    private Long documentId;
    private String title;
    private String category;
    private String description;
    private Integer publishedBy;
    private String visibility;

    public KnowledgeBaseRequestDto() {
    }

    public KnowledgeBaseRequestDto(Integer projectStageId, Long documentId, String title,
                                   String category, String description,
                                   Integer publishedBy, String visibility) {
        this.projectStageId = projectStageId;
        this.documentId = documentId;
        this.title = title;
        this.category = category;
        this.description = description;
        this.publishedBy = publishedBy;
        this.visibility = visibility;
    }

    public Integer getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Integer projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPublishedBy() {
        return publishedBy;
    }

    public void setPublishedBy(Integer publishedBy) {
        this.publishedBy = publishedBy;
    }

    public String getVisibility() {
        return visibility;
    }

    public void setVisibility(String visibility) {
        this.visibility = visibility;
    }
}
