//package com.ilp.projectservice.DTO;
//
//public class UserResponseDto {
//
//    private Integer userId;
//    private String employeeId;
//    private String userName;
//    private String email;
//    private String role;
//
//    public Integer getUserId() {
//        return userId;
//    }
//
//    public void setUserId(Integer userId) {
//        this.userId = userId;
//    }
//
//    public String getEmployeeId() {
//        return employeeId;
//    }
//
//    public void setEmployeeId(String employeeId) {
//        this.employeeId = employeeId;
//    }
//
//    public String getUserName() {
//        return userName;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getRole() {
//        return role;
//    }
//
//    public void setRole(String role) {
//        this.role = role;
//    }
//}



//package com.ilp.inventory_service.Dto;
//
//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//
//@JsonIgnoreProperties(ignoreUnknown = true)
//public class UserDto {
//
//    private Long userId;
//    private String userName;
//    private String email;
//    private String role;
//    private String mobileNumber;
//
//    // Default Constructor
//    public UserDto() {
//    }
//
//    // Parameterized Constructor
//    public UserDto(Long userId, String userName, String email,
//                   String role, String mobileNumber) {
//        this.userId = userId;
//        this.userName = userName;
//        this.email = email;
//        this.role = role;
//        this.mobileNumber = mobileNumber;
//    }
//
//    // Getters and Setters
//
//    public Long getUserId() {
//        return userId;
//    }
//
//    public void setUserId(Long userId) {
//        this.userId = userId;
//    }
//
//    public String getUserName() {
//        return userName;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getRole() {
//        return role;
//    }
//
//    public void setRole(String role) {
//        this.role = role;
//    }
//
//    public String getMobileNumber() {
//        return mobileNumber;
//    }
//
//    public void setMobileNumber(String mobileNumber) {
//        this.mobileNumber = mobileNumber;
//    }
//
//    @Override
//    public String toString() {
//        return "UserDto{" +
//                "userId=" + userId +
//                ", userName='" + userName + '\'' +
//                ", email='" + email + '\'' +
//                ", role='" + role + '\'' +
//                ", mobileNumber='" + mobileNumber + '\'' +
//                '}';
//    }
//}
package com.ilp.projectservice.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserResponseDto {

    private Long userId;

    @JsonProperty("name")
    private String userName;

    private String email;

    private RoleDto role;

    @JsonProperty("phone")
    private String mobileNumber;

    // Default Constructor
    public UserResponseDto() {
    }

    // Parameterized Constructor
    public UserResponseDto(Long userId,
                   String userName,
                   String email,
                   RoleDto role,
                   String mobileNumber) {
        this.userId = userId;
        this.userName = userName;
        this.email = email;
        this.role = role;
        this.mobileNumber = mobileNumber;
    }

    // Getter and Setter for userId
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    // Getter and Setter for userName
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    // Getter and Setter for email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for role
    public RoleDto getRole() {
        return role;
    }

    public void setRole(RoleDto role) {
        this.role = role;
    }

    // Getter and Setter for mobileNumber
    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    @Override
    public String toString() {
        return "UserDto{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", email='" + email + '\'' +
                ", role=" + role +
                ", mobileNumber='" + mobileNumber + '\'' +
                '}';
    }
}