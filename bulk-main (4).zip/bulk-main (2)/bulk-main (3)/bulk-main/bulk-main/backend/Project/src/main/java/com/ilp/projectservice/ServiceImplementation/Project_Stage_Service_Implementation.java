package com.ilp.projectservice.ServiceImplementation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.Client.DocumentClient;
import com.ilp.projectservice.DTO.DocumentRequestDto;
import com.ilp.projectservice.Entity.Project_Stage_Entity;
import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Repository.Project_Stage_Repository;
import com.ilp.projectservice.Repository.Stage_Master_Repository;
import com.ilp.projectservice.Repository.ProjectTeamRepository;
import com.ilp.projectservice.Service.Project_Stage_Service;

@Service
public class Project_Stage_Service_Implementation
        implements Project_Stage_Service {

    @Autowired
    private Project_Stage_Repository repository;

    @Autowired
    private Stage_Master_Repository stageMasterRepository;

    @Autowired
    private ProjectTeamRepository projectTeamRepository;

    @Autowired
    private DocumentClient documentClient;
    @Override
    public void initializeProjectStages(Integer projectId) {
        if (!repository.findByProjectId(projectId).isEmpty()) {
            throw new RuntimeException("Stages already initialized for this project");
        }

        ProjectTeam project = projectTeamRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found with ID: " + projectId));

        Integer batchId = project.getBatchId();
        List<Stage_Master_Entity> stages;
        if (batchId != null) {
            stages = stageMasterRepository.findByBatchIdOrderByStageNoAsc(batchId);
            if (stages.isEmpty()) {
                stages = stageMasterRepository.findByBatchIdIsNullOrderByStageNoAsc();
            }
        } else {
            stages = stageMasterRepository.findByBatchIdIsNullOrderByStageNoAsc();
        }

        for (Stage_Master_Entity stageMaster : stages) {
            Project_Stage_Entity stage = new Project_Stage_Entity();
            stage.setProjectId(projectId);
            stage.setStageMaster(stageMaster);
            stage.setVersionNo(1);

            if (stageMaster.getStageNo() == 1) {
                stage.setSubmissionStatus("IN_PROGRESS");
                stage.setCurrentStage(true);
            } else {
                stage.setSubmissionStatus("NOT_STARTED");
                stage.setCurrentStage(false);
            }

            repository.save(stage);
        }
    }

    @Override
    public Project_Stage_Entity saveProjectStage(
            Project_Stage_Entity projectStage) {

        if (projectStage.getStageDeadline() != null
                && projectStage.getStageDeadline()
                        .isBefore(LocalDate.now())
                && !"APPROVED".equals(
                        projectStage.getSubmissionStatus())) {

            projectStage.setIsOverdue(true);
        }

        return repository.save(projectStage);
    }

    @Override
    public List<Project_Stage_Entity> getAllProjectStages() {

        return repository.findAll();
    }

    @Override
    public Project_Stage_Entity getProjectStageById(Long id) {

        System.out.println("Searching Project Stage ID = " + id);

        Project_Stage_Entity stage =
                repository.findById(id).orElse(null);

        System.out.println("Database Result = " + stage);

        return stage;
    }

    @Override
    public void deleteProjectStage(Long id) {

        repository.deleteById(id);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public Project_Stage_Entity updateProjectStage(
            Long id,
            Project_Stage_Entity projectStage) {

        Project_Stage_Entity existing =
                repository.findById(id).orElse(null);

        if (existing == null) {
            return null;
        }

        String oldStatus =
                existing.getSubmissionStatus();

        String newStatus =
                projectStage.getSubmissionStatus();

        if ("APPROVED".equals(oldStatus)
                && "IN_PROGRESS".equals(newStatus)) {

            existing.setVersionNo(
                    existing.getVersionNo() + 1);
        }

        existing.setSubmissionStatus(newStatus);
        existing.setSubmittedBy(projectStage.getSubmittedBy());
        existing.setSubmittedOn(projectStage.getSubmittedOn());
        existing.setReviewedBy(projectStage.getReviewedBy());
        existing.setReviewedOn(projectStage.getReviewedOn());
        existing.setRemarks(projectStage.getRemarks());
        existing.setStageDeadline(projectStage.getStageDeadline());
        existing.setIsAcknowledged(projectStage.getIsAcknowledged());

        if ("APPROVED".equals(newStatus) && !"APPROVED".equals(oldStatus)) {

            existing.setCurrentStage(false);

            Integer currentStageNo =
                    existing.getStageMaster().getStageNo();

            List<Project_Stage_Entity> projectStages =
                    repository.findByProjectId(
                            existing.getProjectId());

            Project_Stage_Entity nextStage =
                    projectStages.stream()
                            .filter(ps ->
                                    ps.getStageMaster()
                                            .getStageNo()
                                            .equals(currentStageNo + 1))
                            .findFirst()
                            .orElse(null);

            if (nextStage != null) {

                nextStage.setCurrentStage(true);
                nextStage.setSubmissionStatus("IN_PROGRESS");

                repository.save(nextStage);
            }

            if (currentStageNo == 10
                    && Boolean.TRUE.equals(
                            existing.getIsAcknowledged())) {

                try {

                    List<com.ilp.projectservice.DTO.DocumentResponseDto>
                            documents =
                            documentClient
                                    .getDocumentsByProjectStageId(
                                            existing.getProjectStageId());

                    if (documents != null) {

                        for (com.ilp.projectservice.DTO.DocumentResponseDto doc
                                : documents) {

                            com.ilp.projectservice.DTO.KnowledgeBaseRequestDto
                                    kbRequest =
                                    new com.ilp.projectservice.DTO
                                            .KnowledgeBaseRequestDto();

                            kbRequest.setProjectStageId(
                                    existing.getProjectStageId()
                                            .intValue());

                            kbRequest.setDocumentId(
                                    doc.getDocumentId());

                            kbRequest.setTitle(
                                    doc.getTitle());

                            kbRequest.setCategory(
                                    "Project Submission");

                            kbRequest.setDescription(
                                    doc.getDescription() != null
                                            ? doc.getDescription()
                                            : "Approved Project Stage 10 Submission");

                            kbRequest.setPublishedBy(
                                    existing.getReviewedBy() != null
                                            ? existing.getReviewedBy()
                                            : 1);

                            kbRequest.setVisibility(
                                    "Internal");

                            try {

                                documentClient.createKnowledgeBase(
                                        kbRequest);

                            } catch (Exception ex) {

                                // Ignore duplicate or connection issues
                                // for individual knowledge base items.
                            }
                        }
                    }

                } catch (Exception ex) {

                    // Ignore document client failures so stage update
                    // does not fail if document service is unavailable.
                }
            }

        } else if ("REJECTED".equals(newStatus)) {

            existing.setCurrentStage(true);

            if (!"REJECTED".equals(oldStatus)) {

                Integer currentVersion =
                        existing.getVersionNo() == null
                                ? 1
                                : existing.getVersionNo();

                existing.setVersionNo(
                        currentVersion + 1);
            }

        } else {

            existing.setCurrentStage(
                    projectStage.getCurrentStage());
        }

        if (existing.getStageDeadline() != null
                && existing.getStageDeadline()
                        .isBefore(LocalDate.now())
                && !"APPROVED".equals(
                        existing.getSubmissionStatus())) {

            existing.setIsOverdue(true);

        } else {

            existing.setIsOverdue(false);
        }

        return repository.save(existing);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public void uploadDocument(
            Long projectStageId,
            Integer uploadedBy,
            MultipartFile file,
            String description,
            Integer versionNo) {

        try {

            Project_Stage_Entity stage =
                    repository.findById(projectStageId)
                            .orElseThrow(() ->
                                    new RuntimeException(
                                            "Project stage not found"));

            if (!Boolean.TRUE.equals(stage.getCurrentStage())) {

                throw new RuntimeException(
                        "Cannot upload document for a stage that is not the current active stage");
            }

            if ("APPROVED".equals(stage.getSubmissionStatus())) {

                throw new RuntimeException(
                        "Cannot upload document for an already approved stage");
            }

            Integer targetVersion =
                    versionNo != null && versionNo > 0
                            ? versionNo
                            : stage.getVersionNo();

            if (targetVersion == null || targetVersion <= 0) {
                targetVersion = 1;
            }

            DocumentRequestDto document =
                    new DocumentRequestDto();

            document.setProjectStageId(
                    projectStageId.intValue());

            document.setUploadedBy(
                    uploadedBy);

            document.setVersionNo(
                    targetVersion);

            document.setDocumentType(
                    "Submission");

            document.setTitle(
                    file.getOriginalFilename());

            document.setFileName(
                    file.getOriginalFilename());

            document.setOriginalFileName(
                    file.getOriginalFilename());

            document.setFileSize(
                    file.getSize());

            document.setFileData(
                    file.getBytes());

            document.setDescription(
                    description);

            documentClient.createDocument(document);

            stage.setSubmissionStatus("SUBMITTED");
            stage.setSubmittedBy(uploadedBy);
            stage.setSubmittedOn(
                    java.time.LocalDateTime.now());

            stage.setVersionNo(targetVersion);

            repository.save(stage);

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to upload document",
                    e);
        }
    }
}