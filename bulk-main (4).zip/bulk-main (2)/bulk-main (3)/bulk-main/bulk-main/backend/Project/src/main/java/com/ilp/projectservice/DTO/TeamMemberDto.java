package com.ilp.projectservice.DTO;

public class TeamMemberDto {

    private Integer teamMemberId;
    private Integer projectId;
    private Integer traineeId;
    private String memberRole;

    public TeamMemberDto() {
    }

    public TeamMemberDto(
            Integer teamMemberId,
            Integer projectId,
            Integer traineeId,
            String memberRole) {
        this.teamMemberId = teamMemberId;
        this.projectId = projectId;
        this.traineeId = traineeId;
        this.memberRole = memberRole;
    }

    public Integer getTeamMemberId() {
        return teamMemberId;
    }

    public void setTeamMemberId(Integer teamMemberId) {
        this.teamMemberId = teamMemberId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getTraineeId() {
        return traineeId;
    }

    public void setTraineeId(Integer traineeId) {
        this.traineeId = traineeId;
    }

    public String getMemberRole() {
        return memberRole;
    }

    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }

    @Override
    public String toString() {
        return "TeamMemberDto{" +
                "teamMemberId=" + teamMemberId +
                ", projectId=" + projectId +
                ", traineeId=" + traineeId +
                ", memberRole='" + memberRole + '\'' +
                '}';
    }
}
