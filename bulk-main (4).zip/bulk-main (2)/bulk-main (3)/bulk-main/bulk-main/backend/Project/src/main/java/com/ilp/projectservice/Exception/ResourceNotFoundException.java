package com.ilp.projectservice.Exception;

public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
    
    public ResourceNotFoundException(String resourceName, Object resourceId) {
        super(resourceName + " not found with ID: " + resourceId);
    }
}