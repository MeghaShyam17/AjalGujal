package com.ilp.projectservice.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(
    name = "team_member",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_team_member_project_trainee",
            columnNames = {"project_id", "trainee_id"}
        )
    }
)
public class TeamMember {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "team_member_id")
    private Integer teamMemberId;

    // Foreign key referencing project_team.project_id
    @Column(name = "project_id")
    private Integer projectId;

    // Foreign key referencing users.user_id
    @Column(name = "trainee_id")
    private Integer traineeId;

    // Valid values: Leader, Developer, Tester
    @Column(name = "member_role", length = 50)
    private String memberRole;
    
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
    
    public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public TeamMember() {
    }

	public TeamMember(
	        Integer projectId,
	        Integer traineeId,
	        String memberRole) {

	    this.projectId = projectId;
	    this.traineeId = traineeId;
	    this.memberRole = memberRole;
	    this.isDeleted = false;
	}

    public Integer getTeamMemberId() {
        return teamMemberId;
    }

    public void setTeamMemberId(Integer teamMemberId) {
        this.teamMemberId = teamMemberId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getTraineeId() {
        return traineeId;
    }

    public void setTraineeId(Integer traineeId) {
        this.traineeId = traineeId;
    }

    public String getMemberRole() {
        return memberRole;
    }

    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }

    @Override
    public String toString() {
        return "TeamMember{" +
                "teamMemberId=" + teamMemberId +
                ", projectId=" + projectId +
                ", traineeId=" + traineeId +
                ", memberRole='" + memberRole + '\'' +
                ", isDeleted=" + isDeleted +
                '}';
    }
}

