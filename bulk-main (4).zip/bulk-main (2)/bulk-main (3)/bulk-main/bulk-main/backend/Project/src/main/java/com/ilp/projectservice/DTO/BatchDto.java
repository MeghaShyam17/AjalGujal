package com.ilp.projectservice.DTO;

import java.time.LocalDate;

public class BatchDto {
    private Integer batchId;
    private String batchName;
    private Integer year;
    private LocalDate startDate;
    private LocalDate endDate;

    public BatchDto() {}

    public BatchDto(Integer batchId, String batchName, Integer year, LocalDate startDate, LocalDate endDate) {
        this.batchId = batchId;
        this.batchName = batchName;
        this.year = year;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public String getBatchName() {
        return batchName;
    }

    public void setBatchName(String batchName) {
        this.batchName = batchName;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
