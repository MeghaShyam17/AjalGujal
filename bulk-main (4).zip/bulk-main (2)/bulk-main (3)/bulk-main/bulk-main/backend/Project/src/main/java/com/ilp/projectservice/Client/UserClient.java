package com.ilp.projectservice.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.ilp.projectservice.DTO.UserResponseDto;

@FeignClient(
        name = "user-service",
        url = "${user.service.url}"
)
public interface UserClient {

    @GetMapping("/api/users/{userId}")
    UserResponseDto getUserById(
            @PathVariable Integer userId);

    @GetMapping("/api/users/email/{email}")
    UserResponseDto getUserByEmail(
            @PathVariable("email") String email);

    @PostMapping("/api/users/auto-register")
    UserResponseDto autoRegisterUser(
            @RequestBody com.ilp.projectservice.DTO.RegisterUserRequestDto request);

    @PostMapping("/api/batches")
    com.ilp.projectservice.DTO.BatchDto createBatch(
            @RequestBody com.ilp.projectservice.DTO.BatchDto batch);

    @GetMapping("/api/batches")
    java.util.List<com.ilp.projectservice.DTO.BatchDto> getBatches();
}