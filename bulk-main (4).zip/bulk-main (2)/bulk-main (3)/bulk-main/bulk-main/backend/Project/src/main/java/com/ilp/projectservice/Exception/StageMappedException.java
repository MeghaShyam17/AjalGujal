package com.ilp.projectservice.Exception;

public class StageMappedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public StageMappedException(String message) {
        super(message);
    }
}