package com.ilp.projectservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.ApiResponse;
import com.ilp.projectservice.Entity.Project_Stage_Entity;
import com.ilp.projectservice.Service.Project_Stage_Service;

@RestController
@RequestMapping("/project-stage")
public class Project_Stage_Controller {

    @Autowired
    private Project_Stage_Service projectStageService;

    @PostMapping("/initialize/{projectId}")
    public ResponseEntity<ApiResponse> initializeStages(
            @PathVariable Integer projectId) {

        projectStageService.initializeProjectStages(projectId);

        ApiResponse response =
                new ApiResponse(
                        "Stages created successfully",
                        true);

        return new ResponseEntity<>(
                response,
                HttpStatus.CREATED);
    }

    @PostMapping("/save")
    public Project_Stage_Entity saveProjectStage(
            @RequestBody Project_Stage_Entity projectStage) {

        return projectStageService.saveProjectStage(
                projectStage);
    }

    @GetMapping("/all")
    public List<Project_Stage_Entity> getAllProjectStages() {

        return projectStageService.getAllProjectStages();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Project_Stage_Entity> getProjectStageById(
            @PathVariable Long id) {

        Project_Stage_Entity stage =
                projectStageService.getProjectStageById(id);

        System.out.println("RETURNING PROJECT STAGE = " + stage);

        return ResponseEntity.ok(stage);
    }

    @DeleteMapping("/{id}")
    public String deleteProjectStage(
            @PathVariable Long id) {

        projectStageService.deleteProjectStage(id);

        return "Project Stage deleted successfully";
    }

    @PutMapping("/{id}")
    public Project_Stage_Entity updateProjectStage(
            @PathVariable Long id,
            @RequestBody Project_Stage_Entity projectStage) {

        projectStage.setProjectStageId(id);

        return projectStageService.updateProjectStage(
                id,
                projectStage);
    }

    @PostMapping(
            value = "/upload-document",
            consumes = "multipart/form-data")
    public ResponseEntity<String> uploadDocument(
            @RequestParam Long projectStageId,
            @RequestParam Integer uploadedBy,
            @RequestParam MultipartFile file,
            @RequestParam String description,
            @RequestParam Integer versionNo) {

        projectStageService.uploadDocument(
                projectStageId,
                uploadedBy,
                file,
                description,
                versionNo);

        return ResponseEntity.ok(
                "Document uploaded successfully");
    }
}