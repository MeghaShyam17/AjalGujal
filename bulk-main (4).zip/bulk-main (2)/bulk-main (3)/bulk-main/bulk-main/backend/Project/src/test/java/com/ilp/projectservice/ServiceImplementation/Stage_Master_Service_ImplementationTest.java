package com.ilp.projectservice.ServiceImplementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Exception.StageMappedException;
import com.ilp.projectservice.Repository.Project_Stage_Repository;
import com.ilp.projectservice.Repository.Stage_Master_Repository;

@ExtendWith(MockitoExtension.class)
class Stage_Master_Service_ImplementationTest {

    @Mock
    private Stage_Master_Repository repository;

    @Mock
    private Project_Stage_Repository projectStageRepository;

    @InjectMocks
    private Stage_Master_Service_Implementation service;

    @Test
    void shouldSaveStageSuccessfully() {

        Stage_Master_Entity stage =
                new Stage_Master_Entity();

        stage.setStageNo(1);
        stage.setStageName("Idea Submission");

        when(repository.findByStageNo(1))
                .thenReturn(Optional.empty());

        when(repository.save(stage))
                .thenReturn(stage);

        Stage_Master_Entity result =
                service.saveStage(stage);

        assertNotNull(result);

        verify(repository).save(stage);
    }

    @Test
    void shouldThrowExceptionWhenStageNumberAlreadyExists() {

        Stage_Master_Entity stage =
                new Stage_Master_Entity();

        stage.setStageNo(1);

        when(repository.findByStageNo(1))
                .thenReturn(Optional.of(stage));

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.saveStage(stage));

        assertEquals(
                "Stage number already exists",
                exception.getMessage());
    }

    @Test
    void shouldReturnAllStages() {

        Stage_Master_Entity stage1 =
                new Stage_Master_Entity();

        Stage_Master_Entity stage2 =
                new Stage_Master_Entity();

        when(repository.findAllByOrderByStageNoAsc())
                .thenReturn(Arrays.asList(stage1, stage2));

        assertEquals(
                2,
                service.getAllStages().size());
    }

    @Test
    void shouldReturnEmptyStageList() {

        when(repository.findAllByOrderByStageNoAsc())
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getAllStages().isEmpty());
    }

    @Test
    void shouldReturnStageById() {

        Stage_Master_Entity stage =
                new Stage_Master_Entity();

        stage.setStageId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(stage));

        Stage_Master_Entity result =
                service.getStageById(1L);

        assertEquals(
                1L,
                result.getStageId());
    }

    @Test
    void shouldThrowExceptionWhenStageNotFound() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.getStageById(1L));

        assertEquals(
                "Stage not found",
                exception.getMessage());
    }

    @Test
    void shouldUpdateStageSuccessfully() {

        Stage_Master_Entity existing =
                new Stage_Master_Entity();

        existing.setStageId(1L);
        existing.setStageNo(1);
        existing.setStageName("Old");

        Stage_Master_Entity updated =
                new Stage_Master_Entity();

        updated.setStageNo(2);
        updated.setStageName("New");
        updated.setDescription("Updated");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Stage_Master_Entity.class)))
                .thenReturn(existing);

        Stage_Master_Entity result =
                service.updateStage(1L, updated);

        assertNotNull(result);

        assertEquals(
                2,
                existing.getStageNo());

        assertEquals(
                "New",
                existing.getStageName());
    }

    @Test
    void shouldThrowExceptionWhenUpdatingMissingStage() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.updateStage(
                                1L,
                                new Stage_Master_Entity()));

        assertEquals(
                "Stage not found",
                exception.getMessage());
    }

    @Test
    void shouldDeleteStageSuccessfully() {

        Stage_Master_Entity stage =
                new Stage_Master_Entity();

        stage.setStageId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(stage));

        when(projectStageRepository
                .existsByStageMaster_StageId(1L))
                        .thenReturn(false);

        service.deleteStage(1L);

        verify(repository)
                .delete(stage);
    }

    @Test
    void shouldThrowExceptionWhenDeletingMappedStage() {

        Stage_Master_Entity stage =
                new Stage_Master_Entity();

        stage.setStageId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(stage));

        when(projectStageRepository
                .existsByStageMaster_StageId(1L))
                        .thenReturn(true);

        StageMappedException exception =
                assertThrows(
                        StageMappedException.class,
                        () -> service.deleteStage(1L));

        assertEquals(
                "Cannot delete stage. Stage is already mapped to one or more projects.",
                exception.getMessage());
    }

    @Test
    void shouldThrowExceptionWhenDeletingMissingStage() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> service.deleteStage(1L));

        assertEquals(
                "Stage not found",
                exception.getMessage());
    }
}