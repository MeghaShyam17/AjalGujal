package com.ilp.projectservice.Entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "project_stage",
       uniqueConstraints = {
            @UniqueConstraint(columnNames = {"project_id", "stage_id"})
       })
public class Project_Stage_Entity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "project_stage_id")
    private Long projectStageId;

    @Column(name = "project_id")
    private Integer projectId;

    @ManyToOne
    @JoinColumn(name = "stage_id")
    private Stage_Master_Entity stageMaster;

    @Column(name = "version_no")
    private Integer versionNo;

    @Column(name = "submission_status")
    private String submissionStatus;

    @Column(name = "submitted_by")
    private Integer submittedBy;

    @Column(name = "submitted_on")
    private LocalDateTime submittedOn;

    @Column(name = "stage_deadline")
    private LocalDate stageDeadline;

    @Column(name = "reviewed_by")
    private Integer reviewedBy;

    @Column(name = "reviewed_on")
    private LocalDateTime reviewedOn;

    @Column(name = "current_stage")
    private Boolean currentStage;
    
    @Column(name = "is_overdue")
    private Boolean isOverdue = false;

    @Column(name = "is_acknowledged")
    private Boolean isAcknowledged = false;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
   
    
    public Boolean getIsAcknowledged() {
        return isAcknowledged;
    }

    public void setIsAcknowledged(Boolean isAcknowledged) {
        this.isAcknowledged = isAcknowledged;
    }

    public Boolean getIsOverdue() {
		return isOverdue;
	}

	public void setIsOverdue(Boolean isOverdue) {
		this.isOverdue = isOverdue;
	}

	public Long getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Long projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Stage_Master_Entity getStageMaster() {
        return stageMaster;
    }

    public void setStageMaster(Stage_Master_Entity stageMaster) {
        this.stageMaster = stageMaster;
    }

    public Integer getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(Integer versionNo) {
        this.versionNo = versionNo;
    }

    public String getSubmissionStatus() {
        return submissionStatus;
    }

    public void setSubmissionStatus(String submissionStatus) {
        this.submissionStatus = submissionStatus;
    }

    public Integer getSubmittedBy() {
        return submittedBy;
    }

    public void setSubmittedBy(Integer submittedBy) {
        this.submittedBy = submittedBy;
    }

    public LocalDateTime getSubmittedOn() {
        return submittedOn;
    }

    public void setSubmittedOn(LocalDateTime submittedOn) {
        this.submittedOn = submittedOn;
    }

    public LocalDate getStageDeadline() {
        return stageDeadline;
    }

    public void setStageDeadline(LocalDate stageDeadline) {
        this.stageDeadline = stageDeadline;
    }

    public Integer getReviewedBy() {
        return reviewedBy;
    }

    public void setReviewedBy(Integer reviewedBy) {
        this.reviewedBy = reviewedBy;
    }

    public LocalDateTime getReviewedOn() {
        return reviewedOn;
    }

    public void setReviewedOn(LocalDateTime reviewedOn) {
        this.reviewedOn = reviewedOn;
    }

    public Boolean getCurrentStage() {
        return currentStage;
    }

    public void setCurrentStage(Boolean currentStage) {
        this.currentStage = currentStage;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @PreUpdate
    public void preUpdate() {
        updatedAt = LocalDateTime.now();
    }

    @PrePersist
    public void prePersist() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();

        if (versionNo == null) {
            versionNo = 1;
        }

        if (currentStage == null) {
            currentStage = false;
        }

        if (isOverdue == null) {
            isOverdue = false;
        }

        if (isAcknowledged == null) {
            isAcknowledged = false;
        }
    }
}