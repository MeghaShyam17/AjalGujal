package com.ilp.projectservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ilp.projectservice.Entity.Project_Stage_Entity;

public interface Project_Stage_Repository
        extends JpaRepository<Project_Stage_Entity, Long> {

    boolean existsByStageMaster_StageId(Long stageId);

    List<Project_Stage_Entity> findByProjectId(Integer projectId);

    List<Project_Stage_Entity>
    findByProjectIdOrderByStageMaster_StageNoAsc(Integer projectId);
}