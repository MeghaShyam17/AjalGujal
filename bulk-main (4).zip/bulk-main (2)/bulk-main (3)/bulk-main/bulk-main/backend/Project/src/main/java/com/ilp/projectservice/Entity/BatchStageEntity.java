package com.ilp.projectservice.Entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(
    name = "batch_stage",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uq_batch_stage_number",
            columnNames = {"batch_id", "stage_no"}
        ),
        @UniqueConstraint(
            name = "uq_batch_stage_mapping",
            columnNames = {"batch_id", "stage_id"}
        )
    }
)
public class BatchStageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "batch_stage_id")
    private Long batchStageId;

    @Column(name = "batch_id", nullable = false)
    private Integer batchId;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "stage_id", nullable = false)
    private Stage_Master_Entity stage;

    @Column(name = "stage_no", nullable = false)
    private Integer stageNo;

    @Column(name = "stage_deadline", nullable = false)
    private LocalDate stageDeadline;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    public BatchStageEntity() {
    }

    @PrePersist
    public void prePersist() {
        LocalDateTime now = LocalDateTime.now();
        if (createdAt == null) {
            createdAt = now;
        }
        updatedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public Long getBatchStageId() {
        return batchStageId;
    }

    public void setBatchStageId(Long batchStageId) {
        this.batchStageId = batchStageId;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Stage_Master_Entity getStage() {
        return stage;
    }

    public void setStage(Stage_Master_Entity stage) {
        this.stage = stage;
    }

    public Integer getStageNo() {
        return stageNo;
    }

    public void setStageNo(Integer stageNo) {
        this.stageNo = stageNo;
    }

    public LocalDate getStageDeadline() {
        return stageDeadline;
    }

    public void setStageDeadline(LocalDate stageDeadline) {
        this.stageDeadline = stageDeadline;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
