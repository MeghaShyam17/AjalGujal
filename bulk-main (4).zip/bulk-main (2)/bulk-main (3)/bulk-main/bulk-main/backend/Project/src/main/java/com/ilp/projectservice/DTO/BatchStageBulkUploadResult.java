package com.ilp.projectservice.DTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Response returned after processing a Batch Stage Excel upload.
 */
public class BatchStageBulkUploadResult {

    private boolean success;
    private String message;
    private Integer batchId;
    private int rowsProcessed;
    private int stagesInserted;
    private int stagesSkipped;
    private List<BatchStageUploadError> errors = new ArrayList<>();

    public BatchStageBulkUploadResult() {
    }

    public BatchStageBulkUploadResult(
            boolean success,
            String message,
            Integer batchId,
            int rowsProcessed,
            int stagesInserted,
            int stagesSkipped,
            List<BatchStageUploadError> errors) {
        this.success = success;
        this.message = message;
        this.batchId = batchId;
        this.rowsProcessed = rowsProcessed;
        this.stagesInserted = stagesInserted;
        this.stagesSkipped = stagesSkipped;
        setErrors(errors);
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public int getRowsProcessed() {
        return rowsProcessed;
    }

    public void setRowsProcessed(int rowsProcessed) {
        this.rowsProcessed = rowsProcessed;
    }

    public int getStagesInserted() {
        return stagesInserted;
    }

    public void setStagesInserted(int stagesInserted) {
        this.stagesInserted = stagesInserted;
    }

    public int getStagesSkipped() {
        return stagesSkipped;
    }

    public void setStagesSkipped(int stagesSkipped) {
        this.stagesSkipped = stagesSkipped;
    }

    public List<BatchStageUploadError> getErrors() {
        return errors;
    }

    public void setErrors(List<BatchStageUploadError> errors) {
        this.errors = errors == null
            ? new ArrayList<>()
            : new ArrayList<>(errors);
    }

    public void addError(BatchStageUploadError error) {
        if (error != null) {
            this.errors.add(error);
        }
    }
}
