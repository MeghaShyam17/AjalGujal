package com.ilp.projectservice.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.projectservice.Entity.TeamMember;

@Repository
public interface TeamMemberRepository
        extends JpaRepository<TeamMember, Integer> {

    boolean existsByProjectIdAndTraineeId(
            Integer projectId,
            Integer traineeId);

    Optional<TeamMember> findByProjectIdAndTraineeId(
            Integer projectId,
            Integer traineeId);

    List<TeamMember> findByProjectId(
            Integer projectId);

    List<TeamMember> findByTraineeId(
            Integer traineeId);

    List<TeamMember> findByMemberRole(
            String memberRole);

    // Soft Delete Methods

    List<TeamMember> findByIsDeletedFalse();

    Optional<TeamMember> findByTeamMemberIdAndIsDeletedFalse(
            Integer teamMemberId);

    List<TeamMember> findByProjectIdAndIsDeletedFalse(
            Integer projectId);

    List<TeamMember> findByTraineeIdAndIsDeletedFalse(
            Integer traineeId);

    List<TeamMember> findByMemberRoleAndIsDeletedFalse(
            String memberRole);

    boolean existsByProjectIdAndTraineeIdAndIsDeletedFalse(
            Integer projectId,
            Integer traineeId);

    Optional<TeamMember>
    findByProjectIdAndTraineeIdAndIsDeletedFalse(
            Integer projectId,
            Integer traineeId);
}