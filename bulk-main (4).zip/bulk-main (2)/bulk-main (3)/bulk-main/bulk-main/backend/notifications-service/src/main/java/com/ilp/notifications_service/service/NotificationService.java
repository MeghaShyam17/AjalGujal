package com.ilp.notifications_service.service;

import com.ilp.notifications_service.dto.ApiResponse;
import com.ilp.notifications_service.dto.CreateNotificationRequest;
import com.ilp.notifications_service.dto.MarkNotificationReadRequest;

public interface NotificationService {

    ApiResponse createNotification(CreateNotificationRequest request);

    ApiResponse getNotificationsByUserId(Integer userId);

    ApiResponse getUnreadNotifications(Integer userId);

    ApiResponse markNotificationAsRead(MarkNotificationReadRequest request);

    ApiResponse getUnreadCount(Integer userId);
}