package com.ilp.notifications_service.mapper;

import org.springframework.stereotype.Component;

import com.ilp.notifications_service.dto.NotificationResponse;
import com.ilp.notifications_service.entity.NotificationEntity;

@Component
public class NotificationMapper {

    public NotificationResponse mapToResponse(
            NotificationEntity notification) {

        NotificationResponse response =
                new NotificationResponse();

        response.setNotificationId(
                notification.getNotificationId());

        response.setUserId(
                notification.getUserId());

        response.setTitle(
                notification.getTitle());

        response.setMessage(
                notification.getMessage());

        response.setNotificationType(
                notification.getNotificationType());

        response.setModuleName(
                notification.getModuleName());

        response.setReferenceId(
                notification.getReferenceId());

        response.setPriority(
                notification.getPriority());

        response.setIsRead(
                notification.getIsRead());

        response.setReadAt(
                notification.getReadAt());

        response.setCreatedBy(
                notification.getCreatedBy());

        response.setCreatedAt(
                notification.getCreatedAt());

        return response;
    }
}