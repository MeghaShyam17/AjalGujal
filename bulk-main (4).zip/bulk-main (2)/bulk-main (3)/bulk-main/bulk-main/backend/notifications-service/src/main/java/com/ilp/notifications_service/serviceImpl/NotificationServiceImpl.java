package com.ilp.notifications_service.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.ilp.notifications_service.dto.ApiResponse;
import com.ilp.notifications_service.dto.CreateNotificationRequest;
import com.ilp.notifications_service.dto.MarkNotificationReadRequest;
import com.ilp.notifications_service.dto.NotificationResponse;
import com.ilp.notifications_service.entity.NotificationEntity;
import com.ilp.notifications_service.exception.NotificationNotFoundException;
import com.ilp.notifications_service.mapper.NotificationMapper;
import com.ilp.notifications_service.repository.NotificationRepository;
import com.ilp.notifications_service.service.NotificationService;

@Service
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;

    private final NotificationMapper notificationMapper;

    public NotificationServiceImpl(
            NotificationRepository notificationRepository,
            NotificationMapper notificationMapper) {

        this.notificationRepository = notificationRepository;
        this.notificationMapper = notificationMapper;
    }

    @Override
    public ApiResponse createNotification(
            CreateNotificationRequest request) {

        NotificationEntity notification =
                new NotificationEntity();

        notification.setUserId(request.getUserId());
        notification.setTitle(request.getTitle());
        notification.setMessage(request.getMessage());
        notification.setNotificationType(
                request.getNotificationType());
        notification.setModuleName(
                request.getModuleName());
        notification.setReferenceId(
                request.getReferenceId());
        notification.setPriority(
                request.getPriority());
        notification.setCreatedBy(
                request.getCreatedBy());
        notification.setIsRead(false);
        notification.setCreatedAt(
                LocalDateTime.now());

        NotificationEntity savedNotification =
                notificationRepository.save(notification);

        return new ApiResponse(
                true,
                "Notification created successfully",
                notificationMapper.mapToResponse(
                        savedNotification));
    }

    @Override
    public ApiResponse getNotificationsByUserId(
            Integer userId) {

        List<NotificationResponse> notifications =
                notificationRepository
                        .findByUserIdOrderByCreatedAtDesc(
                                userId)
                        .stream()
                        .map(notificationMapper::mapToResponse)
                        .collect(Collectors.toList());

        return new ApiResponse(
                true,
                "Notifications fetched successfully",
                notifications);
    }

    @Override
    public ApiResponse getUnreadNotifications(
            Integer userId) {

        List<NotificationResponse> notifications =
                notificationRepository
                        .findByUserIdAndIsReadFalseOrderByCreatedAtDesc(
                                userId)
                        .stream()
                        .map(notificationMapper::mapToResponse)
                        .collect(Collectors.toList());

        return new ApiResponse(
                true,
                "Unread notifications fetched successfully",
                notifications);
    }

    @Override
    public ApiResponse markNotificationAsRead(
            MarkNotificationReadRequest request) {

        NotificationEntity notification =
                notificationRepository
                        .findById(
                                request.getNotificationId())
                        .orElseThrow(
                                () ->
                                        new NotificationNotFoundException(
                                                "Notification not found with id : "
                                                        + request.getNotificationId()));

        notification.setIsRead(true);
        notification.setReadAt(
                LocalDateTime.now());

        notificationRepository.save(notification);

        return new ApiResponse(
                true,
                "Notification marked as read",
                notificationMapper.mapToResponse(
                        notification));
    }

    @Override
    public ApiResponse getUnreadCount(
            Integer userId) {

        long unreadCount =
                notificationRepository
                        .countByUserIdAndIsReadFalse(
                                userId);

        return new ApiResponse(
                true,
                "Unread notification count fetched successfully",
                unreadCount);
    }
}