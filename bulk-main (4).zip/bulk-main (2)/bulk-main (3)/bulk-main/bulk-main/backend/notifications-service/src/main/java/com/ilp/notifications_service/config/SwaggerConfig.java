package com.ilp.notifications_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI notificationServiceOpenAPI() {

        return new OpenAPI()
                .info(new Info()
                        .title("Notification Service API")
                        .description("API documentation for Notification Service")
                        .version("1.0")
                        .contact(new Contact()
                                .name("ILP Team")
                                .email("support@ilp.com")));
    }
}