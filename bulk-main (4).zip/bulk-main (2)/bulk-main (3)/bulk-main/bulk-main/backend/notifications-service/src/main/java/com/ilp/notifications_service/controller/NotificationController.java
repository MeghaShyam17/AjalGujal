package com.ilp.notifications_service.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilp.notifications_service.dto.ApiResponse;
import com.ilp.notifications_service.dto.CreateNotificationRequest;
import com.ilp.notifications_service.dto.MarkNotificationReadRequest;
import com.ilp.notifications_service.service.NotificationService;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse> createNotification(
            @RequestBody CreateNotificationRequest request) {

        return ResponseEntity.ok(
                notificationService.createNotification(request));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse> getNotificationsByUserId(
            @PathVariable Integer userId) {

        return ResponseEntity.ok(
                notificationService.getNotificationsByUserId(userId));
    }

    @GetMapping("/user/{userId}/unread")
    public ResponseEntity<ApiResponse> getUnreadNotifications(
            @PathVariable Integer userId) {

        return ResponseEntity.ok(
                notificationService.getUnreadNotifications(userId));
    }

    @PutMapping("/read")
    public ResponseEntity<ApiResponse> markNotificationAsRead(
            @RequestBody MarkNotificationReadRequest request) {

        return ResponseEntity.ok(
                notificationService.markNotificationAsRead(request));
    }

    @GetMapping("/user/{userId}/unread-count")
    public ResponseEntity<ApiResponse> getUnreadCount(
            @PathVariable Integer userId) {

        return ResponseEntity.ok(
                notificationService.getUnreadCount(userId));
    }
}