package com.ilp.notifications_service.dto;

import jakarta.validation.constraints.*;


public class CreateNotificationRequest {

	@NotNull(message = "User Id is required")
	private Integer userId;

	@NotBlank(message = "Title is required")
	@Size(max = 150,
	      message = "Title cannot exceed 150 characters")
	private String title;

	@NotBlank(message = "Message is required")
	private String message;

	@NotBlank(message = "Notification Type is required")
	private String notificationType;

	@NotBlank(message = "Module Name is required")
	private String moduleName;

	@NotNull(message = "Reference Id is required")
	private Integer referenceId;

	@NotBlank(message = "Priority is required")
	private String priority;

	@NotNull(message = "Created By is required")
	private Integer createdBy;
    public CreateNotificationRequest() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public Integer getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(Integer referenceId) {
        this.referenceId = referenceId;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }
}