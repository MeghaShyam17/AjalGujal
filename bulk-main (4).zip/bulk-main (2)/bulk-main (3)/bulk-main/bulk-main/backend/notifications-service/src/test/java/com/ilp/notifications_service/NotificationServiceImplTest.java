package com.ilp.notifications_service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.notifications_service.dto.ApiResponse;
import com.ilp.notifications_service.dto.CreateNotificationRequest;
import com.ilp.notifications_service.dto.MarkNotificationReadRequest;
import com.ilp.notifications_service.dto.NotificationResponse;
import com.ilp.notifications_service.entity.NotificationEntity;
import com.ilp.notifications_service.exception.NotificationNotFoundException;
import com.ilp.notifications_service.mapper.NotificationMapper;
import com.ilp.notifications_service.repository.NotificationRepository;
import com.ilp.notifications_service.serviceImpl.NotificationServiceImpl;

@ExtendWith(MockitoExtension.class)
class NotificationServiceImplTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private NotificationMapper notificationMapper;

    @InjectMocks
    private NotificationServiceImpl notificationService;

    private NotificationEntity notificationEntity;

    private NotificationResponse notificationResponse;

    @BeforeEach
    void setUp() {

        notificationEntity = new NotificationEntity();

        notificationEntity.setNotificationId(1);
        notificationEntity.setUserId(100);
        notificationEntity.setTitle("Project Approved");
        notificationEntity.setMessage("Project approved");
        notificationEntity.setNotificationType("APPROVAL");
        notificationEntity.setModuleName("PROJECT");
        notificationEntity.setReferenceId(10);
        notificationEntity.setPriority("HIGH");
        notificationEntity.setIsRead(false);
        notificationEntity.setCreatedBy(1);
        notificationEntity.setCreatedAt(LocalDateTime.now());

        notificationResponse = new NotificationResponse();

        notificationResponse.setNotificationId(1);
        notificationResponse.setUserId(100);
    }

    @Test
    void createNotificationShouldCreateSuccessfully() {

        CreateNotificationRequest request =
                createNotificationRequest();

        when(notificationRepository.save(
                any(NotificationEntity.class)))
                .thenReturn(notificationEntity);

        when(notificationMapper.mapToResponse(
                notificationEntity))
                .thenReturn(notificationResponse);

        ApiResponse response =
                notificationService.createNotification(request);

        assertTrue(response.isSuccess());

        assertEquals(
                "Notification created successfully",
                response.getMessage());

        verify(notificationRepository)
                .save(any(NotificationEntity.class));

        verify(notificationMapper)
                .mapToResponse(notificationEntity);
    }

    @Test
    void createNotificationShouldPopulateEntityFields() {

        CreateNotificationRequest request =
                createNotificationRequest();

        when(notificationRepository.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        when(notificationMapper.mapToResponse(any()))
                .thenReturn(notificationResponse);

        notificationService.createNotification(request);

        verify(notificationRepository)
                .save(argThat(entity ->

                        entity.getUserId().equals(100)
                                && entity.getTitle()
                                        .equals("Project Approved")
                                && entity.getMessage()
                                        .equals("Project approved")
                                && entity.getNotificationType()
                                        .equals("APPROVAL")
                                && entity.getModuleName()
                                        .equals("PROJECT")
                                && entity.getReferenceId()
                                        .equals(10)
                                && entity.getPriority()
                                        .equals("HIGH")
                                && entity.getCreatedBy()
                                        .equals(1)
                                && !entity.getIsRead()));
    }

    @Test
    void createNotificationShouldMapSavedNotification() {

        CreateNotificationRequest request =
                createNotificationRequest();

        when(notificationRepository.save(any()))
                .thenReturn(notificationEntity);

        when(notificationMapper.mapToResponse(
                notificationEntity))
                .thenReturn(notificationResponse);

        ApiResponse response =
                notificationService.createNotification(request);

        NotificationResponse data =
                (NotificationResponse) response.getData();

        assertEquals(
                1,
                data.getNotificationId());

        assertEquals(
                100,
                data.getUserId());
    }

    @Test
    void createNotificationWhenRepositoryThrowsException() {

        CreateNotificationRequest request =
                createNotificationRequest();

        when(notificationRepository.save(any()))
                .thenThrow(
                        new RuntimeException(
                                "Database Error"));

        assertThrows(
                RuntimeException.class,
                () ->
                        notificationService
                                .createNotification(request));
    }

    @Test
    void getNotificationsByUserIdShouldReturnNotifications() {

        when(notificationRepository
                .findByUserIdOrderByCreatedAtDesc(100))
                .thenReturn(
                        Arrays.asList(notificationEntity));

        when(notificationMapper.mapToResponse(
                notificationEntity))
                .thenReturn(notificationResponse);

        ApiResponse response =
                notificationService
                        .getNotificationsByUserId(100);

        assertTrue(response.isSuccess());

        verify(notificationRepository)
                .findByUserIdOrderByCreatedAtDesc(100);

        verify(notificationMapper)
                .mapToResponse(notificationEntity);
    }

    @Test
    void getNotificationsByUserIdShouldReturnEmptyList() {

        when(notificationRepository
                .findByUserIdOrderByCreatedAtDesc(100))
                .thenReturn(Collections.emptyList());

        ApiResponse response =
                notificationService
                        .getNotificationsByUserId(100);

        assertTrue(response.isSuccess());
    }

    @Test
    void getUnreadNotificationsShouldReturnUnreadNotifications() {

        when(notificationRepository
                .findByUserIdAndIsReadFalseOrderByCreatedAtDesc(
                        100))
                .thenReturn(
                        Arrays.asList(notificationEntity));

        when(notificationMapper.mapToResponse(
                notificationEntity))
                .thenReturn(notificationResponse);

        ApiResponse response =
                notificationService
                        .getUnreadNotifications(100);

        assertTrue(response.isSuccess());

        verify(notificationRepository)
                .findByUserIdAndIsReadFalseOrderByCreatedAtDesc(
                        100);
    }

    @Test
    void getUnreadNotificationsShouldReturnEmptyList() {

        when(notificationRepository
                .findByUserIdAndIsReadFalseOrderByCreatedAtDesc(
                        100))
                .thenReturn(Collections.emptyList());

        ApiResponse response =
                notificationService
                        .getUnreadNotifications(100);

        assertTrue(response.isSuccess());
    }

    @Test
    void getUnreadNotificationsShouldReturnMappedList() {

        when(notificationRepository
                .findByUserIdAndIsReadFalseOrderByCreatedAtDesc(
                        100))
                .thenReturn(
                        Arrays.asList(notificationEntity));

        when(notificationMapper
                .mapToResponse(notificationEntity))
                .thenReturn(notificationResponse);

        ApiResponse response =
                notificationService
                        .getUnreadNotifications(100);

        assertNotNull(response.getData());

        verify(notificationMapper)
                .mapToResponse(notificationEntity);
    }

    @Test
    void markNotificationAsReadShouldMarkSuccessfully() {

        MarkNotificationReadRequest request =
                createReadRequest(1);

        when(notificationRepository.findById(1))
                .thenReturn(Optional.of(notificationEntity));

        when(notificationMapper
                .mapToResponse(notificationEntity))
                .thenReturn(notificationResponse);

        ApiResponse response =
                notificationService
                        .markNotificationAsRead(request);

        assertTrue(response.isSuccess());

        verify(notificationRepository)
                .save(notificationEntity);
    }

    @Test
    void markNotificationAsReadShouldSetReadFlagAndReadAt() {

        MarkNotificationReadRequest request =
                createReadRequest(1);

        notificationEntity.setIsRead(false);

        notificationEntity.setReadAt(null);

        when(notificationRepository.findById(1))
                .thenReturn(Optional.of(notificationEntity));

        when(notificationMapper
                .mapToResponse(notificationEntity))
                .thenReturn(notificationResponse);

        notificationService.markNotificationAsRead(request);

        assertTrue(notificationEntity.getIsRead());

        assertNotNull(notificationEntity.getReadAt());

        verify(notificationRepository)
                .save(notificationEntity);
    }

    @Test
    void markNotificationAsReadShouldSaveExactlyOnce() {

        MarkNotificationReadRequest request =
                createReadRequest(1);

        when(notificationRepository.findById(1))
                .thenReturn(Optional.of(notificationEntity));

        when(notificationMapper
                .mapToResponse(notificationEntity))
                .thenReturn(notificationResponse);

        notificationService.markNotificationAsRead(request);

        verify(notificationRepository, times(1))
                .save(notificationEntity);
    }

    @Test
    void markNotificationAsReadShouldThrowException() {

        MarkNotificationReadRequest request =
                createReadRequest(999);

        when(notificationRepository.findById(999))
                .thenReturn(Optional.empty());

        assertThrows(
                NotificationNotFoundException.class,
                () ->
                        notificationService
                                .markNotificationAsRead(request));
    }

    @Test
    void markNotificationAsReadShouldThrowCorrectMessage() {

        MarkNotificationReadRequest request =
                createReadRequest(999);

        when(notificationRepository.findById(999))
                .thenReturn(Optional.empty());

        NotificationNotFoundException ex =
                assertThrows(
                        NotificationNotFoundException.class,
                        () ->
                                notificationService
                                        .markNotificationAsRead(
                                                request));

        assertEquals(
                "Notification not found with id : 999",
                ex.getMessage());
    }

    @Test
    void getUnreadCountShouldReturnCount() {

        when(notificationRepository
                .countByUserIdAndIsReadFalse(100))
                .thenReturn(5L);

        ApiResponse response =
                notificationService.getUnreadCount(100);

        assertEquals(5L, response.getData());

        verify(notificationRepository)
                .countByUserIdAndIsReadFalse(100);
    }

    @Test
    void getUnreadCountShouldReturnZero() {

        when(notificationRepository
                .countByUserIdAndIsReadFalse(100))
                .thenReturn(0L);

        ApiResponse response =
                notificationService.getUnreadCount(100);

        assertEquals(0L, response.getData());
    }

    private CreateNotificationRequest createNotificationRequest() {

        CreateNotificationRequest request =
                new CreateNotificationRequest();

        request.setUserId(100);
        request.setTitle("Project Approved");
        request.setMessage("Project approved");
        request.setNotificationType("APPROVAL");
        request.setModuleName("PROJECT");
        request.setReferenceId(10);
        request.setPriority("HIGH");
        request.setCreatedBy(1);

        return request;
    }

    private MarkNotificationReadRequest createReadRequest(
            Integer id) {

        MarkNotificationReadRequest request =
                new MarkNotificationReadRequest();

        request.setNotificationId(id);

        return request;
    }
}