package com.ilp.notifications_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationsServiceApplicationTests {

    @Test
    void contextLoads() {
        // Verifies that the Spring application context loads successfully.
    }

    @Test
    void main() {
        NotificationsServiceApplication.main(new String[] {});
    }
}