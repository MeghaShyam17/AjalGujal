package com.ilp.notifications_service.dto;

public class MarkNotificationReadRequest {

    private Integer notificationId;

    public MarkNotificationReadRequest() {
    }

    public Integer getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Integer notificationId) {
        this.notificationId = notificationId;
    }
}