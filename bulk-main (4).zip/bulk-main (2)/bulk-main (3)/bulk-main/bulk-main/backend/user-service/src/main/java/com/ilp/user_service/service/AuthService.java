package com.ilp.user_service.service;

import com.ilp.user_service.dto.LoginRequest;
import com.ilp.user_service.dto.LoginResponse;
import com.ilp.user_service.dto.RegisterUserRequest;
import com.ilp.user_service.dto.ResetPasswordRequest;
public interface AuthService {

    LoginResponse login(LoginRequest loginRequest);

    String registerUser(RegisterUserRequest registerUserRequest);
    
    
    String resetPassword(
            Integer userId,
            ResetPasswordRequest request);
}