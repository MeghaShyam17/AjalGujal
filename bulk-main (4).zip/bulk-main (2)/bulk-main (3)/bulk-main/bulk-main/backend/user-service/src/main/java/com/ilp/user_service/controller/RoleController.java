package com.ilp.user_service.controller;

import com.ilp.user_service.entity.RoleEntity;
import com.ilp.user_service.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/roles")

public class RoleController {

    @Autowired
    private RoleService roleService;

    @PostMapping
    public ResponseEntity<RoleEntity> createRole(
            @RequestBody RoleEntity role) {

        RoleEntity savedRole = roleService.createRole(role);
        return ResponseEntity.ok(savedRole);
    }

    @GetMapping("/{roleId}")
    public ResponseEntity<RoleEntity> getRoleById(
            @PathVariable Integer roleId) {

        RoleEntity role = roleService.getRoleById(roleId);

        if (role == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(role);
    }

    @GetMapping
    public ResponseEntity<List<RoleEntity>> getAllRoles() {

        List<RoleEntity> roles = roleService.getAllRoles();
        return ResponseEntity.ok(roles);
    }

    @PutMapping("/{roleId}")
    public ResponseEntity<RoleEntity> updateRole(
            @PathVariable Integer roleId,
            @RequestBody RoleEntity role) {

        RoleEntity updatedRole =
                roleService.updateRole(roleId, role);

        if (updatedRole == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(updatedRole);
    }

    @DeleteMapping("/{roleId}")
    public ResponseEntity<String> deleteRole(
            @PathVariable Integer roleId) {

        roleService.deleteRole(roleId);

        return ResponseEntity.ok("Role deleted successfully");
    }
}