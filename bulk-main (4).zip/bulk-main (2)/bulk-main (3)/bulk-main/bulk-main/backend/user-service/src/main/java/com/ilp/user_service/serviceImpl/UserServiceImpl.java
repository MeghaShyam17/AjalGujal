package com.ilp.user_service.serviceImpl;
import com.ilp.user_service.dto.RegisterUserRequest;
import com.ilp.user_service.entity.BatchEntity;
import com.ilp.user_service.entity.RoleEntity;
import com.ilp.user_service.entity.UserEntity;
import com.ilp.user_service.exception.UserNotFoundException;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.service.UserService;
import com.ilp.user_service.dto.UserResponse;
import com.ilp.user_service.mapper.UserResponseMapper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final BatchRepository batchRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(
            UserRepository userRepository,
            RoleRepository roleRepository,
            BatchRepository batchRepository,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.batchRepository = batchRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserResponse createUser(UserEntity user) {
        UserEntity saved = userRepository.save(user);
        return UserResponseMapper.toResponse(saved);
    }

    @Override
    public UserResponse getUserById(Integer userId) {
        UserEntity user = userRepository.findById(userId).orElse(null);

        if (user == null || (!"ACTIVE".equals(user.getStatus()) && !"FORCE_PASSWORD_CHANGE".equals(user.getStatus()))) {
            throw new UserNotFoundException("User not found with ID: " + userId);
        }

        return UserResponseMapper.toResponse(user);
    }

    @Override
    public UserResponse updateUser(Integer userId, UserEntity user) {
        UserEntity existingUser = userRepository.findById(userId).orElse(null);

        if (existingUser == null || (!"ACTIVE".equals(existingUser.getStatus()) && !"FORCE_PASSWORD_CHANGE".equals(existingUser.getStatus()))) {
            throw new UserNotFoundException("User not found with ID: " + userId);
        }

        existingUser.setRole(user.getRole());
        existingUser.setBatch(user.getBatch());
        existingUser.setName(user.getName());
        existingUser.setPhone(user.getPhone());
        existingUser.setEmail(user.getEmail());
        existingUser.setGender(user.getGender());
        existingUser.setYear(user.getYear());
        existingUser.setProfileImage(user.getProfileImage());
        existingUser.setStatus(user.getStatus());
        existingUser.setUpdatedAt(user.getUpdatedAt());
        existingUser.setLastLogin(user.getLastLogin());
        existingUser.setDob(user.getDob());

        UserEntity saved = userRepository.save(existingUser);
        return UserResponseMapper.toResponse(saved);
    }

    @Override
    public void softDeleteUser(Integer userId) {
        UserEntity user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found"));

        user.setStatus("INACTIVE");
        userRepository.save(user);
    }

    @Override
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .filter(u -> "ACTIVE".equals(u.getStatus()) || "FORCE_PASSWORD_CHANGE".equals(u.getStatus()))
                .map(UserResponseMapper::toResponse)
                .toList();
    }

    @Override
    public UserResponse getUserByEmail(String email) {
        if (email == null) return null;
        UserEntity user = userRepository.findByEmail(email.trim().toLowerCase()).orElse(null);
        if (user == null || (!"ACTIVE".equals(user.getStatus()) && !"FORCE_PASSWORD_CHANGE".equals(user.getStatus()))) {
            return null;
        }
        return UserResponseMapper.toResponse(user);
    }

    @Override
    public UserResponse autoRegisterUser(com.ilp.user_service.dto.RegisterUserRequest request) {
        if (request.getUserId() == null) {
            throw new IllegalArgumentException("Trainee ID is required");
        }
        if (userRepository.existsById(request.getUserId())) {
            throw new IllegalArgumentException("User ID already exists: " + request.getUserId());
        }

        String email = request.getEmail().trim().toLowerCase();

        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email already exists: " + email);
        }

        if (request.getPhone() != null && !request.getPhone().isBlank()) {
            if (userRepository.existsByPhone(request.getPhone().trim())) {
                throw new IllegalArgumentException("Phone number already exists: " + request.getPhone());
            }
        }

        RoleEntity role = roleRepository.findByRoleName("Trainee")
                .orElseThrow(() -> new IllegalArgumentException("Role 'Trainee' not found. Please setup Trainee role."));

        BatchEntity batch = null;
        if (request.getBatchId() != null) {
            batch = batchRepository.findById(request.getBatchId()).orElse(null);
        }

        UserEntity user = new UserEntity();
        user.setUserId(request.getUserId());
        user.setDob(request.getDob());
        user.setName(request.getName().trim());
        user.setEmail(email);
        user.setPhone(request.getPhone() != null && !request.getPhone().isBlank() ? request.getPhone().trim() : null);
        user.setGender(request.getGender());
        user.setYear(request.getYear());
        user.setRole(role);
        user.setBatch(batch);
        user.setPasswordHash(passwordEncoder.encode(request.getPassword() != null ? request.getPassword() : "Temp@123"));
        user.setStatus("FORCE_PASSWORD_CHANGE");

        UserEntity saved = userRepository.save(user);
        return UserResponseMapper.toResponse(saved);
    }@Override
    public void deleteUser(Integer userId) {
        UserEntity user = userRepository.findById(userId).orElse(null);

        if (user == null) {
            throw new UserNotFoundException("User not found with ID: " + userId);
        }

        userRepository.delete(user);
    }

    @Override
    public String uploadUsers(MultipartFile file) {
        int uploadedCount = 0;
        java.util.List<String> errors = new java.util.ArrayList<>();

        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter formatter = new DataFormatter();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);

                if (row == null) {
                    continue;
                }

                String roleName = formatter.formatCellValue(row.getCell(0)).trim();
                String batchName = formatter.formatCellValue(row.getCell(1)).trim();
                String name = formatter.formatCellValue(row.getCell(2)).trim();
                String phone = formatter.formatCellValue(row.getCell(3)).trim();
                String email = formatter.formatCellValue(row.getCell(4)).trim().toLowerCase();
                String gender = formatter.formatCellValue(row.getCell(5)).trim();
                String yearText = formatter.formatCellValue(row.getCell(6)).trim();
                String password = formatter.formatCellValue(row.getCell(7)).trim();
                String userIdText = formatter.formatCellValue(row.getCell(8)).trim();
                String dobText = formatter.formatCellValue(row.getCell(9)).trim();

                // If all cells in the row are blank, skip it silently (blank line)
                if (roleName.isBlank() && batchName.isBlank() && name.isBlank() && phone.isBlank() && 
                    email.isBlank() && gender.isBlank() && yearText.isBlank() && password.isBlank() && 
                    userIdText.isBlank() && dobText.isBlank()) {
                    continue;
                }

                if (userIdText.isBlank()) {
                    errors.add("Row " + (i + 1) + ": User ID is required");
                    continue;
                }
                if (name.isBlank()) {
                    errors.add("Row " + (i + 1) + ": Name is required");
                    continue;
                }
                if (phone.isBlank()) {
                    errors.add("Row " + (i + 1) + ": Phone is required");
                    continue;
                }
                if (email.isBlank()) {
                    errors.add("Row " + (i + 1) + ": Email is required");
                    continue;
                }
                if (password.isBlank()) {
                    errors.add("Row " + (i + 1) + ": Password is required");
                    continue;
                }

                Integer userId;
                try {
                    userId = Integer.parseInt(userIdText);
                } catch (NumberFormatException ex) {
                    errors.add("Row " + (i + 1) + ": Invalid User ID format: " + userIdText);
                    continue;
                }

                Integer year;
                try {
                    year = Integer.parseInt(yearText);
                } catch (NumberFormatException ex) {
                    errors.add("Row " + (i + 1) + ": Invalid year format: " + yearText);
                    continue;
                }

                if (userRepository.existsById(userId)) {
                    errors.add("Row " + (i + 1) + ": User ID already exists: " + userId);
                    continue;
                }
                if (userRepository.existsByEmail(email)) {
                    errors.add("Row " + (i + 1) + ": Email already exists: " + email);
                    continue;
                }
                if (userRepository.existsByPhone(phone)) {
                    errors.add("Row " + (i + 1) + ": Phone number already exists: " + phone);
                    continue;
                }

                // Strictly find role matching case-insensitive
                String finalRoleName = roleName;
                RoleEntity role = roleRepository.findByRoleName(roleName)
                        .or(() -> roleRepository.findAll().stream()
                                .filter(r -> r.getRoleName().equalsIgnoreCase(finalRoleName))
                                .findFirst())
                        .orElse(null);

                BatchEntity batch = batchRepository.findByBatchName(batchName).orElse(null);

                if (role == null) {
                    errors.add("Row " + (i + 1) + ": Role not found: " + roleName);
                    continue;
                }
                if (batch == null) {
                    errors.add("Row " + (i + 1) + ": Batch not found: " + batchName);
                    continue;
                }

                java.time.LocalDate dob = null;
                if (!dobText.isBlank()) {
                    try {
                        org.apache.poi.ss.usermodel.Cell dobCell = row.getCell(9);
                        if (dobCell != null && dobCell.getCellType() == org.apache.poi.ss.usermodel.CellType.NUMERIC 
                                && org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(dobCell)) {
                            dob = dobCell.getDateCellValue().toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else {
                            dob = java.time.LocalDate.parse(dobText);
                        }
                    } catch (Exception ex) {
                        errors.add("Row " + (i + 1) + ": Invalid DOB format (should be yyyy-MM-dd): " + dobText);
                        continue;
                    }
                }

                UserEntity user = new UserEntity();
                user.setUserId(userId);
                user.setDob(dob);
                user.setRole(role);
                user.setBatch(batch);
                user.setName(name);
                user.setPhone(phone);
                user.setEmail(email);
                user.setGender(gender);
                user.setYear(year);
                user.setPasswordHash(passwordEncoder.encode(password));
                user.setStatus("ACTIVE");

                userRepository.save(user);
                uploadedCount++;
            }

            if (!errors.isEmpty()) {
                if (uploadedCount > 0) {
                    return uploadedCount + " users uploaded. Errors: " + String.join(" | ", errors);
                } else {
                    return "Upload failed. Errors: " + String.join(" | ", errors);
                }
            }

            return uploadedCount + " users uploaded successfully";
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed to upload users : "
                    + e.getClass().getSimpleName()
                    + " - "
                    + e.getMessage();
        }
    }
}
