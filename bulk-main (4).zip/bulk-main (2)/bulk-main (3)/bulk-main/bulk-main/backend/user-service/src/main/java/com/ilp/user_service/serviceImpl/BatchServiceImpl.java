package com.ilp.user_service.serviceImpl;

import com.ilp.user_service.entity.BatchEntity;
import com.ilp.user_service.exception.BatchDeletionException;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.service.BatchService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchServiceImpl implements BatchService {

    @Autowired
    private BatchRepository batchRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public BatchEntity createBatch(BatchEntity batch) {
        validateBatch(batch);

        String batchName = batch.getBatchName().trim();
        Integer year = batch.getYear();

        boolean batchAlreadyExists =
            batchRepository.existsByBatchNameIgnoreCaseAndYear(
                batchName,
                year
            );

        if (batchAlreadyExists) {
            throw new IllegalArgumentException(
                "Batch '" + batchName +
                "' already exists for year " + year
            );
        }

        batch.setBatchId(null);
        batch.setBatchName(batchName);

        return batchRepository.save(batch);
    }

    @Override
    public BatchEntity getBatchById(Integer batchId) {
        return batchRepository
            .findById(batchId)
            .orElse(null);
    }

    @Override
    public List<BatchEntity> getAllBatches() {
        return batchRepository.findAll();
    }

    @Override
    public List<BatchEntity> getBatchesByYear(Integer year) {
        validateYear(year);

        return batchRepository
            .findByYearOrderByBatchNameAsc(year);
    }

    @Override
    public BatchEntity updateBatch(
            Integer batchId,
            BatchEntity batch) {

        BatchEntity existingBatch = batchRepository
            .findById(batchId)
            .orElse(null);

        if (existingBatch == null) {
            return null;
        }

        validateBatch(batch);

        String batchName = batch.getBatchName().trim();
        Integer year = batch.getYear();

        batchRepository
            .findByBatchNameIgnoreCaseAndYear(batchName, year)
            .filter(foundBatch ->
                !foundBatch.getBatchId().equals(batchId)
            )
            .ifPresent(foundBatch -> {
                throw new IllegalArgumentException(
                    "Batch '" + batchName +
                    "' already exists for year " + year
                );
            });

        existingBatch.setBatchName(batchName);
        existingBatch.setYear(year);
        existingBatch.setStartDate(batch.getStartDate());
        existingBatch.setEndDate(batch.getEndDate());

        return batchRepository.save(existingBatch);
    }

    @Override
    public void deleteBatch(Integer batchId) {
        if (!batchRepository.existsById(batchId)) {
            return;
        }

        if (userRepository.existsByBatch_BatchId(batchId)) {
            throw new BatchDeletionException(
                "Cannot delete batch. Users are assigned to this batch."
            );
        }

        batchRepository.deleteById(batchId);
    }

    private void validateBatch(BatchEntity batch) {
        if (batch == null) {
            throw new IllegalArgumentException(
                "Batch details are required."
            );
        }

        if (
            batch.getBatchName() == null ||
            batch.getBatchName().trim().isEmpty()
        ) {
            throw new IllegalArgumentException(
                "Batch name is required."
            );
        }

        if (batch.getBatchName().trim().length() > 50) {
            throw new IllegalArgumentException(
                "Batch name must not exceed 50 characters."
            );
        }

        validateYear(batch.getYear());
        validateDates(batch);
    }

    private void validateYear(Integer year) {
        if (year == null) {
            throw new IllegalArgumentException(
                "Batch year is required."
            );
        }

        if (year < 2000 || year > 9999) {
            throw new IllegalArgumentException(
                "Batch year must be a valid four-digit year."
            );
        }
    }

    private void validateDates(BatchEntity batch) {
        if (batch.getStartDate() == null) {
            throw new IllegalArgumentException(
                "Batch start date is required."
            );
        }

        if (batch.getEndDate() == null) {
            throw new IllegalArgumentException(
                "Batch end date is required."
            );
        }

        if (batch.getEndDate().isBefore(batch.getStartDate())) {
            throw new IllegalArgumentException(
                "Batch end date cannot be earlier than the start date."
            );
        }
    }
}
