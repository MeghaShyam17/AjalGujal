package com.ilp.user_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
        name = "batch-service",
        url = "http://localhost:8081")
public interface BatchClient {

    @GetMapping("/api/batches/{id}")
    Object getBatchById(
            @PathVariable Integer id);
}