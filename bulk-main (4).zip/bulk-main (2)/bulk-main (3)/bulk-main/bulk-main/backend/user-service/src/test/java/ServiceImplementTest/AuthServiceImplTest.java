// package ServiceImplementTest;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// import static org.mockito.ArgumentMatchers.any;

// import java.util.Optional;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;
// import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

// import com.ilp.user_service.dto.LoginRequest;
// import com.ilp.user_service.dto.LoginResponse;
// import com.ilp.user_service.dto.RegisterUserRequest;
// import com.ilp.user_service.dto.ResetPasswordRequest;
// import com.ilp.user_service.entity.BatchEntity;
// import com.ilp.user_service.entity.RoleEntity;
// import com.ilp.user_service.entity.UserEntity;
// import com.ilp.user_service.exception.InvalidCredentialsException;
// import com.ilp.user_service.repository.BatchRepository;
// import com.ilp.user_service.repository.RoleRepository;
// import com.ilp.user_service.repository.UserRepository;
// import com.ilp.user_service.security.JwtUtil;
// import com.ilp.user_service.serviceImpl.AuthServiceImpl;

// @ExtendWith(MockitoExtension.class)
// class AuthServiceImplTest {

//     @Mock
//     private UserRepository userRepository;

//     @Mock
//     private RoleRepository roleRepository;

//     @Mock
//     private BatchRepository batchRepository;

//     @Mock
//     private BCryptPasswordEncoder passwordEncoder;

//     @Mock
//     private JwtUtil jwtUtil;

//     @InjectMocks
//     private AuthServiceImpl authService;

//     private UserEntity user;
//     private RoleEntity role;
//     private BatchEntity batch;

//     @BeforeEach
//     void setup() {

//         role = new RoleEntity();
//         role.setRoleId(1);
//         role.setRoleName("Trainee");

//         batch = new BatchEntity();
//         batch.setBatchId(1);
//         batch.setBatchName("ILP Batch");

//         user = new UserEntity();
//         user.setUserId(1);
//         user.setName("Test User");
//         user.setEmail("test@gmail.com");
//         user.setPasswordHash("encodedPassword");
//         user.setRole(role);
//         user.setBatch(batch);
//     }

//     @Test
//     void loginSuccess() {

//         LoginRequest request = new LoginRequest();
//         request.setEmail("test@gmail.com");
//         request.setPassword("password");

//         when(userRepository.findByEmail("test@gmail.com"))
//                 .thenReturn(Optional.of(user));

//         when(passwordEncoder.matches(
//                 "password",
//                 "encodedPassword"))
//                 .thenReturn(true);

//         when(jwtUtil.generateToken("test@gmail.com"))
//                 .thenReturn("jwt-token");

//         LoginResponse response =
//                 authService.login(request);

//         assertNotNull(response);
//         assertEquals("Test User", response.getName());
//         assertEquals("jwt-token", response.getToken());

//         verify(userRepository).save(user);
//     }

//     @Test
//     void loginUserNotFound() {

//         LoginRequest request = new LoginRequest();
//         request.setEmail("unknown@gmail.com");

//         when(userRepository.findByEmail(any()))
//                 .thenReturn(Optional.empty());

//         LoginResponse response =
//                 authService.login(request);

//         assertNull(response);
//     }

//     @Test
//     void loginInvalidPassword() {

//         LoginRequest request = new LoginRequest();
//         request.setEmail("test@gmail.com");
//         request.setPassword("wrongPassword");

//         when(userRepository.findByEmail(any()))
//                 .thenReturn(Optional.of(user));

//         when(passwordEncoder.matches(any(), any()))
//                 .thenReturn(false);

//         assertThrows(
//                 InvalidCredentialsException.class,
//                 () -> authService.login(request));
//     }

//     @Test
//     void loginWithoutRole() {

//         user.setRole(null);

//         LoginRequest request = new LoginRequest();
//         request.setEmail("test@gmail.com");
//         request.setPassword("password");

//         when(userRepository.findByEmail(any()))
//                 .thenReturn(Optional.of(user));

//         when(passwordEncoder.matches(any(), any()))
//                 .thenReturn(true);

//         when(jwtUtil.generateToken(any()))
//                 .thenReturn("token");

//         LoginResponse response =
//                 authService.login(request);

//         assertEquals(
//                 "No Role Assigned",
//                 response.getRole());
//     }

//     @Test
//     void registerUserSuccess() {

//         RegisterUserRequest request =
//                 new RegisterUserRequest();

//         request.setRoleId(1);
//         request.setBatchId(1);
//         request.setName("Test User");
//         request.setPhone("9876543210");
//         request.setEmail("test@gmail.com");
//         request.setPassword("password");

//         when(userRepository.existsByEmail(any()))
//                 .thenReturn(false);

//         when(userRepository.existsByPhone(any()))
//                 .thenReturn(false);

//         when(roleRepository.findById(1))
//                 .thenReturn(Optional.of(role));

//         when(batchRepository.findById(1))
//                 .thenReturn(Optional.of(batch));

//         when(passwordEncoder.encode(any()))
//                 .thenReturn("encodedPassword");

//         String result =
//                 authService.registerUser(request);

//         assertEquals(
//                 "User registered successfully",
//                 result);

//         verify(userRepository)
//                 .save(any(UserEntity.class));
//     }

//     @Test
//     void registerUserEmailAlreadyExists() {

//         RegisterUserRequest request =
//                 new RegisterUserRequest();

//         request.setEmail("test@gmail.com");

//         when(userRepository.existsByEmail(any()))
//                 .thenReturn(true);

//         String result =
//                 authService.registerUser(request);

//         assertEquals(
//                 "Email already exists",
//                 result);
//     }

//     @Test
//     void registerUserPhoneAlreadyExists() {

//         RegisterUserRequest request =
//                 new RegisterUserRequest();

//         request.setEmail("test@gmail.com");
//         request.setPhone("9876543210");

//         when(userRepository.existsByEmail(any()))
//                 .thenReturn(false);

//         when(userRepository.existsByPhone(any()))
//                 .thenReturn(true);

//         String result =
//                 authService.registerUser(request);

//         assertEquals(
//                 "Phone number already exists",
//                 result);
//     }

//     @Test
//     void registerUserRoleNotFound() {

//         RegisterUserRequest request =
//                 new RegisterUserRequest();

//         request.setEmail("test@gmail.com");
//         request.setPhone("9876543210");
//         request.setRoleId(1);

//         when(userRepository.existsByEmail(any()))
//                 .thenReturn(false);

//         when(userRepository.existsByPhone(any()))
//                 .thenReturn(false);

//         when(roleRepository.findById(1))
//                 .thenReturn(Optional.empty());

//         String result =
//                 authService.registerUser(request);

//         assertEquals(
//                 "Role not found",
//                 result);
//     }

//     @Test
//     void registerUserBatchNotFound() {

//         RegisterUserRequest request =
//                 new RegisterUserRequest();

//         request.setEmail("test@gmail.com");
//         request.setPhone("9876543210");
//         request.setRoleId(1);
//         request.setBatchId(1);

//         when(userRepository.existsByEmail(any()))
//                 .thenReturn(false);

//         when(userRepository.existsByPhone(any()))
//                 .thenReturn(false);

//         when(roleRepository.findById(1))
//                 .thenReturn(Optional.of(role));

//         when(batchRepository.findById(1))
//                 .thenReturn(Optional.empty());

//         String result =
//                 authService.registerUser(request);

//         assertEquals(
//                 "Batch not found",
//                 result);
//     }

//     @Test
//     void resetPasswordSuccess() {

//         ResetPasswordRequest request =
//                 new ResetPasswordRequest();

//         request.setOldPassword("old");
//         request.setNewPassword("new");

//         when(userRepository.findById(1))
//                 .thenReturn(Optional.of(user));

//         when(passwordEncoder.matches(
//                 "old",
//                 "encodedPassword"))
//                 .thenReturn(true);

//         when(passwordEncoder.encode("new"))
//                 .thenReturn("newEncodedPassword");

//         String result =
//                 authService.resetPassword(
//                         1,
//                         request);

//         assertEquals(
//                 "Password reset successfully",
//                 result);

//         verify(userRepository)
//                 .save(user);
//     }

//     @Test
//     void resetPasswordUserNotFound() {

//         ResetPasswordRequest request =
//                 new ResetPasswordRequest();

//         when(userRepository.findById(1))
//                 .thenReturn(Optional.empty());

//         String result =
//                 authService.resetPassword(
//                         1,
//                         request);

//         assertEquals(
//                 "User not found",
//                 result);
//     }

//     @Test
//     void resetPasswordWrongOldPassword() {

//         ResetPasswordRequest request =
//                 new ResetPasswordRequest();

//         request.setOldPassword("wrong");

//         when(userRepository.findById(1))
//                 .thenReturn(Optional.of(user));

//         when(passwordEncoder.matches(any(), any()))
//                 .thenReturn(false);

//         String result =
//                 authService.resetPassword(
//                         1,
//                         request);

//         assertEquals(
//                 "Old password is incorrect",
//                 result);
//     }
// }