package com.ilp.user_service.dto;

public class LoginResponse {

    private Integer userId;
    private String name;
    private String email;
    private String role;
    private String token;
    private boolean firstTimeLogin;
    private String phone;
    
    // No-Args Constructor
    public LoginResponse() {
    }

    // All-Args Constructor
    public LoginResponse(Integer userId, String name, String email,
                         String role, String token, boolean firstTimeLogin, String phone) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.role = role;
        this.token = token;
        this.firstTimeLogin = firstTimeLogin;
        this.phone = phone;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public boolean isFirstTimeLogin() {
        return firstTimeLogin;
    }

    public void setFirstTimeLogin(boolean firstTimeLogin) {
        this.firstTimeLogin = firstTimeLogin;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}