package com.ilp.user_service.controller;

import com.ilp.user_service.entity.BatchEntity;
import com.ilp.user_service.service.BatchService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/batches")
public class BatchController {

    @Autowired
    private BatchService batchService;

    @PostMapping
    public ResponseEntity<BatchEntity> createBatch(
            @RequestBody BatchEntity batch) {

        BatchEntity savedBatch = batchService.createBatch(batch);
        return ResponseEntity.ok(savedBatch);
    }

    @GetMapping("/{batchId}")
    public ResponseEntity<BatchEntity> getBatchById(
            @PathVariable Integer batchId) {

        BatchEntity batch = batchService.getBatchById(batchId);

        if (batch == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(batch);
    }

    @GetMapping
    public ResponseEntity<List<BatchEntity>> getBatches(
            @RequestParam(required = false) Integer year) {

        List<BatchEntity> batches;

        if (year != null) {
            batches = batchService.getBatchesByYear(year);
        } else {
            batches = batchService.getAllBatches();
        }

        return ResponseEntity.ok(batches);
    }

    @PutMapping("/{batchId}")
    public ResponseEntity<BatchEntity> updateBatch(
            @PathVariable Integer batchId,
            @RequestBody BatchEntity batch) {

        BatchEntity updatedBatch =
            batchService.updateBatch(batchId, batch);

        if (updatedBatch == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(updatedBatch);
    }

    @DeleteMapping("/{batchId}")
    public ResponseEntity<String> deleteBatch(
            @PathVariable Integer batchId) {

        batchService.deleteBatch(batchId);
        return ResponseEntity.ok("Batch deleted successfully");
    }
}
