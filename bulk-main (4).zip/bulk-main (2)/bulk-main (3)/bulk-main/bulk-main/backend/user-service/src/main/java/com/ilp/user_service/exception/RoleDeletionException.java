package com.ilp.user_service.exception;

public class RoleDeletionException extends RuntimeException {

    public RoleDeletionException(String message) {
        super(message);
    }
}