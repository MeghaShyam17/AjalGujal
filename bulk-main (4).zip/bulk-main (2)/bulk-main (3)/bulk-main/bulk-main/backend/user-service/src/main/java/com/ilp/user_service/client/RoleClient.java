package com.ilp.user_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
        name = "role-service",
        url = "http://localhost:8081")
public interface RoleClient {

    @GetMapping("/api/roles/{id}")
    Object getRoleById(
            @PathVariable Integer id);
}