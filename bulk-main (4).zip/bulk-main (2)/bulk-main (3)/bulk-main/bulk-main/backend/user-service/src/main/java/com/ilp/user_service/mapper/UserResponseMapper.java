package com.ilp.user_service.mapper;

import com.ilp.user_service.dto.UserResponse;
import com.ilp.user_service.entity.UserEntity;

public class UserResponseMapper {

    private UserResponseMapper() {
    }

    public static UserResponse toResponse(
            UserEntity user) {

        UserResponse response =
                new UserResponse();

        response.setUserId(user.getUserId());
        response.setName(user.getName());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
        response.setGender(user.getGender());
        response.setYear(user.getYear());
        response.setStatus(user.getStatus());
        response.setDob(user.getDob());

        if (user.getRole() != null) {
            response.setRoleName(
                    user.getRole().getRoleName());
        }

        if (user.getBatch() != null) {
            response.setBatchName(
                    user.getBatch().getBatchName());
        }

        return response;
    }
}