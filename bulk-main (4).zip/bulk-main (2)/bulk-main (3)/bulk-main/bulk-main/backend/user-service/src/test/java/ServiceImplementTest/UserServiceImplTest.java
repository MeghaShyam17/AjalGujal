package ServiceImplementTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.user_service.dto.UserResponse;
import com.ilp.user_service.entity.UserEntity;
import com.ilp.user_service.exception.UserNotFoundException;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.serviceImpl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private BatchRepository batchRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    /*
     * Utility method for creating an active test user.
     */
    private UserEntity createActiveUser(
            Integer userId,
            String name) {

        UserEntity user = new UserEntity();

        user.setUserId(userId);
        user.setName(name);
        user.setStatus("ACTIVE");

        return user;
    }

    @Test
    void createUserSuccess() {

        UserEntity user = createActiveUser(
                1,
                "Test User"
        );

        when(userRepository.save(user))
                .thenReturn(user);

        UserResponse result = userService.createUser(user);

        assertNotNull(result);
        assertEquals("Test User", result.getName());

        verify(userRepository).save(user);
    }

    @Test
    void getUserByIdSuccess() {

        UserEntity user = createActiveUser(
                1,
                "Test User"
        );

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        UserResponse result = userService.getUserById(1);

        assertNotNull(result);
        assertEquals(1, result.getUserId());
        assertEquals("Test User", result.getName());

        verify(userRepository).findById(1);
    }

    @Test
    void getUserByIdNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        UserNotFoundException exception = assertThrows(
                UserNotFoundException.class,
                () -> userService.getUserById(1)
        );

        assertEquals(
                "User not found with ID: 1",
                exception.getMessage()
        );

        verify(userRepository).findById(1);
    }

    @Test
    void getUserByIdInactiveUser() {

        UserEntity user = new UserEntity();

        user.setUserId(1);
        user.setName("Inactive User");
        user.setStatus("INACTIVE");

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        assertThrows(
                UserNotFoundException.class,
                () -> userService.getUserById(1)
        );

        verify(userRepository).findById(1);
    }

    @Test
    void getUserByIdForcePasswordChangeSuccess() {

        UserEntity user = new UserEntity();

        user.setUserId(1);
        user.setName("Test User");
        user.setStatus("FORCE_PASSWORD_CHANGE");

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        UserResponse result = userService.getUserById(1);

        assertNotNull(result);
        assertEquals(1, result.getUserId());

        verify(userRepository).findById(1);
    }

    @Test
    void getAllUsersSuccess() {

        UserEntity firstUser = createActiveUser(
                1,
                "First User"
        );

        UserEntity secondUser = createActiveUser(
                2,
                "Second User"
        );

        when(userRepository.findAll())
                .thenReturn(Arrays.asList(
                        firstUser,
                        secondUser
                ));

        assertEquals(
                2,
                userService.getAllUsers().size()
        );

        verify(userRepository).findAll();
    }

    @Test
    void getAllUsersFiltersInactiveUsers() {

        UserEntity activeUser = createActiveUser(
                1,
                "Active User"
        );

        UserEntity inactiveUser = new UserEntity();

        inactiveUser.setUserId(2);
        inactiveUser.setName("Inactive User");
        inactiveUser.setStatus("INACTIVE");

        when(userRepository.findAll())
                .thenReturn(Arrays.asList(
                        activeUser,
                        inactiveUser
                ));

        assertEquals(
                1,
                userService.getAllUsers().size()
        );

        verify(userRepository).findAll();
    }

    @Test
    void getAllUsersEmptyList() {

        when(userRepository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(userService.getAllUsers().isEmpty());

        verify(userRepository).findAll();
    }

    @Test
    void updateUserSuccess() {

        UserEntity existing = createActiveUser(
                1,
                "Old Name"
        );

        existing.setEmail("old@gmail.com");
        existing.setPhone("9000000001");

        UserEntity updateRequest = new UserEntity();

        updateRequest.setName("New Name");
        updateRequest.setEmail("new@gmail.com");
        updateRequest.setPhone("9000000002");
        updateRequest.setStatus("ACTIVE");

        when(userRepository.findById(1))
                .thenReturn(Optional.of(existing));

        when(userRepository.save(any(UserEntity.class)))
                .thenAnswer(invocation ->
                        invocation.getArgument(0)
                );

        UserResponse result = userService.updateUser(
                1,
                updateRequest
        );

        assertNotNull(result);
        assertEquals("New Name", result.getName());
        assertEquals("new@gmail.com", result.getEmail());
        assertEquals("9000000002", result.getPhone());

        assertEquals("New Name", existing.getName());
        assertEquals("new@gmail.com", existing.getEmail());

        verify(userRepository).findById(1);
        verify(userRepository).save(existing);
    }

    @Test
    void updateUserNotFound() {

        UserEntity updateRequest = new UserEntity();

        updateRequest.setName("New Name");

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        UserNotFoundException exception = assertThrows(
                UserNotFoundException.class,
                () -> userService.updateUser(
                        1,
                        updateRequest
                )
        );

        assertEquals(
                "User not found with ID: 1",
                exception.getMessage()
        );

        verify(userRepository).findById(1);
        verify(userRepository, never())
                .save(any(UserEntity.class));
    }

    @Test
    void updateInactiveUserThrowsException() {

        UserEntity existing = new UserEntity();

        existing.setUserId(1);
        existing.setStatus("INACTIVE");

        UserEntity updateRequest = new UserEntity();

        updateRequest.setName("New Name");

        when(userRepository.findById(1))
                .thenReturn(Optional.of(existing));

        assertThrows(
                UserNotFoundException.class,
                () -> userService.updateUser(
                        1,
                        updateRequest
                )
        );

        verify(userRepository, never())
                .save(any(UserEntity.class));
    }

    @Test
    void deleteUserSuccess() {

        UserEntity user = createActiveUser(
                1,
                "Test User"
        );

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        userService.deleteUser(1);

        verify(userRepository).findById(1);
        verify(userRepository).delete(user);
    }

    @Test
    void deleteUserNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        UserNotFoundException exception = assertThrows(
                UserNotFoundException.class,
                () -> userService.deleteUser(1)
        );

        assertEquals(
                "User not found with ID: 1",
                exception.getMessage()
        );

        verify(userRepository).findById(1);
        verify(userRepository, never())
                .delete(any(UserEntity.class));
    }

    @Test
    void softDeleteUserSuccess() {

        UserEntity user = createActiveUser(
                1,
                "Test User"
        );

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        when(userRepository.save(user))
                .thenReturn(user);

        userService.softDeleteUser(1);

        assertEquals("INACTIVE", user.getStatus());

        verify(userRepository).findById(1);
        verify(userRepository).save(user);
    }

    @Test
    void softDeleteUserNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> userService.softDeleteUser(1)
        );

        verify(userRepository).findById(1);
        verify(userRepository, never())
                .save(any(UserEntity.class));
    }

    @Test
    void getUserByEmailSuccess() {

        UserEntity user = createActiveUser(
                1,
                "Test User"
        );

        user.setEmail("test@gmail.com");

        when(userRepository.findByEmail("test@gmail.com"))
                .thenReturn(Optional.of(user));

        UserResponse result = userService.getUserByEmail(
                " TEST@GMAIL.COM "
        );

        assertNotNull(result);
        assertEquals("test@gmail.com", result.getEmail());

        verify(userRepository)
                .findByEmail("test@gmail.com");
    }

    @Test
    void getUserByEmailNullReturnsNull() {

        UserResponse result = userService.getUserByEmail(null);

        assertNull(result);

        verifyNoInteractions(userRepository);
    }

    @Test
    void getUserByEmailNotFoundReturnsNull() {

        when(userRepository.findByEmail("test@gmail.com"))
                .thenReturn(Optional.empty());

        UserResponse result = userService.getUserByEmail(
                "test@gmail.com"
        );

        assertNull(result);

        verify(userRepository)
                .findByEmail("test@gmail.com");
    }

    @Test
    void getUserByEmailInactiveReturnsNull() {

        UserEntity user = new UserEntity();

        user.setUserId(1);
        user.setEmail("test@gmail.com");
        user.setStatus("INACTIVE");

        when(userRepository.findByEmail("test@gmail.com"))
                .thenReturn(Optional.of(user));

        UserResponse result = userService.getUserByEmail(
                "test@gmail.com"
        );

        assertNull(result);
    }

    @Test
    void uploadUsersInvalidFile() throws IOException {

        MultipartFile file = mock(MultipartFile.class);

        when(file.getInputStream())
                .thenThrow(new IOException("Invalid file"));

        String result = userService.uploadUsers(file);

        assertNotNull(result);
        assertTrue(
                result.startsWith("Failed to upload users"),
                "Unexpected upload result: " + result
        );

        assertTrue(
                result.contains("IOException"),
                "Expected IOException in result: " + result
        );

        verify(file).getInputStream();
    }

    @Test
    void createUserRepositoryCalled() {

        UserEntity user = createActiveUser(
                1,
                "Test User"
        );

        when(userRepository.save(user))
                .thenReturn(user);

        userService.createUser(user);

        verify(userRepository, times(1))
                .save(user);
    }
}