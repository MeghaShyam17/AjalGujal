package com.ilp.user_service.exception;

public class BatchNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

    public BatchNotFoundException() {
        super();
    }

    public BatchNotFoundException(String message) {
        super(message);
    }

    public BatchNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public BatchNotFoundException(Throwable cause) {
        super(cause);
    }
}