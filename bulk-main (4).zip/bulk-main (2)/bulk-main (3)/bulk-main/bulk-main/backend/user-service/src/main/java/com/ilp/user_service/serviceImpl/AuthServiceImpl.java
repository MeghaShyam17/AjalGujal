package com.ilp.user_service.serviceImpl;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ilp.user_service.dto.LoginRequest;
import com.ilp.user_service.dto.LoginResponse;
import com.ilp.user_service.dto.RegisterUserRequest;
import com.ilp.user_service.dto.ResetPasswordRequest;
import com.ilp.user_service.entity.BatchEntity;
import com.ilp.user_service.entity.RoleEntity;
import com.ilp.user_service.entity.UserEntity;
import com.ilp.user_service.exception.InvalidCredentialsException;
import com.ilp.user_service.mapper.UserMapper;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.security.JwtUtil;
import com.ilp.user_service.service.AuthService;


@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BatchRepository batchRepository;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public LoginResponse login(LoginRequest loginRequest) {

        UserEntity user = userRepository
                .findByEmail(loginRequest.getEmail())
                .orElse(null);
        if (user == null) {
            return null;
        }
        if (!"ACTIVE".equals(user.getStatus()) && !"FORCE_PASSWORD_CHANGE".equals(user.getStatus())) {
            throw new InvalidCredentialsException(
                    "User account is inactive");
        }

        if (!passwordEncoder.matches(
                loginRequest.getPassword(),
                user.getPasswordHash())) {

            throw new InvalidCredentialsException(
                    "Invalid email or password");
        }

        boolean isFirstTime = (user.getLastLogin() == null) || "FORCE_PASSWORD_CHANGE".equals(user.getStatus());

        if (!isFirstTime) {
            user.setLastLogin(LocalDateTime.now());
            userRepository.save(user);
        }

        LoginResponse response = new LoginResponse();

        response.setUserId(user.getUserId());
        response.setName(user.getName());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
       
        if (user.getRole() != null) {
            response.setRole(user.getRole().getRoleName());
        } else {
            response.setRole("No Role Assigned");
        }
        
        response.setToken(
                jwtUtil.generateToken(user.getEmail(), user.getRole().getRoleName()));
        response.setFirstTimeLogin(isFirstTime);

        return response;
        
    }
    
    @Override
    public String registerUser(RegisterUserRequest registerUserRequest) {
        RoleEntity role = roleRepository
                .findById(registerUserRequest.getRoleId())
                .orElse(null);

        if (role == null) {
            return "Role not found";
        }

        if (registerUserRequest.getUserId() == null) {
            return "User ID is required";
        }

        if (userRepository.existsById(registerUserRequest.getUserId())) {
            return "User ID already exists";
        }

        if (userRepository.existsByEmail(registerUserRequest.getEmail())) {
            return "Email already exists";
        }

        if (userRepository.existsByPhone(registerUserRequest.getPhone())) {
            return "Phone number already exists";
        }

        BatchEntity batch = null;

        if (registerUserRequest.getBatchId() != null) {
            batch = batchRepository
                    .findById(registerUserRequest.getBatchId())
                    .orElse(null);
        }
        
        if (batch == null && ("Trainee".equalsIgnoreCase(role.getRoleName()) || "Member".equalsIgnoreCase(role.getRoleName()))) {
            return "Batch not found";
        }

        UserEntity user =
                UserMapper.toEntity(registerUserRequest);

        user.setUserId(registerUserRequest.getUserId());
        user.setDob(registerUserRequest.getDob());

        // Later replace with BCrypt password encoding
        user.setPasswordHash(
                passwordEncoder.encode(
                        registerUserRequest.getPassword()));
        user.setRole(role);
        user.setBatch(batch);
        user.setStatus("ACTIVE");
        
        user.setCreatedAt(LocalDateTime.now());

        userRepository.save(user);

        return "User registered successfully";
    }
    @Override
    public String resetPassword(
            Integer userId,
            ResetPasswordRequest request) {

        UserEntity user =
                userRepository.findById(userId)
                        .orElse(null);

        if (user == null) {
            return "User not found";
        }
    
        if (!"ACTIVE".equals(user.getStatus()) && !"FORCE_PASSWORD_CHANGE".equals(user.getStatus())) {
            return "User account is inactive";
        }
        if (!passwordEncoder.matches(
                request.getOldPassword(),
                user.getPasswordHash())) {

            return "Old password is incorrect";
        }

        if (!request.getNewPassword()
                .equals(request.getConfirmPassword())) {

            return "New password and confirm password do not match";
        }

        user.setPasswordHash(
                passwordEncoder.encode(
                        request.getNewPassword()));

        if ("FORCE_PASSWORD_CHANGE".equals(user.getStatus())) {
            user.setStatus("ACTIVE");
        }

        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        return "Password reset successfully";
    }
}