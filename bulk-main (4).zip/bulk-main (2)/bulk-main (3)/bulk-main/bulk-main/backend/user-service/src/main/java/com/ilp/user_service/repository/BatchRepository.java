package com.ilp.user_service.repository;

import com.ilp.user_service.entity.BatchEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BatchRepository extends JpaRepository<BatchEntity, Integer> {

    Optional<BatchEntity> findByBatchName(String batchName);
    
 // Fetch batches belonging to a specific year
    List<BatchEntity> findByYearOrderByBatchNameAsc(Integer year);

    // Find a batch using both name and year
    Optional<BatchEntity> findByBatchNameIgnoreCaseAndYear(
            String batchName,
            Integer year
    );
    
    boolean existsByBatchNameIgnoreCaseAndYear(
            String batchName,
            Integer year
    );
    
    boolean existsByBatchName(String batchName);
}