package ServiceImplementTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ilp.user_service.entity.RoleEntity;
import com.ilp.user_service.exception.RoleDeletionException;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.serviceImpl.RoleServiceImpl;

@ExtendWith(MockitoExtension.class)
class RoleServiceImplTest {

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private UserRepository userRepository;

    private RoleServiceImpl roleService;

    @BeforeEach
    void setup() {

        roleService = new RoleServiceImpl(roleRepository);

        ReflectionTestUtils.setField(
                roleService,
                "userRepository",
                userRepository);
    }

    @Test
    void createRoleSuccess() {

        RoleEntity role = new RoleEntity();
        role.setRoleId(1);
        role.setRoleName("Trainee");

        when(roleRepository.save(role))
                .thenReturn(role);

        RoleEntity result =
                roleService.createRole(role);

        assertNotNull(result);
        assertEquals(
                "Trainee",
                result.getRoleName());
    }

    @Test
    void getRoleByIdSuccess() {

        RoleEntity role = new RoleEntity();
        role.setRoleId(1);

        when(roleRepository.findById(1))
                .thenReturn(Optional.of(role));

        RoleEntity result =
                roleService.getRoleById(1);

        assertNotNull(result);
        assertEquals(
                1,
                result.getRoleId());
    }

    @Test
    void getRoleByIdNotFound() {

        when(roleRepository.findById(1))
                .thenReturn(Optional.empty());

        RoleEntity result =
                roleService.getRoleById(1);

        assertNull(result);
    }

    @Test
    void getAllRolesSuccess() {

        RoleEntity role1 = new RoleEntity();
        RoleEntity role2 = new RoleEntity();

        when(roleRepository.findAll())
                .thenReturn(Arrays.asList(role1, role2));

        assertEquals(
                2,
                roleService.getAllRoles().size());
    }

    @Test
    void getAllRolesEmptyList() {

        when(roleRepository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(
                roleService.getAllRoles().isEmpty());
    }

    @Test
    void updateRoleSuccess() {

        RoleEntity existingRole =
                new RoleEntity();

        existingRole.setRoleId(1);
        existingRole.setRoleName("Old Role");

        RoleEntity updatedRole =
                new RoleEntity();

        updatedRole.setRoleName("New Role");

        when(roleRepository.findById(1))
                .thenReturn(Optional.of(existingRole));

        when(roleRepository.save(any(RoleEntity.class)))
                .thenReturn(existingRole);

        RoleEntity result =
                roleService.updateRole(
                        1,
                        updatedRole);

        assertNotNull(result);

        assertEquals(
                "New Role",
                existingRole.getRoleName());
    }

    @Test
    void updateRoleNotFound() {

        RoleEntity role =
                new RoleEntity();

        when(roleRepository.findById(1))
                .thenReturn(Optional.empty());

        RoleEntity result =
                roleService.updateRole(
                        1,
                        role);

        assertNull(result);
    }

    @Test
    void deleteRoleSuccess() {

        when(userRepository.existsByRole_RoleId(1))
                .thenReturn(false);

        roleService.deleteRole(1);

        verify(roleRepository)
                .deleteById(1);
    }

    @Test
    void deleteRoleUsersAssigned() {

        when(userRepository.existsByRole_RoleId(1))
                .thenReturn(true);

        assertThrows(
                RoleDeletionException.class,
                () -> roleService.deleteRole(1));
    }
}