package com.ilp.user_service.mapper;

import com.ilp.user_service.dto.RegisterUserRequest;
import com.ilp.user_service.entity.UserEntity;

public class UserMapper {

    private UserMapper() {
    }

    public static UserEntity toEntity(RegisterUserRequest request) {

        UserEntity user = new UserEntity();

        user.setName(request.getName());
        user.setPhone(request.getPhone());
        user.setEmail(request.getEmail());
        user.setGender(request.getGender());
        user.setYear(request.getYear());

        return user;
    }
}