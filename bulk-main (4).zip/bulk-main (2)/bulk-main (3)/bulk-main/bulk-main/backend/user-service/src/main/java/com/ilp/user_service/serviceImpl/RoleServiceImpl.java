package com.ilp.user_service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.user_service.entity.RoleEntity;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.service.RoleService;
import com.ilp.user_service.exception.RoleDeletionException;

@Service
public class RoleServiceImpl implements RoleService {

    private final RoleRepository roleRepository;
    @Autowired
    private UserRepository userRepository;

    public RoleServiceImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public RoleEntity createRole(RoleEntity role) {
        return roleRepository.save(role);
    }

    @Override
    public RoleEntity getRoleById(Integer roleId) {
        return roleRepository.findById(roleId).orElse(null);
    }

    @Override
    public List<RoleEntity> getAllRoles() {
        return roleRepository.findAll();
    }

    @Override
    public RoleEntity updateRole(Integer roleId, RoleEntity role) {

        RoleEntity existingRole = roleRepository.findById(roleId).orElse(null);

        if (existingRole != null) {
            existingRole.setRoleName(role.getRoleName());
            return roleRepository.save(existingRole);
        }

        return null;
    }
    
    

    @Override
    public void deleteRole(Integer roleId) {
    	if (userRepository.existsByRole_RoleId(roleId)) {

    		throw new RoleDeletionException(
    		        "Cannot delete role. Users are assigned to this role.");
    	}

    	roleRepository.deleteById(roleId);
        
    }
}