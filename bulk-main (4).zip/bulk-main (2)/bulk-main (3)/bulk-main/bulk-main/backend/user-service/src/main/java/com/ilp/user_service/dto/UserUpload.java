package com.ilp.user_service.dto;

public class UserUpload {

    private String roleName;
    private String batchName;
    private String name;
    private String phone;
    private String email;
    private String gender;
    private Integer year;
    private String password;

    // No-Args Constructor
    public UserUpload() {
    }

    // All-Args Constructor
    public UserUpload(String roleName, String batchName, String name,
                         String phone, String email, String gender,
                         Integer year, String password) {
        this.roleName = roleName;
        this.batchName = batchName;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.gender = gender;
        this.year = year;
        this.password = password;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getBatchName() {
        return batchName;
    }

    public void setBatchName(String batchName) {
        this.batchName = batchName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}