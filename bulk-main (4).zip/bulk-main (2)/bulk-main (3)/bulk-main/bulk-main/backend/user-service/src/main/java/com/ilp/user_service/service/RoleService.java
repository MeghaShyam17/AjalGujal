package com.ilp.user_service.service;

import com.ilp.user_service.entity.RoleEntity;

import java.util.List;

public interface RoleService {

    RoleEntity createRole(RoleEntity role);

    RoleEntity getRoleById(Integer roleId);

    List<RoleEntity> getAllRoles();

    RoleEntity updateRole(Integer roleId, RoleEntity role);

    void deleteRole(Integer roleId);
}