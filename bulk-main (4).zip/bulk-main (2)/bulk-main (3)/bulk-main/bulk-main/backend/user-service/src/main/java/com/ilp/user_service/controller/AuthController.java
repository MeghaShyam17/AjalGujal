package com.ilp.user_service.controller;

import com.ilp.user_service.dto.LoginRequest;
import com.ilp.user_service.dto.LoginResponse;
import com.ilp.user_service.dto.RegisterUserRequest;
import com.ilp.user_service.service.AuthService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ilp.user_service.dto.ResetPasswordRequest;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
@RequestMapping("/api/auth")

public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(
            @RequestBody LoginRequest loginRequest) {

        LoginResponse response =
                authService.login(loginRequest);

        return ResponseEntity.ok(response);
    }
    

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(
            @Valid @RequestBody RegisterUserRequest registerUserRequest) {

        String response =
                authService.registerUser(registerUserRequest);

        return ResponseEntity.ok(response);
    }
    @PutMapping("/reset-password/{userId}")
    public ResponseEntity<String> resetPassword(
            @PathVariable Integer userId,
            @RequestBody ResetPasswordRequest request) {

        return ResponseEntity.ok(
                authService.resetPassword(
                        userId,
                        request));
    }
   
}