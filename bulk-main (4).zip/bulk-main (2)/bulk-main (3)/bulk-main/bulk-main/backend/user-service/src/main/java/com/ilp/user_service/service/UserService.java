package com.ilp.user_service.service;

import com.ilp.user_service.entity.UserEntity;
import org.springframework.web.multipart.MultipartFile;
import com.ilp.user_service.dto.UserResponse;

import java.util.List;

public interface UserService {

    UserResponse createUser(UserEntity user);

    UserResponse getUserById(Integer userId);

    List<UserResponse> getAllUsers();

    UserResponse updateUser(Integer userId, UserEntity user);

    void softDeleteUser(Integer userId);

    void deleteUser(Integer userId);

    String uploadUsers(MultipartFile file);

    UserResponse getUserByEmail(String email);

    UserResponse autoRegisterUser(com.ilp.user_service.dto.RegisterUserRequest request);
}