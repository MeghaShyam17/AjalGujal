package com.ilp.user_service.exception;

public class BatchDeletionException extends RuntimeException {

    public BatchDeletionException(String message) {
        super(message);
    }
}