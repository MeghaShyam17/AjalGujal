package ServiceImplementTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.ilp.user_service.serviceImpl.BatchServiceImpl;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.user_service.entity.BatchEntity;
import com.ilp.user_service.exception.BatchDeletionException;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
class BatchServiceImplTest {

    @Mock
    private BatchRepository batchRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private BatchServiceImpl batchService;

    @Test
    void createBatchSuccess() {

        BatchEntity batch = new BatchEntity();
        batch.setBatchId(1);
        batch.setBatchName("ILP Batch");

        when(batchRepository.save(batch))
                .thenReturn(batch);

        BatchEntity result =
                batchService.createBatch(batch);

        assertNotNull(result);
        assertEquals(
                "ILP Batch",
                result.getBatchName());
    }

    @Test
    void getBatchByIdSuccess() {

        BatchEntity batch = new BatchEntity();
        batch.setBatchId(1);

        when(batchRepository.findById(1))
                .thenReturn(Optional.of(batch));

        BatchEntity result =
                batchService.getBatchById(1);

        assertNotNull(result);
        assertEquals(1, result.getBatchId());
    }

    @Test
    void getBatchByIdNotFound() {

        when(batchRepository.findById(1))
                .thenReturn(Optional.empty());

        BatchEntity result =
                batchService.getBatchById(1);

        assertNull(result);
    }

    @Test
    void getAllBatchesSuccess() {

        BatchEntity batch1 = new BatchEntity();
        BatchEntity batch2 = new BatchEntity();

        when(batchRepository.findAll())
                .thenReturn(
                        Arrays.asList(batch1, batch2));

        assertEquals(
                2,
                batchService.getAllBatches().size());
    }

    @Test
    void getAllBatchesEmptyList() {

        when(batchRepository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(
                batchService.getAllBatches().isEmpty());
    }

    @Test
    void updateBatchSuccess() {

        BatchEntity existing =
                new BatchEntity();

        existing.setBatchId(1);
        existing.setBatchName("Old Batch");

        BatchEntity updated =
                new BatchEntity();

        updated.setBatchName("New Batch");

        when(batchRepository.findById(1))
                .thenReturn(Optional.of(existing));

        when(batchRepository.save(any()))
                .thenReturn(existing);

        BatchEntity result =
                batchService.updateBatch(
                        1,
                        updated);

        assertNotNull(result);

        assertEquals(
                "New Batch",
                existing.getBatchName());
    }

    @Test
    void updateBatchNotFound() {

        BatchEntity batch = new BatchEntity();

        when(batchRepository.findById(1))
                .thenReturn(Optional.empty());

        BatchEntity result =
                batchService.updateBatch(
                        1,
                        batch);

        assertNull(result);
    }

    @Test
    void deleteBatchSuccess() {

        when(userRepository
                .existsByBatch_BatchId(1))
                .thenReturn(false);

        batchService.deleteBatch(1);

        verify(batchRepository)
                .deleteById(1);
    }

    @Test
    void deleteBatchUsersAssigned() {

        when(userRepository
                .existsByBatch_BatchId(1))
                .thenReturn(true);

        assertThrows(
                BatchDeletionException.class,
                () -> batchService.deleteBatch(1));
    }
}