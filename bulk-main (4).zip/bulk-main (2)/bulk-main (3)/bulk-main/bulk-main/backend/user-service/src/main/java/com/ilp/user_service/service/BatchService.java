package com.ilp.user_service.service;

import com.ilp.user_service.entity.BatchEntity;

import java.util.List;

public interface BatchService {

    BatchEntity createBatch(BatchEntity batch);

    BatchEntity getBatchById(Integer batchId);

    List<BatchEntity> getAllBatches();

    List<BatchEntity> getBatchesByYear(Integer year);

    BatchEntity updateBatch(Integer batchId, BatchEntity batch);

    void deleteBatch(Integer batchId);
}
