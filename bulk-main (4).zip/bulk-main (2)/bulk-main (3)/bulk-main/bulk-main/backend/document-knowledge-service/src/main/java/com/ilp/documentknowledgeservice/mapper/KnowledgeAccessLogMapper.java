package com.ilp.documentknowledgeservice.mapper;

import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogResponseDto;
import com.ilp.documentknowledgeservice.entity.KnowledgeAccessLogEntity;
import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;

public class KnowledgeAccessLogMapper {

    // Request DTO -> Entity
    public static KnowledgeAccessLogEntity toEntity(KnowledgeAccessLogRequestDto requestDto) {

        KnowledgeAccessLogEntity entity = new KnowledgeAccessLogEntity();

        KnowledgeBaseEntity knowledgeBase = new KnowledgeBaseEntity();
        knowledgeBase.setKnowledgeId(requestDto.getKnowledgeId());

        entity.setKnowledgeBase(knowledgeBase);
        entity.setStudentId(requestDto.getStudentId());
        entity.setAction(requestDto.getAction());

        return entity;
    }

    // Entity -> Response DTO
    public static KnowledgeAccessLogResponseDto toResponseDto(KnowledgeAccessLogEntity entity) {

        KnowledgeAccessLogResponseDto responseDto = new KnowledgeAccessLogResponseDto();

        responseDto.setAccessId(entity.getAccessId());

        if (entity.getKnowledgeBase() != null) {
            responseDto.setKnowledgeId(entity.getKnowledgeBase().getKnowledgeId());
        }

        responseDto.setStudentId(entity.getStudentId());
        responseDto.setAction(entity.getAction());
        responseDto.setAccessedOn(entity.getAccessedOn());

        return responseDto;
    }
}