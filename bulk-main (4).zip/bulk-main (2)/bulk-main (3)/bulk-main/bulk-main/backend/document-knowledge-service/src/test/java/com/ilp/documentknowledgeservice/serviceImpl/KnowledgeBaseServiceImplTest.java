package com.ilp.documentknowledgeservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseResponseDto;
import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;
import com.ilp.documentknowledgeservice.dto.ProjectResponseDto;
import com.ilp.documentknowledgeservice.dto.UserResponseDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;
import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.repository.KnowledgeBaseRepository;

@ExtendWith(MockitoExtension.class)
class KnowledgeBaseServiceImplTest {

    @InjectMocks
    private KnowledgeBaseServiceImpl knowledgeBaseService;

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Mock
    private UserClient userClient;

    @Mock
    private ProjectClient projectClient;

    @Mock
    private NotificationClient notificationClient;

    private KnowledgeBaseRequestDto requestDto;
    private KnowledgeBaseEntity knowledgeBaseEntity;

    @BeforeEach
    void setUp() {

        requestDto = new KnowledgeBaseRequestDto();
        requestDto.setProjectStageId(1);
        requestDto.setDocumentId(100L);
        requestDto.setTitle("Java Notes");
        requestDto.setCategory("Programming");
        requestDto.setDescription("Core Java");
        requestDto.setPublishedBy(10);
        requestDto.setVisibility("PUBLIC");

        DocumentEntity document = new DocumentEntity();
        document.setDocumentId(100L);

        knowledgeBaseEntity = new KnowledgeBaseEntity();
        knowledgeBaseEntity.setKnowledgeId(1);
        knowledgeBaseEntity.setProjectStageId(1);
        knowledgeBaseEntity.setDocument(document);
        knowledgeBaseEntity.setTitle("Java Notes");
        knowledgeBaseEntity.setCategory("Programming");
        knowledgeBaseEntity.setDescription("Core Java");
        knowledgeBaseEntity.setPublishedBy(10);
        knowledgeBaseEntity.setPublishedOn(LocalDateTime.now());
        knowledgeBaseEntity.setVisibility("PUBLIC");
    }

    @Test
    void testCreateKnowledgeBaseSuccess() {

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenReturn(new ProjectResponseDto());

        when(knowledgeBaseRepository.existsByTitle("Java Notes"))
                .thenReturn(false);

        when(knowledgeBaseRepository.save(any(KnowledgeBaseEntity.class)))
                .thenReturn(knowledgeBaseEntity);

        doNothing().when(notificationClient)
                .createNotification(any(NotificationRequestDto.class));

        KnowledgeBaseResponseDto response =
                knowledgeBaseService.createKnowledgeBase(requestDto);

        assertNotNull(response);
        assertEquals(1, response.getKnowledgeId());
        assertEquals("Java Notes", response.getTitle());
        assertEquals("Programming", response.getCategory());
        assertEquals("PUBLIC", response.getVisibility());

        verify(userClient).getUserById(10);
        verify(projectClient).getProjectStageById(1L);
        verify(knowledgeBaseRepository).existsByTitle("Java Notes");
        verify(knowledgeBaseRepository).save(any(KnowledgeBaseEntity.class));
        verify(notificationClient)
                .createNotification(any(NotificationRequestDto.class));
    }

    @Test
    void testCreateKnowledgeBaseDuplicateTitle() {

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenReturn(new ProjectResponseDto());

        when(knowledgeBaseRepository.existsByTitle("Java Notes"))
                .thenReturn(true);

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Knowledge title already exists",
                exception.getMessage());

        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testCreateKnowledgeBaseUserNotFound() {

        when(userClient.getUserById(10))
                .thenThrow(new ResourceNotFoundException("User not found"));

        assertThrows(ResourceNotFoundException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testCreateKnowledgeBaseProjectStageNotFound() {

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenThrow(new ResourceNotFoundException("Project Stage not found"));

        assertThrows(ResourceNotFoundException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testCreateKnowledgeBaseNotificationFailure() {

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenReturn(new ProjectResponseDto());

        when(knowledgeBaseRepository.existsByTitle("Java Notes"))
                .thenReturn(false);

        when(knowledgeBaseRepository.save(any(KnowledgeBaseEntity.class)))
                .thenReturn(knowledgeBaseEntity);

        doThrow(new RuntimeException("Notification Failed"))
                .when(notificationClient)
                .createNotification(any(NotificationRequestDto.class));

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Notification Failed",
                exception.getMessage());
    }
    
    @Test
    void testCreateKnowledgeBaseNullRequest() {

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(null));

        assertEquals("Request cannot be null",
                exception.getMessage());

        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testCreateKnowledgeBaseNullProjectStageId() {

        requestDto.setProjectStageId(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Project Stage Id is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseNullDocumentId() {

        requestDto.setDocumentId(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Document Id is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseNullTitle() {

        requestDto.setTitle(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Title is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseEmptyTitle() {

        requestDto.setTitle("");

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Title is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseNullCategory() {

        requestDto.setCategory(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Category is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseEmptyCategory() {

        requestDto.setCategory("");

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Category is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseNullPublishedBy() {

        requestDto.setPublishedBy(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Published By is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseNullVisibility() {

        requestDto.setVisibility(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Visibility is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }

    @Test
    void testCreateKnowledgeBaseEmptyVisibility() {

        requestDto.setVisibility("");

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> knowledgeBaseService.createKnowledgeBase(requestDto));

        assertEquals("Visibility is required",
                exception.getMessage());

        verifyNoInteractions(userClient);
    }
    
    @Test
    void testUpdateKnowledgeBaseSuccess() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.of(knowledgeBaseEntity));

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenReturn(new ProjectResponseDto());

        when(knowledgeBaseRepository.save(any(KnowledgeBaseEntity.class)))
                .thenReturn(knowledgeBaseEntity);

        doNothing().when(notificationClient)
                .createNotification(any(NotificationRequestDto.class));

        KnowledgeBaseResponseDto response =
                knowledgeBaseService.updateKnowledgeBase(1, requestDto);

        assertNotNull(response);
        assertEquals(1, response.getKnowledgeId());
        assertEquals("Java Notes", response.getTitle());
        assertEquals("Programming", response.getCategory());
        assertEquals("PUBLIC", response.getVisibility());

        verify(knowledgeBaseRepository).findById(1);
        verify(knowledgeBaseRepository).save(any(KnowledgeBaseEntity.class));
        verify(notificationClient)
                .createNotification(any(NotificationRequestDto.class));
    }

    @Test
    void testUpdateKnowledgeBaseNotFound() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Knowledge Base not found",
                exception.getMessage());

        verify(knowledgeBaseRepository).findById(1);
        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testUpdateKnowledgeBaseUserNotFound() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.of(knowledgeBaseEntity));

        when(userClient.getUserById(10))
                .thenThrow(new ResourceNotFoundException("User not found"));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("User not found",
                exception.getMessage());

        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testUpdateKnowledgeBaseProjectStageNotFound() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.of(knowledgeBaseEntity));

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenThrow(new ResourceNotFoundException("Project Stage not found"));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Project Stage not found",
                exception.getMessage());

        verify(knowledgeBaseRepository, never()).save(any());
    }

    @Test
    void testUpdateKnowledgeBaseNotificationFailure() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.of(knowledgeBaseEntity));

        when(userClient.getUserById(10))
                .thenReturn(new UserResponseDto());

        when(projectClient.getProjectStageById(1L))
                .thenReturn(new ProjectResponseDto());

        when(knowledgeBaseRepository.save(any(KnowledgeBaseEntity.class)))
                .thenReturn(knowledgeBaseEntity);

        doThrow(new RuntimeException("Notification Failed"))
                .when(notificationClient)
                .createNotification(any(NotificationRequestDto.class));

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Notification Failed",
                exception.getMessage());
    }

    @Test
    void testUpdateKnowledgeBaseNullRequest() {

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, null));

        assertEquals("Request cannot be null",
                exception.getMessage());
    }

    @Test
    void testUpdateKnowledgeBaseNullProjectStageId() {

        requestDto.setProjectStageId(null);

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Project Stage Id is required",
                exception.getMessage());
    }

    @Test
    void testUpdateKnowledgeBaseNullDocumentId() {

        requestDto.setDocumentId(null);

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Document Id is required",
                exception.getMessage());
    }

    @Test
    void testUpdateKnowledgeBaseNullPublishedBy() {

        requestDto.setPublishedBy(null);

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Published By is required",
                exception.getMessage());
    }

    @Test
    void testUpdateKnowledgeBaseNullVisibility() {

        requestDto.setVisibility(null);

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Visibility is required",
                exception.getMessage());
    }

    @Test
    void testUpdateKnowledgeBaseEmptyVisibility() {

        requestDto.setVisibility("");

        RuntimeException exception =
                assertThrows(RuntimeException.class,
                        () -> knowledgeBaseService.updateKnowledgeBase(1, requestDto));

        assertEquals("Visibility is required",
                exception.getMessage());
    }
    
    @Test
    void testDeleteKnowledgeBaseSuccess() {

        when(knowledgeBaseRepository.existsById(1))
                .thenReturn(true);

        doNothing().when(knowledgeBaseRepository).deleteById(1);

        knowledgeBaseService.deleteKnowledgeBase(1);

        verify(knowledgeBaseRepository).existsById(1);
        verify(knowledgeBaseRepository).deleteById(1);
    }

    @Test
    void testDeleteKnowledgeBaseNotFound() {

        when(knowledgeBaseRepository.existsById(1))
                .thenReturn(false);

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeBaseService.deleteKnowledgeBase(1));

        assertEquals("Knowledge Base not found",
                exception.getMessage());

        verify(knowledgeBaseRepository, never()).deleteById(any());
    }

    @Test
    void testGetKnowledgeBaseByIdSuccess() {

        when(knowledgeBaseRepository.findByKnowledgeId(1))
                .thenReturn(Optional.of(knowledgeBaseEntity));

        KnowledgeBaseResponseDto response =
                knowledgeBaseService.getKnowledgeBaseById(1);

        assertNotNull(response);
        assertEquals(1, response.getKnowledgeId());
        assertEquals("Java Notes", response.getTitle());

        verify(knowledgeBaseRepository).findByKnowledgeId(1);
    }

    @Test
    void testGetKnowledgeBaseByIdNotFound() {

        when(knowledgeBaseRepository.findByKnowledgeId(1))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeBaseService.getKnowledgeBaseById(1));

        assertEquals("Knowledge Base not found",
                exception.getMessage());

        verify(knowledgeBaseRepository).findByKnowledgeId(1);
    }

    @Test
    void testGetAllKnowledgeBaseSuccess() {

        when(knowledgeBaseRepository.findAllByOrderByPublishedOnDesc())
                .thenReturn(Arrays.asList(knowledgeBaseEntity));

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getAllKnowledgeBase();

        assertEquals(1, response.size());
        assertEquals("Java Notes", response.get(0).getTitle());

        verify(knowledgeBaseRepository)
                .findAllByOrderByPublishedOnDesc();
    }

    @Test
    void testGetAllKnowledgeBaseEmpty() {

        when(knowledgeBaseRepository.findAllByOrderByPublishedOnDesc())
                .thenReturn(Collections.emptyList());

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getAllKnowledgeBase();

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(knowledgeBaseRepository)
                .findAllByOrderByPublishedOnDesc();
    }

    @Test
    void testSearchKnowledgeByTitleSuccess() {

        when(knowledgeBaseRepository.findByTitleContainingIgnoreCase("Java"))
                .thenReturn(Arrays.asList(knowledgeBaseEntity));

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.searchKnowledgeByTitle("Java");

        assertEquals(1, response.size());

        verify(knowledgeBaseRepository)
                .findByTitleContainingIgnoreCase("Java");
    }

    @Test
    void testSearchKnowledgeByTitleEmpty() {

        when(knowledgeBaseRepository.findByTitleContainingIgnoreCase("Python"))
                .thenReturn(Collections.emptyList());

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.searchKnowledgeByTitle("Python");

        assertTrue(response.isEmpty());

        verify(knowledgeBaseRepository)
                .findByTitleContainingIgnoreCase("Python");
    }

    @Test
    void testGetKnowledgeByCategorySuccess() {

        when(knowledgeBaseRepository.findByCategory("Programming"))
                .thenReturn(Arrays.asList(knowledgeBaseEntity));

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByCategory("Programming");

        assertEquals(1, response.size());

        verify(knowledgeBaseRepository)
                .findByCategory("Programming");
    }

    @Test
    void testGetKnowledgeByCategoryEmpty() {

        when(knowledgeBaseRepository.findByCategory("AI"))
                .thenReturn(Collections.emptyList());

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByCategory("AI");

        assertTrue(response.isEmpty());

        verify(knowledgeBaseRepository)
                .findByCategory("AI");
    }

    @Test
    void testGetKnowledgeByVisibilitySuccess() {

        when(knowledgeBaseRepository.findByVisibility("PUBLIC"))
                .thenReturn(Arrays.asList(knowledgeBaseEntity));

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByVisibility("PUBLIC");

        assertEquals(1, response.size());

        verify(knowledgeBaseRepository)
                .findByVisibility("PUBLIC");
    }

    @Test
    void testGetKnowledgeByVisibilityEmpty() {

        when(knowledgeBaseRepository.findByVisibility("PRIVATE"))
                .thenReturn(Collections.emptyList());

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByVisibility("PRIVATE");

        assertTrue(response.isEmpty());

        verify(knowledgeBaseRepository)
                .findByVisibility("PRIVATE");
    }

    @Test
    void testGetKnowledgeByProjectStageSuccess() {

        when(knowledgeBaseRepository.findByProjectStageId(1))
                .thenReturn(Arrays.asList(knowledgeBaseEntity));

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByProjectStage(1);

        assertEquals(1, response.size());

        verify(knowledgeBaseRepository)
                .findByProjectStageId(1);
    }

    @Test
    void testGetKnowledgeByProjectStageEmpty() {

        when(knowledgeBaseRepository.findByProjectStageId(99))
                .thenReturn(Collections.emptyList());

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByProjectStage(99);

        assertTrue(response.isEmpty());

        verify(knowledgeBaseRepository)
                .findByProjectStageId(99);
    }

    @Test
    void testGetKnowledgeByPublishedBySuccess() {

        when(knowledgeBaseRepository.findByPublishedBy(10))
                .thenReturn(Arrays.asList(knowledgeBaseEntity));

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByPublishedBy(10);

        assertEquals(1, response.size());

        verify(knowledgeBaseRepository)
                .findByPublishedBy(10);
    }

    @Test
    void testGetKnowledgeByPublishedByEmpty() {

        when(knowledgeBaseRepository.findByPublishedBy(999))
                .thenReturn(Collections.emptyList());

        List<KnowledgeBaseResponseDto> response =
                knowledgeBaseService.getKnowledgeByPublishedBy(999);

        assertTrue(response.isEmpty());

        verify(knowledgeBaseRepository)
                .findByPublishedBy(999);
    }
}