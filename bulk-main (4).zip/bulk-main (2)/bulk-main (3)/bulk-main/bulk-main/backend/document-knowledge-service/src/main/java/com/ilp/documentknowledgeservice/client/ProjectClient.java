package com.ilp.documentknowledgeservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ilp.documentknowledgeservice.dto.ProjectResponseDto;
import com.ilp.documentknowledgeservice.dto.ProjectTeamResponseDto;
import com.ilp.documentknowledgeservice.config.FeignConfig;

@FeignClient(
        name = "project-service",
        url = "${project-service.url}",
        configuration = FeignConfig.class
)
public interface ProjectClient {

    @GetMapping("/project-stage/{id}")
    ProjectResponseDto getProjectStageById(
            @PathVariable("id") Long projectStageId);

    @GetMapping("/api/projects/{projectId}")
    ProjectTeamResponseDto getProjectById(
            @PathVariable("projectId") Integer projectId);

    @GetMapping("/api/projects/faculty/{facultyId}")
    List<ProjectTeamResponseDto> getProjectsByFaculty(
            @PathVariable("facultyId") Integer facultyId);

}