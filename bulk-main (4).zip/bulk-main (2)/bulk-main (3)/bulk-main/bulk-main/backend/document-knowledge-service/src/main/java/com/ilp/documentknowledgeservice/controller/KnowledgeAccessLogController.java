package com.ilp.documentknowledgeservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogResponseDto;
import com.ilp.documentknowledgeservice.service.KnowledgeAccessLogService;

@RestController
@RequestMapping("/api/knowledge-access-log")
public class KnowledgeAccessLogController {

    private final KnowledgeAccessLogService knowledgeAccessLogService;

    public KnowledgeAccessLogController(KnowledgeAccessLogService knowledgeAccessLogService) {
        this.knowledgeAccessLogService = knowledgeAccessLogService;
    }

    // Create Access Log
    @PostMapping
    public ResponseEntity<KnowledgeAccessLogResponseDto> createAccessLog(
            @RequestBody KnowledgeAccessLogRequestDto requestDto) {

        return new ResponseEntity<>(
                knowledgeAccessLogService.createAccessLog(requestDto),
                HttpStatus.CREATED);
    }

    // Get Access Log by ID
    @GetMapping("/{accessId}")
    public ResponseEntity<KnowledgeAccessLogResponseDto> getAccessLogById(
            @PathVariable Integer accessId) {

        return ResponseEntity.ok(
                knowledgeAccessLogService.getAccessLogById(accessId));
    }

    // Get All Access Logs
    @GetMapping
    public ResponseEntity<List<KnowledgeAccessLogResponseDto>> getAllAccessLogs() {

        return ResponseEntity.ok(
                knowledgeAccessLogService.getAllAccessLogs());
    }

    // Get Logs by Student
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<KnowledgeAccessLogResponseDto>> getAccessLogsByStudent(
            @PathVariable Integer studentId) {

        return ResponseEntity.ok(
                knowledgeAccessLogService.getAccessLogsByStudent(studentId));
    }

    // Get Logs by Knowledge Base
    @GetMapping("/knowledge/{knowledgeId}")
    public ResponseEntity<List<KnowledgeAccessLogResponseDto>> getAccessLogsByKnowledge(
            @PathVariable Integer knowledgeId) {

        return ResponseEntity.ok(
                knowledgeAccessLogService.getAccessLogsByKnowledge(knowledgeId));
    }

    // Get Logs by Action
    @GetMapping("/action/{action}")
    public ResponseEntity<List<KnowledgeAccessLogResponseDto>> getAccessLogsByAction(
            @PathVariable String action) {

        return ResponseEntity.ok(
                knowledgeAccessLogService.getAccessLogsByAction(action));
    }

    // Delete Access Log
    @DeleteMapping("/{accessId}")
    public ResponseEntity<String> deleteAccessLog(
            @PathVariable Integer accessId) {

        knowledgeAccessLogService.deleteAccessLog(accessId);

        return ResponseEntity.ok("Access Log deleted successfully.");
    }
}