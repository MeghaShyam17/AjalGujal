package com.ilp.documentknowledgeservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.documentknowledgeservice.entity.EnquiryManagementEntity;

@Repository
public interface EnquiryManagementRepository
        extends JpaRepository<EnquiryManagementEntity, Integer> {

    List<EnquiryManagementEntity> findByUserId(Integer userId);

    List<EnquiryManagementEntity> findByProjectId(Integer projectId);

    List<EnquiryManagementEntity> findByProjectIdIn(List<Integer> projectIds);
}