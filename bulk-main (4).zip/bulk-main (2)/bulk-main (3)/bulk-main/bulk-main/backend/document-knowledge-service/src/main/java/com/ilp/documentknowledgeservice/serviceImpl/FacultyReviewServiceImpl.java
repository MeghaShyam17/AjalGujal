package com.ilp.documentknowledgeservice.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import feign.FeignException;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.client.UserClient;

import com.ilp.documentknowledgeservice.dto.FacultyReviewRequestDto;
import com.ilp.documentknowledgeservice.dto.FacultyReviewResponseDto;
import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;
import com.ilp.documentknowledgeservice.dto.ProjectResponseDto;

import com.ilp.documentknowledgeservice.entity.FacultyReviewEntity;

import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;

import com.ilp.documentknowledgeservice.mapper.FacultyReviewMapper;

import com.ilp.documentknowledgeservice.repository.FacultyReviewRepository;

import com.ilp.documentknowledgeservice.service.FacultyReviewService;

@Service
public class FacultyReviewServiceImpl
        implements FacultyReviewService {

    @Autowired
    private FacultyReviewRepository facultyReviewRepository;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private NotificationClient notificationClient;

    @Override
    public FacultyReviewResponseDto addFacultyReview(
            FacultyReviewRequestDto reviewDto) {

        validateFacultyReview(reviewDto);

        // Validate Faculty
        try {
            userClient.getUserById(
                    reviewDto.getFacultyId());
        } catch (FeignException ex) {
            throw new ResourceNotFoundException(
                    "Faculty not found with ID : "
                            + reviewDto.getFacultyId());
        }

        // Validate Project Stage
        ProjectResponseDto projectResponse;

        try {

            projectResponse =
                    projectClient.getProjectStageById(
                            Long.valueOf(
                                    reviewDto.getProjectStageId()));

        } catch (FeignException ex) {

            throw new ResourceNotFoundException(
                    "Project Stage not found with ID : "
                            + reviewDto.getProjectStageId());
        }

        FacultyReviewEntity entity =
                FacultyReviewMapper.toEntity(reviewDto);

        entity.setReviewedOn(
                LocalDateTime.now());

        FacultyReviewEntity savedReview =
                facultyReviewRepository.save(entity);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(
                reviewDto.getFacultyId());

        notification.setTitle(
                "Faculty Review Added");

        notification.setMessage(
                "Faculty review has been submitted successfully.");

        notification.setNotificationType(
                "FACULTY_REVIEW");

        notification.setModuleName(
                "Faculty Review");

        notification.setReferenceId(
                savedReview.getReviewId());

        notification.setPriority(
                "Medium");

        notificationClient.createNotification(
                notification);

        return FacultyReviewMapper
                .toResponseDto(savedReview);
    }
    
    @Override
    public FacultyReviewResponseDto getFacultyReviewById(
            Integer reviewId) {

        FacultyReviewEntity review =
                facultyReviewRepository.findById(reviewId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Faculty Review not found with ID : "
                                                + reviewId));

        return FacultyReviewMapper.toResponseDto(review);
    }

    @Override
    public List<FacultyReviewResponseDto> getAllFacultyReviews() {

        List<FacultyReviewEntity> reviews =
                facultyReviewRepository.findAll();

        return reviews.stream()
                .map(FacultyReviewMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<FacultyReviewResponseDto> getReviewsByProjectStageId(
            Integer projectStageId) {

        try {
            projectClient.getProjectStageById(
                    Long.valueOf(projectStageId));

        } catch (FeignException ex) {

            throw new ResourceNotFoundException(
                    "Project Stage not found with ID : "
                            + projectStageId);
        }

        List<FacultyReviewEntity> reviews =
                facultyReviewRepository.findByProjectStageId(
                        projectStageId);

        return reviews.stream()
                .map(FacultyReviewMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<FacultyReviewResponseDto> getReviewsByFacultyId(
            Integer facultyId) {

        try {
            userClient.getUserById(facultyId);

        } catch (FeignException ex) {

            throw new ResourceNotFoundException(
                    "Faculty not found with ID : "
                            + facultyId);
        }

        List<FacultyReviewEntity> reviews =
                facultyReviewRepository.findByFacultyId(
                        facultyId);

        return reviews.stream()
                .map(FacultyReviewMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<FacultyReviewResponseDto> getReviewsByDocumentId(
            Integer documentId) {

        List<FacultyReviewEntity> reviews =
                facultyReviewRepository.findByDocumentId(
                        documentId);

        return reviews.stream()
                .map(FacultyReviewMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<FacultyReviewResponseDto> getReviewsByStatus(
            String reviewStatus) {

        List<FacultyReviewEntity> reviews =
                facultyReviewRepository.findByReviewStatus(
                        reviewStatus);

        return reviews.stream()
                .map(FacultyReviewMapper::toResponseDto)
                .toList();
    }
    
    @Override
    public FacultyReviewResponseDto updateFacultyReview(
            Integer reviewId,
            FacultyReviewRequestDto reviewDto) {

        validateFacultyReview(reviewDto);

        FacultyReviewEntity existingReview =
                facultyReviewRepository.findById(reviewId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Faculty Review not found with ID : "
                                                + reviewId));

        try {
            userClient.getUserById(reviewDto.getFacultyId());

        } catch (FeignException ex) {

            throw new ResourceNotFoundException(
                    "Faculty not found with ID : "
                            + reviewDto.getFacultyId());
        }

        try {
            projectClient.getProjectStageById(
                    Long.valueOf(reviewDto.getProjectStageId()));

        } catch (FeignException ex) {

            throw new ResourceNotFoundException(
                    "Project Stage not found with ID : "
                            + reviewDto.getProjectStageId());
        }

        existingReview.setProjectStageId(
                reviewDto.getProjectStageId());

        existingReview.setFacultyId(
                reviewDto.getFacultyId());

        existingReview.setDocumentId(
                reviewDto.getDocumentId());

        existingReview.setReviewStatus(
                reviewDto.getReviewStatus());

        existingReview.setReviewComment(
                reviewDto.getReviewComment());

        existingReview.setReviewedOn(
                LocalDateTime.now());

        FacultyReviewEntity updatedReview =
                facultyReviewRepository.save(existingReview);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(
                reviewDto.getFacultyId());

        notification.setTitle(
                "Faculty Review Updated");

        notification.setMessage(
                "Faculty review has been updated successfully.");

        notification.setNotificationType(
                "FACULTY_REVIEW");

        notification.setModuleName(
                "Faculty Review");

        notification.setReferenceId(
                updatedReview.getReviewId());

        notification.setPriority(
                "Medium");

        notificationClient.createNotification(
                notification);

        return FacultyReviewMapper.toResponseDto(
                updatedReview);
    }

    @Override
    public FacultyReviewResponseDto updateReviewStatus(
            Integer reviewId,
            String reviewStatus) {

        FacultyReviewEntity review =
                facultyReviewRepository.findById(reviewId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Faculty Review not found with ID : "
                                                + reviewId));

        review.setReviewStatus(reviewStatus);
        review.setReviewedOn(LocalDateTime.now());

        FacultyReviewEntity updatedReview =
                facultyReviewRepository.save(review);

        return FacultyReviewMapper.toResponseDto(
                updatedReview);
    }

    @Override
    public void deleteFacultyReview(
            Integer reviewId) {

        FacultyReviewEntity review =
                facultyReviewRepository.findById(reviewId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Faculty Review not found with ID : "
                                                + reviewId));

        facultyReviewRepository.delete(review);
    }

    private void validateFacultyReview(
            FacultyReviewRequestDto reviewDto) {

        if (reviewDto.getProjectStageId() == null
                || reviewDto.getProjectStageId() <= 0) {

            throw new IllegalArgumentException(
                    "Project Stage ID is required.");
        }

        if (reviewDto.getFacultyId() == null
                || reviewDto.getFacultyId() <= 0) {

            throw new IllegalArgumentException(
                    "Faculty ID is required.");
        }

        if (reviewDto.getDocumentId() == null
                || reviewDto.getDocumentId() <= 0) {

            throw new IllegalArgumentException(
                    "Document ID is required.");
        }

        if (reviewDto.getReviewStatus() == null
                || reviewDto.getReviewStatus().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Review Status is required.");
        }

        if (reviewDto.getReviewComment() == null
                || reviewDto.getReviewComment().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Review Comment is required.");
        }
    }
}