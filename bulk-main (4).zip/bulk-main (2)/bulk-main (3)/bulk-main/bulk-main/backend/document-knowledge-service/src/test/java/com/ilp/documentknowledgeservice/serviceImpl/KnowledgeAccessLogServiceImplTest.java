package com.ilp.documentknowledgeservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogResponseDto;
import com.ilp.documentknowledgeservice.entity.KnowledgeAccessLogEntity;
import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.repository.KnowledgeAccessLogRepository;
import com.ilp.documentknowledgeservice.repository.KnowledgeBaseRepository;

@ExtendWith(MockitoExtension.class)
class KnowledgeAccessLogServiceImplTest {

    @InjectMocks
    private KnowledgeAccessLogServiceImpl knowledgeAccessLogService;

    @Mock
    private KnowledgeAccessLogRepository knowledgeAccessLogRepository;

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    private KnowledgeAccessLogRequestDto requestDto;
    private KnowledgeBaseEntity knowledgeBase;
    private KnowledgeAccessLogEntity accessLogEntity;

    @BeforeEach
    void setUp() {

        requestDto = new KnowledgeAccessLogRequestDto();
        requestDto.setKnowledgeId(1);
        requestDto.setStudentId(100);
        requestDto.setAction("Viewed");

        knowledgeBase = new KnowledgeBaseEntity();
        knowledgeBase.setKnowledgeId(1);

        accessLogEntity = new KnowledgeAccessLogEntity();
        accessLogEntity.setAccessId(1);
        accessLogEntity.setKnowledgeBase(knowledgeBase);
        accessLogEntity.setStudentId(100);
        accessLogEntity.setAction("Viewed");
        accessLogEntity.setAccessedOn(LocalDateTime.now());
    }

    @Test
    void testCreateAccessLogSuccess() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.of(knowledgeBase));

        when(knowledgeAccessLogRepository.save(any(KnowledgeAccessLogEntity.class)))
                .thenReturn(accessLogEntity);

        KnowledgeAccessLogResponseDto response =
                knowledgeAccessLogService.createAccessLog(requestDto);

        assertNotNull(response);
        assertEquals(1, response.getAccessId());
        assertEquals(1, response.getKnowledgeId());
        assertEquals(100, response.getStudentId());
        assertEquals("Viewed", response.getAction());

        verify(knowledgeBaseRepository).findById(1);
        verify(knowledgeAccessLogRepository)
                .save(any(KnowledgeAccessLogEntity.class));
    }

    @Test
    void testCreateAccessLogKnowledgeBaseNotFound() {

        when(knowledgeBaseRepository.findById(1))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeAccessLogService.createAccessLog(requestDto));

        assertEquals("Knowledge Base not found", exception.getMessage());

        verify(knowledgeAccessLogRepository, never())
                .save(any(KnowledgeAccessLogEntity.class));
    }
    
    @Test
    void testGetAccessLogByIdSuccess() {

        when(knowledgeAccessLogRepository.findById(1))
                .thenReturn(Optional.of(accessLogEntity));

        KnowledgeAccessLogResponseDto response =
                knowledgeAccessLogService.getAccessLogById(1);

        assertNotNull(response);
        assertEquals(1, response.getAccessId());
        assertEquals(1, response.getKnowledgeId());
        assertEquals(100, response.getStudentId());
        assertEquals("Viewed", response.getAction());

        verify(knowledgeAccessLogRepository).findById(1);
    }

    @Test
    void testGetAccessLogByIdNotFound() {

        when(knowledgeAccessLogRepository.findById(1))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeAccessLogService.getAccessLogById(1));

        assertEquals("Access Log not found", exception.getMessage());

        verify(knowledgeAccessLogRepository).findById(1);
    }

    @Test
    void testGetAllAccessLogsSuccess() {

        when(knowledgeAccessLogRepository.findAll())
                .thenReturn(java.util.Arrays.asList(accessLogEntity));

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAllAccessLogs();

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(1, response.get(0).getKnowledgeId());
        assertEquals(100, response.get(0).getStudentId());
        assertEquals("Viewed", response.get(0).getAction());

        verify(knowledgeAccessLogRepository).findAll();
    }

    @Test
    void testGetAllAccessLogsEmpty() {

        when(knowledgeAccessLogRepository.findAll())
                .thenReturn(java.util.Collections.emptyList());

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAllAccessLogs();

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(knowledgeAccessLogRepository).findAll();
    }
    
    @Test
    void testGetAccessLogsByStudentSuccess() {

        when(knowledgeAccessLogRepository.findByStudentId(100))
                .thenReturn(Arrays.asList(accessLogEntity));

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAccessLogsByStudent(100);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(100, response.get(0).getStudentId());
        assertEquals("Viewed", response.get(0).getAction());

        verify(knowledgeAccessLogRepository).findByStudentId(100);
    }

    @Test
    void testGetAccessLogsByStudentEmpty() {

        when(knowledgeAccessLogRepository.findByStudentId(999))
                .thenReturn(Collections.emptyList());

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAccessLogsByStudent(999);

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(knowledgeAccessLogRepository).findByStudentId(999);
    }

    @Test
    void testGetAccessLogsByKnowledgeSuccess() {

        when(knowledgeAccessLogRepository.findByKnowledgeBaseKnowledgeId(1))
                .thenReturn(Arrays.asList(accessLogEntity));

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAccessLogsByKnowledge(1);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(1, response.get(0).getKnowledgeId());

        verify(knowledgeAccessLogRepository)
                .findByKnowledgeBaseKnowledgeId(1);
    }

    @Test
    void testGetAccessLogsByKnowledgeEmpty() {

        when(knowledgeAccessLogRepository.findByKnowledgeBaseKnowledgeId(99))
                .thenReturn(Collections.emptyList());

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAccessLogsByKnowledge(99);

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(knowledgeAccessLogRepository)
                .findByKnowledgeBaseKnowledgeId(99);
    }
    
    @Test
    void testGetAccessLogsByActionSuccess() {

        when(knowledgeAccessLogRepository.findByAction("Viewed"))
                .thenReturn(Arrays.asList(accessLogEntity));

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAccessLogsByAction("Viewed");

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("Viewed", response.get(0).getAction());

        verify(knowledgeAccessLogRepository).findByAction("Viewed");
    }

    @Test
    void testGetAccessLogsByActionEmpty() {

        when(knowledgeAccessLogRepository.findByAction("Downloaded"))
                .thenReturn(Collections.emptyList());

        List<KnowledgeAccessLogResponseDto> response =
                knowledgeAccessLogService.getAccessLogsByAction("Downloaded");

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(knowledgeAccessLogRepository).findByAction("Downloaded");
    }

    @Test
    void testDeleteAccessLogSuccess() {

        when(knowledgeAccessLogRepository.findById(1))
                .thenReturn(Optional.of(accessLogEntity));

        doNothing().when(knowledgeAccessLogRepository)
                .delete(accessLogEntity);

        knowledgeAccessLogService.deleteAccessLog(1);

        verify(knowledgeAccessLogRepository).findById(1);
        verify(knowledgeAccessLogRepository).delete(accessLogEntity);
    }

    @Test
    void testDeleteAccessLogNotFound() {

        when(knowledgeAccessLogRepository.findById(1))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeAccessLogService.deleteAccessLog(1));

        assertEquals("Access Log not found", exception.getMessage());

        verify(knowledgeAccessLogRepository).findById(1);
        verify(knowledgeAccessLogRepository, never())
                .delete(any(KnowledgeAccessLogEntity.class));
    }
}