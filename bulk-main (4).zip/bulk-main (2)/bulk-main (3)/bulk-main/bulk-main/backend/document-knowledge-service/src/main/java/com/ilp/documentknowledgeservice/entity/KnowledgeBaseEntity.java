package com.ilp.documentknowledgeservice.entity;

import java.time.*;
import jakarta.persistence.*;

@Entity
@Table(name = "knowledge_base")
public class KnowledgeBaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "knowledge_id")
    private Integer knowledgeId;

    @Column(name = "project_stage_id")
    private Integer projectStageId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_id", referencedColumnName = "document_id")
    private DocumentEntity document;

    @Column(name = "title", length = 200)
    private String title;

    @Column(name = "category", length = 100)
    private String category;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "published_by")
    private Integer publishedBy;

    @Column(name = "published_on")
    private LocalDateTime publishedOn;

    @Column(name = "visibility", length = 20)
    private String visibility;

    // Default Constructor
    public KnowledgeBaseEntity() {
    }

    // Parameterized Constructor
    public KnowledgeBaseEntity(Integer knowledgeId, Integer projectStageId, DocumentEntity document,
                               String title, String category, String description,
                               Integer publishedBy, LocalDateTime publishedOn,
                               String visibility) {
        this.knowledgeId = knowledgeId;
        this.projectStageId = projectStageId;
        this.document = document;
        this.title = title;
        this.category = category;
        this.description = description;
        this.publishedBy = publishedBy;
        this.publishedOn = publishedOn;
        this.visibility = visibility;
    }

    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public Integer getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Integer projectStageId) {
        this.projectStageId = projectStageId;
    }

    public DocumentEntity getDocument() {
        return document;
    }

    public void setDocument(DocumentEntity document) {
        this.document = document;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPublishedBy() {
        return publishedBy;
    }

    public void setPublishedBy(Integer publishedBy) {
        this.publishedBy = publishedBy;
    }

    public LocalDateTime getPublishedOn() {
        return publishedOn;
    }

    public void setPublishedOn(LocalDateTime publishedOn) {
        this.publishedOn = publishedOn;
    }

    public String getVisibility() {
        return visibility;
    }

    public void setVisibility(String visibility) {
        this.visibility = visibility;
    }
}