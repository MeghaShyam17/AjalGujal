package com.ilp.documentknowledgeservice.dto;

import java.time.LocalDateTime;

public class KnowledgeAccessLogResponseDto {

    private Integer accessId;
    private Integer knowledgeId;
    private Integer studentId;
    private String action;
    private LocalDateTime accessedOn;

    // Default Constructor
    public KnowledgeAccessLogResponseDto() {
    }

    // Parameterized Constructor
    public KnowledgeAccessLogResponseDto(Integer accessId, Integer knowledgeId,
            Integer studentId, String action, LocalDateTime accessedOn) {

        this.accessId = accessId;
        this.knowledgeId = knowledgeId;
        this.studentId = studentId;
        this.action = action;
        this.accessedOn = accessedOn;
    }

    public Integer getAccessId() {
        return accessId;
    }

    public void setAccessId(Integer accessId) {
        this.accessId = accessId;
    }

    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public LocalDateTime getAccessedOn() {
        return accessedOn;
    }

    public void setAccessedOn(LocalDateTime accessedOn) {
        this.accessedOn = accessedOn;
    }
}