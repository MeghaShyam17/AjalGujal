package com.ilp.documentknowledgeservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ilp.documentknowledgeservice.dto.UserResponseDto;
import com.ilp.documentknowledgeservice.config.FeignConfig;

@FeignClient(
	    name = "user-service",
	    url = "${user.service.url}",
	    configuration = FeignConfig.class
	)
public interface UserClient {

    @GetMapping("/api/users/{userId}")
    UserResponseDto getUserById(
            @PathVariable Integer userId);
}