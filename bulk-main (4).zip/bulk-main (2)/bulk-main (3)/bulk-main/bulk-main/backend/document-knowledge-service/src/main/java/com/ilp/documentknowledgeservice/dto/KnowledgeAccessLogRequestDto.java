package com.ilp.documentknowledgeservice.dto;

public class KnowledgeAccessLogRequestDto {

    private Integer knowledgeId;
    private Integer studentId;
    private String action;

    // Default Constructor
    public KnowledgeAccessLogRequestDto() {
    }

    // Parameterized Constructor
    public KnowledgeAccessLogRequestDto(Integer knowledgeId, Integer studentId, String action) {
        this.knowledgeId = knowledgeId;
        this.studentId = studentId;
        this.action = action;
    }

    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}