package com.ilp.documentknowledgeservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementRequestDto;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementResponseDto;
import com.ilp.documentknowledgeservice.dto.ProjectTeamResponseDto;
import com.ilp.documentknowledgeservice.entity.EnquiryManagementEntity;
import com.ilp.documentknowledgeservice.exception.EnquiryManagementException;
import com.ilp.documentknowledgeservice.mapper.EnquiryManagementMapper;
import com.ilp.documentknowledgeservice.repository.EnquiryManagementRepository;

@ExtendWith(MockitoExtension.class)
class EnquiryManagementServiceImplTest {

    @Mock
    private EnquiryManagementRepository repository;

    @Mock
    private EnquiryManagementMapper mapper;

    @Mock
    private NotificationClient notificationClient;

    @Mock
    private ProjectClient projectClient;

    @InjectMocks
    private EnquiryManagementServiceImpl service;

    private EnquiryManagementRequestDto requestDto;
    private EnquiryManagementEntity entity;
    private EnquiryManagementResponseDto responseDto;
    private ProjectTeamResponseDto projectTeamDto;

    @BeforeEach
    void setUp() {

        requestDto = new EnquiryManagementRequestDto();
        requestDto.setUserId(501);
        requestDto.setProjectId(101);
        requestDto.setUserComment("When should we submit the document?");

        entity = new EnquiryManagementEntity();
        entity.setEnquiryId(1);
        entity.setUserId(501);
        entity.setProjectId(101);
        entity.setUserComment("When should we submit the document?");
        entity.setEnquiryStatus("In Progress");
        entity.setCreatedAt(LocalDateTime.now());

        responseDto = new EnquiryManagementResponseDto();
        responseDto.setEnquiryId(1);
        responseDto.setUserId(501);
        responseDto.setProjectId(101);
        responseDto.setProjectName("BrainVision");
        responseDto.setUserComment("When should we submit the document?");
        responseDto.setEnquiryStatus("In Progress");

        projectTeamDto = new ProjectTeamResponseDto(101, "BrainVision", 20);
    }

    // ===============================
    // createEnquiry()
    // ===============================

    @Test
    void testCreateEnquirySuccess() {

        when(projectClient.getProjectById(101))
                .thenReturn(projectTeamDto);

        when(mapper.toEntity(requestDto))
                .thenReturn(entity);

        when(repository.save(any(EnquiryManagementEntity.class)))
                .thenReturn(entity);

        when(mapper.toResponse(entity, "BrainVision"))
                .thenReturn(responseDto);

        doNothing().when(notificationClient)
                .createNotification(any());

        EnquiryManagementResponseDto response =
                service.createEnquiry(requestDto);

        assertNotNull(response);
        assertEquals(1, response.getEnquiryId());
        assertEquals(501, response.getUserId());
        assertEquals(101, response.getProjectId());
        assertEquals("BrainVision", response.getProjectName());
        assertEquals("In Progress", response.getEnquiryStatus());

        verify(projectClient).getProjectById(101);
        verify(mapper).toEntity(requestDto);
        verify(repository).save(any(EnquiryManagementEntity.class));
        verify(notificationClient).createNotification(any());
        verify(mapper).toResponse(entity, "BrainVision");
    }

    @Test
    void testCreateEnquiryNullRequest() {

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createEnquiry(null));

        verify(repository, never()).save(any());
        verify(notificationClient, never()).createNotification(any());
    }

    @Test
    void testCreateEnquiryProjectNotFound() {

        when(projectClient.getProjectById(101))
                .thenReturn(null);

        EnquiryManagementException ex = assertThrows(
                EnquiryManagementException.class,
                () -> service.createEnquiry(requestDto));

        assertTrue(ex.getMessage().contains("Project not found"));
        verify(repository, never()).save(any());
    }

    @Test
    void testCreateEnquiryNoFacultyAssigned() {

        ProjectTeamResponseDto noFacultyProject = new ProjectTeamResponseDto(101, "BrainVision", null);
        when(projectClient.getProjectById(101))
                .thenReturn(noFacultyProject);

        EnquiryManagementException ex = assertThrows(
                EnquiryManagementException.class,
                () -> service.createEnquiry(requestDto));

        assertTrue(ex.getMessage().contains("No faculty assigned"));
        verify(repository, never()).save(any());
    }

    // ===============================
    // getAllEnquiries()
    // ===============================

    @Test
    void testGetAllEnquiriesSuccess() {

        when(repository.findAll())
                .thenReturn(Arrays.asList(entity));

        when(projectClient.getProjectById(101))
                .thenReturn(projectTeamDto);

        when(mapper.toResponse(entity, "BrainVision"))
                .thenReturn(responseDto);

        List<EnquiryManagementResponseDto> response =
                service.getAllEnquiries();

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("BrainVision", response.get(0).getProjectName());

        verify(repository).findAll();
        verify(mapper).toResponse(entity, "BrainVision");
    }

    // ===============================
    // getEnquiryById()
    // ===============================

    @Test
    void testGetEnquiryByIdSuccess() {

        when(repository.findById(1))
                .thenReturn(Optional.of(entity));

        when(projectClient.getProjectById(101))
                .thenReturn(projectTeamDto);

        when(mapper.toResponse(entity, "BrainVision"))
                .thenReturn(responseDto);

        EnquiryManagementResponseDto response =
                service.getEnquiryById(1);

        assertNotNull(response);
        assertEquals(1, response.getEnquiryId());
        assertEquals("BrainVision", response.getProjectName());

        verify(repository).findById(1);
        verify(mapper).toResponse(entity, "BrainVision");
    }

    @Test
    void testGetEnquiryByIdNotFound() {

        when(repository.findById(100))
                .thenReturn(Optional.empty());

        EnquiryManagementException exception =
                assertThrows(
                        EnquiryManagementException.class,
                        () -> service.getEnquiryById(100));

        assertEquals(
                "Enquiry not found with id: 100",
                exception.getMessage());

        verify(repository).findById(100);
    }

    // ===============================
    // getEnquiriesByUserId()
    // ===============================

    @Test
    void testGetEnquiriesByUserIdSuccess() {

        when(repository.findByUserId(501))
                .thenReturn(Arrays.asList(entity));

        when(projectClient.getProjectById(101))
                .thenReturn(projectTeamDto);

        when(mapper.toResponse(entity, "BrainVision"))
                .thenReturn(responseDto);

        List<EnquiryManagementResponseDto> response =
                service.getEnquiriesByUserId(501);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(501, response.get(0).getUserId());

        verify(repository).findByUserId(501);
    }

    // ===============================
    // getEnquiriesByFacultyId()
    // ===============================

    @Test
    void testGetEnquiriesByFacultyIdSuccess() {

        ProjectTeamResponseDto proj1 = new ProjectTeamResponseDto(101, "BrainVision", 20);
        ProjectTeamResponseDto proj2 = new ProjectTeamResponseDto(102, "BloodConnect", 20);

        when(projectClient.getProjectsByFaculty(20))
                .thenReturn(Arrays.asList(proj1, proj2));

        when(repository.findByProjectIdIn(anyList()))
                .thenReturn(Arrays.asList(entity));

        when(mapper.toResponse(entity, "BrainVision"))
                .thenReturn(responseDto);

        List<EnquiryManagementResponseDto> response =
                service.getEnquiriesByFacultyId(20);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("BrainVision", response.get(0).getProjectName());

        verify(projectClient).getProjectsByFaculty(20);
        verify(repository).findByProjectIdIn(anyList());
    }

    @Test
    void testGetEnquiriesByFacultyIdNoProjects() {

        when(projectClient.getProjectsByFaculty(999))
                .thenReturn(Collections.emptyList());

        List<EnquiryManagementResponseDto> response =
                service.getEnquiriesByFacultyId(999);

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(projectClient).getProjectsByFaculty(999);
        verify(repository, never()).findByProjectIdIn(any());
    }

    // ===============================
    // facultyReply()
    // ===============================

    @Test
    void testFacultyReplySuccess() {

        responseDto.setFacultyComment("Submit by Friday");
        responseDto.setEnquiryStatus("Closed");

        when(repository.findById(1))
                .thenReturn(Optional.of(entity));

        when(repository.save(any(EnquiryManagementEntity.class)))
                .thenReturn(entity);

        when(projectClient.getProjectById(101))
                .thenReturn(projectTeamDto);

        when(mapper.toResponse(entity, "BrainVision"))
                .thenReturn(responseDto);

        doNothing().when(notificationClient)
                .createNotification(any());

        EnquiryManagementResponseDto response =
                service.facultyReply(1, "Submit by Friday");

        assertNotNull(response);
        assertEquals("Submit by Friday", response.getFacultyComment());
        assertEquals("Closed", response.getEnquiryStatus());

        verify(repository).findById(1);
        verify(repository).save(any(EnquiryManagementEntity.class));
        verify(notificationClient).createNotification(any());
        verify(mapper).toResponse(entity, "BrainVision");
    }

    // ===============================
    // deleteEnquiry()
    // ===============================

    @Test
    void testDeleteEnquirySuccess() {

        when(repository.existsById(1))
                .thenReturn(true);

        doNothing().when(repository)
                .deleteById(1);

        service.deleteEnquiry(1);

        verify(repository).existsById(1);
        verify(repository).deleteById(1);
    }

    @Test
    void testDeleteEnquiryNotFound() {

        when(repository.existsById(100))
                .thenReturn(false);

        EnquiryManagementException exception =
                assertThrows(
                        EnquiryManagementException.class,
                        () -> service.deleteEnquiry(100));

        assertEquals(
                "Enquiry not found with id: 100",
                exception.getMessage());

        verify(repository).existsById(100);
        verify(repository, never()).deleteById(anyInt());
    }
}