package com.ilp.documentknowledgeservice.dto;

public class FacultyReviewRequestDto {

    private Integer projectStageId;
    private Integer facultyId;
    private Integer documentId;
    private String reviewStatus;
    private String reviewComment;

    public FacultyReviewRequestDto() {
    }

    public FacultyReviewRequestDto(
            Integer projectStageId,
            Integer facultyId,
            Integer documentId,
            String reviewStatus,
            String reviewComment) {

        this.projectStageId = projectStageId;
        this.facultyId = facultyId;
        this.documentId = documentId;
        this.reviewStatus = reviewStatus;
        this.reviewComment = reviewComment;
    }

    public Integer getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Integer projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Integer facultyId) {
        this.facultyId = facultyId;
    }

    public Integer getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Integer documentId) {
        this.documentId = documentId;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getReviewComment() {
        return reviewComment;
    }

    public void setReviewComment(String reviewComment) {
        this.reviewComment = reviewComment;
    }

    @Override
    public String toString() {
        return "FacultyReviewRequestDto{" +
                "projectStageId=" + projectStageId +
                ", facultyId=" + facultyId +
                ", documentId=" + documentId +
                ", reviewStatus='" + reviewStatus + '\'' +
                ", reviewComment='" + reviewComment + '\'' +
                '}';
    }
}