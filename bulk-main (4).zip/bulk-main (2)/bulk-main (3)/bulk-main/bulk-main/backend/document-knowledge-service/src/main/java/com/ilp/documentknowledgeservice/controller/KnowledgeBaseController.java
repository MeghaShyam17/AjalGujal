package com.ilp.documentknowledgeservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilp.documentknowledgeservice.dto.KnowledgeBaseRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseResponseDto;
import com.ilp.documentknowledgeservice.service.KnowledgeBaseService;

@RestController
@RequestMapping("/api/knowledge-base")
public class KnowledgeBaseController {

    private final KnowledgeBaseService knowledgeBaseService;

    public KnowledgeBaseController(KnowledgeBaseService knowledgeBaseService) {
        this.knowledgeBaseService = knowledgeBaseService;
    }

    // Add Knowledge Base
    @PostMapping
    public ResponseEntity<KnowledgeBaseResponseDto> createKnowledgeBase(
            @RequestBody KnowledgeBaseRequestDto requestDto) {

        return new ResponseEntity<>(
                knowledgeBaseService.createKnowledgeBase(requestDto),
                HttpStatus.CREATED);
    }

    // Update Knowledge Base
    @PutMapping("/{knowledgeId}")
    public ResponseEntity<KnowledgeBaseResponseDto> updateKnowledgeBase(
            @PathVariable Integer knowledgeId,
            @RequestBody KnowledgeBaseRequestDto requestDto) {

        return ResponseEntity.ok(
                knowledgeBaseService.updateKnowledgeBase(knowledgeId, requestDto));
    }

    // Delete Knowledge Base
    @DeleteMapping("/{knowledgeId}")
    public ResponseEntity<String> deleteKnowledgeBase(
            @PathVariable Integer knowledgeId) {

        knowledgeBaseService.deleteKnowledgeBase(knowledgeId);
        return ResponseEntity.ok("Knowledge Base deleted successfully.");
    }

    // Get Knowledge Base by Id
    @GetMapping("/{knowledgeId}")
    public ResponseEntity<KnowledgeBaseResponseDto> getKnowledgeBaseById(
            @PathVariable Integer knowledgeId) {

        return ResponseEntity.ok(
                knowledgeBaseService.getKnowledgeBaseById(knowledgeId));
    }

    // Get All Knowledge Base
    @GetMapping
    public ResponseEntity<List<KnowledgeBaseResponseDto>> getAllKnowledgeBase() {

        return ResponseEntity.ok(
                knowledgeBaseService.getAllKnowledgeBase());
    }

    // Search by Title
    @GetMapping("/title/{title}")
    public ResponseEntity<List<KnowledgeBaseResponseDto>> searchKnowledgeByTitle(
            @PathVariable String title) {

        return ResponseEntity.ok(
                knowledgeBaseService.searchKnowledgeByTitle(title));
    }

    // Search by Category
    @GetMapping("/category/{category}")
    public ResponseEntity<List<KnowledgeBaseResponseDto>> getKnowledgeByCategory(
            @PathVariable String category) {

        return ResponseEntity.ok(
                knowledgeBaseService.getKnowledgeByCategory(category));
    }

    // Search by Visibility
    @GetMapping("/visibility/{visibility}")
    public ResponseEntity<List<KnowledgeBaseResponseDto>> getKnowledgeByVisibility(
            @PathVariable String visibility) {

        return ResponseEntity.ok(
                knowledgeBaseService.getKnowledgeByVisibility(visibility));
    }

    // Search by Project Stage
    @GetMapping("/project-stage/{projectStageId}")
    public ResponseEntity<List<KnowledgeBaseResponseDto>> getKnowledgeByProjectStage(
            @PathVariable Integer projectStageId) {

        return ResponseEntity.ok(
                knowledgeBaseService.getKnowledgeByProjectStage(projectStageId));
    }

    // Search by Published By
    @GetMapping("/published-by/{publishedBy}")
    public ResponseEntity<List<KnowledgeBaseResponseDto>> getKnowledgeByPublishedBy(
            @PathVariable Integer publishedBy) {

        return ResponseEntity.ok(
                knowledgeBaseService.getKnowledgeByPublishedBy(publishedBy));
    }
}