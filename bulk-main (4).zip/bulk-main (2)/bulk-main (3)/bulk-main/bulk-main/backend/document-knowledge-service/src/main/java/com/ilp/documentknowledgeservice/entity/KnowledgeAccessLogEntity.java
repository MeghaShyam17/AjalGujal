package com.ilp.documentknowledgeservice.entity;

import java.time.*;
import jakarta.persistence.*;

@Entity
@Table(name = "knowledge_access_log")
public class KnowledgeAccessLogEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "access_id")
    private Integer accessId;

    // Many access logs belong to one Knowledge Base
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "knowledge_id", referencedColumnName = "knowledge_id")
    private KnowledgeBaseEntity knowledgeBase;

    // Student belongs to another microservice
    @Column(name = "student_id")
    private Integer studentId;

    @Column(name = "action", length = 20)
    private String action;

    @Column(name = "accessed_on")
    private LocalDateTime accessedOn;

    // Default Constructor
    public KnowledgeAccessLogEntity() {
    }

    // Parameterized Constructor
    public KnowledgeAccessLogEntity(Integer accessId, KnowledgeBaseEntity knowledgeBase,
            Integer studentId, String action, LocalDateTime accessedOn) {
        this.accessId = accessId;
        this.knowledgeBase = knowledgeBase;
        this.studentId = studentId;
        this.action = action;
        this.accessedOn = accessedOn;
    }

    public Integer getAccessId() {
        return accessId;
    }

    public void setAccessId(Integer accessId) {
        this.accessId = accessId;
    }

    public KnowledgeBaseEntity getKnowledgeBase() {
        return knowledgeBase;
    }

    public void setKnowledgeBase(KnowledgeBaseEntity knowledgeBase) {
        this.knowledgeBase = knowledgeBase;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public LocalDateTime getAccessedOn() {
        return accessedOn;
    }

    public void setAccessedOn(LocalDateTime accessedOn) {
        this.accessedOn = accessedOn;
    }

}