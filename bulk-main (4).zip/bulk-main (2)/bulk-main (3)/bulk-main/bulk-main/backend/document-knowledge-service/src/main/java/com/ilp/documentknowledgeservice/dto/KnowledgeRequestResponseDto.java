package com.ilp.documentknowledgeservice.dto;

import java.time.LocalDateTime;

public class KnowledgeRequestResponseDto{

    private Long requestId;
    private Long studentId;
    private Long knowledgeId;
    private String requestReason;
    private String requestStatus;
    private Long approvedBy;
    private LocalDateTime approvedOn;
    private LocalDateTime requestedOn;
    private String remarks;

    public KnowledgeRequestResponseDto() {
    }

    public KnowledgeRequestResponseDto(Long requestId,
                                       Long studentId,
                                       Long knowledgeId,
                                       String requestReason,
                                       String requestStatus,
                                       Long approvedBy,
                                       LocalDateTime approvedOn,
                                       LocalDateTime requestedOn,
                                       String remarks) {
        this.requestId = requestId;
        this.studentId = studentId;
        this.knowledgeId = knowledgeId;
        this.requestReason = requestReason;
        this.requestStatus = requestStatus;
        this.approvedBy = approvedBy;
        this.approvedOn = approvedOn;
        this.requestedOn = requestedOn;
        this.remarks = remarks;
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Long getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Long knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public String getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(String requestReason) {
        this.requestReason = requestReason;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public Long getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Long approvedBy) {
        this.approvedBy = approvedBy;
    }

    public LocalDateTime getApprovedOn() {
        return approvedOn;
    }

    public void setApprovedOn(LocalDateTime approvedOn) {
        this.approvedOn = approvedOn;
    }

    public LocalDateTime getRequestedOn() {
        return requestedOn;
    }

    public void setRequestedOn(LocalDateTime requestedOn) {
        this.requestedOn = requestedOn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}