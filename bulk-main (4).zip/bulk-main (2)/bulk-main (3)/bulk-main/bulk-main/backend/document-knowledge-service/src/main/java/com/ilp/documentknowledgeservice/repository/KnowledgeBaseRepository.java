package com.ilp.documentknowledgeservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;

@Repository
public interface KnowledgeBaseRepository extends JpaRepository<KnowledgeBaseEntity, Integer> {

    // Find Knowledge by ID
    Optional<KnowledgeBaseEntity> findByKnowledgeId(Integer knowledgeId);

    // Find by Title
    List<KnowledgeBaseEntity> findByTitle(String title);

    // Search Title (LIKE)
    List<KnowledgeBaseEntity> findByTitleContainingIgnoreCase(String title);

    // Find by Category
    List<KnowledgeBaseEntity> findByCategory(String category);

    // Search Category (LIKE)
    List<KnowledgeBaseEntity> findByCategoryContainingIgnoreCase(String category);

    // Find by Visibility
    List<KnowledgeBaseEntity> findByVisibility(String visibility);

    // Find by Project Stage ID
    List<KnowledgeBaseEntity> findByProjectStageId(Integer projectStageId);

    // Find by Published By
    List<KnowledgeBaseEntity> findByPublishedBy(Integer publishedBy);

    // Find by Category and Visibility
    List<KnowledgeBaseEntity> findByCategoryAndVisibility(String category, String visibility);

    // Find by Document ID
    Optional<KnowledgeBaseEntity> findByDocumentDocumentId(Long documentId);

    // Check whether a title already exists
    boolean existsByTitle(String title);

    // Delete by Document ID
    void deleteByDocumentDocumentId(Long documentId);

    // Get all knowledge ordered by published date (latest first)
    List<KnowledgeBaseEntity> findAllByOrderByPublishedOnDesc();

}