package com.ilp.documentknowledgeservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.sql.Timestamp;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.FeignException;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.DocumentRequestDto;
import com.ilp.documentknowledgeservice.dto.DocumentResponseDto;
import com.ilp.documentknowledgeservice.dto.ProjectResponseDto;
import com.ilp.documentknowledgeservice.dto.UserResponseDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.repository.DocumentRepository;

@ExtendWith(MockitoExtension.class)
class DocumentServiceImplTest {

    @InjectMocks
    private DocumentServiceImpl documentService;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private ProjectClient projectClient;

    @Mock
    private UserClient userClient;

    @Mock
    private NotificationClient notificationClient;

    private DocumentRequestDto requestDto;
    private DocumentEntity documentEntity;
    private UserResponseDto userResponse;
    private ProjectResponseDto projectResponse;

    @BeforeEach
    void setUp() {

        requestDto = new DocumentRequestDto();
        requestDto.setProjectStageId(1L);
        requestDto.setUploadedBy(101);
        requestDto.setVersionNo(1);
        requestDto.setDocumentType("PDF");
        requestDto.setTitle("Java Notes");
        requestDto.setFileName("java.pdf");
        requestDto.setOriginalFileName("java_notes.pdf");
        requestDto.setFileData("Sample".getBytes());
        requestDto.setFileSize(6L);
        requestDto.setDescription("Core Java Notes");

        documentEntity = new DocumentEntity();
        documentEntity.setDocumentId(1L);
        documentEntity.setProjectStageId(1L);
        documentEntity.setUploadedBy(101);
        documentEntity.setVersionNo(1);
        documentEntity.setDocumentType("PDF");
        documentEntity.setTitle("Java Notes");
        documentEntity.setFileName("java.pdf");
        documentEntity.setOriginalFileName("java_notes.pdf");
        documentEntity.setFileData("Sample".getBytes());
        documentEntity.setFileSize(6L);
        documentEntity.setDescription("Core Java Notes");
        documentEntity.setUploadedAt(
                new Timestamp(System.currentTimeMillis()));

        userResponse = new UserResponseDto();
        userResponse.setUserId(101);
        userResponse.setName("John");

        projectResponse = new ProjectResponseDto();
        projectResponse.setProjectStageId(1L);
    }
    
    // ===============================
    // addDocument()
    // ===============================

    @Test
    void testAddDocumentSuccess() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenReturn(projectResponse);

        when(documentRepository.save(any(DocumentEntity.class)))
                .thenReturn(documentEntity);

        DocumentResponseDto response =
                documentService.addDocument(requestDto);

        assertNotNull(response);
        assertEquals(1L, response.getDocumentId());
        assertEquals("Java Notes", response.getTitle());

        verify(userClient).getUserById(101);
        verify(projectClient).getProjectStageById(1L);
        verify(documentRepository)
                .save(any(DocumentEntity.class));
        verify(notificationClient)
                .createNotification(any());
    }

    @Test
    void testAddDocumentNullRequest() {

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(null));

        assertEquals(
                "Document request cannot be null.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentNullProjectStageId() {

        requestDto.setProjectStageId(null);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "Project Stage ID is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentNullUploadedBy() {

        requestDto.setUploadedBy(null);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "Uploaded By is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentEmptyTitle() {

        requestDto.setTitle("");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "Document title is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentEmptyDocumentType() {

        requestDto.setDocumentType("");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "Document type is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentEmptyFileName() {

        requestDto.setFileName("");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "File name is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentNullFileData() {

        requestDto.setFileData(null);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "File data is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentEmptyFileData() {

        requestDto.setFileData(new byte[0]);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "File data is required.",
                exception.getMessage());
    }

    @Test
    void testAddDocumentUserNotFound() {

        when(userClient.getUserById(101))
                .thenThrow(mock(FeignException.class));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "User not found with ID : 101",
                exception.getMessage());

        verify(documentRepository, never())
                .save(any());
    }

    @Test
    void testAddDocumentProjectStageNotFound() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenThrow(mock(FeignException.class));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.addDocument(requestDto));

        assertEquals(
                "Project Stage not found with ID : 1",
                exception.getMessage());

        verify(documentRepository, never())
                .save(any());
    }

    @Test
    void testAddDocumentDefaultVersionNumber() {

        requestDto.setVersionNo(null);

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenReturn(projectResponse);

        when(documentRepository.save(any(DocumentEntity.class)))
                .thenReturn(documentEntity);

        documentService.addDocument(requestDto);

        assertEquals(1, requestDto.getVersionNo());

        verify(documentRepository)
                .save(any(DocumentEntity.class));
    }

    @Test
    void testAddDocumentAutoCalculateFileSize() {

        requestDto.setFileSize(null);
        requestDto.setFileData("Updated".getBytes());

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenReturn(projectResponse);

        when(documentRepository.save(any(DocumentEntity.class)))
                .thenReturn(documentEntity);

        documentService.addDocument(requestDto);

        assertNotNull(requestDto.getFileSize());

        verify(documentRepository)
                .save(any(DocumentEntity.class));
    }
    
    // ===============================
    // getDocumentById()
    // ===============================

    @Test
    void testGetDocumentByIdSuccess() {

        when(documentRepository.findById(1L))
                .thenReturn(Optional.of(documentEntity));

        DocumentResponseDto response =
                documentService.getDocumentById(1L);

        assertNotNull(response);
        assertEquals(1L, response.getDocumentId());
        assertEquals("Java Notes", response.getTitle());

        verify(documentRepository).findById(1L);
    }

    @Test
    void testGetDocumentByIdNotFound() {

        when(documentRepository.findById(10L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.getDocumentById(10L));

        assertEquals(
                "Document not found with ID : 10",
                exception.getMessage());

        verify(documentRepository).findById(10L);
    }


    // ===============================
    // getAllDocuments()
    // ===============================

    @Test
    void testGetAllDocumentsSuccess() {

        when(documentRepository.findAll())
                .thenReturn(java.util.Arrays.asList(documentEntity));

        java.util.List<DocumentResponseDto> response =
                documentService.getAllDocuments();

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("Java Notes",
                response.get(0).getTitle());

        verify(documentRepository).findAll();
    }

    @Test
    void testGetAllDocumentsEmpty() {

        when(documentRepository.findAll())
                .thenReturn(java.util.Collections.emptyList());

        java.util.List<DocumentResponseDto> response =
                documentService.getAllDocuments();

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(documentRepository).findAll();
    }


    // ===============================
    // getDocumentsByProjectStageId()
    // ===============================

    @Test
    void testGetDocumentsByProjectStageIdSuccess() {

        when(projectClient.getProjectStageById(1L))
                .thenReturn(projectResponse);

        when(documentRepository.findByProjectStageId(1L))
                .thenReturn(java.util.Arrays.asList(documentEntity));

        java.util.List<DocumentResponseDto> response =
                documentService.getDocumentsByProjectStageId(1L);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(1L,
                response.get(0).getProjectStageId());

        verify(projectClient).getProjectStageById(1L);
        verify(documentRepository)
                .findByProjectStageId(1L);
    }

    @Test
    void testGetDocumentsByProjectStageIdNotFound() {

        when(projectClient.getProjectStageById(1L))
                .thenThrow(mock(FeignException.class));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService
                                .getDocumentsByProjectStageId(1L));

        assertEquals(
                "Project Stage not found with ID : 1",
                exception.getMessage());

        verify(documentRepository, never())
                .findByProjectStageId(anyLong());
    }


    // ===============================
    // getDocumentsByUploadedBy()
    // ===============================

    @Test
    void testGetDocumentsByUploadedBySuccess() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(documentRepository.findByUploadedBy(101))
                .thenReturn(java.util.Arrays.asList(documentEntity));

        java.util.List<DocumentResponseDto> response =
                documentService.getDocumentsByUploadedBy(101);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(101,
                response.get(0).getUploadedBy());

        verify(userClient).getUserById(101);
        verify(documentRepository)
                .findByUploadedBy(101);
    }

    @Test
    void testGetDocumentsByUploadedByNotFound() {

        when(userClient.getUserById(101))
                .thenThrow(mock(FeignException.class));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService
                                .getDocumentsByUploadedBy(101));

        assertEquals(
                "User not found with ID : 101",
                exception.getMessage());

        verify(documentRepository, never())
                .findByUploadedBy(anyInt());
    }

    @Test
    void testGetDocumentsByUploadedByEmpty() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(documentRepository.findByUploadedBy(101))
                .thenReturn(java.util.Collections.emptyList());

        java.util.List<DocumentResponseDto> response =
                documentService.getDocumentsByUploadedBy(101);

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(userClient).getUserById(101);
        verify(documentRepository)
                .findByUploadedBy(101);
    }
    
    // ===============================
    // updateDocument()
    // ===============================

    @Test
    void testUpdateDocumentSuccess() {

        when(documentRepository.findById(1L))
                .thenReturn(Optional.of(documentEntity));

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenReturn(projectResponse);

        when(documentRepository.save(any(DocumentEntity.class)))
                .thenReturn(documentEntity);

        DocumentResponseDto response =
                documentService.updateDocument(1L, requestDto);

        assertNotNull(response);
        assertEquals(1L, response.getDocumentId());
        assertEquals("Java Notes", response.getTitle());

        verify(documentRepository).findById(1L);
        verify(userClient).getUserById(101);
        verify(projectClient).getProjectStageById(1L);
        verify(documentRepository).save(any(DocumentEntity.class));
        verify(notificationClient).createNotification(any());
    }

    @Test
    void testUpdateDocumentNotFound() {

        when(documentRepository.findById(10L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.updateDocument(10L, requestDto));

        assertEquals(
                "Document not found with ID : 10",
                exception.getMessage());

        verify(documentRepository).findById(10L);
        verify(documentRepository, never()).save(any());
    }

    @Test
    void testUpdateDocumentUserNotFound() {

        when(documentRepository.findById(1L))
                .thenReturn(Optional.of(documentEntity));

        when(userClient.getUserById(101))
                .thenThrow(mock(FeignException.class));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "User not found with ID : 101",
                exception.getMessage());

        verify(documentRepository, never()).save(any());
    }

    @Test
    void testUpdateDocumentProjectStageNotFound() {

        when(documentRepository.findById(1L))
                .thenReturn(Optional.of(documentEntity));

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenThrow(mock(FeignException.class));

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "Project Stage not found with ID : 1",
                exception.getMessage());

        verify(documentRepository, never()).save(any());
    }

    @Test
    void testUpdateDocumentNullRequest() {

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, null));

        assertEquals(
                "Document request cannot be null.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentNullProjectStageId() {

        requestDto.setProjectStageId(null);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "Project Stage ID is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentNullUploadedBy() {

        requestDto.setUploadedBy(null);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "Uploaded By is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentEmptyTitle() {

        requestDto.setTitle("");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "Document title is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentEmptyDocumentType() {

        requestDto.setDocumentType("");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "Document type is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentEmptyFileName() {

        requestDto.setFileName("");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "File name is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentNullFileData() {

        requestDto.setFileData(null);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "File data is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentEmptyFileData() {

        requestDto.setFileData(new byte[0]);

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> documentService.updateDocument(1L, requestDto));

        assertEquals(
                "File data is required.",
                exception.getMessage());
    }

    @Test
    void testUpdateDocumentAutoCalculateFileSize() {

        requestDto.setFileSize(null);
        requestDto.setFileData("Updated File".getBytes());

        when(documentRepository.findById(1L))
                .thenReturn(Optional.of(documentEntity));

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(projectClient.getProjectStageById(1L))
                .thenReturn(projectResponse);

        when(documentRepository.save(any(DocumentEntity.class)))
                .thenReturn(documentEntity);

        documentService.updateDocument(1L, requestDto);

        verify(documentRepository).save(any(DocumentEntity.class));
        verify(notificationClient).createNotification(any());
    }
    
    // ===============================
    // deleteDocument()
    // ===============================

    @Test
    void testDeleteDocumentSuccess() {

        when(documentRepository.findById(1L))
                .thenReturn(Optional.of(documentEntity));

        doNothing().when(documentRepository)
                .delete(documentEntity);

        assertDoesNotThrow(() ->
                documentService.deleteDocument(1L));

        verify(documentRepository).findById(1L);
        verify(documentRepository).delete(documentEntity);
        verify(notificationClient).createNotification(any());
    }

    @Test
    void testDeleteDocumentNotFound() {

        when(documentRepository.findById(100L))
                .thenReturn(Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> documentService.deleteDocument(100L));

        assertEquals(
                "Document not found with ID : 100",
                exception.getMessage());

        verify(documentRepository).findById(100L);
        verify(documentRepository, never())
                .delete(any(DocumentEntity.class));
        verify(notificationClient, never())
                .createNotification(any());
    }

}