package com.ilp.documentknowledgeservice.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogResponseDto;
import com.ilp.documentknowledgeservice.entity.KnowledgeAccessLogEntity;
import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;
import com.ilp.documentknowledgeservice.mapper.KnowledgeAccessLogMapper;
import com.ilp.documentknowledgeservice.repository.KnowledgeAccessLogRepository;
import com.ilp.documentknowledgeservice.repository.KnowledgeBaseRepository;
import com.ilp.documentknowledgeservice.service.KnowledgeAccessLogService;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;

@Service
@Transactional
public class KnowledgeAccessLogServiceImpl implements KnowledgeAccessLogService {

    private final KnowledgeAccessLogRepository knowledgeAccessLogRepository;
    private final KnowledgeBaseRepository knowledgeBaseRepository;

    public KnowledgeAccessLogServiceImpl(
            KnowledgeAccessLogRepository knowledgeAccessLogRepository,
            KnowledgeBaseRepository knowledgeBaseRepository) {

        this.knowledgeAccessLogRepository = knowledgeAccessLogRepository;
        this.knowledgeBaseRepository = knowledgeBaseRepository;
    }

    @Override
    public KnowledgeAccessLogResponseDto createAccessLog(
            KnowledgeAccessLogRequestDto requestDto) {

        KnowledgeBaseEntity knowledgeBase = knowledgeBaseRepository
                .findById(requestDto.getKnowledgeId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Knowledge Base not found"));

        KnowledgeAccessLogEntity entity =
                KnowledgeAccessLogMapper.toEntity(requestDto);

        entity.setKnowledgeBase(knowledgeBase);
        entity.setAccessedOn(LocalDateTime.now());

        KnowledgeAccessLogEntity savedEntity =
                knowledgeAccessLogRepository.save(entity);

        return KnowledgeAccessLogMapper.toResponseDto(savedEntity);
    }

    @Override
    public KnowledgeAccessLogResponseDto getAccessLogById(Integer accessId) {

        KnowledgeAccessLogEntity entity =
                knowledgeAccessLogRepository.findById(accessId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Access Log not found"));

        return KnowledgeAccessLogMapper.toResponseDto(entity);
    }

    @Override
    public List<KnowledgeAccessLogResponseDto> getAllAccessLogs() {

        return knowledgeAccessLogRepository.findAll()
                .stream()
                .map(KnowledgeAccessLogMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeAccessLogResponseDto> getAccessLogsByStudent(
            Integer studentId) {

        return knowledgeAccessLogRepository
                .findByStudentId(studentId)
                .stream()
                .map(KnowledgeAccessLogMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeAccessLogResponseDto> getAccessLogsByKnowledge(
            Integer knowledgeId) {

        return knowledgeAccessLogRepository
                .findByKnowledgeBaseKnowledgeId(knowledgeId)
                .stream()
                .map(KnowledgeAccessLogMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeAccessLogResponseDto> getAccessLogsByAction(
            String action) {

        return knowledgeAccessLogRepository
                .findByAction(action)
                .stream()
                .map(KnowledgeAccessLogMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteAccessLog(Integer accessId) {

        KnowledgeAccessLogEntity entity =
                knowledgeAccessLogRepository.findById(accessId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Access Log not found"));

        knowledgeAccessLogRepository.delete(entity);
    }

}