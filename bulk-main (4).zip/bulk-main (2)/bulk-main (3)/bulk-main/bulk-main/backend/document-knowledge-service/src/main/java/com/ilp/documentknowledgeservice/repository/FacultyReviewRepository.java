package com.ilp.documentknowledgeservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.documentknowledgeservice.entity.*;

@Repository
public interface FacultyReviewRepository extends JpaRepository<FacultyReviewEntity, Integer> {

    List<FacultyReviewEntity> findByProjectStageId(Integer projectStageId);

    List<FacultyReviewEntity> findByFacultyId(Integer facultyId);

    List<FacultyReviewEntity> findByDocumentId(Integer documentId);

    List<FacultyReviewEntity> findByReviewStatus(String reviewStatus);
}