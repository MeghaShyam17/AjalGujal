package com.ilp.documentknowledgeservice.service;

import com.ilp.documentknowledgeservice.dto.KnowledgeRequestRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestResponseDto;

import java.util.List;

public interface KnowledgeRequestService {

    KnowledgeRequestResponseDto createRequest(
            KnowledgeRequestRequestDto requestDto);

    KnowledgeRequestResponseDto getRequestById(
            Long requestId);

    List<KnowledgeRequestResponseDto> getAllRequests();

    List<KnowledgeRequestResponseDto> getRequestsByStudentId(
            Long studentId);

    List<KnowledgeRequestResponseDto> getRequestsByKnowledgeId(
            Long knowledgeId);

    List<KnowledgeRequestResponseDto> getRequestsByStatus(
            String status);

    KnowledgeRequestResponseDto approveRequest(
            Long requestId,
            Long approvedBy,
            String remarks);

    KnowledgeRequestResponseDto rejectRequest(
            Long requestId,
            Long approvedBy,
            String remarks);

    void deleteRequest(
            Long requestId);
}