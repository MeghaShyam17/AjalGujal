package com.ilp.documentknowledgeservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestResponseDto;
import com.ilp.documentknowledgeservice.dto.UserResponseDto;
import com.ilp.documentknowledgeservice.entity.KnowledgeRequestEntity;
import com.ilp.documentknowledgeservice.exception.BadRequestException;
import com.ilp.documentknowledgeservice.exception.DuplicateResourceException;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.repository.KnowledgeRequestRepository;

@ExtendWith(MockitoExtension.class)
class KnowledgeRequestServiceImplTest {

    @InjectMocks
    private KnowledgeRequestServiceImpl knowledgeRequestService;

    @Mock
    private KnowledgeRequestRepository repository;

    @Mock
    private UserClient userClient;

    @Mock
    private NotificationClient notificationClient;

    private KnowledgeRequestRequestDto requestDto;
    private KnowledgeRequestEntity requestEntity;
    private UserResponseDto userResponse;

    @BeforeEach
    void setUp() {

        requestDto = new KnowledgeRequestRequestDto();
        requestDto.setStudentId(101L);
        requestDto.setKnowledgeId(1001L);
        requestDto.setRequestReason("Need this document");

        requestEntity = new KnowledgeRequestEntity();
        requestEntity.setRequestId(1L);
        requestEntity.setStudentId(101L);
        requestEntity.setKnowledgeId(1001L);
        requestEntity.setRequestReason("Need this document");
        requestEntity.setRequestStatus("Pending");
        requestEntity.setRequestedOn(LocalDateTime.now());

        userResponse = new UserResponseDto();
        userResponse.setUserId(101);
        userResponse.setName("John");
    }
    
    // ===============================
    // createRequest()
    // ===============================

    @Test
    void testCreateRequestSuccess() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(repository.findByStudentIdAndRequestStatus(101L, "Pending"))
                .thenReturn(new ArrayList<>());

        when(repository.save(any(KnowledgeRequestEntity.class)))
                .thenReturn(requestEntity);

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.createRequest(requestDto);

        assertNotNull(response);
        assertEquals(1L, response.getRequestId());
        assertEquals(101L, response.getStudentId());
        assertEquals(1001L, response.getKnowledgeId());

        verify(userClient).getUserById(101);
        verify(repository)
                .findByStudentIdAndRequestStatus(101L, "Pending");
        verify(repository).save(any(KnowledgeRequestEntity.class));
        verify(notificationClient).createNotification(any());
    }

    @Test
    void testCreateRequestStudentNotFound() {

        when(userClient.getUserById(101))
                .thenReturn(null);

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeRequestService.createRequest(requestDto));

        assertEquals(
                "Student not found with id: 101",
                exception.getMessage());

        verify(repository, never()).save(any());
        verify(notificationClient, never()).createNotification(any());
    }

    @Test
    void testCreateRequestDuplicatePendingRequest() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        KnowledgeRequestEntity existingRequest =
                new KnowledgeRequestEntity();

        existingRequest.setKnowledgeId(1001L);
        existingRequest.setRequestStatus("Pending");

        when(repository.findByStudentIdAndRequestStatus(101L, "Pending"))
                .thenReturn(java.util.Arrays.asList(existingRequest));

        DuplicateResourceException exception =
                assertThrows(DuplicateResourceException.class,
                        () -> knowledgeRequestService.createRequest(requestDto));

        assertEquals(
                "A pending request already exists for this knowledge item.",
                exception.getMessage());

        verify(repository, never()).save(any());
        verify(notificationClient, never()).createNotification(any());
    }

    @Test
    void testCreateRequestNoDuplicateRequest() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        KnowledgeRequestEntity existingRequest =
                new KnowledgeRequestEntity();

        existingRequest.setKnowledgeId(2000L);

        when(repository.findByStudentIdAndRequestStatus(101L, "Pending"))
                .thenReturn(java.util.Arrays.asList(existingRequest));

        when(repository.save(any(KnowledgeRequestEntity.class)))
                .thenReturn(requestEntity);

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.createRequest(requestDto);

        assertNotNull(response);
        assertEquals(1L, response.getRequestId());

        verify(repository).save(any(KnowledgeRequestEntity.class));
        verify(notificationClient).createNotification(any());
    }
    
    // ===============================
    // getRequestById()
    // ===============================

    @Test
    void testGetRequestByIdSuccess() {

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.getRequestById(1L);

        assertNotNull(response);
        assertEquals(1L, response.getRequestId());
        assertEquals(101L, response.getStudentId());

        verify(repository).findById(1L);
    }

    @Test
    void testGetRequestByIdNotFound() {

        when(repository.findById(10L))
                .thenReturn(java.util.Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeRequestService.getRequestById(10L));

        assertEquals(
                "Knowledge request not found with id: 10",
                exception.getMessage());

        verify(repository).findById(10L);
    }


    // ===============================
    // getAllRequests()
    // ===============================

    @Test
    void testGetAllRequestsSuccess() {

        when(repository.findAll())
                .thenReturn(java.util.Arrays.asList(requestEntity));

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getAllRequests();

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(1L, response.get(0).getRequestId());

        verify(repository).findAll();
    }

    @Test
    void testGetAllRequestsEmpty() {

        when(repository.findAll())
                .thenReturn(java.util.Collections.emptyList());

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getAllRequests();

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(repository).findAll();
    }


    // ===============================
    // getRequestsByStudentId()
    // ===============================

    @Test
    void testGetRequestsByStudentIdSuccess() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(repository.findByStudentId(101L))
                .thenReturn(java.util.Arrays.asList(requestEntity));

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getRequestsByStudentId(101L);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(101L, response.get(0).getStudentId());

        verify(userClient).getUserById(101);
        verify(repository).findByStudentId(101L);
    }

    @Test
    void testGetRequestsByStudentIdEmpty() {

        when(userClient.getUserById(101))
                .thenReturn(userResponse);

        when(repository.findByStudentId(101L))
                .thenReturn(java.util.Collections.emptyList());

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getRequestsByStudentId(101L);

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(userClient).getUserById(101);
        verify(repository).findByStudentId(101L);
    }


    // ===============================
    // getRequestsByKnowledgeId()
    // ===============================

    @Test
    void testGetRequestsByKnowledgeIdSuccess() {

        when(repository.findByKnowledgeId(1001L))
                .thenReturn(java.util.Arrays.asList(requestEntity));

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getRequestsByKnowledgeId(1001L);

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(1001L, response.get(0).getKnowledgeId());

        verify(repository).findByKnowledgeId(1001L);
    }

    @Test
    void testGetRequestsByKnowledgeIdEmpty() {

        when(repository.findByKnowledgeId(1001L))
                .thenReturn(java.util.Collections.emptyList());

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getRequestsByKnowledgeId(1001L);

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(repository).findByKnowledgeId(1001L);
    }


    // ===============================
    // getRequestsByStatus()
    // ===============================

    @Test
    void testGetRequestsByStatusSuccess() {

        when(repository.findByRequestStatus("Pending"))
                .thenReturn(java.util.Arrays.asList(requestEntity));

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getRequestsByStatus("Pending");

        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("Pending",
                response.get(0).getRequestStatus());

        verify(repository).findByRequestStatus("Pending");
    }

    @Test
    void testGetRequestsByStatusEmpty() {

        when(repository.findByRequestStatus("Pending"))
                .thenReturn(java.util.Collections.emptyList());

        java.util.List<KnowledgeRequestResponseDto> response =
                knowledgeRequestService.getRequestsByStatus("Pending");

        assertNotNull(response);
        assertTrue(response.isEmpty());

        verify(repository).findByRequestStatus("Pending");
    }
    
    // ===============================
    // approveRequest()
    // ===============================

    @Test
    void testApproveRequestSuccess() {

        requestEntity.setRequestStatus("Pending");

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        when(repository.save(any(KnowledgeRequestEntity.class)))
                .thenReturn(requestEntity);

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.approveRequest(
                        1L,
                        201L,
                        "Approved successfully");

        assertNotNull(response);
        assertEquals("Approved", response.getRequestStatus());
        assertEquals(201L, response.getApprovedBy());
        assertEquals("Approved successfully",
                response.getRemarks());
        assertNotNull(response.getApprovedOn());

        verify(repository).findById(1L);
        verify(repository).save(any(KnowledgeRequestEntity.class));
        verify(notificationClient).createNotification(any());
    }

    @Test
    void testApproveRequestNotFound() {

        when(repository.findById(10L))
                .thenReturn(java.util.Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeRequestService.approveRequest(
                                10L,
                                201L,
                                "Approved"));

        assertEquals(
                "Knowledge request not found with id: 10",
                exception.getMessage());

        verify(repository).findById(10L);
        verify(repository, never()).save(any());
        verify(notificationClient, never())
                .createNotification(any());
    }

    @Test
    void testApproveRequestAlreadyApproved() {

        requestEntity.setRequestStatus("Approved");

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        BadRequestException exception =
                assertThrows(BadRequestException.class,
                        () -> knowledgeRequestService.approveRequest(
                                1L,
                                201L,
                                "Approved"));

        assertEquals(
                "Request is already approved.",
                exception.getMessage());

        verify(repository).findById(1L);
        verify(repository, never()).save(any());
        verify(notificationClient, never())
                .createNotification(any());
    }

    @Test
    void testApproveRequestFromRejectedStatus() {

        requestEntity.setRequestStatus("Rejected");

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        when(repository.save(any(KnowledgeRequestEntity.class)))
                .thenReturn(requestEntity);

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.approveRequest(
                        1L,
                        300L,
                        "Re-approved");

        assertNotNull(response);
        assertEquals("Approved",
                response.getRequestStatus());
        assertEquals(300L,
                response.getApprovedBy());

        verify(repository).save(any(KnowledgeRequestEntity.class));
        verify(notificationClient).createNotification(any());
    }
    
    // ===============================
    // rejectRequest()
    // ===============================

    @Test
    void testRejectRequestSuccess() {

        requestEntity.setRequestStatus("Pending");

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        when(repository.save(any(KnowledgeRequestEntity.class)))
                .thenReturn(requestEntity);

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.rejectRequest(
                        1L,
                        201L,
                        "Rejected due to insufficient details");

        assertNotNull(response);
        assertEquals("Rejected", response.getRequestStatus());
        assertEquals(201L, response.getApprovedBy());
        assertEquals("Rejected due to insufficient details",
                response.getRemarks());
        assertNotNull(response.getApprovedOn());

        verify(repository).findById(1L);
        verify(repository).save(any(KnowledgeRequestEntity.class));
        verify(notificationClient).createNotification(any());
    }

    @Test
    void testRejectRequestNotFound() {

        when(repository.findById(10L))
                .thenReturn(java.util.Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeRequestService.rejectRequest(
                                10L,
                                201L,
                                "Rejected"));

        assertEquals(
                "Knowledge request not found with id: 10",
                exception.getMessage());

        verify(repository).findById(10L);
        verify(repository, never()).save(any());
        verify(notificationClient, never()).createNotification(any());
    }

    @Test
    void testRejectRequestAlreadyRejected() {

        requestEntity.setRequestStatus("Rejected");

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        BadRequestException exception =
                assertThrows(BadRequestException.class,
                        () -> knowledgeRequestService.rejectRequest(
                                1L,
                                201L,
                                "Rejected"));

        assertEquals(
                "Request is already rejected.",
                exception.getMessage());

        verify(repository).findById(1L);
        verify(repository, never()).save(any());
        verify(notificationClient, never()).createNotification(any());
    }

    @Test
    void testRejectRequestFromApprovedStatus() {

        requestEntity.setRequestStatus("Approved");

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        when(repository.save(any(KnowledgeRequestEntity.class)))
                .thenReturn(requestEntity);

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.rejectRequest(
                        1L,
                        301L,
                        "Rejected after review");

        assertNotNull(response);
        assertEquals("Rejected", response.getRequestStatus());
        assertEquals(301L, response.getApprovedBy());

        verify(repository).save(any(KnowledgeRequestEntity.class));
        verify(notificationClient).createNotification(any());
    }


    // ===============================
    // deleteRequest()
    // ===============================

    @Test
    void testDeleteRequestSuccess() {

        when(repository.findById(1L))
                .thenReturn(java.util.Optional.of(requestEntity));

        doNothing().when(repository).delete(requestEntity);

        knowledgeRequestService.deleteRequest(1L);

        verify(repository).findById(1L);
        verify(repository).delete(requestEntity);
    }

    @Test
    void testDeleteRequestNotFound() {

        when(repository.findById(10L))
                .thenReturn(java.util.Optional.empty());

        ResourceNotFoundException exception =
                assertThrows(ResourceNotFoundException.class,
                        () -> knowledgeRequestService.deleteRequest(10L));

        assertEquals(
                "Knowledge request not found with id: 10",
                exception.getMessage());

        verify(repository).findById(10L);
        verify(repository, never()).delete(any());
    }
}