package com.ilp.documentknowledgeservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.documentknowledgeservice.entity.KnowledgeAccessLogEntity;

@Repository
public interface KnowledgeAccessLogRepository extends JpaRepository<KnowledgeAccessLogEntity, Integer> {

    // Find all logs of a student
    List<KnowledgeAccessLogEntity> findByStudentId(Integer studentId);

    // Find logs by action (Viewed / Downloaded)
    List<KnowledgeAccessLogEntity> findByAction(String action);

    // Find logs for a Knowledge Base
    List<KnowledgeAccessLogEntity> findByKnowledgeBaseKnowledgeId(Integer knowledgeId);

    // Find logs by Student and Action
    List<KnowledgeAccessLogEntity> findByStudentIdAndAction(Integer studentId, String action);

    // Find logs by Student and Knowledge Base
    List<KnowledgeAccessLogEntity> findByStudentIdAndKnowledgeBaseKnowledgeId(Integer studentId, Integer knowledgeId);

    // Check if a student has already accessed a Knowledge Base
    boolean existsByStudentIdAndKnowledgeBaseKnowledgeId(Integer studentId, Integer knowledgeId);

    // Delete all logs of a Knowledge Base
    void deleteByKnowledgeBaseKnowledgeId(Integer knowledgeId);

    // Get all logs ordered by latest access
    List<KnowledgeAccessLogEntity> findAllByOrderByAccessedOnDesc();
}