package com.ilp.documentknowledgeservice.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseResponseDto;
import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;
import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.mapper.KnowledgeBaseMapper;
import com.ilp.documentknowledgeservice.repository.KnowledgeBaseRepository;
import com.ilp.documentknowledgeservice.service.KnowledgeBaseService;

@Service
public class KnowledgeBaseServiceImpl implements KnowledgeBaseService {

    @Autowired
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Autowired
    private UserClient userClient;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private NotificationClient notificationClient;

    @Override
    public KnowledgeBaseResponseDto createKnowledgeBase(KnowledgeBaseRequestDto requestDto) {

        validateKnowledgeBase(requestDto);

        userClient.getUserById(requestDto.getPublishedBy());

        projectClient.getProjectStageById(
                Long.valueOf(requestDto.getProjectStageId()));

        if (knowledgeBaseRepository.existsByTitle(requestDto.getTitle())) {
            throw new RuntimeException("Knowledge title already exists");
        }

        KnowledgeBaseEntity entity = KnowledgeBaseMapper.toEntity(requestDto);

        entity.setPublishedOn(LocalDateTime.now());

        KnowledgeBaseEntity savedEntity = knowledgeBaseRepository.save(entity);

        NotificationRequestDto notification = new NotificationRequestDto();
        notification.setUserId(requestDto.getPublishedBy());
        notification.setTitle("Knowledge Base Published");
        notification.setMessage("Knowledge Base has been published successfully.");
        notification.setNotificationType("KNOWLEDGE_BASE");
        notification.setModuleName("Knowledge Base");
        notification.setReferenceId(savedEntity.getKnowledgeId());
        notification.setPriority("Medium");

        notificationClient.createNotification(notification);

        return KnowledgeBaseMapper.toResponseDto(savedEntity);
    }
    
    @Override
    public KnowledgeBaseResponseDto updateKnowledgeBase(Integer knowledgeId,
            KnowledgeBaseRequestDto requestDto) {

        validateKnowledgeBase(requestDto);

        KnowledgeBaseEntity entity = knowledgeBaseRepository.findById(knowledgeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Knowledge Base not found"));

        userClient.getUserById(requestDto.getPublishedBy());

        projectClient.getProjectStageById(
                Long.valueOf(requestDto.getProjectStageId()));

        entity.setProjectStageId(requestDto.getProjectStageId());

        DocumentEntity document = new DocumentEntity();
        document.setDocumentId(requestDto.getDocumentId());
        entity.setDocument(document);

        entity.setTitle(requestDto.getTitle());
        entity.setCategory(requestDto.getCategory());
        entity.setDescription(requestDto.getDescription());
        entity.setPublishedBy(requestDto.getPublishedBy());
        entity.setVisibility(requestDto.getVisibility());

        KnowledgeBaseEntity updatedEntity =
                knowledgeBaseRepository.save(entity);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(requestDto.getPublishedBy());
        notification.setTitle("Knowledge Base Updated");
        notification.setMessage(
                "Knowledge Base has been updated successfully.");
        notification.setNotificationType("KNOWLEDGE_BASE");
        notification.setModuleName("Knowledge Base");
        notification.setReferenceId(updatedEntity.getKnowledgeId());
        notification.setPriority("Medium");

        notificationClient.createNotification(notification);

        return KnowledgeBaseMapper.toResponseDto(updatedEntity);
    }

    @Override
    public void deleteKnowledgeBase(Integer knowledgeId) {

        if (!knowledgeBaseRepository.existsById(knowledgeId)) {
            throw new ResourceNotFoundException(
                    "Knowledge Base not found");
        }

        knowledgeBaseRepository.deleteById(knowledgeId);
    }

    @Override
    public KnowledgeBaseResponseDto getKnowledgeBaseById(Integer knowledgeId) {

        Optional<KnowledgeBaseEntity> entity =
                knowledgeBaseRepository.findByKnowledgeId(knowledgeId);

        if (entity.isEmpty()) {
            throw new ResourceNotFoundException(
                    "Knowledge Base not found");
        }

        return KnowledgeBaseMapper.toResponseDto(entity.get());
    }

    @Override
    public List<KnowledgeBaseResponseDto> getAllKnowledgeBase() {

        return knowledgeBaseRepository.findAllByOrderByPublishedOnDesc()
                .stream()
                .map(KnowledgeBaseMapper::toResponseDto)
                .collect(Collectors.toList());
    }
    
    @Override
    public List<KnowledgeBaseResponseDto> searchKnowledgeByTitle(String title) {

        return knowledgeBaseRepository.findByTitleContainingIgnoreCase(title)
                .stream()
                .map(KnowledgeBaseMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeBaseResponseDto> getKnowledgeByCategory(String category) {

        return knowledgeBaseRepository.findByCategory(category)
                .stream()
                .map(KnowledgeBaseMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeBaseResponseDto> getKnowledgeByVisibility(String visibility) {

        return knowledgeBaseRepository.findByVisibility(visibility)
                .stream()
                .map(KnowledgeBaseMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeBaseResponseDto> getKnowledgeByProjectStage(Integer projectStageId) {

        return knowledgeBaseRepository.findByProjectStageId(projectStageId)
                .stream()
                .map(KnowledgeBaseMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeBaseResponseDto> getKnowledgeByPublishedBy(Integer publishedBy) {

        return knowledgeBaseRepository.findByPublishedBy(publishedBy)
                .stream()
                .map(KnowledgeBaseMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    private void validateKnowledgeBase(KnowledgeBaseRequestDto requestDto) {

        if (requestDto == null) {
            throw new RuntimeException("Request cannot be null");
        }

        if (requestDto.getProjectStageId() == null) {
            throw new RuntimeException("Project Stage Id is required");
        }

        if (requestDto.getDocumentId() == null) {
            throw new RuntimeException("Document Id is required");
        }

        if (requestDto.getTitle() == null ||
                requestDto.getTitle().trim().isEmpty()) {
            throw new RuntimeException("Title is required");
        }

        if (requestDto.getCategory() == null ||
                requestDto.getCategory().trim().isEmpty()) {
            throw new RuntimeException("Category is required");
        }

        if (requestDto.getPublishedBy() == null) {
            throw new RuntimeException("Published By is required");
        }

        if (requestDto.getVisibility() == null ||
                requestDto.getVisibility().trim().isEmpty()) {
            throw new RuntimeException("Visibility is required");
        }
    }
}