package com.ilp.documentknowledgeservice.mapper;

import com.ilp.documentknowledgeservice.dto.KnowledgeBaseRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseResponseDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;
import com.ilp.documentknowledgeservice.entity.KnowledgeBaseEntity;

public class KnowledgeBaseMapper {

    // Convert Request DTO to Entity
    public static KnowledgeBaseEntity toEntity(KnowledgeBaseRequestDto requestDto) {

        KnowledgeBaseEntity entity = new KnowledgeBaseEntity();

        entity.setProjectStageId(requestDto.getProjectStageId());

        DocumentEntity document = new DocumentEntity();
        document.setDocumentId(requestDto.getDocumentId());
        entity.setDocument(document);

        entity.setTitle(requestDto.getTitle());
        entity.setCategory(requestDto.getCategory());
        entity.setDescription(requestDto.getDescription());
        entity.setPublishedBy(requestDto.getPublishedBy());
        entity.setVisibility(requestDto.getVisibility());

        return entity;
    }

    // Convert Entity to Response DTO
    public static KnowledgeBaseResponseDto toResponseDto(KnowledgeBaseEntity entity) {

        KnowledgeBaseResponseDto responseDto = new KnowledgeBaseResponseDto();

        responseDto.setKnowledgeId(entity.getKnowledgeId());
        responseDto.setProjectStageId(entity.getProjectStageId());

        if (entity.getDocument() != null) {
            responseDto.setDocumentId(entity.getDocument().getDocumentId());
        }

        responseDto.setTitle(entity.getTitle());
        responseDto.setCategory(entity.getCategory());
        responseDto.setDescription(entity.getDescription());
        responseDto.setPublishedBy(entity.getPublishedBy());
        responseDto.setPublishedOn(entity.getPublishedOn());
        responseDto.setVisibility(entity.getVisibility());

        return responseDto;
    }
}