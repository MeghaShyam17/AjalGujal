package com.ilp.documentknowledgeservice.service;

import java.util.List;

import com.ilp.documentknowledgeservice.dto.FacultyReviewRequestDto;
import com.ilp.documentknowledgeservice.dto.FacultyReviewResponseDto;

public interface FacultyReviewService {

    FacultyReviewResponseDto addFacultyReview(
            FacultyReviewRequestDto reviewDto);

    FacultyReviewResponseDto getFacultyReviewById(
            Integer reviewId);

    List<FacultyReviewResponseDto> getAllFacultyReviews();

    List<FacultyReviewResponseDto> getReviewsByProjectStageId(
            Integer projectStageId);

    List<FacultyReviewResponseDto> getReviewsByFacultyId(
            Integer facultyId);

    List<FacultyReviewResponseDto> getReviewsByDocumentId(
            Integer documentId);

    List<FacultyReviewResponseDto> getReviewsByStatus(
            String reviewStatus);

    FacultyReviewResponseDto updateFacultyReview(
            Integer reviewId,
            FacultyReviewRequestDto reviewDto);

    FacultyReviewResponseDto updateReviewStatus(
            Integer reviewId,
            String reviewStatus);

    void deleteFacultyReview(
            Integer reviewId);
}