package com.ilp.documentknowledgeservice.serviceImpl;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import feign.FeignException;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.DocumentRequestDto;
import com.ilp.documentknowledgeservice.dto.DocumentResponseDto;
import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;
import com.ilp.documentknowledgeservice.dto.ProjectResponseDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.mapper.DocumentMapper;
import com.ilp.documentknowledgeservice.repository.DocumentRepository;
import com.ilp.documentknowledgeservice.service.DocumentService;

@Service
public class DocumentServiceImpl implements DocumentService {

    @Autowired
    private DocumentRepository documentRepository;

    @Autowired
    private ProjectClient projectClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private NotificationClient notificationClient;

    @Override
    public DocumentResponseDto addDocument(DocumentRequestDto dto) {

        System.out.println("INSIDE ADD DOCUMENT");

        validateDocument(dto);

        try {
            userClient.getUserById(dto.getUploadedBy());
        } catch (FeignException ex) {
            throw new ResourceNotFoundException(
                    "User not found with ID : "
                            + dto.getUploadedBy());
        }

        ProjectResponseDto projectResponse;

        try {

            projectResponse =
                    projectClient.getProjectStageById(
                            dto.getProjectStageId());

            System.out.println("========== PROJECT RESPONSE ==========");
            System.out.println(projectResponse);
            System.out.println("======================================");

        } catch (FeignException ex) {

            throw new ResourceNotFoundException(
                    "Project Stage not found with ID : "
                            + dto.getProjectStageId());
        }

        if (dto.getVersionNo() == null) {
            dto.setVersionNo(1);
        }

        if (dto.getOriginalFileName() == null
                || dto.getOriginalFileName().trim().isEmpty()) {

            dto.setOriginalFileName(dto.getFileName());
        }

        if (dto.getFileSize() == null
                && dto.getFileData() != null) {

            dto.setFileSize(
                    (long) dto.getFileData().length);
        }

        boolean duplicate =
                documentRepository
                        .existsByProjectStageIdAndVersionNoAndOriginalFileNameIgnoreCase(
                                dto.getProjectStageId(),
                                dto.getVersionNo(),
                                dto.getOriginalFileName()
                        );

        if (duplicate) {

            throw new IllegalArgumentException(
                    "A file with the same name already exists in Version "
                            + dto.getVersionNo()
                            + ". Please rename the file and upload again."
            );
        }

        DocumentEntity entity =
                DocumentMapper.toEntity(dto);

        entity.setProjectStageId(
                projectResponse.getProjectStageId());

        entity.setUploadedAt(
                new Timestamp(System.currentTimeMillis()));

        DocumentEntity savedEntity =
                documentRepository.save(entity);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(dto.getUploadedBy());

        notification.setTitle(
                "Document Uploaded");

        notification.setMessage(
                "Document '"
                        + savedEntity.getTitle()
                        + "' uploaded successfully.");

        notification.setNotificationType(
                "DOCUMENT");

        notification.setModuleName(
                "Document Management");

        notification.setReferenceId(
                savedEntity.getDocumentId().intValue());

        notification.setPriority("Medium");

        notificationClient.createNotification(
                notification);

        return DocumentMapper.toResponseDto(
                savedEntity);
    }

    @Override
    public DocumentResponseDto updateDocument(
            Long documentId,
            DocumentRequestDto dto) {

        validateDocument(dto);

        DocumentEntity existingDocument =
                documentRepository.findById(documentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Document not found with ID : "
                                                + documentId));

        try {
            userClient.getUserById(dto.getUploadedBy());
        } catch (FeignException ex) {
            throw new ResourceNotFoundException(
                    "User not found with ID : "
                            + dto.getUploadedBy());
        }

        ProjectResponseDto projectResponse;

        try {
            projectResponse =
                    projectClient.getProjectStageById(
                            dto.getProjectStageId());

            System.out.println("========== PROJECT RESPONSE ==========");
            System.out.println("Response object = " + projectResponse);

            if (projectResponse != null) {
                System.out.println("ProjectStageId = "
                        + projectResponse.getProjectStageId());

                System.out.println("ProjectId = "
                        + projectResponse.getProjectId());

                System.out.println("SubmissionStatus = "
                        + projectResponse.getSubmissionStatus());

                System.out.println("CurrentStage = "
                        + projectResponse.getCurrentStage());
            }

            System.out.println("======================================");

        } catch (FeignException ex) {
            throw new ResourceNotFoundException(
                    "Project Stage not found with ID : "
                            + dto.getProjectStageId());
        }

        if (dto.getVersionNo() == null) {
            dto.setVersionNo(1);
        }

        if (dto.getOriginalFileName() == null
                || dto.getOriginalFileName().trim().isEmpty()) {

            dto.setOriginalFileName(dto.getFileName());
        }

        if (dto.getFileSize() == null
                && dto.getFileData() != null) {

            dto.setFileSize(
                    (long) dto.getFileData().length);
        }

        boolean duplicate =
                documentRepository
                        .existsByProjectStageIdAndVersionNoAndOriginalFileNameIgnoreCase(
                                dto.getProjectStageId(),
                                dto.getVersionNo(),
                                dto.getOriginalFileName()
                        );

        boolean sameDocument =
                existingDocument.getProjectStageId()
                        .equals(dto.getProjectStageId())
                        &&
                        existingDocument.getVersionNo()
                                .equals(dto.getVersionNo())
                        &&
                        existingDocument.getOriginalFileName() != null
                        &&
                        existingDocument.getOriginalFileName()
                                .equalsIgnoreCase(dto.getOriginalFileName());

        if (duplicate && !sameDocument) {

            throw new IllegalArgumentException(
                    "A file with the same name already exists in Version "
                            + dto.getVersionNo()
                            + ". Please rename the file and upload again."
            );
        }

        existingDocument.setProjectStageId(
                projectResponse.getProjectStageId());

        existingDocument.setUploadedBy(
                dto.getUploadedBy());

        existingDocument.setVersionNo(
                dto.getVersionNo());

        existingDocument.setDocumentType(
                dto.getDocumentType());

        existingDocument.setTitle(
                dto.getTitle());

        existingDocument.setFileName(
                dto.getFileName());

        existingDocument.setOriginalFileName(
                dto.getOriginalFileName());

        existingDocument.setFileData(
                dto.getFileData());

        existingDocument.setFileSize(
                dto.getFileSize());

        existingDocument.setDescription(
                dto.getDescription());

        existingDocument.setUploadedAt(
                new Timestamp(System.currentTimeMillis()));

        DocumentEntity updatedDocument =
                documentRepository.save(existingDocument);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(
                dto.getUploadedBy());

        notification.setTitle(
                "Document Updated");

        notification.setMessage(
                "Document '"
                        + updatedDocument.getTitle()
                        + "' updated successfully.");

        notification.setNotificationType(
                "DOCUMENT");

        notification.setModuleName(
                "Document Management");

        notification.setReferenceId(
                updatedDocument.getDocumentId().intValue());

        notification.setPriority(
                "Medium");

        notificationClient.createNotification(
                notification);

        return DocumentMapper.toResponseDto(
                updatedDocument);
    }

    @Override
    public DocumentResponseDto getDocumentById(
            Long documentId) {

        DocumentEntity entity =
                documentRepository.findById(documentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Document not found with ID : "
                                                + documentId));

        return DocumentMapper.toResponseDto(entity);
    }

    @Override
    public List<DocumentResponseDto> getAllDocuments() {

        List<DocumentEntity> documents =
                documentRepository.findAll();

        return documents.stream()
                .map(DocumentMapper::toResponseDto)
                .toList();
    }

    @Override
    public void deleteDocument(Long documentId) {

        DocumentEntity document =
                documentRepository.findById(documentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Document not found with ID : "
                                                + documentId));

        documentRepository.delete(document);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(
                document.getUploadedBy());

        notification.setTitle(
                "Document Deleted");

        notification.setMessage(
                "Document '"
                        + document.getTitle()
                        + "' has been deleted successfully.");

        notification.setNotificationType(
                "DOCUMENT");

        notification.setModuleName(
                "Document Management");

        notification.setReferenceId(
                document.getDocumentId().intValue());

        notification.setPriority(
                "Medium");

        notificationClient.createNotification(
                notification);
    }

    @Override
    public List<DocumentResponseDto> getDocumentsByProjectStageId(
            Long projectStageId) {

        try {
            projectClient.getProjectStageById(projectStageId);
        } catch (FeignException ex) {
            throw new ResourceNotFoundException(
                    "Project Stage not found with ID : "
                            + projectStageId);
        }

        List<DocumentEntity> documents =
                documentRepository.findByProjectStageId(projectStageId);

        return documents.stream()
                .map(DocumentMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<DocumentResponseDto> getDocumentsByUploadedBy(
            Integer uploadedBy) {

        try {
            userClient.getUserById(uploadedBy);
        } catch (FeignException ex) {
            throw new ResourceNotFoundException(
                    "User not found with ID : "
                            + uploadedBy);
        }

        List<DocumentEntity> documents =
                documentRepository.findByUploadedBy(uploadedBy);

        return documents.stream()
                .map(DocumentMapper::toResponseDto)
                .toList();
    }

    @Override
    public DocumentEntity getDocumentEntityById(Long documentId) {

        return documentRepository.findById(documentId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Document not found with ID: "
                                        + documentId));
    }

    private void validateDocument(DocumentRequestDto dto) {

        if (dto == null) {
            throw new IllegalArgumentException(
                    "Document request cannot be null.");
        }

        if (dto.getProjectStageId() == null) {
            throw new IllegalArgumentException(
                    "Project Stage ID is required.");
        }

        if (dto.getUploadedBy() == null) {
            throw new IllegalArgumentException(
                    "Uploaded By is required.");
        }

        if (dto.getTitle() == null
                || dto.getTitle().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Document title is required.");
        }

        if (dto.getDocumentType() == null
                || dto.getDocumentType().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Document type is required.");
        }

        if (dto.getFileName() == null
                || dto.getFileName().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "File name is required.");
        }

        if (dto.getFileData() == null
                || dto.getFileData().length == 0) {

            throw new IllegalArgumentException(
                    "File data is required.");
        }
    }
}