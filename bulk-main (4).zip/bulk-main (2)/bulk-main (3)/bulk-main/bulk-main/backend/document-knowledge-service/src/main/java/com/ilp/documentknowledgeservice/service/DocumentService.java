package com.ilp.documentknowledgeservice.service;

import java.util.List;

import com.ilp.documentknowledgeservice.dto.DocumentRequestDto;
import com.ilp.documentknowledgeservice.dto.DocumentResponseDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;
public interface DocumentService {

    DocumentResponseDto addDocument(DocumentRequestDto dto);

    DocumentResponseDto getDocumentById(Long documentId);

    List<DocumentResponseDto> getAllDocuments();

    List<DocumentResponseDto> getDocumentsByProjectStageId(Long projectStageId);

    DocumentResponseDto updateDocument(Long documentId,
                                       DocumentRequestDto dto);

    void deleteDocument(Long documentId);

	List<DocumentResponseDto> getDocumentsByUploadedBy(Integer uploadedBy);

    DocumentEntity getDocumentEntityById(Long documentId);
}