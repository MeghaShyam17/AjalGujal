package com.ilp.documentknowledgeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentKnowledgeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
