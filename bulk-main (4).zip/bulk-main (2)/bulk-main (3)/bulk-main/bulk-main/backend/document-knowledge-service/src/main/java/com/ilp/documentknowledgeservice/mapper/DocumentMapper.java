package com.ilp.documentknowledgeservice.mapper;

import com.ilp.documentknowledgeservice.dto.DocumentRequestDto;
import com.ilp.documentknowledgeservice.dto.DocumentResponseDto;
import com.ilp.documentknowledgeservice.entity.DocumentEntity;

public class DocumentMapper {

    /**
     * Request DTO -> Entity
     */
    public static DocumentEntity toEntity(DocumentRequestDto dto) {

        DocumentEntity entity = new DocumentEntity();

        entity.setProjectStageId(dto.getProjectStageId());
        entity.setUploadedBy(dto.getUploadedBy());
        entity.setVersionNo(dto.getVersionNo());
        entity.setDocumentType(dto.getDocumentType());
        entity.setTitle(dto.getTitle());
        entity.setFileName(dto.getFileName());
        entity.setOriginalFileName(dto.getOriginalFileName());
        entity.setFileSize(dto.getFileSize());
        entity.setFileData(dto.getFileData());
        entity.setDescription(dto.getDescription());

        return entity;
    }

    /**
     * Entity -> Response DTO
     */
    public static DocumentResponseDto toResponseDto(DocumentEntity entity) {

        DocumentResponseDto dto = new DocumentResponseDto();

        dto.setDocumentId(entity.getDocumentId());
        dto.setProjectStageId(entity.getProjectStageId());
        dto.setUploadedBy(entity.getUploadedBy());
        dto.setVersionNo(entity.getVersionNo());
        dto.setDocumentType(entity.getDocumentType());
        dto.setTitle(entity.getTitle());
        dto.setFileName(entity.getFileName());
        dto.setOriginalFileName(entity.getOriginalFileName());
        dto.setFileSize(entity.getFileSize());
        dto.setDescription(entity.getDescription());
        dto.setUploadedAt(entity.getUploadedAt());

        return dto;
    }
}