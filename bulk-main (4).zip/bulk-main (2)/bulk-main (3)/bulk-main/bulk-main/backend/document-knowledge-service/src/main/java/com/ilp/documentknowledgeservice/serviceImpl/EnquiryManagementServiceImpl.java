package com.ilp.documentknowledgeservice.serviceImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementRequestDto;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementResponseDto;
import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;
import com.ilp.documentknowledgeservice.dto.ProjectTeamResponseDto;
import com.ilp.documentknowledgeservice.entity.EnquiryManagementEntity;
import com.ilp.documentknowledgeservice.exception.EnquiryManagementException;
import com.ilp.documentknowledgeservice.mapper.EnquiryManagementMapper;
import com.ilp.documentknowledgeservice.repository.EnquiryManagementRepository;
import com.ilp.documentknowledgeservice.service.EnquiryManagementService;

@Service
public class EnquiryManagementServiceImpl
        implements EnquiryManagementService {

    private static final Logger log =
            LoggerFactory.getLogger(
                    EnquiryManagementServiceImpl.class);

    private final EnquiryManagementRepository repository;
    private final EnquiryManagementMapper mapper;
    private final NotificationClient notificationClient;
    private final ProjectClient projectClient;

    public EnquiryManagementServiceImpl(
            EnquiryManagementRepository repository,
            EnquiryManagementMapper mapper,
            NotificationClient notificationClient,
            ProjectClient projectClient) {

        this.repository = repository;
        this.mapper = mapper;
        this.notificationClient = notificationClient;
        this.projectClient = projectClient;
    }

    @Override
    public EnquiryManagementResponseDto createEnquiry(
            EnquiryManagementRequestDto request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Enquiry request cannot be null");
        }

        if (request.getProjectId() == null) {
            throw new EnquiryManagementException(
                    "Project ID is required");
        }

        ProjectTeamResponseDto project;

        try {
            project = projectClient.getProjectById(
                    request.getProjectId());
        } catch (Exception ex) {
            log.error(
                    "Error fetching project with id: {}",
                    request.getProjectId(),
                    ex);

            throw new EnquiryManagementException(
                    "Project not found with id: "
                            + request.getProjectId());
        }

        if (project == null
                || project.getProjectId() == null) {

            throw new EnquiryManagementException(
                    "Project not found with id: "
                            + request.getProjectId());
        }

        Integer facultyId = project.getFacultyId();

        if (facultyId == null) {
            throw new EnquiryManagementException(
                    "No faculty assigned to project id: "
                            + request.getProjectId());
        }

        EnquiryManagementEntity enquiry =
                mapper.toEntity(request);

        enquiry.setEnquiryStatus("In Progress");
        enquiry.setCreatedAt(LocalDateTime.now());

        EnquiryManagementEntity savedEnquiry =
                repository.save(enquiry);

        try {
            NotificationRequestDto notification =
                    new NotificationRequestDto();

            notification.setUserId(facultyId);
            notification.setTitle(
                    "New Enquiry Received");
            notification.setMessage(
                    "A student has raised a new enquiry for project: "
                            + project.getProjectName());
            notification.setNotificationType(
                    "ENQUIRY");
            notification.setModuleName(
                    "Enquiry Management");
            notification.setReferenceId(
                    savedEnquiry.getEnquiryId());
            notification.setPriority("Medium");

            notificationClient.createNotification(
                    notification);

        } catch (Exception ex) {
            log.warn(
                    "Failed to send notification to faculty: {}",
                    facultyId,
                    ex);
        }

        return mapToResponse(
                savedEnquiry,
                project);
    }

    @Override
    public List<EnquiryManagementResponseDto>
            getAllEnquiries() {

        List<EnquiryManagementEntity> enquiries =
                repository.findAll();

        return enquiries.stream()
                .map(this::buildEnquiryResponse)
                .collect(Collectors.toList());
    }

    @Override
    public EnquiryManagementResponseDto getEnquiryById(
            Integer enquiryId) {

        if (enquiryId == null) {
            throw new EnquiryManagementException(
                    "Enquiry ID is required");
        }

        EnquiryManagementEntity enquiry =
                repository.findById(enquiryId)
                        .orElseThrow(() ->
                                new EnquiryManagementException(
                                        "Enquiry not found with id: "
                                                + enquiryId));

        return buildEnquiryResponse(enquiry);
    }

    @Override
    public List<EnquiryManagementResponseDto>
            getEnquiriesByUserId(Integer userId) {

        if (userId == null) {
            throw new EnquiryManagementException(
                    "User ID is required");
        }

        List<EnquiryManagementEntity> enquiries =
                repository.findByUserId(userId);

        return enquiries.stream()
                .map(this::buildEnquiryResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<EnquiryManagementResponseDto>
            getEnquiriesByFacultyId(Integer facultyId) {

        if (facultyId == null) {
            throw new EnquiryManagementException(
                    "Faculty ID is required");
        }

        List<ProjectTeamResponseDto> projects;

        try {
            projects =
                    projectClient.getProjectsByFaculty(
                            facultyId);

        } catch (Exception ex) {
            log.error(
                    "Error fetching projects for faculty id: {}",
                    facultyId,
                    ex);

            return Collections.emptyList();
        }

        if (projects == null || projects.isEmpty()) {
            return Collections.emptyList();
        }

        Map<Integer, ProjectTeamResponseDto> projectMap =
                projects.stream()
                        .filter(project ->
                                project != null
                                        && project.getProjectId()
                                        != null)
                        .collect(Collectors.toMap(
                                ProjectTeamResponseDto::getProjectId,
                                project -> project,
                                (existing, replacement) ->
                                        existing));

        List<Integer> projectIds =
                new ArrayList<>(projectMap.keySet());

        if (projectIds.isEmpty()) {
            return Collections.emptyList();
        }

        List<EnquiryManagementEntity> enquiries =
                repository.findByProjectIdIn(
                        projectIds);

        return enquiries.stream()
                .map(enquiry -> {
                    ProjectTeamResponseDto project =
                            projectMap.get(
                                    enquiry.getProjectId());

                    if (project != null) {
                        return mapToResponse(
                                enquiry,
                                project);
                    }

                    EnquiryManagementResponseDto response =
                            mapper.toResponse(
                                    enquiry,
                                    null);

                    response.setFacultyId(facultyId);

                    return response;
                })
                .collect(Collectors.toList());
    }

    @Override
    public EnquiryManagementResponseDto facultyReply(
            Integer enquiryId,
            String facultyComment) {

        if (enquiryId == null) {
            throw new EnquiryManagementException(
                    "Enquiry ID is required");
        }

        if (facultyComment == null
                || facultyComment.trim().isEmpty()) {

            throw new EnquiryManagementException(
                    "Faculty comment cannot be empty");
        }

        EnquiryManagementEntity enquiry =
                repository.findById(enquiryId)
                        .orElseThrow(() ->
                                new EnquiryManagementException(
                                        "Enquiry not found with id: "
                                                + enquiryId));

        enquiry.setFacultyComment(
                facultyComment.trim());
        enquiry.setEnquiryStatus("Closed");
        enquiry.setRepliedAt(LocalDateTime.now());

        EnquiryManagementEntity updatedEnquiry =
                repository.save(enquiry);

        try {
            NotificationRequestDto notification =
                    new NotificationRequestDto();

            notification.setUserId(
                    updatedEnquiry.getUserId());
            notification.setTitle(
                    "Enquiry Reply Received");
            notification.setMessage(
                    "Faculty has replied to your enquiry.");
            notification.setNotificationType(
                    "ENQUIRY_REPLY");
            notification.setModuleName(
                    "Enquiry Management");
            notification.setReferenceId(
                    updatedEnquiry.getEnquiryId());
            notification.setPriority("Medium");

            notificationClient.createNotification(
                    notification);

        } catch (Exception ex) {
            log.warn(
                    "Failed to send notification to student: {}",
                    updatedEnquiry.getUserId(),
                    ex);
        }

        return buildEnquiryResponse(
                updatedEnquiry);
    }

    @Override
    public void deleteEnquiry(Integer enquiryId) {

        if (enquiryId == null) {
            throw new EnquiryManagementException(
                    "Enquiry ID is required");
        }

        if (!repository.existsById(enquiryId)) {
            throw new EnquiryManagementException(
                    "Enquiry not found with id: "
                            + enquiryId);
        }

        repository.deleteById(enquiryId);
    }

    private EnquiryManagementResponseDto
            buildEnquiryResponse(
                    EnquiryManagementEntity enquiry) {

        if (enquiry == null) {
            return null;
        }

        ProjectTeamResponseDto project =
                getProjectQuietly(
                        enquiry.getProjectId());

        return mapToResponse(
                enquiry,
                project);
    }

    private EnquiryManagementResponseDto mapToResponse(
            EnquiryManagementEntity enquiry,
            ProjectTeamResponseDto project) {

        String projectName =
                project != null
                        ? project.getProjectName()
                        : null;

        Integer facultyId =
                project != null
                        ? project.getFacultyId()
                        : null;

        EnquiryManagementResponseDto response =
                mapper.toResponse(
                        enquiry,
                        projectName);

        response.setFacultyId(facultyId);

        return response;
    }

    private ProjectTeamResponseDto getProjectQuietly(
            Integer projectId) {

        if (projectId == null) {
            return null;
        }

        try {
            return projectClient.getProjectById(
                    projectId);

        } catch (Exception ex) {
            log.warn(
                    "Failed to fetch project details for projectId: {}",
                    projectId,
                    ex);

            return null;
        }
    }
}