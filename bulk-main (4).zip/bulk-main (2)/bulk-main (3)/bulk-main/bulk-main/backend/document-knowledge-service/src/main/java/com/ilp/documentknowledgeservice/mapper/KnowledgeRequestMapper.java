package com.ilp.documentknowledgeservice.mapper;

import com.ilp.documentknowledgeservice.dto.KnowledgeRequestRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestResponseDto;
import com.ilp.documentknowledgeservice.entity.KnowledgeRequestEntity;

public class KnowledgeRequestMapper {

    private KnowledgeRequestMapper() {
        // Prevent instantiation
    }

    public static KnowledgeRequestEntity toEntity(
            KnowledgeRequestRequestDto requestDto) {

        KnowledgeRequestEntity entity = new KnowledgeRequestEntity();

        entity.setStudentId(requestDto.getStudentId());
        entity.setKnowledgeId(requestDto.getKnowledgeId());
        entity.setRequestReason(requestDto.getRequestReason());

        return entity;
    }

    public static KnowledgeRequestResponseDto toResponseDto(
            KnowledgeRequestEntity entity) {

        KnowledgeRequestResponseDto responseDto =
                new KnowledgeRequestResponseDto();

        responseDto.setRequestId(entity.getRequestId());
        responseDto.setStudentId(entity.getStudentId());
        responseDto.setKnowledgeId(entity.getKnowledgeId());
        responseDto.setRequestReason(entity.getRequestReason());
        responseDto.setRequestStatus(entity.getRequestStatus());
        responseDto.setApprovedBy(entity.getApprovedBy());
        responseDto.setApprovedOn(entity.getApprovedOn());
        responseDto.setRequestedOn(entity.getRequestedOn());
        responseDto.setRemarks(entity.getRemarks());

        return responseDto;
    }
}