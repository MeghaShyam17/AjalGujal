package com.ilp.documentknowledgeservice.repository;

import com.ilp.documentknowledgeservice.entity.KnowledgeRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KnowledgeRequestRepository extends JpaRepository<KnowledgeRequestEntity, Long> {

    List<KnowledgeRequestEntity> findByStudentId(Long studentId);

    List<KnowledgeRequestEntity> findByKnowledgeId(Long knowledgeId);

    List<KnowledgeRequestEntity> findByRequestStatus(String requestStatus);

    List<KnowledgeRequestEntity> findByStudentIdAndRequestStatus(Long studentId, String requestStatus);

    List<KnowledgeRequestEntity> findByApprovedBy(Long approvedBy);
}