package com.ilp.documentknowledgeservice.dto;

import java.time.LocalDateTime;

public class FacultyReviewResponseDto {

    private Integer reviewId;
    private Integer projectStageId;
    private Integer facultyId;
    private Integer documentId;
    private String reviewStatus;
    private String reviewComment;
    private LocalDateTime reviewedOn;

    public FacultyReviewResponseDto() {
    }

    public FacultyReviewResponseDto(
            Integer reviewId,
            Integer projectStageId,
            Integer facultyId,
            Integer documentId,
            String reviewStatus,
            String reviewComment,
            LocalDateTime reviewedOn) {

        this.reviewId = reviewId;
        this.projectStageId = projectStageId;
        this.facultyId = facultyId;
        this.documentId = documentId;
        this.reviewStatus = reviewStatus;
        this.reviewComment = reviewComment;
        this.reviewedOn = reviewedOn;
    }

    public Integer getReviewId() {
        return reviewId;
    }

    public void setReviewId(Integer reviewId) {
        this.reviewId = reviewId;
    }

    public Integer getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Integer projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Integer facultyId) {
        this.facultyId = facultyId;
    }

    public Integer getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Integer documentId) {
        this.documentId = documentId;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getReviewComment() {
        return reviewComment;
    }

    public void setReviewComment(String reviewComment) {
        this.reviewComment = reviewComment;
    }

    public LocalDateTime getReviewedOn() {
        return reviewedOn;
    }

    public void setReviewedOn(LocalDateTime reviewedOn) {
        this.reviewedOn = reviewedOn;
    }

    @Override
    public String toString() {
        return "FacultyReviewResponseDto{" +
                "reviewId=" + reviewId +
                ", projectStageId=" + projectStageId +
                ", facultyId=" + facultyId +
                ", documentId=" + documentId +
                ", reviewStatus='" + reviewStatus + '\'' +
                ", reviewComment='" + reviewComment + '\'' +
                ", reviewedOn=" + reviewedOn +
                '}';
    }
}