package com.ilp.documentknowledgeservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.FeignException;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.ProjectClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.FacultyReviewRequestDto;
import com.ilp.documentknowledgeservice.dto.FacultyReviewResponseDto;
import com.ilp.documentknowledgeservice.dto.ProjectResponseDto;
import com.ilp.documentknowledgeservice.dto.UserResponseDto;
import com.ilp.documentknowledgeservice.entity.FacultyReviewEntity;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.repository.FacultyReviewRepository;

@ExtendWith(MockitoExtension.class)
class FacultyReviewServiceImplTest {

    @InjectMocks
    private FacultyReviewServiceImpl facultyReviewService;

    @Mock
    private FacultyReviewRepository facultyReviewRepository;

    @Mock
    private UserClient userClient;

    @Mock
    private ProjectClient projectClient;

    @Mock
    private NotificationClient notificationClient;

    private FacultyReviewRequestDto requestDto;
    private FacultyReviewEntity reviewEntity;
    private UserResponseDto userResponse;
    private ProjectResponseDto projectResponse;

    @BeforeEach
    void setUp() {

        requestDto = new FacultyReviewRequestDto();
        requestDto.setProjectStageId(1);
        requestDto.setFacultyId(10);
        requestDto.setDocumentId(100);
        requestDto.setReviewStatus("APPROVED");
        requestDto.setReviewComment("Excellent Work");

        reviewEntity = new FacultyReviewEntity();
        reviewEntity.setReviewId(1);
        reviewEntity.setProjectStageId(1);
        reviewEntity.setFacultyId(10);
        reviewEntity.setDocumentId(100);
        reviewEntity.setReviewStatus("APPROVED");
        reviewEntity.setReviewComment("Excellent Work");
        reviewEntity.setReviewedOn(LocalDateTime.now());

        userResponse = new UserResponseDto();
        userResponse.setUserId(10);
        userResponse.setName("Faculty");

        projectResponse = new ProjectResponseDto();
        projectResponse.setProjectStageId(1L);
        projectResponse.setProjectId(200);
        projectResponse.setSubmissionStatus("Submitted");
        projectResponse.setCurrentStage(true);
    }
    
 // ===============================
 // addFacultyReview()
 // ===============================

 @Test
 void testAddFacultyReviewSuccess() {

     when(userClient.getUserById(10))
             .thenReturn(userResponse);

     when(projectClient.getProjectStageById(1L))
             .thenReturn(projectResponse);

     when(facultyReviewRepository.save(any(FacultyReviewEntity.class)))
             .thenReturn(reviewEntity);

     FacultyReviewResponseDto response =
             facultyReviewService.addFacultyReview(requestDto);

     assertNotNull(response);
     assertEquals(1, response.getReviewId());
     assertEquals(1, response.getProjectStageId());
     assertEquals(10, response.getFacultyId());
     assertEquals(100, response.getDocumentId());
     assertEquals("APPROVED", response.getReviewStatus());
     assertEquals("Excellent Work", response.getReviewComment());

     verify(userClient).getUserById(10);
     verify(projectClient).getProjectStageById(1L);
     verify(facultyReviewRepository).save(any(FacultyReviewEntity.class));
     verify(notificationClient).createNotification(any());
 }

 @Test
 void testAddFacultyReviewFacultyNotFound() {

     when(userClient.getUserById(10))
             .thenThrow(mock(FeignException.class));

     ResourceNotFoundException exception =
             assertThrows(ResourceNotFoundException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals(
             "Faculty not found with ID : 10",
             exception.getMessage());

     verify(facultyReviewRepository, never()).save(any());
     verify(notificationClient, never()).createNotification(any());
 }

 @Test
 void testAddFacultyReviewProjectStageNotFound() {

     when(userClient.getUserById(10))
             .thenReturn(userResponse);

     when(projectClient.getProjectStageById(1L))
             .thenThrow(mock(FeignException.class));

     ResourceNotFoundException exception =
             assertThrows(ResourceNotFoundException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals(
             "Project Stage not found with ID : 1",
             exception.getMessage());

     verify(facultyReviewRepository, never()).save(any());
     verify(notificationClient, never()).createNotification(any());
 }

 @Test
 void testAddFacultyReviewInvalidProjectStageId() {

     requestDto.setProjectStageId(0);

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Project Stage ID is required.",
             exception.getMessage());
 }

 @Test
 void testAddFacultyReviewInvalidFacultyId() {

     requestDto.setFacultyId(0);

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Faculty ID is required.",
             exception.getMessage());
 }

 @Test
 void testAddFacultyReviewInvalidDocumentId() {

     requestDto.setDocumentId(0);

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Document ID is required.",
             exception.getMessage());
 }

 @Test
 void testAddFacultyReviewEmptyReviewStatus() {

     requestDto.setReviewStatus("");

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Review Status is required.",
             exception.getMessage());
 }

 @Test
 void testAddFacultyReviewNullReviewStatus() {

     requestDto.setReviewStatus(null);

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Review Status is required.",
             exception.getMessage());
 }

 @Test
 void testAddFacultyReviewEmptyReviewComment() {

     requestDto.setReviewComment("");

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Review Comment is required.",
             exception.getMessage());
 }

 @Test
 void testAddFacultyReviewNullReviewComment() {

     requestDto.setReviewComment(null);

     IllegalArgumentException exception =
             assertThrows(IllegalArgumentException.class,
                     () -> facultyReviewService.addFacultyReview(requestDto));

     assertEquals("Review Comment is required.",
             exception.getMessage());
 }
 
//===============================
//getFacultyReviewById()
//===============================

@Test
void testGetFacultyReviewByIdSuccess() {

  when(facultyReviewRepository.findById(1))
          .thenReturn(Optional.of(reviewEntity));

  FacultyReviewResponseDto response =
          facultyReviewService.getFacultyReviewById(1);

  assertNotNull(response);
  assertEquals(1, response.getReviewId());
  assertEquals(10, response.getFacultyId());
  assertEquals(100, response.getDocumentId());

  verify(facultyReviewRepository).findById(1);
}

@Test
void testGetFacultyReviewByIdNotFound() {

  when(facultyReviewRepository.findById(1))
          .thenReturn(Optional.empty());

  ResourceNotFoundException exception =
          assertThrows(ResourceNotFoundException.class,
                  () -> facultyReviewService.getFacultyReviewById(1));

  assertEquals(
          "Faculty Review not found with ID : 1",
          exception.getMessage());

  verify(facultyReviewRepository).findById(1);
}


//===============================
//getAllFacultyReviews()
//===============================

@Test
void testGetAllFacultyReviewsSuccess() {

  when(facultyReviewRepository.findAll())
          .thenReturn(Arrays.asList(reviewEntity));

  List<FacultyReviewResponseDto> response =
          facultyReviewService.getAllFacultyReviews();

  assertNotNull(response);
  assertEquals(1, response.size());
  assertEquals(1, response.get(0).getReviewId());

  verify(facultyReviewRepository).findAll();
}

@Test
void testGetAllFacultyReviewsEmpty() {

  when(facultyReviewRepository.findAll())
          .thenReturn(Collections.emptyList());

  List<FacultyReviewResponseDto> response =
          facultyReviewService.getAllFacultyReviews();

  assertNotNull(response);
  assertTrue(response.isEmpty());

  verify(facultyReviewRepository).findAll();
}


//===============================
//getReviewsByProjectStageId()
//===============================

@Test
void testGetReviewsByProjectStageIdSuccess() {

  when(projectClient.getProjectStageById(1L))
          .thenReturn(projectResponse);

  when(facultyReviewRepository.findByProjectStageId(1))
          .thenReturn(Arrays.asList(reviewEntity));

  List<FacultyReviewResponseDto> response =
          facultyReviewService.getReviewsByProjectStageId(1);

  assertNotNull(response);
  assertEquals(1, response.size());
  assertEquals(1,
          response.get(0).getProjectStageId());

  verify(projectClient).getProjectStageById(1L);
  verify(facultyReviewRepository)
          .findByProjectStageId(1);
}

@Test
void testGetReviewsByProjectStageIdNotFound() {

  when(projectClient.getProjectStageById(1L))
          .thenThrow(mock(FeignException.class));

  ResourceNotFoundException exception =
          assertThrows(ResourceNotFoundException.class,
                  () -> facultyReviewService
                          .getReviewsByProjectStageId(1));

  assertEquals(
          "Project Stage not found with ID : 1",
          exception.getMessage());

  verify(facultyReviewRepository, never())
          .findByProjectStageId(anyInt());
}

@Test
void testGetReviewsByProjectStageIdEmpty() {

  when(projectClient.getProjectStageById(1L))
          .thenReturn(projectResponse);

  when(facultyReviewRepository.findByProjectStageId(1))
          .thenReturn(Collections.emptyList());

  List<FacultyReviewResponseDto> response =
          facultyReviewService.getReviewsByProjectStageId(1);

  assertNotNull(response);
  assertTrue(response.isEmpty());

  verify(projectClient).getProjectStageById(1L);
  verify(facultyReviewRepository)
          .findByProjectStageId(1);
}


//===============================
//getReviewsByFacultyId()
//===============================

@Test
void testGetReviewsByFacultyIdSuccess() {

  when(userClient.getUserById(10))
          .thenReturn(userResponse);

  when(facultyReviewRepository.findByFacultyId(10))
          .thenReturn(Arrays.asList(reviewEntity));

  List<FacultyReviewResponseDto> response =
          facultyReviewService.getReviewsByFacultyId(10);

  assertNotNull(response);
  assertEquals(1, response.size());
  assertEquals(10,
          response.get(0).getFacultyId());

  verify(userClient).getUserById(10);
  verify(facultyReviewRepository)
          .findByFacultyId(10);
}

@Test
void testGetReviewsByFacultyIdNotFound() {

  when(userClient.getUserById(10))
          .thenThrow(mock(FeignException.class));

  ResourceNotFoundException exception =
          assertThrows(ResourceNotFoundException.class,
                  () -> facultyReviewService
                          .getReviewsByFacultyId(10));

  assertEquals(
          "Faculty not found with ID : 10",
          exception.getMessage());

  verify(facultyReviewRepository, never())
          .findByFacultyId(anyInt());
}

@Test
void testGetReviewsByFacultyIdEmpty() {

  when(userClient.getUserById(10))
          .thenReturn(userResponse);

  when(facultyReviewRepository.findByFacultyId(10))
          .thenReturn(Collections.emptyList());

  List<FacultyReviewResponseDto> response =
          facultyReviewService.getReviewsByFacultyId(10);

  assertNotNull(response);
  assertTrue(response.isEmpty());

  verify(userClient).getUserById(10);
  verify(facultyReviewRepository)
          .findByFacultyId(10);
}

//===============================
//getReviewsByDocumentId()
//===============================

@Test
void testGetReviewsByDocumentIdSuccess() {

 when(facultyReviewRepository.findByDocumentId(100))
         .thenReturn(Arrays.asList(reviewEntity));

 List<FacultyReviewResponseDto> response =
         facultyReviewService.getReviewsByDocumentId(100);

 assertNotNull(response);
 assertEquals(1, response.size());
 assertEquals(100,
         response.get(0).getDocumentId());

 verify(facultyReviewRepository)
         .findByDocumentId(100);
}

@Test
void testGetReviewsByDocumentIdEmpty() {

 when(facultyReviewRepository.findByDocumentId(100))
         .thenReturn(Collections.emptyList());

 List<FacultyReviewResponseDto> response =
         facultyReviewService.getReviewsByDocumentId(100);

 assertNotNull(response);
 assertTrue(response.isEmpty());

 verify(facultyReviewRepository)
         .findByDocumentId(100);
}


//===============================
//getReviewsByStatus()
//===============================

@Test
void testGetReviewsByStatusSuccess() {

 when(facultyReviewRepository.findByReviewStatus("APPROVED"))
         .thenReturn(Arrays.asList(reviewEntity));

 List<FacultyReviewResponseDto> response =
         facultyReviewService.getReviewsByStatus("APPROVED");

 assertNotNull(response);
 assertEquals(1, response.size());
 assertEquals("APPROVED",
         response.get(0).getReviewStatus());

 verify(facultyReviewRepository)
         .findByReviewStatus("APPROVED");
}

@Test
void testGetReviewsByStatusEmpty() {

 when(facultyReviewRepository.findByReviewStatus("APPROVED"))
         .thenReturn(Collections.emptyList());

 List<FacultyReviewResponseDto> response =
         facultyReviewService.getReviewsByStatus("APPROVED");

 assertNotNull(response);
 assertTrue(response.isEmpty());

 verify(facultyReviewRepository)
         .findByReviewStatus("APPROVED");
}


//===============================
//updateFacultyReview()
//===============================

@Test
void testUpdateFacultyReviewSuccess() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.of(reviewEntity));

 when(userClient.getUserById(10))
         .thenReturn(userResponse);

 when(projectClient.getProjectStageById(1L))
         .thenReturn(projectResponse);

 when(facultyReviewRepository.save(any(FacultyReviewEntity.class)))
         .thenReturn(reviewEntity);

 FacultyReviewResponseDto response =
         facultyReviewService.updateFacultyReview(
                 1,
                 requestDto);

 assertNotNull(response);
 assertEquals(1, response.getReviewId());
 assertEquals(10, response.getFacultyId());
 assertEquals(100, response.getDocumentId());

 verify(facultyReviewRepository).findById(1);
 verify(userClient).getUserById(10);
 verify(projectClient).getProjectStageById(1L);
 verify(facultyReviewRepository)
         .save(any(FacultyReviewEntity.class));
 verify(notificationClient)
         .createNotification(any());
}

@Test
void testUpdateFacultyReviewNotFound() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.empty());

 ResourceNotFoundException exception =
         assertThrows(ResourceNotFoundException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Faculty Review not found with ID : 1",
         exception.getMessage());

 verify(facultyReviewRepository).findById(1);
}

@Test
void testUpdateFacultyReviewFacultyNotFound() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.of(reviewEntity));

 when(userClient.getUserById(10))
         .thenThrow(mock(FeignException.class));

 ResourceNotFoundException exception =
         assertThrows(ResourceNotFoundException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Faculty not found with ID : 10",
         exception.getMessage());

 verify(facultyReviewRepository, never())
         .save(any());
}

@Test
void testUpdateFacultyReviewProjectStageNotFound() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.of(reviewEntity));

 when(userClient.getUserById(10))
         .thenReturn(userResponse);

 when(projectClient.getProjectStageById(1L))
         .thenThrow(mock(FeignException.class));

 ResourceNotFoundException exception =
         assertThrows(ResourceNotFoundException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Project Stage not found with ID : 1",
         exception.getMessage());

 verify(facultyReviewRepository, never())
         .save(any());
}

@Test
void testUpdateFacultyReviewInvalidProjectStageId() {

 requestDto.setProjectStageId(0);

 IllegalArgumentException exception =
         assertThrows(IllegalArgumentException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Project Stage ID is required.",
         exception.getMessage());
}

@Test
void testUpdateFacultyReviewInvalidFacultyId() {

 requestDto.setFacultyId(0);

 IllegalArgumentException exception =
         assertThrows(IllegalArgumentException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Faculty ID is required.",
         exception.getMessage());
}

@Test
void testUpdateFacultyReviewInvalidDocumentId() {

 requestDto.setDocumentId(0);

 IllegalArgumentException exception =
         assertThrows(IllegalArgumentException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Document ID is required.",
         exception.getMessage());
}

@Test
void testUpdateFacultyReviewEmptyReviewStatus() {

 requestDto.setReviewStatus("");

 IllegalArgumentException exception =
         assertThrows(IllegalArgumentException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Review Status is required.",
         exception.getMessage());
}

@Test
void testUpdateFacultyReviewEmptyReviewComment() {

 requestDto.setReviewComment("");

 IllegalArgumentException exception =
         assertThrows(IllegalArgumentException.class,
                 () -> facultyReviewService
                         .updateFacultyReview(1, requestDto));

 assertEquals(
         "Review Comment is required.",
         exception.getMessage());
}

//===============================
//updateReviewStatus()
//===============================

@Test
void testUpdateReviewStatusSuccess() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.of(reviewEntity));

 when(facultyReviewRepository.save(any(FacultyReviewEntity.class)))
         .thenReturn(reviewEntity);

 FacultyReviewResponseDto response =
         facultyReviewService.updateReviewStatus(
                 1,
                 "REJECTED");

 assertNotNull(response);
 assertEquals(1, response.getReviewId());
 assertEquals(10, response.getFacultyId());

 verify(facultyReviewRepository).findById(1);
 verify(facultyReviewRepository)
         .save(any(FacultyReviewEntity.class));
}

@Test
void testUpdateReviewStatusNotFound() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.empty());

 ResourceNotFoundException exception =
         assertThrows(ResourceNotFoundException.class,
                 () -> facultyReviewService.updateReviewStatus(
                         1,
                         "APPROVED"));

 assertEquals(
         "Faculty Review not found with ID : 1",
         exception.getMessage());

 verify(facultyReviewRepository).findById(1);
 verify(facultyReviewRepository, never())
         .save(any());
}


//===============================
//deleteFacultyReview()
//===============================

@Test
void testDeleteFacultyReviewSuccess() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.of(reviewEntity));

 doNothing().when(facultyReviewRepository)
         .delete(reviewEntity);

 assertDoesNotThrow(() ->
         facultyReviewService.deleteFacultyReview(1));

 verify(facultyReviewRepository).findById(1);
 verify(facultyReviewRepository)
         .delete(reviewEntity);
}

@Test
void testDeleteFacultyReviewNotFound() {

 when(facultyReviewRepository.findById(1))
         .thenReturn(Optional.empty());

 ResourceNotFoundException exception =
         assertThrows(ResourceNotFoundException.class,
                 () -> facultyReviewService.deleteFacultyReview(1));

 assertEquals(
         "Faculty Review not found with ID : 1",
         exception.getMessage());

 verify(facultyReviewRepository).findById(1);
 verify(facultyReviewRepository, never())
         .delete(any(FacultyReviewEntity.class));
}

}