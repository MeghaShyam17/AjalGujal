package com.ilp.documentknowledgeservice.exception;

public class EnquiryManagementException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3266186451655934748L;

	public EnquiryManagementException(String message) {
        super(message);
    }
}