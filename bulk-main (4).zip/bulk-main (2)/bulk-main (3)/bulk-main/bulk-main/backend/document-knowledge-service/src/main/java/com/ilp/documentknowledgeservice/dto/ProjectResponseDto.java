package com.ilp.documentknowledgeservice.dto;

public class ProjectResponseDto {

    private Long projectStageId;
    private Integer projectId;
    private String submissionStatus;
    private Boolean currentStage;

    public ProjectResponseDto() {
    }

    public Long getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Long projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getSubmissionStatus() {
        return submissionStatus;
    }

    public void setSubmissionStatus(String submissionStatus) {
        this.submissionStatus = submissionStatus;
    }

    public Boolean getCurrentStage() {
        return currentStage;
    }

    public void setCurrentStage(Boolean currentStage) {
        this.currentStage = currentStage;
    }

    @Override
    public String toString() {
        return "ProjectResponseDto{" +
                "projectStageId=" + projectStageId +
                ", projectId=" + projectId +
                ", submissionStatus='" + submissionStatus + '\'' +
                ", currentStage=" + currentStage +
                '}';
    }
}