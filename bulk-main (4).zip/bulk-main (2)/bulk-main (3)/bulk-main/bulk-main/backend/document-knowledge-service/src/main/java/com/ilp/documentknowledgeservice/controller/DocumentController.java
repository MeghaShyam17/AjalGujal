package com.ilp.documentknowledgeservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.documentknowledgeservice.dto.DocumentRequestDto;
import com.ilp.documentknowledgeservice.dto.DocumentResponseDto;
import com.ilp.documentknowledgeservice.service.DocumentService;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    @PostMapping
    public DocumentResponseDto addDocument(
            @RequestBody DocumentRequestDto documentDto) {

        return documentService.addDocument(documentDto);
    }

    @GetMapping("/{documentId}")
    public DocumentResponseDto getDocumentById(
            @PathVariable Long documentId) {

        return documentService.getDocumentById(documentId);
    }

    @GetMapping
    public List<DocumentResponseDto> getAllDocuments() {

        return documentService.getAllDocuments();
    }

    @GetMapping("/project-stage/{projectStageId}")
    public List<DocumentResponseDto> getDocumentsByProjectStageId(
            @PathVariable Long projectStageId) {

        return documentService
                .getDocumentsByProjectStageId(projectStageId);
    }

    @PutMapping("/{documentId}")
    public DocumentResponseDto updateDocument(
            @PathVariable Long documentId,
            @RequestBody DocumentRequestDto documentDto) {

        return documentService.updateDocument(
                documentId,
                documentDto);
    }

    @DeleteMapping("/{documentId}")
    public String deleteDocument(
            @PathVariable Long documentId) {

        documentService.deleteDocument(documentId);

        return "Document deleted successfully";
    }

    @GetMapping("/{documentId}/view")
    public org.springframework.http.ResponseEntity<byte[]> viewDocument(
            @PathVariable Long documentId) {

        com.ilp.documentknowledgeservice.entity.DocumentEntity doc =
                documentService.getDocumentEntityById(documentId);

        String fileName = doc.getFileName() != null ? doc.getFileName() : "document.pdf";
        String contentType = determineContentType(fileName);

        return org.springframework.http.ResponseEntity.ok()
                .header(org.springframework.http.HttpHeaders.CONTENT_TYPE, contentType)
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + fileName + "\"")
                .body(doc.getFileData());
    }

    @GetMapping("/{documentId}/download")
    public org.springframework.http.ResponseEntity<byte[]> downloadDocument(
            @PathVariable Long documentId) {

        com.ilp.documentknowledgeservice.entity.DocumentEntity doc =
                documentService.getDocumentEntityById(documentId);

        String fileName = doc.getFileName() != null ? doc.getFileName() : "document.pdf";
        String contentType = determineContentType(fileName);

        return org.springframework.http.ResponseEntity.ok()
                .header(org.springframework.http.HttpHeaders.CONTENT_TYPE, contentType)
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(doc.getFileData());
    }

    private String determineContentType(String fileName) {
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".pdf")) return "application/pdf";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".doc")) return "application/msword";
        if (lower.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (lower.endsWith(".zip")) return "application/zip";
        if (lower.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }
}