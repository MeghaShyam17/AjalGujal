package com.ilp.documentknowledgeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class DocumentKnowledgeServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(
                DocumentKnowledgeServiceApplication.class,
                args);
    }
}