package com.ilp.documentknowledgeservice.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import com.ilp.documentknowledgeservice.service.EnquiryManagementService;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementRequestDto;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementResponseDto;

@RestController
@RequestMapping("/api/enquiries")

public class EnquiryManagementController {

    private final EnquiryManagementService service;

    public EnquiryManagementController(
            EnquiryManagementService service) {

        this.service = service;
    }

    @PostMapping
    public ResponseEntity<EnquiryManagementResponseDto> createEnquiry(
            @Valid @RequestBody EnquiryManagementRequestDto request) {

        return ResponseEntity.ok(
                service.createEnquiry(request));
    }

    @GetMapping
    public ResponseEntity<List<EnquiryManagementResponseDto>> getAllEnquiries() {

        return ResponseEntity.ok(
                service.getAllEnquiries());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EnquiryManagementResponseDto> getEnquiryById(
            @PathVariable Integer id) {

        return ResponseEntity.ok(
                service.getEnquiryById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<EnquiryManagementResponseDto>> getByUserId(
            @PathVariable Integer userId) {

        return ResponseEntity.ok(
                service.getEnquiriesByUserId(userId));
    }

    @GetMapping("/faculty/{facultyId}")
    public ResponseEntity<List<EnquiryManagementResponseDto>> getByFacultyId(
            @PathVariable Integer facultyId) {

        return ResponseEntity.ok(
                service.getEnquiriesByFacultyId(facultyId));
    }

    @PutMapping("/{id}/reply")
    public ResponseEntity<EnquiryManagementResponseDto> facultyReply(
            @PathVariable Integer id,
            @RequestParam String facultyComment) {

        return ResponseEntity.ok(
                service.facultyReply(
                        id,
                        facultyComment));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEnquiry(
            @PathVariable Integer id) {

        service.deleteEnquiry(id);

        return ResponseEntity.ok(
                "Enquiry deleted successfully");
    }
}