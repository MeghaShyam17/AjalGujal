package com.ilp.documentknowledgeservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class EnquiryManagementRequestDto {

    @NotNull(message = "User Id is required")
    private Integer userId;

    @NotNull(message = "Project Id is required")
    private Integer projectId;

    @NotBlank(message = "User Comment is required")
    private String userComment;

    public EnquiryManagementRequestDto() {
    }

    public EnquiryManagementRequestDto(Integer userId, Integer projectId, String userComment) {
        this.userId = userId;
        this.projectId = projectId;
        this.userComment = userComment;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getUserComment() {
        return userComment;
    }

    public void setUserComment(String userComment) {
        this.userComment = userComment;
    }
}