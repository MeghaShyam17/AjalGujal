package com.ilp.documentknowledgeservice.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.ilp.documentknowledgeservice.client.NotificationClient;
import com.ilp.documentknowledgeservice.client.UserClient;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestResponseDto;
import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;
import com.ilp.documentknowledgeservice.dto.UserResponseDto;
import com.ilp.documentknowledgeservice.entity.KnowledgeRequestEntity;
import com.ilp.documentknowledgeservice.exception.BadRequestException;
import com.ilp.documentknowledgeservice.exception.DuplicateResourceException;
import com.ilp.documentknowledgeservice.exception.ResourceNotFoundException;
import com.ilp.documentknowledgeservice.mapper.KnowledgeRequestMapper;
import com.ilp.documentknowledgeservice.repository.KnowledgeRequestRepository;
import com.ilp.documentknowledgeservice.service.KnowledgeRequestService;

@Service
public class KnowledgeRequestServiceImpl
        implements KnowledgeRequestService {

    private final KnowledgeRequestRepository repository;

    private final UserClient userClient;

    private final NotificationClient notificationClient;

    public KnowledgeRequestServiceImpl(
            KnowledgeRequestRepository repository,
            UserClient userClient,
            NotificationClient notificationClient) {

        this.repository = repository;
        this.userClient = userClient;
        this.notificationClient = notificationClient;
    }

    @Override
    public KnowledgeRequestResponseDto createRequest(
            KnowledgeRequestRequestDto requestDto) {

        UserResponseDto user =
                userClient.getUserById(
                        requestDto.getStudentId().intValue());

        if (user == null) {
            throw new ResourceNotFoundException(
                    "Student not found with id: "
                            + requestDto.getStudentId());
        }

        List<KnowledgeRequestEntity> existingRequests =
                repository.findByStudentIdAndRequestStatus(
                        requestDto.getStudentId(),
                        "Pending");

        boolean duplicateExists =
                existingRequests.stream()
                        .anyMatch(request ->
                                request.getKnowledgeId()
                                        .equals(requestDto.getKnowledgeId()));

        if (duplicateExists) {
            throw new DuplicateResourceException(
                    "A pending request already exists for this knowledge item.");
        }

        KnowledgeRequestEntity entity =
                KnowledgeRequestMapper.toEntity(requestDto);

        entity.setStudentId(user.getUserId().longValue());

        KnowledgeRequestEntity savedEntity =
                repository.save(entity);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(user.getUserId());

        notification.setTitle(
                "Knowledge Request Submitted");

        notification.setMessage(
                "Your knowledge request has been submitted successfully.");

        notification.setNotificationType(
                "KNOWLEDGE_REQUEST");

        notification.setModuleName(
                "Knowledge Request");

        notification.setReferenceId(
                savedEntity.getRequestId().intValue());

        notification.setPriority(
                "Medium");

        notificationClient.createNotification(
                notification);

        return KnowledgeRequestMapper
                .toResponseDto(savedEntity);
    }
    
    @Override
    public KnowledgeRequestResponseDto getRequestById(
            Long requestId) {

        KnowledgeRequestEntity entity =
                repository.findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Knowledge request not found with id: "
                                                + requestId));

        return KnowledgeRequestMapper.toResponseDto(entity);
    }

    @Override
    public List<KnowledgeRequestResponseDto> getAllRequests() {

        return repository.findAll()
                .stream()
                .map(KnowledgeRequestMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeRequestResponseDto> getRequestsByStudentId(
            Long studentId) {

        userClient.getUserById(studentId.intValue());

        return repository.findByStudentId(studentId)
                .stream()
                .map(KnowledgeRequestMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeRequestResponseDto> getRequestsByKnowledgeId(
            Long knowledgeId) {

        return repository.findByKnowledgeId(knowledgeId)
                .stream()
                .map(KnowledgeRequestMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<KnowledgeRequestResponseDto> getRequestsByStatus(
            String status) {

        return repository.findByRequestStatus(status)
                .stream()
                .map(KnowledgeRequestMapper::toResponseDto)
                .collect(Collectors.toList());
    }
    
    @Override
    public KnowledgeRequestResponseDto approveRequest(
            Long requestId,
            Long approvedBy,
            String remarks) {

        KnowledgeRequestEntity entity =
                repository.findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Knowledge request not found with id: "
                                                + requestId));

        if ("Approved".equalsIgnoreCase(entity.getRequestStatus())) {
            throw new BadRequestException(
                    "Request is already approved.");
        }

        entity.setRequestStatus("Approved");
        entity.setApprovedBy(approvedBy);
        entity.setApprovedOn(LocalDateTime.now());
        entity.setRemarks(remarks);

        KnowledgeRequestEntity updatedEntity =
                repository.save(entity);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(
                entity.getStudentId().intValue());

        notification.setTitle(
                "Knowledge Request Approved");

        notification.setMessage(
                "Your knowledge request has been approved.");

        notification.setNotificationType(
                "KNOWLEDGE_REQUEST");

        notification.setModuleName(
                "Knowledge Request");

        notification.setReferenceId(
                updatedEntity.getRequestId().intValue());

        notification.setPriority(
                "High");

        notificationClient.createNotification(notification);

        return KnowledgeRequestMapper
                .toResponseDto(updatedEntity);
    }

    @Override
    public KnowledgeRequestResponseDto rejectRequest(
            Long requestId,
            Long approvedBy,
            String remarks) {

        KnowledgeRequestEntity entity =
                repository.findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Knowledge request not found with id: "
                                                + requestId));

        if ("Rejected".equalsIgnoreCase(entity.getRequestStatus())) {
            throw new BadRequestException(
                    "Request is already rejected.");
        }

        entity.setRequestStatus("Rejected");
        entity.setApprovedBy(approvedBy);
        entity.setApprovedOn(LocalDateTime.now());
        entity.setRemarks(remarks);

        KnowledgeRequestEntity updatedEntity =
                repository.save(entity);

        NotificationRequestDto notification =
                new NotificationRequestDto();

        notification.setUserId(
                entity.getStudentId().intValue());

        notification.setTitle(
                "Knowledge Request Rejected");

        notification.setMessage(
                "Your knowledge request has been rejected.");

        notification.setNotificationType(
                "KNOWLEDGE_REQUEST");

        notification.setModuleName(
                "Knowledge Request");

        notification.setReferenceId(
                updatedEntity.getRequestId().intValue());

        notification.setPriority(
                "High");

        notificationClient.createNotification(notification);

        return KnowledgeRequestMapper
                .toResponseDto(updatedEntity);
    }

    @Override
    public void deleteRequest(
            Long requestId) {

        KnowledgeRequestEntity entity =
                repository.findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Knowledge request not found with id: "
                                                + requestId));

        repository.delete(entity);
    }
}