package com.ilp.documentknowledgeservice.service;

import java.util.List;

import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeAccessLogResponseDto;

public interface KnowledgeAccessLogService {

    // Record a View or Download action
    KnowledgeAccessLogResponseDto createAccessLog(KnowledgeAccessLogRequestDto requestDto);

    // Get Access Log by ID
    KnowledgeAccessLogResponseDto getAccessLogById(Integer accessId);

    // Get all Access Logs
    List<KnowledgeAccessLogResponseDto> getAllAccessLogs();

    // Get Access Logs by Student
    List<KnowledgeAccessLogResponseDto> getAccessLogsByStudent(Integer studentId);

    // Get Access Logs by Knowledge Base
    List<KnowledgeAccessLogResponseDto> getAccessLogsByKnowledge(Integer knowledgeId);

    // Get Access Logs by Action (Viewed / Downloaded)
    List<KnowledgeAccessLogResponseDto> getAccessLogsByAction(String action);

    // Delete Access Log
    void deleteAccessLog(Integer accessId);
}