package com.ilp.documentknowledgeservice.controller;

import com.ilp.documentknowledgeservice.dto.KnowledgeRequestRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeRequestResponseDto;
import com.ilp.documentknowledgeservice.service.KnowledgeRequestService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/knowledge-requests")
public class KnowledgeRequestController {

    private final KnowledgeRequestService knowledgeRequestService;

    public KnowledgeRequestController(
            KnowledgeRequestService knowledgeRequestService) {
        this.knowledgeRequestService = knowledgeRequestService;
    }

    @PostMapping
    public ResponseEntity<KnowledgeRequestResponseDto> createRequest(
            @Valid @RequestBody KnowledgeRequestRequestDto requestDto) {

        KnowledgeRequestResponseDto response =
                knowledgeRequestService.createRequest(requestDto);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{requestId}")
    public ResponseEntity<KnowledgeRequestResponseDto> getRequestById(
            @PathVariable Long requestId) {

        return ResponseEntity.ok(
                knowledgeRequestService.getRequestById(requestId));
    }

    @GetMapping
    public ResponseEntity<List<KnowledgeRequestResponseDto>> getAllRequests() {

        return ResponseEntity.ok(
                knowledgeRequestService.getAllRequests());
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<KnowledgeRequestResponseDto>> getRequestsByStudentId(
            @PathVariable Long studentId) {

        return ResponseEntity.ok(
                knowledgeRequestService.getRequestsByStudentId(studentId));
    }

    @GetMapping("/knowledge/{knowledgeId}")
    public ResponseEntity<List<KnowledgeRequestResponseDto>> getRequestsByKnowledgeId(
            @PathVariable Long knowledgeId) {

        return ResponseEntity.ok(
                knowledgeRequestService.getRequestsByKnowledgeId(knowledgeId));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<KnowledgeRequestResponseDto>> getRequestsByStatus(
            @PathVariable String status) {

        return ResponseEntity.ok(
                knowledgeRequestService.getRequestsByStatus(status));
    }

    @PutMapping("/{requestId}/approve")
    public ResponseEntity<KnowledgeRequestResponseDto> approveRequest(
            @PathVariable Long requestId,
            @RequestParam Long approvedBy,
            @RequestParam(required = false) String remarks) {

        return ResponseEntity.ok(
                knowledgeRequestService.approveRequest(
                        requestId,
                        approvedBy,
                        remarks));
    }

    @PutMapping("/{requestId}/reject")
    public ResponseEntity<KnowledgeRequestResponseDto> rejectRequest(
            @PathVariable Long requestId,
            @RequestParam Long approvedBy,
            @RequestParam(required = false) String remarks) {

        return ResponseEntity.ok(
                knowledgeRequestService.rejectRequest(
                        requestId,
                        approvedBy,
                        remarks));
    }

    @DeleteMapping("/{requestId}")
    public ResponseEntity<Void> deleteRequest(
            @PathVariable Long requestId) {

        knowledgeRequestService.deleteRequest(requestId);

        return ResponseEntity.noContent().build();
    }
}