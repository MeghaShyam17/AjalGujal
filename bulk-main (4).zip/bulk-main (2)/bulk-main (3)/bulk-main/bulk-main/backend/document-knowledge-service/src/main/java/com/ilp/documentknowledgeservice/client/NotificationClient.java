package com.ilp.documentknowledgeservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.ilp.documentknowledgeservice.config.FeignConfig;

import com.ilp.documentknowledgeservice.dto.NotificationRequestDto;

@FeignClient(
        name = "notification-service",
        url = "${notification.service.url}",
        configuration = FeignConfig.class)
public interface NotificationClient {

    @PostMapping("/api/notifications")
    void createNotification(
            @RequestBody NotificationRequestDto request);
}