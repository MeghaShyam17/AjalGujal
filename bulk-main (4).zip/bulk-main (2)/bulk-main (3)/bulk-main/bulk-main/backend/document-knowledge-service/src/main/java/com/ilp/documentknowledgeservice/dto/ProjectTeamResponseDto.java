package com.ilp.documentknowledgeservice.dto;

import java.time.LocalDate;

public class ProjectTeamResponseDto {

    private Integer projectId;
    private String projectName;
    private String description;
    private Integer teamLeaderId;
    private Integer facultyId;
    private Integer batchId;
    private Integer year;
    private LocalDate deadline;
    private String projectStatus;

    public ProjectTeamResponseDto() {
    }

    public ProjectTeamResponseDto(Integer projectId, String projectName, Integer facultyId) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.facultyId = facultyId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTeamLeaderId() {
        return teamLeaderId;
    }

    public void setTeamLeaderId(Integer teamLeaderId) {
        this.teamLeaderId = teamLeaderId;
    }

    public Integer getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Integer facultyId) {
        this.facultyId = facultyId;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    @Override
    public String toString() {
        return "ProjectTeamResponseDto{" +
                "projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", facultyId=" + facultyId +
                ", projectStatus='" + projectStatus + '\'' +
                '}';
    }
}
