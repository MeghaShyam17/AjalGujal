package com.ilp.documentknowledgeservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class KnowledgeRequestRequestDto {

    @NotNull(message = "Student ID is required")
    private Long studentId;

    @NotNull(message = "Knowledge ID is required")
    private Long knowledgeId;

    @NotBlank(message = "Request reason is required")
    private String requestReason;

    public KnowledgeRequestRequestDto() {
    }

    public KnowledgeRequestRequestDto(Long studentId,
                                      Long knowledgeId,
                                      String requestReason) {
        this.studentId = studentId;
        this.knowledgeId = knowledgeId;
        this.requestReason = requestReason;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Long getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Long knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public String getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(String requestReason) {
        this.requestReason = requestReason;
    }
}