package com.ilp.documentknowledgeservice.mapper;

import org.springframework.stereotype.Component;

import com.ilp.documentknowledgeservice.dto.EnquiryManagementResponseDto;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementRequestDto;
import com.ilp.documentknowledgeservice.entity.EnquiryManagementEntity;

@Component
public class EnquiryManagementMapper {

    public EnquiryManagementEntity toEntity(
            EnquiryManagementRequestDto request) {

        if (request == null) {
            return null;
        }

        EnquiryManagementEntity entity = new EnquiryManagementEntity();

        entity.setUserId(request.getUserId());
        entity.setProjectId(request.getProjectId());
        entity.setUserComment(request.getUserComment());

        return entity;
    }

    public EnquiryManagementResponseDto toResponse(
            EnquiryManagementEntity entity) {

        return toResponse(entity, null);
    }

    public EnquiryManagementResponseDto toResponse(
            EnquiryManagementEntity entity,
            String projectName) {

        if (entity == null) {
            return null;
        }

        EnquiryManagementResponseDto response =
                new EnquiryManagementResponseDto();

        response.setEnquiryId(entity.getEnquiryId());
        response.setUserId(entity.getUserId());
        response.setProjectId(entity.getProjectId());
        response.setProjectName(projectName);
        response.setUserComment(entity.getUserComment());
        response.setFacultyComment(entity.getFacultyComment());
        response.setEnquiryStatus(entity.getEnquiryStatus());
        response.setCreatedAt(entity.getCreatedAt());
        response.setRepliedAt(entity.getRepliedAt());

        return response;
    }
}