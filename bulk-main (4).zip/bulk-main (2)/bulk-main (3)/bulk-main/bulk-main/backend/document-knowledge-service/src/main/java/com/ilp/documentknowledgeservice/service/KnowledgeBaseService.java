package com.ilp.documentknowledgeservice.service;

import java.util.List;

import com.ilp.documentknowledgeservice.dto.KnowledgeBaseRequestDto;
import com.ilp.documentknowledgeservice.dto.KnowledgeBaseResponseDto;

public interface KnowledgeBaseService {

    // Create a new Knowledge Base entry
    KnowledgeBaseResponseDto createKnowledgeBase(KnowledgeBaseRequestDto requestDto);

    // Update an existing Knowledge Base entry
    KnowledgeBaseResponseDto updateKnowledgeBase(Integer knowledgeId,
            KnowledgeBaseRequestDto requestDto);

    // Delete a Knowledge Base entry
    void deleteKnowledgeBase(Integer knowledgeId);

    // Get a Knowledge Base entry by ID
    KnowledgeBaseResponseDto getKnowledgeBaseById(Integer knowledgeId);

    // Get all Knowledge Base entries
    List<KnowledgeBaseResponseDto> getAllKnowledgeBase();

    // Search Knowledge Base by Title
    List<KnowledgeBaseResponseDto> searchKnowledgeByTitle(String title);

    // Get Knowledge Base by Category
    List<KnowledgeBaseResponseDto> getKnowledgeByCategory(String category);

    // Get Knowledge Base by Visibility
    List<KnowledgeBaseResponseDto> getKnowledgeByVisibility(String visibility);

    // Get Knowledge Base by Project Stage
    List<KnowledgeBaseResponseDto> getKnowledgeByProjectStage(Integer projectStageId);

    // Get Knowledge Base published by a Faculty/User
    List<KnowledgeBaseResponseDto> getKnowledgeByPublishedBy(Integer publishedBy);

}