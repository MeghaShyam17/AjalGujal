package com.ilp.documentknowledgeservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ilp.documentknowledgeservice.entity.DocumentEntity;

@Repository
public interface DocumentRepository
        extends JpaRepository<DocumentEntity, Long> {

    List<DocumentEntity> findByProjectStageId(Long projectStageId);

    List<DocumentEntity> findByUploadedBy(Integer uploadedBy);

    boolean existsByProjectStageIdAndVersionNoAndOriginalFileNameIgnoreCase(
            Long projectStageId,
            Integer versionNo,
            String originalFileName
    );
}