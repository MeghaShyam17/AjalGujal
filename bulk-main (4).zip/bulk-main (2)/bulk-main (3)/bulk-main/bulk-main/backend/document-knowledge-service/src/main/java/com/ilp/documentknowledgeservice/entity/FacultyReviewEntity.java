package com.ilp.documentknowledgeservice.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "faculty_review")
public class FacultyReviewEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    private Integer reviewId;

    @Column(name = "project_stage_id", nullable = false)
    private Integer projectStageId;

    @Column(name = "faculty_id", nullable = false)
    private Integer facultyId;
    
    @Column(name = "document_id", nullable = false)
    private Integer documentId;

    @Column(name = "review_status", length = 50)
    private String reviewStatus;

    @Column(name = "review_comment", length = 2000)
    private String reviewComment;

    @Column(name = "reviewed_on")
    private LocalDateTime reviewedOn;

    // Default Constructor
    public FacultyReviewEntity() {
    }

    // Parameterized Constructor
    public FacultyReviewEntity(Integer reviewId, Integer projectStageId,
                               Integer facultyId, Integer documentId,
                               String reviewStatus, String reviewComment,
                               LocalDateTime reviewedOn) {
        this.reviewId = reviewId;
        this.projectStageId = projectStageId;
        this.facultyId = facultyId;
        this.documentId = documentId;
        this.reviewStatus = reviewStatus;
        this.reviewComment = reviewComment;
        this.reviewedOn = reviewedOn;
    }

    // Getters and Setters

    public Integer getReviewId() {
        return reviewId;
    }

    public void setReviewId(Integer reviewId) {
        this.reviewId = reviewId;
    }

    public Integer getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Integer projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Integer facultyId) {
        this.facultyId = facultyId;
    }

    public Integer getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Integer documentId) {
        this.documentId = documentId;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getReviewComment() {
        return reviewComment;
    }

    public void setReviewComment(String reviewComment) {
        this.reviewComment = reviewComment;
    }

    public LocalDateTime getReviewedOn() {
        return reviewedOn;
    }

    public void setReviewedOn(LocalDateTime reviewedOn) {
        this.reviewedOn = reviewedOn;
    }

    @Override
    public String toString() {
        return "FacultyReviewEntity{" +
                "reviewId=" + reviewId +
                ", projectStageId=" + projectStageId +
                ", facultyId=" + facultyId +
                ", documentId=" + documentId +
                ", reviewStatus='" + reviewStatus + '\'' +
                ", reviewComment='" + reviewComment + '\'' +
                ", reviewedOn=" + reviewedOn +
                '}';
    }
}