package com.ilp.documentknowledgeservice.dto;

public class ApprovalRequestDto {

    private Long approvedBy;
    private String remarks;

    public Long getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Long approvedBy) {
        this.approvedBy = approvedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}