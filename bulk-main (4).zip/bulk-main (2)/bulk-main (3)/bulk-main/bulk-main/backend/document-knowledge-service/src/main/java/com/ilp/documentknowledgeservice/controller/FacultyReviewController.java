package com.ilp.documentknowledgeservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.documentknowledgeservice.dto.FacultyReviewRequestDto;
import com.ilp.documentknowledgeservice.dto.FacultyReviewResponseDto;
import com.ilp.documentknowledgeservice.service.FacultyReviewService;

@RestController
@RequestMapping("/api/faculty-reviews")
public class FacultyReviewController {

    @Autowired
    private FacultyReviewService facultyReviewService;

    @PostMapping
    public FacultyReviewResponseDto addFacultyReview(
            @RequestBody FacultyReviewRequestDto reviewDto) {

        return facultyReviewService
                .addFacultyReview(reviewDto);
    }

    @GetMapping("/{reviewId}")
    public FacultyReviewResponseDto getFacultyReviewById(
            @PathVariable Integer reviewId) {

        return facultyReviewService
                .getFacultyReviewById(reviewId);
    }

    @GetMapping
    public List<FacultyReviewResponseDto> getAllFacultyReviews() {

        return facultyReviewService
                .getAllFacultyReviews();
    }

    @GetMapping("/project-stage/{projectStageId}")
    public List<FacultyReviewResponseDto> getReviewsByProjectStageId(
            @PathVariable Integer projectStageId) {

        return facultyReviewService
                .getReviewsByProjectStageId(projectStageId);
    }

    @GetMapping("/faculty/{facultyId}")
    public List<FacultyReviewResponseDto> getReviewsByFacultyId(
            @PathVariable Integer facultyId) {

        return facultyReviewService
                .getReviewsByFacultyId(facultyId);
    }

    @GetMapping("/document/{documentId}")
    public List<FacultyReviewResponseDto> getReviewsByDocumentId(
            @PathVariable Integer documentId) {

        return facultyReviewService
                .getReviewsByDocumentId(documentId);
    }

    @GetMapping("/status/{status}")
    public List<FacultyReviewResponseDto> getReviewsByStatus(
            @PathVariable String status) {

        return facultyReviewService
                .getReviewsByStatus(status);
    }

    @PutMapping("/{reviewId}")
    public FacultyReviewResponseDto updateFacultyReview(
            @PathVariable Integer reviewId,
            @RequestBody FacultyReviewRequestDto reviewDto) {

        return facultyReviewService
                .updateFacultyReview(
                        reviewId,
                        reviewDto);
    }

    @PatchMapping("/{reviewId}/status")
    public FacultyReviewResponseDto updateReviewStatus(
            @PathVariable Integer reviewId,
            @RequestParam String status) {

        return facultyReviewService
                .updateReviewStatus(
                        reviewId,
                        status);
    }

    @DeleteMapping("/{reviewId}")
    public String deleteFacultyReview(
            @PathVariable Integer reviewId) {

        facultyReviewService
                .deleteFacultyReview(reviewId);

        return "Faculty Review deleted successfully";
    }
}