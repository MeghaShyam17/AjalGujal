package com.ilp.documentknowledgeservice.service;

import java.util.List;

import com.ilp.documentknowledgeservice.dto.EnquiryManagementResponseDto;
import com.ilp.documentknowledgeservice.dto.EnquiryManagementRequestDto;

public interface EnquiryManagementService {

    EnquiryManagementResponseDto createEnquiry(
            EnquiryManagementRequestDto request);

    List<EnquiryManagementResponseDto> getAllEnquiries();

    EnquiryManagementResponseDto getEnquiryById(
            Integer enquiryId);

    List<EnquiryManagementResponseDto> getEnquiriesByUserId(
            Integer userId);

    List<EnquiryManagementResponseDto> getEnquiriesByFacultyId(
            Integer facultyId);
    
    EnquiryManagementResponseDto facultyReply(
            Integer enquiryId,
            String facultyComment);

    void deleteEnquiry(Integer enquiryId);
}