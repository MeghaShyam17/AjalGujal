package com.ilp.documentknowledgeservice.mapper;

import com.ilp.documentknowledgeservice.dto.FacultyReviewRequestDto;
import com.ilp.documentknowledgeservice.dto.FacultyReviewResponseDto;
import com.ilp.documentknowledgeservice.entity.FacultyReviewEntity;

public class FacultyReviewMapper {

    /**
     * Request DTO -> Entity
     */
    public static FacultyReviewEntity toEntity(
            FacultyReviewRequestDto dto) {

        FacultyReviewEntity entity = new FacultyReviewEntity();

        entity.setProjectStageId(dto.getProjectStageId());
        entity.setFacultyId(dto.getFacultyId());
        entity.setDocumentId(dto.getDocumentId());
        entity.setReviewStatus(dto.getReviewStatus());
        entity.setReviewComment(dto.getReviewComment());

        return entity;
    }

    /**
     * Entity -> Response DTO
     */
    public static FacultyReviewResponseDto toResponseDto(
            FacultyReviewEntity entity) {

        FacultyReviewResponseDto dto =
                new FacultyReviewResponseDto();

        dto.setReviewId(entity.getReviewId());
        dto.setProjectStageId(entity.getProjectStageId());
        dto.setFacultyId(entity.getFacultyId());
        dto.setDocumentId(entity.getDocumentId());
        dto.setReviewStatus(entity.getReviewStatus());
        dto.setReviewComment(entity.getReviewComment());
        dto.setReviewedOn(entity.getReviewedOn());

        return dto;
    }
}