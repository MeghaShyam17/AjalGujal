package com.ilp.documentknowledgeservice.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.Arrays;

@Entity
@Table(name = "document")
public class DocumentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "document_id")
    private Long documentId;

    @Column(name = "project_stage_id", nullable = false)
    private Long projectStageId;

    @Column(name = "uploaded_by", nullable = false)
    private Integer uploadedBy;

    @Column(name = "version_no")
    private Integer versionNo;

    @Column(name = "document_type", length = 100)
    private String documentType;

    @Column(name = "title", length = 255)
    private String title;

    @Column(name = "file_name", length = 255)
    private String fileName;

    @Column(name = "original_file_name", length = 255)
    private String originalFileName;

    @Column(name = "file_size")
    private Long fileSize;

    @Column(name = "file_data",columnDefinition = "bytea")
    private byte[] fileData;

    @Column(name = "description", length = 1000)
    private String description;

    @Column(name = "uploaded_at")
    private Timestamp uploadedAt;

    // Default Constructor
    public DocumentEntity() {
    }

    // Parameterized Constructor
    public DocumentEntity(Long documentId, Long projectStageId, Integer uploadedBy,
                          Integer versionNo, String documentType, String title,
                          String fileName, String originalFileName, Long fileSize,
                          byte[] fileData, String description,
                          Timestamp uploadedAt) {

        this.documentId = documentId;
        this.projectStageId = projectStageId;
        this.uploadedBy = uploadedBy;
        this.versionNo = versionNo;
        this.documentType = documentType;
        this.title = title;
        this.fileName = fileName;
        this.originalFileName = originalFileName;
        this.fileSize = fileSize;
        this.fileData = fileData;
        this.description = description;
        this.uploadedAt = uploadedAt;
    }

    // Getters and Setters

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public Long getProjectStageId() {
        return projectStageId;
    }

    public void setProjectStageId(Long projectStageId) {
        this.projectStageId = projectStageId;
    }

    public Integer getUploadedBy() {
        return uploadedBy;
    }

    public void setUploadedBy(int i) {
        this.uploadedBy = i;
    }

    public Integer getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(Integer versionNo) {
        this.versionNo = versionNo;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public byte[] getFileData() {
        return fileData;
    }

    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Timestamp getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(Timestamp uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    @Override
    public String toString() {
        return "DocumentEntity{" +
                "documentId=" + documentId +
                ", projectStageId=" + projectStageId +
                ", uploadedBy=" + uploadedBy +
                ", versionNo=" + versionNo +
                ", documentType='" + documentType + '\'' +
                ", title='" + title + '\'' +
                ", fileName='" + fileName + '\'' +
                ", originalFileName='" + originalFileName + '\'' +
                ", fileSize=" + fileSize +
                ", fileData=" + Arrays.toString(fileData) +
                ", description='" + description + '\'' +
                ", uploadedAt=" + uploadedAt +
                '}';
    }
}