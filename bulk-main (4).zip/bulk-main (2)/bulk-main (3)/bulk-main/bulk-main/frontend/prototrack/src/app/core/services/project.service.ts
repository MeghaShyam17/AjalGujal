import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  BulkUploadResult,
  ProjectTeamDto,
  ProjectStageDto,
  StageMasterDto,
  TeamMemberDto
} from '../models/project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private readonly baseUrl = environment.apiBaseUrl;

  private readonly projectUrl = `${this.baseUrl}/api/projects`;
  private readonly projectStageUrl = `${this.baseUrl}/project-stage`;
  private readonly stageMasterUrl = `${this.baseUrl}/stage-master`;
  private readonly teamMemberUrl = `${this.baseUrl}/api/team-members`;

  constructor(private http: HttpClient) {}

  // ==========================================
  // PROJECT TEAM
  // ==========================================

  createProject(
    data: ProjectTeamDto
  ): Observable<ProjectTeamDto> {
    return this.http.post<ProjectTeamDto>(
      this.projectUrl,
      data
    );
  }

  /**
   * Uploads an .xlsx file containing projects and team members.
   *
   * Endpoint:
   * POST /api/projects/bulk-upload
   *
   * The backend returns a BulkUploadResult JSON object.
   */
  uploadTeams(
    formData: FormData
  ): Observable<BulkUploadResult> {
    return this.http.post<BulkUploadResult>(
      `${this.projectUrl}/bulk-upload`,
      formData
    );
  }

  /**
   * Convenience method for callers that have a File instead of FormData.
   * Uses the same backend endpoint as uploadTeams().
   */
  uploadProjectsBulk(
    file: File
  ): Observable<BulkUploadResult> {
    const formData = new FormData();
    formData.append('file', file, file.name);

    return this.uploadTeams(formData);
  }

  getAllProjects(): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      this.projectUrl
    );
  }

  getProjectById(
    id: number
  ): Observable<ProjectTeamDto> {
    return this.http.get<ProjectTeamDto>(
      `${this.projectUrl}/${id}`
    );
  }

  getProjectsByFacultyId(
    facultyId: number
  ): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      `${this.projectUrl}/faculty/${facultyId}`
    );
  }

  getProjectsByTeamLeaderId(
    teamLeaderId: number
  ): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      `${this.projectUrl}/team-leader/${teamLeaderId}`
    );
  }

  getProjectsByStatus(
    status: string
  ): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      `${this.projectUrl}/status/${encodeURIComponent(status)}`
    );
  }

  getProjectsByBatchId(
    batchId: number
  ): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      `${this.projectUrl}/batch/${batchId}`
    );
  }

  getProjectsByYear(
    year: number
  ): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      `${this.projectUrl}/year/${year}`
    );
  }

  searchProjects(
    keyword: string
  ): Observable<ProjectTeamDto[]> {
    return this.http.get<ProjectTeamDto[]>(
      `${this.projectUrl}/search`,
      {
        params: {
          name: keyword
        }
      }
    );
  }

  updateProject(
    id: number,
    data: ProjectTeamDto
  ): Observable<ProjectTeamDto> {
    return this.http.put<ProjectTeamDto>(
      `${this.projectUrl}/${id}`,
      data
    );
  }

  deleteProjectHard(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.projectUrl}/hard-delete/${id}`
    );
  }

  deleteProjectSoft(
    id: number
  ): Observable<void> {
    return this.http.put<void>(
      `${this.projectUrl}/soft-delete/${id}`,
      {}
    );
  }

  // ==========================================
  // PROJECT STAGE
  // ==========================================

  initializeProjectStages(
    projectId: number
  ): Observable<unknown> {
    return this.http.post<unknown>(
      `${this.projectStageUrl}/initialize/${projectId}`,
      {}
    );
  }

  saveProjectStage(
    data: ProjectStageDto
  ): Observable<ProjectStageDto> {
    return this.http.post<ProjectStageDto>(
      `${this.projectStageUrl}/save`,
      data
    );
  }

  getAllProjectStages(): Observable<ProjectStageDto[]> {
    return this.http.get<ProjectStageDto[]>(
      `${this.projectStageUrl}/all`
    );
  }

  getProjectStageById(
    id: number
  ): Observable<ProjectStageDto> {
    return this.http.get<ProjectStageDto>(
      `${this.projectStageUrl}/${id}`
    );
  }

  updateProjectStage(
    id: number,
    data: ProjectStageDto
  ): Observable<ProjectStageDto> {
    return this.http.put<ProjectStageDto>(
      `${this.projectStageUrl}/${id}`,
      data
    );
  }

  deleteProjectStage(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.projectStageUrl}/${id}`
    );
  }

  uploadDocument(
    formData: FormData
  ): Observable<string> {
    return this.http.post(
      `${this.projectStageUrl}/upload-document`,
      formData,
      {
        responseType: 'text'
      }
    );
  }

  // ==========================================
  // STAGE MASTER
  // ==========================================

  createStageMaster(
    data: StageMasterDto
  ): Observable<StageMasterDto> {
    return this.http.post<StageMasterDto>(
      this.stageMasterUrl,
      data
    );
  }

  getAllStageMasters(): Observable<StageMasterDto[]> {
    return this.http.get<StageMasterDto[]>(
      this.stageMasterUrl
    );
  }

  getStageMasterById(
    id: number
  ): Observable<StageMasterDto> {
    return this.http.get<StageMasterDto>(
      `${this.stageMasterUrl}/${id}`
    );
  }

  updateStageMaster(
    id: number,
    data: StageMasterDto
  ): Observable<StageMasterDto> {
    return this.http.put<StageMasterDto>(
      `${this.stageMasterUrl}/${id}`,
      data
    );
  }

  deleteStageMaster(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.stageMasterUrl}/${id}`
    );
  }

  // ==========================================
  // TEAM MEMBER
  // ==========================================

  addTeamMember(
    data: TeamMemberDto
  ): Observable<TeamMemberDto> {
    return this.http.post<TeamMemberDto>(
      this.teamMemberUrl,
      data
    );
  }

  getAllTeamMembers(): Observable<TeamMemberDto[]> {
    return this.http.get<TeamMemberDto[]>(
      this.teamMemberUrl
    );
  }

  getTeamMemberById(
    teamMemberId: number
  ): Observable<TeamMemberDto> {
    return this.http.get<TeamMemberDto>(
      `${this.teamMemberUrl}/${teamMemberId}`
    );
  }

  updateTeamMember(
    teamMemberId: number,
    data: TeamMemberDto
  ): Observable<TeamMemberDto> {
    return this.http.put<TeamMemberDto>(
      `${this.teamMemberUrl}/${teamMemberId}`,
      data
    );
  }

  deleteTeamMemberSoft(
    teamMemberId: number
  ): Observable<void> {
    return this.http.put<void>(
      `${this.teamMemberUrl}/soft-delete/${teamMemberId}`,
      {}
    );
  }

  deleteTeamMemberHard(
    teamMemberId: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.teamMemberUrl}/hard-delete/${teamMemberId}`
    );
  }

  getTeamMembersByProjectId(
    projectId: number
  ): Observable<TeamMemberDto[]> {
    return this.http.get<TeamMemberDto[]>(
      `${this.teamMemberUrl}/project/${projectId}`
    );
  }

  changeScrum(
    projectId: number,
    oldScrumId: number,
    newScrumId: number
  ): Observable<string> {
    return this.http.put(
      `${this.teamMemberUrl}/change-scrum`,
      {},
      {
        params: {
          projectId,
          oldScrumId,
          newScrumId
        },
        responseType: 'text'
      }
    );
  }
}
