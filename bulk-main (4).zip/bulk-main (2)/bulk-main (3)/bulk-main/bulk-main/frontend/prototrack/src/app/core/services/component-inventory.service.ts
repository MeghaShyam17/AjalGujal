// import { Injectable } from '@angular/core';
// import {
//   HttpClient,
//   HttpParams
// } from '@angular/common/http';

// import { Observable } from 'rxjs';

// import {
//   ComponentRequestDto,
//   ComponentRequestResponseDto,
//   ComponentRequestItemResponseDto,
//   ComponentReturnDto,
//   ComponentReturnResponseDto,
//   ComponentReturnItemResponseDto
// } from '../models/component-inventory';

// @Injectable({
//   providedIn: 'root'
// })
// export class ComponentInventoryService {

//   private baseUrl = 'http://localhost:8086/api';

//   private componentRequestUrl =
//     `${this.baseUrl}/component-request`;

//   private componentRequestItemUrl =
//     `${this.baseUrl}/component-request-item`;

//   private componentReturnUrl =
//     `${this.baseUrl}/component-return`;

//   private componentReturnItemUrl =
//     `${this.baseUrl}/component-return-item`;

//   constructor(
//     private http: HttpClient
//   ) {}

//   // =====================================================
//   // COMPONENT REQUEST APIs
//   // =====================================================

//   createComponentRequest(
//     data: ComponentRequestDto
//   ): Observable<ComponentRequestResponseDto> {
//     return this.http.post<ComponentRequestResponseDto>(
//       this.componentRequestUrl,
//       data
//     );
//   }

//   getComponentRequestById(
//     componentRequestId: number
//   ): Observable<ComponentRequestResponseDto> {
//     return this.http.get<ComponentRequestResponseDto>(
//       `${this.componentRequestUrl}/${componentRequestId}`
//     );
//   }

//   getComponentRequests(
//     filters?: {
//       projectId?: number;
//       requestedBy?: number;
//       facultyId?: number;
//       status?: string;
//     }
//   ): Observable<ComponentRequestResponseDto[]> {

//     let params = new HttpParams();

//     if (filters?.projectId !== undefined) {
//       params = params.set(
//         'projectId',
//         filters.projectId.toString()
//       );
//     }

//     if (filters?.requestedBy !== undefined) {
//       params = params.set(
//         'requestedBy',
//         filters.requestedBy.toString()
//       );
//     }

//     if (filters?.facultyId !== undefined) {
//       params = params.set(
//         'facultyId',
//         filters.facultyId.toString()
//       );
//     }

//     if (filters?.status) {
//       params = params.set(
//         'status',
//         filters.status
//       );
//     }

//     return this.http.get<ComponentRequestResponseDto[]>(
//       this.componentRequestUrl,
//       { params }
//     );
//   }

//   getRequestsByProjectId(
//     projectId: number
//   ): Observable<ComponentRequestResponseDto[]> {
//     return this.getComponentRequests({
//       projectId: projectId
//     });
//   }

//   getRequestsByRequestedBy(
//     requestedBy: number
//   ): Observable<ComponentRequestResponseDto[]> {
//     return this.getComponentRequests({
//       requestedBy: requestedBy
//     });
//   }

//   getRequestsByFacultyId(
//     facultyId: number
//   ): Observable<ComponentRequestResponseDto[]> {
//     return this.getComponentRequests({
//       facultyId: facultyId
//     });
//   }

//   getRequestsByStatus(
//     status: string
//   ): Observable<ComponentRequestResponseDto[]> {
//     return this.getComponentRequests({
//       status: status
//     });
//   }

//   approveRequest(
//     componentRequestId: number,
//     approvedBy: number
//   ): Observable<ComponentRequestResponseDto> {
//     return this.http.put<ComponentRequestResponseDto>(
//       `${this.componentRequestUrl}/${componentRequestId}/approve/${approvedBy}`,
//       {}
//     );
//   }

//   rejectRequest(
//     componentRequestId: number,
//     approvedBy: number,
//     remarks: string
//   ): Observable<ComponentRequestResponseDto> {
//     return this.http.put<ComponentRequestResponseDto>(
//       `${this.componentRequestUrl}/${componentRequestId}/reject/${approvedBy}`,
//       {},
//       {
//         params: {
//           remarks: remarks
//         }
//       }
//     );
//   }

//   issueRequest(
//     componentRequestId: number,
//     issuedBy: number
//   ): Observable<ComponentRequestResponseDto> {
//     return this.http.put<ComponentRequestResponseDto>(
//       `${this.componentRequestUrl}/${componentRequestId}/issue/${issuedBy}`,
//       {}
//     );
//   }

//   deleteComponentRequest(
//     componentRequestId: number
//   ): Observable<void> {
//     return this.http.delete<void>(
//       `${this.componentRequestUrl}/${componentRequestId}`
//     );
//   }

//   // =====================================================
//   // COMPONENT REQUEST ITEM APIs
//   // =====================================================

//   getRequestItemById(
//     requestItemId: number
//   ): Observable<ComponentRequestItemResponseDto> {
//     return this.http.get<ComponentRequestItemResponseDto>(
//       `${this.componentRequestItemUrl}/${requestItemId}`
//     );
//   }

//   getRequestItems(
//     filters?: {
//       componentRequestId?: number;
//       itemId?: number;
//       itemStatus?: string;
//       projectId?: number;
//       requestedBy?: number;
//       facultyId?: number;
//     }
//   ): Observable<ComponentRequestItemResponseDto[]> {

//     let params = new HttpParams();

//     if (filters?.componentRequestId !== undefined) {
//       params = params.set(
//         'componentRequestId',
//         filters.componentRequestId.toString()
//       );
//     }

//     if (filters?.itemId !== undefined) {
//       params = params.set(
//         'itemId',
//         filters.itemId.toString()
//       );
//     }

//     if (filters?.itemStatus) {
//       params = params.set(
//         'itemStatus',
//         filters.itemStatus
//       );
//     }

//     if (filters?.projectId !== undefined) {
//       params = params.set(
//         'projectId',
//         filters.projectId.toString()
//       );
//     }

//     if (filters?.requestedBy !== undefined) {
//       params = params.set(
//         'requestedBy',
//         filters.requestedBy.toString()
//       );
//     }

//     if (filters?.facultyId !== undefined) {
//       params = params.set(
//         'facultyId',
//         filters.facultyId.toString()
//       );
//     }

//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       this.componentRequestItemUrl,
//       { params }
//     );
//   }

//   getRequestItemsByComponentRequestId(
//     componentRequestId: number
//   ): Observable<ComponentRequestItemResponseDto[]> {
//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       `${this.componentRequestItemUrl}/request/${componentRequestId}`
//     );
//   }

//   getRequestItemsByItemId(
//     itemId: number
//   ): Observable<ComponentRequestItemResponseDto[]> {
//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       `${this.componentRequestItemUrl}/item/${itemId}`
//     );
//   }

//   getRequestItemsByStatus(
//     itemStatus: string
//   ): Observable<ComponentRequestItemResponseDto[]> {
//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       `${this.componentRequestItemUrl}/status/${itemStatus}`
//     );
//   }

//   getRequestItemsByProjectId(
//     projectId: number
//   ): Observable<ComponentRequestItemResponseDto[]> {
//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       `${this.componentRequestItemUrl}/project/${projectId}`
//     );
//   }

//   getRequestItemsByRequestedBy(
//     requestedBy: number
//   ): Observable<ComponentRequestItemResponseDto[]> {
//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       `${this.componentRequestItemUrl}/requested-by/${requestedBy}`
//     );
//   }

//   getRequestItemsByFacultyId(
//     facultyId: number
//   ): Observable<ComponentRequestItemResponseDto[]> {
//     return this.http.get<ComponentRequestItemResponseDto[]>(
//       `${this.componentRequestItemUrl}/faculty/${facultyId}`
//     );
//   }

//   // =====================================================
//   // COMPONENT RETURN APIs
//   // =====================================================

//   createComponentReturn(
//     data: ComponentReturnDto
//   ): Observable<ComponentReturnResponseDto> {
//     return this.http.post<ComponentReturnResponseDto>(
//       this.componentReturnUrl,
//       data
//     );
//   }

//   getComponentReturnById(
//     componentReturnId: number
//   ): Observable<ComponentReturnResponseDto> {
//     return this.http.get<ComponentReturnResponseDto>(
//       `${this.componentReturnUrl}/${componentReturnId}`
//     );
//   }

//   getComponentReturns(
//     filters?: {
//       projectId?: number;
//       returnedBy?: number;
//       receivedBy?: number;
//       componentRequestId?: number;
//       status?: string;
//     }
//   ): Observable<ComponentReturnResponseDto[]> {

//     let params = new HttpParams();

//     if (filters?.projectId !== undefined) {
//       params = params.set(
//         'projectId',
//         filters.projectId.toString()
//       );
//     }

//     if (filters?.returnedBy !== undefined) {
//       params = params.set(
//         'returnedBy',
//         filters.returnedBy.toString()
//       );
//     }

//     if (filters?.receivedBy !== undefined) {
//       params = params.set(
//         'receivedBy',
//         filters.receivedBy.toString()
//       );
//     }

//     if (filters?.componentRequestId !== undefined) {
//       params = params.set(
//         'componentRequestId',
//         filters.componentRequestId.toString()
//       );
//     }

//     if (filters?.status) {
//       params = params.set(
//         'status',
//         filters.status
//       );
//     }

//     return this.http.get<ComponentReturnResponseDto[]>(
//       this.componentReturnUrl,
//       { params }
//     );
//   }

//   getReturnsByProjectId(
//     projectId: number
//   ): Observable<ComponentReturnResponseDto[]> {
//     return this.getComponentReturns({
//       projectId: projectId
//     });
//   }

//   getReturnsByReturnedBy(
//     returnedBy: number
//   ): Observable<ComponentReturnResponseDto[]> {
//     return this.getComponentReturns({
//       returnedBy: returnedBy
//     });
//   }

//   getReturnsByReceivedBy(
//     receivedBy: number
//   ): Observable<ComponentReturnResponseDto[]> {
//     return this.getComponentReturns({
//       receivedBy: receivedBy
//     });
//   }

//   getReturnsByComponentRequestId(
//     componentRequestId: number
//   ): Observable<ComponentReturnResponseDto[]> {
//     return this.getComponentReturns({
//       componentRequestId: componentRequestId
//     });
//   }

//   getReturnsByStatus(
//     status: string
//   ): Observable<ComponentReturnResponseDto[]> {
//     return this.getComponentReturns({
//       status: status
//     });
//   }

//   receiveReturn(
//     componentReturnId: number,
//     receivedBy: number
//   ): Observable<ComponentReturnResponseDto> {
//     return this.http.put<ComponentReturnResponseDto>(
//       `${this.componentReturnUrl}/${componentReturnId}/receive/${receivedBy}`,
//       {}
//     );
//   }

//   deleteComponentReturn(
//     componentReturnId: number
//   ): Observable<void> {
//     return this.http.delete<void>(
//       `${this.componentReturnUrl}/${componentReturnId}`
//     );
//   }

//   // =====================================================
//   // COMPONENT RETURN ITEM APIs
//   // =====================================================

//   getReturnItemById(
//     returnItemId: number
//   ): Observable<ComponentReturnItemResponseDto> {
//     return this.http.get<ComponentReturnItemResponseDto>(
//       `${this.componentReturnItemUrl}/${returnItemId}`
//     );
//   }

//   getReturnItems(
//     filters?: {
//       componentReturnId?: number;
//       itemId?: number;
//       condition?: string;
//     }
//   ): Observable<ComponentReturnItemResponseDto[]> {

//     let params = new HttpParams();

//     if (filters?.componentReturnId !== undefined) {
//       params = params.set(
//         'componentReturnId',
//         filters.componentReturnId.toString()
//       );
//     }

//     if (filters?.itemId !== undefined) {
//       params = params.set(
//         'itemId',
//         filters.itemId.toString()
//       );
//     }

//     if (filters?.condition) {
//       params = params.set(
//         'condition',
//         filters.condition
//       );
//     }

//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       this.componentReturnItemUrl,
//       { params }
//     );
//   }

//   getReturnItemsByComponentReturnId(
//     componentReturnId: number
//   ): Observable<ComponentReturnItemResponseDto[]> {
//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       `${this.componentReturnItemUrl}/return/${componentReturnId}`
//     );
//   }

//   getReturnItemsByItemId(
//     itemId: number
//   ): Observable<ComponentReturnItemResponseDto[]> {
//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       `${this.componentReturnItemUrl}/item/${itemId}`
//     );
//   }

//   getReturnItemsByCondition(
//     condition: string
//   ): Observable<ComponentReturnItemResponseDto[]> {
//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       `${this.componentReturnItemUrl}/condition/${condition}`
//     );
//   }

//   getDamagedReturnItems(): Observable<ComponentReturnItemResponseDto[]> {
//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       `${this.componentReturnItemUrl}/damaged`
//     );
//   }

//   getConsumedReturnItems(): Observable<ComponentReturnItemResponseDto[]> {
//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       `${this.componentReturnItemUrl}/consumed`
//     );
//   }

//   getInventoryReturnHistory(
//     itemId: number
//   ): Observable<ComponentReturnItemResponseDto[]> {
//     return this.http.get<ComponentReturnItemResponseDto[]>(
//       `${this.componentReturnItemUrl}/history/${itemId}`
//     );
//   }
// }
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';

import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  ComponentRequestDto,
  ComponentRequestResponseDto,
  ComponentRequestItemResponseDto,
  ComponentReturnDto,
  ComponentReturnResponseDto,
  ComponentReturnItemResponseDto
} from '../models/component-inventory';

@Injectable({
  providedIn: 'root'
})
export class ComponentInventoryService {

  private baseUrl = `${environment.apiBaseUrl}/api`;

  private componentRequestUrl =
    `${this.baseUrl}/component-request`;

  private componentRequestItemUrl =
    `${this.baseUrl}/component-request-item`;

  private componentReturnUrl =
    `${this.baseUrl}/component-return`;

  private componentReturnItemUrl =
    `${this.baseUrl}/component-return-item`;

  constructor(
    private http: HttpClient
  ) {}

  // =====================================================
  // COMPONENT REQUEST APIs
  // =====================================================

  createComponentRequest(
    data: ComponentRequestDto
  ): Observable<ComponentRequestResponseDto> {
    return this.http.post<ComponentRequestResponseDto>(
      this.componentRequestUrl,
      data
    );
  }

  getComponentRequestById(
    componentRequestId: number
  ): Observable<ComponentRequestResponseDto> {
    return this.http.get<ComponentRequestResponseDto>(
      `${this.componentRequestUrl}/${componentRequestId}`
    );
  }

  getComponentRequests(
    filters?: {
      projectId?: number;
      requestedBy?: number;
      facultyId?: number;
      status?: string;
    }
  ): Observable<ComponentRequestResponseDto[]> {

    let params = new HttpParams();

    if (filters?.projectId !== undefined) {
      params = params.set(
        'projectId',
        filters.projectId.toString()
      );
    }

    if (filters?.requestedBy !== undefined) {
      params = params.set(
        'requestedBy',
        filters.requestedBy.toString()
      );
    }

    if (filters?.facultyId !== undefined) {
      params = params.set(
        'facultyId',
        filters.facultyId.toString()
      );
    }

    if (filters?.status) {
      params = params.set(
        'status',
        filters.status
      );
    }

    return this.http.get<ComponentRequestResponseDto[]>(
      this.componentRequestUrl,
      { params }
    );
  }

  getRequestsByProjectId(
    projectId: number
  ): Observable<ComponentRequestResponseDto[]> {
    return this.getComponentRequests({
      projectId: projectId
    });
  }

  getRequestsByRequestedBy(
    requestedBy: number
  ): Observable<ComponentRequestResponseDto[]> {
    return this.getComponentRequests({
      requestedBy: requestedBy
    });
  }

  getRequestsByFacultyId(
    facultyId: number
  ): Observable<ComponentRequestResponseDto[]> {
    return this.getComponentRequests({
      facultyId: facultyId
    });
  }

  getRequestsByStatus(
    status: string
  ): Observable<ComponentRequestResponseDto[]> {
    return this.getComponentRequests({
      status: status
    });
  }

  approveRequest(
    componentRequestId: number,
    approvedBy: number
  ): Observable<ComponentRequestResponseDto> {
    return this.http.put<ComponentRequestResponseDto>(
      `${this.componentRequestUrl}/${componentRequestId}/approve/${approvedBy}`,
      {}
    );
  }

  rejectRequest(
    componentRequestId: number,
    approvedBy: number,
    remarks: string
  ): Observable<ComponentRequestResponseDto> {
    return this.http.put<ComponentRequestResponseDto>(
      `${this.componentRequestUrl}/${componentRequestId}/reject/${approvedBy}`,
      {},
      {
        params: {
          remarks: remarks
        }
      }
    );
  }

  issueRequest(
    componentRequestId: number,
    issuedBy: number,
    payload: any[]
  ): Observable<ComponentRequestResponseDto> {
    return this.http.put<ComponentRequestResponseDto>(
      `${this.componentRequestUrl}/${componentRequestId}/issue/${issuedBy}`,
      payload
    );
  }

  deleteComponentRequest(
    componentRequestId: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.componentRequestUrl}/${componentRequestId}`
    );
  }

  // =====================================================
  // COMPONENT REQUEST ITEM APIs
  // =====================================================

  getRequestItemById(
    requestItemId: number
  ): Observable<ComponentRequestItemResponseDto> {
    return this.http.get<ComponentRequestItemResponseDto>(
      `${this.componentRequestItemUrl}/${requestItemId}`
    );
  }

  getRequestItems(
    filters?: {
      componentRequestId?: number;
      itemId?: number;
      itemStatus?: string;
      projectId?: number;
      requestedBy?: number;
      facultyId?: number;
    }
  ): Observable<ComponentRequestItemResponseDto[]> {

    let params = new HttpParams();

    if (filters?.componentRequestId !== undefined) {
      params = params.set(
        'componentRequestId',
        filters.componentRequestId.toString()
      );
    }

    if (filters?.itemId !== undefined) {
      params = params.set(
        'itemId',
        filters.itemId.toString()
      );
    }

    if (filters?.itemStatus) {
      params = params.set(
        'itemStatus',
        filters.itemStatus
      );
    }

    if (filters?.projectId !== undefined) {
      params = params.set(
        'projectId',
        filters.projectId.toString()
      );
    }

    if (filters?.requestedBy !== undefined) {
      params = params.set(
        'requestedBy',
        filters.requestedBy.toString()
      );
    }

    if (filters?.facultyId !== undefined) {
      params = params.set(
        'facultyId',
        filters.facultyId.toString()
      );
    }

    return this.http.get<ComponentRequestItemResponseDto[]>(
      this.componentRequestItemUrl,
      { params }
    );
  }

  getRequestItemsByComponentRequestId(
    componentRequestId: number
  ): Observable<ComponentRequestItemResponseDto[]> {
    return this.http.get<ComponentRequestItemResponseDto[]>(
      `${this.componentRequestItemUrl}/request/${componentRequestId}`
    );
  }

  getRequestItemsByItemId(
    itemId: number
  ): Observable<ComponentRequestItemResponseDto[]> {
    return this.http.get<ComponentRequestItemResponseDto[]>(
      `${this.componentRequestItemUrl}/item/${itemId}`
    );
  }

  getRequestItemsByStatus(
    itemStatus: string
  ): Observable<ComponentRequestItemResponseDto[]> {
    return this.http.get<ComponentRequestItemResponseDto[]>(
      `${this.componentRequestItemUrl}/status/${itemStatus}`
    );
  }

  getRequestItemsByProjectId(
    projectId: number
  ): Observable<ComponentRequestItemResponseDto[]> {
    return this.http.get<ComponentRequestItemResponseDto[]>(
      `${this.componentRequestItemUrl}/project/${projectId}`
    );
  }

  getRequestItemsByRequestedBy(
    requestedBy: number
  ): Observable<ComponentRequestItemResponseDto[]> {
    return this.http.get<ComponentRequestItemResponseDto[]>(
      `${this.componentRequestItemUrl}/requested-by/${requestedBy}`
    );
  }

  getRequestItemsByFacultyId(
    facultyId: number
  ): Observable<ComponentRequestItemResponseDto[]> {
    return this.http.get<ComponentRequestItemResponseDto[]>(
      `${this.componentRequestItemUrl}/faculty/${facultyId}`
    );
  }

  // =====================================================
  // COMPONENT RETURN APIs
  // =====================================================

  createComponentReturn(
    data: ComponentReturnDto
  ): Observable<ComponentReturnResponseDto> {
    return this.http.post<ComponentReturnResponseDto>(
      this.componentReturnUrl,
      data
    );
  }

  getComponentReturnById(
    componentReturnId: number
  ): Observable<ComponentReturnResponseDto> {
    return this.http.get<ComponentReturnResponseDto>(
      `${this.componentReturnUrl}/${componentReturnId}`
    );
  }

  getComponentReturns(
    filters?: {
      projectId?: number;
      returnedBy?: number;
      receivedBy?: number;
      componentRequestId?: number;
      status?: string;
    }
  ): Observable<ComponentReturnResponseDto[]> {

    let params = new HttpParams();

    if (filters?.projectId !== undefined) {
      params = params.set(
        'projectId',
        filters.projectId.toString()
      );
    }

    if (filters?.returnedBy !== undefined) {
      params = params.set(
        'returnedBy',
        filters.returnedBy.toString()
      );
    }

    if (filters?.receivedBy !== undefined) {
      params = params.set(
        'receivedBy',
        filters.receivedBy.toString()
      );
    }

    if (filters?.componentRequestId !== undefined) {
      params = params.set(
        'componentRequestId',
        filters.componentRequestId.toString()
      );
    }

    if (filters?.status) {
      params = params.set(
        'status',
        filters.status
      );
    }

    return this.http.get<ComponentReturnResponseDto[]>(
      this.componentReturnUrl,
      { params }
    );
  }

  getReturnsByProjectId(
    projectId: number
  ): Observable<ComponentReturnResponseDto[]> {
    return this.getComponentReturns({
      projectId: projectId
    });
  }

  getReturnsByReturnedBy(
    returnedBy: number
  ): Observable<ComponentReturnResponseDto[]> {
    return this.getComponentReturns({
      returnedBy: returnedBy
    });
  }

  getReturnsByReceivedBy(
    receivedBy: number
  ): Observable<ComponentReturnResponseDto[]> {
    return this.getComponentReturns({
      receivedBy: receivedBy
    });
  }

  getReturnsByComponentRequestId(
    componentRequestId: number
  ): Observable<ComponentReturnResponseDto[]> {
    return this.getComponentReturns({
      componentRequestId: componentRequestId
    });
  }

  getReturnsByStatus(
    status: string
  ): Observable<ComponentReturnResponseDto[]> {
    return this.getComponentReturns({
      status: status
    });
  }

  receiveReturn(
    componentReturnId: number,
    receivedBy: number
  ): Observable<ComponentReturnResponseDto> {
    return this.http.put<ComponentReturnResponseDto>(
      `${this.componentReturnUrl}/${componentReturnId}/receive/${receivedBy}`,
      {}
    );
  }

  deleteComponentReturn(
    componentReturnId: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.componentReturnUrl}/${componentReturnId}`
    );
  }

  // =====================================================
  // COMPONENT RETURN ITEM APIs
  // =====================================================

  getReturnItemById(
    returnItemId: number
  ): Observable<ComponentReturnItemResponseDto> {
    return this.http.get<ComponentReturnItemResponseDto>(
      `${this.componentReturnItemUrl}/${returnItemId}`
    );
  }

  getReturnItems(
    filters?: {
      componentReturnId?: number;
      itemId?: number;
      condition?: string;
    }
  ): Observable<ComponentReturnItemResponseDto[]> {

    let params = new HttpParams();

    if (filters?.componentReturnId !== undefined) {
      params = params.set(
        'componentReturnId',
        filters.componentReturnId.toString()
      );
    }

    if (filters?.itemId !== undefined) {
      params = params.set(
        'itemId',
        filters.itemId.toString()
      );
    }

    if (filters?.condition) {
      params = params.set(
        'condition',
        filters.condition
      );
    }

    return this.http.get<ComponentReturnItemResponseDto[]>(
      this.componentReturnItemUrl,
      { params }
    );
  }

  getReturnItemsByComponentReturnId(
    componentReturnId: number
  ): Observable<ComponentReturnItemResponseDto[]> {
    return this.http.get<ComponentReturnItemResponseDto[]>(
      `${this.componentReturnItemUrl}/return/${componentReturnId}`
    );
  }

  getReturnItemsByItemId(
    itemId: number
  ): Observable<ComponentReturnItemResponseDto[]> {
    return this.http.get<ComponentReturnItemResponseDto[]>(
      `${this.componentReturnItemUrl}/item/${itemId}`
    );
  }

  getReturnItemsByCondition(
    condition: string
  ): Observable<ComponentReturnItemResponseDto[]> {
    return this.http.get<ComponentReturnItemResponseDto[]>(
      `${this.componentReturnItemUrl}/condition/${condition}`
    );
  }

  getDamagedReturnItems(): Observable<ComponentReturnItemResponseDto[]> {
    return this.http.get<ComponentReturnItemResponseDto[]>(
      `${this.componentReturnItemUrl}/damaged`
    );
  }

  getConsumedReturnItems(): Observable<ComponentReturnItemResponseDto[]> {
    return this.http.get<ComponentReturnItemResponseDto[]>(
      `${this.componentReturnItemUrl}/consumed`
    );
  }

  getInventoryReturnHistory(
    itemId: number
  ): Observable<ComponentReturnItemResponseDto[]> {
    return this.http.get<ComponentReturnItemResponseDto[]>(
      `${this.componentReturnItemUrl}/history/${itemId}`
    );
  }
}
