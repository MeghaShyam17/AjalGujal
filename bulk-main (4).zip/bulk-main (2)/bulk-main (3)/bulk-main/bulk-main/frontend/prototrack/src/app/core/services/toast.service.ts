import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  duration?: number;
}

export interface DialogOptions {
  title: string;
  message: string;
  type?: 'success' | 'error' | 'warning' | 'info' | 'confirm';
  confirmText?: string;
  cancelText?: string;
  resolve?: (value: boolean) => void;
}

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  private toasts$ = new BehaviorSubject<ToastMessage[]>([]);
  private dialog$ = new BehaviorSubject<DialogOptions | null>(null);

  getToasts(): Observable<ToastMessage[]> {
    return this.toasts$.asObservable();
  }

  getDialog(): Observable<DialogOptions | null> {
    return this.dialog$.asObservable();
  }

  show(type: 'success' | 'error' | 'warning' | 'info', message: string, title?: string, duration: number = 4000): void {
    const id = Math.random().toString(36).substring(2, 9);
    const defaultTitles: Record<string, string> = {
      success: 'Success',
      error: 'Error',
      warning: 'Attention',
      info: 'Information'
    };

    const newToast: ToastMessage = {
      id,
      type,
      title: title || defaultTitles[type] || 'Notification',
      message,
      duration
    };

    const current = this.toasts$.value;
    this.toasts$.next([...current, newToast]);

    if (duration > 0) {
      setTimeout(() => {
        this.dismiss(id);
      }, duration);
    }
  }

  showSuccess(message: string, title: string = 'Success'): void {
    this.show('success', message, title);
  }

  showError(message: string, title: string = 'Error'): void {
    this.show('error', message, title, 5000);
  }

  showWarning(message: string, title: string = 'Warning'): void {
    this.show('warning', message, title, 4500);
  }

  showInfo(message: string, title: string = 'Notice'): void {
    this.show('info', message, title);
  }

  dismiss(id: string): void {
    const updated = this.toasts$.value.filter(t => t.id !== id);
    this.toasts$.next(updated);
  }

  /**
   * Unified Modal Alert (replaces browser window.alert)
   */
  alert(message: string, title: string = 'Notification', type: 'success' | 'error' | 'warning' | 'info' = 'info'): Promise<void> {
    return new Promise<void>((resolve) => {
      this.dialog$.next({
        title,
        message,
        type,
        confirmText: 'OK',
        resolve: () => {
          this.closeDialog();
          resolve();
        }
      });
    });
  }

  /**
   * Unified Modal Confirmation (replaces browser window.confirm)
   */
  confirm(message: string, title: string = 'Confirm Action', confirmText: string = 'Confirm', cancelText: string = 'Cancel'): Promise<boolean> {
    return new Promise<boolean>((resolve) => {
      this.dialog$.next({
        title,
        message,
        type: 'confirm',
        confirmText,
        cancelText,
        resolve: (result: boolean) => {
          this.closeDialog();
          resolve(result);
        }
      });
    });
  }

  closeDialog(): void {
    this.dialog$.next(null);
  }
}
