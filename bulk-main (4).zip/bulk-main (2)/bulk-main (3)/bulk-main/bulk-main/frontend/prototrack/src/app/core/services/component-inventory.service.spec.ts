import { TestBed } from '@angular/core/testing';

import { ComponentInventoryService } from './component-inventory.service';

describe('ComponentInventoryService', () => {
  let service: ComponentInventoryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComponentInventoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
