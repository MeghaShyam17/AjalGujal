// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class EnquiryService {

//   private apiUrl = 'http://localhost:8090/api/enquiries';
// // private apiUrl = 'http://localhost:8080/api/enquiries';
//   constructor(private http: HttpClient) { }

//   createEnquiry(data: any): Observable<any> {
//     return this.http.post(this.apiUrl, data);
//   }

//   getAllEnquiries(): Observable<any> {
//     return this.http.get(this.apiUrl);
//   }

//   getEnquiryById(id: number): Observable<any> {
//     return this.http.get(`${this.apiUrl}/${id}`);
//   }

//   getByUserId(userId: number): Observable<any> {
//     return this.http.get(`${this.apiUrl}/user/${userId}`);
//   }

//   getByFacultyId(facultyId: number): Observable<any> {
//     return this.http.get(`${this.apiUrl}/faculty/${facultyId}`);
//   }

//   replyEnquiry(
//     id: number,
//     facultyComment: string
//   ): Observable<any> {

//     return this.http.put(
//       `${this.apiUrl}/${id}/reply?facultyComment=${facultyComment}`,
//       {}
//     );
//   }

//   deleteEnquiry(id: number): Observable<any> {
//     return this.http.delete(`${this.apiUrl}/${id}`);
//   }
// }
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  EnquiryRequest,
  EnquiryResponse
} from '../models/enquiry';

@Injectable({
  providedIn: 'root'
})
export class EnquiryManagementService {

  private apiUrl = `${environment.apiBaseUrl}/api/enquiries`;

  constructor(private http: HttpClient) {}

  /**
   * Create Enquiry
   */
  createEnquiry(
    enquiry: EnquiryRequest
  ): Observable<EnquiryResponse> {
    return this.http.post<EnquiryResponse>(
      this.apiUrl,
      enquiry
    );
  }

  /**
   * Get All Enquiries
   */
  getAllEnquiries(): Observable<EnquiryResponse[]> {
    return this.http.get<EnquiryResponse[]>(
      this.apiUrl
    );
  }

  /**
   * Get Enquiry By Id
   */
  getEnquiryById(
    enquiryId: number
  ): Observable<EnquiryResponse> {
    return this.http.get<EnquiryResponse>(
      `${this.apiUrl}/${enquiryId}`
    );
  }

  /**
   * Get Enquiries By User Id
   */
  getEnquiriesByUserId(
    userId: number
  ): Observable<EnquiryResponse[]> {
    return this.http.get<EnquiryResponse[]>(
      `${this.apiUrl}/user/${userId}`
    );
  }

  /**
   * Get Enquiries By Faculty Id
   */
  getEnquiriesByFacultyId(
    facultyId: number
  ): Observable<EnquiryResponse[]> {
    return this.http.get<EnquiryResponse[]>(
      `${this.apiUrl}/faculty/${facultyId}`
    );
  }

  /**
   * Alias method for faculty enquiry list component
   */
  getByFacultyId(
    facultyId: number
  ): Observable<EnquiryResponse[]> {
    return this.getEnquiriesByFacultyId(facultyId);
  }

  /**
   * Faculty Reply
   */
  facultyReply(
    enquiryId: number,
    facultyComment: string
  ): Observable<EnquiryResponse> {

    const params = new HttpParams()
      .set('facultyComment', facultyComment);

    return this.http.put<EnquiryResponse>(
      `${this.apiUrl}/${enquiryId}/reply`,
      {},
      { params }
    );
  }

  /**
   * Alias method for reply enquiry components
   */
  replyEnquiry(
    enquiryId: number,
    replyContent: string
  ): Observable<EnquiryResponse> {
    return this.facultyReply(
      enquiryId,
      replyContent
    );
  }

  /**
   * Delete Enquiry
   */
  deleteEnquiry(
    enquiryId: number
  ): Observable<string> {
    return this.http.delete(
      `${this.apiUrl}/${enquiryId}`,
      {
        responseType: 'text'
      }
    );
  }
}