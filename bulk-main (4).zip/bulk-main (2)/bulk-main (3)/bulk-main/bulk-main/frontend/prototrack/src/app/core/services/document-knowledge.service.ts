import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  KnowledgeBaseRequest,
  KnowledgeBaseResponse,
  KnowledgeRequestRequest,
  KnowledgeRequestResponse,
  DocumentRequest,
  DocumentResponse
} from '../models/document-knowledge.model';

@Injectable({
  providedIn: 'root'
})
export class DocumentKnowledgeService {

  private baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  // =====================================================
  // KNOWLEDGE BASE
  // =====================================================

  createKnowledgeBase(data: KnowledgeBaseRequest): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/api/knowledge-base`,
      data
    );
  }

  updateKnowledgeBase(
    knowledgeId: number,
    data: KnowledgeBaseRequest
  ): Observable<any> {
    return this.http.put(
      `${this.baseUrl}/api/knowledge-base/${knowledgeId}`,
      data
    );
  }

  getKnowledgeBaseById(
    knowledgeId: number
  ): Observable<KnowledgeBaseResponse> {
    return this.http.get<KnowledgeBaseResponse>(
      `${this.baseUrl}/api/knowledge-base/${knowledgeId}`
    );
  }

  getAllKnowledgeBase(): Observable<KnowledgeBaseResponse[]> {
    return this.http.get<KnowledgeBaseResponse[]>(
      `${this.baseUrl}/api/knowledge-base`
    );
  }

  deleteKnowledgeBase(
    knowledgeId: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.baseUrl}/api/knowledge-base/${knowledgeId}`
    );
  }

  searchByTitle(
    title: string
  ): Observable<KnowledgeBaseResponse[]> {
    return this.http.get<KnowledgeBaseResponse[]>(
      `${this.baseUrl}/api/knowledge-base/title/${title}`
    );
  }

  getKnowledgeByCategory(
    category: string
  ): Observable<KnowledgeBaseResponse[]> {
    return this.http.get<KnowledgeBaseResponse[]>(
      `${this.baseUrl}/api/knowledge-base/category/${category}`
    );
  }

  getKnowledgeByVisibility(
    visibility: string
  ): Observable<KnowledgeBaseResponse[]> {
    return this.http.get<KnowledgeBaseResponse[]>(
      `${this.baseUrl}/api/knowledge-base/visibility/${visibility}`
    );
  }

  getKnowledgeByProjectStage(
    projectStageId: number
  ): Observable<KnowledgeBaseResponse[]> {
    return this.http.get<KnowledgeBaseResponse[]>(
      `${this.baseUrl}/api/knowledge-base/project-stage/${projectStageId}`
    );
  }

  getKnowledgeByPublishedBy(
    publishedBy: number
  ): Observable<KnowledgeBaseResponse[]> {
    return this.http.get<KnowledgeBaseResponse[]>(
      `${this.baseUrl}/api/knowledge-base/published-by/${publishedBy}`
    );
  }

// =====================================================
// KNOWLEDGE REQUEST
// =====================================================

createRequest(
  data: KnowledgeRequestRequest
): Observable<any> {
  return this.http.post(
    `${this.baseUrl}/api/knowledge-requests`,
    data
  );
}

getAllRequests(): Observable<KnowledgeRequestResponse[]> {
  return this.http.get<KnowledgeRequestResponse[]>(
    `${this.baseUrl}/api/knowledge-requests`
  );
}

getRequestById(
  requestId: number
): Observable<KnowledgeRequestResponse> {
  return this.http.get<KnowledgeRequestResponse>(
    `${this.baseUrl}/api/knowledge-requests/${requestId}`
  );
}

deleteRequest(
  requestId: number
): Observable<void> {
  return this.http.delete<void>(
    `${this.baseUrl}/api/knowledge-requests/${requestId}`
  );
}

getRequestsByStudentId(
  studentId: number
): Observable<KnowledgeRequestResponse[]> {
  return this.http.get<KnowledgeRequestResponse[]>(
    `${this.baseUrl}/api/knowledge-requests/student/${studentId}`
  );
}

getRequestsByKnowledgeId(
  knowledgeId: number
): Observable<KnowledgeRequestResponse[]> {
  return this.http.get<KnowledgeRequestResponse[]>(
    `${this.baseUrl}/api/knowledge-requests/knowledge/${knowledgeId}`
  );
}

getRequestsByStatus(
  status: string
): Observable<KnowledgeRequestResponse[]> {
  return this.http.get<KnowledgeRequestResponse[]>(
    `${this.baseUrl}/api/knowledge-requests/status/${status}`
  );
}

approveRequest(
  requestId: number,
  approvedBy: number,
  remarks: string
): Observable<any> {
  return this.http.put(
    `${this.baseUrl}/api/knowledge-requests/${requestId}/approve?approvedBy=${approvedBy}&remarks=${encodeURIComponent(remarks)}`,
    {}
  );
}

rejectRequest(
  requestId: number,
  approvedBy: number,
  remarks: string
): Observable<any> {
  return this.http.put(
    `${this.baseUrl}/api/knowledge-requests/${requestId}/reject?approvedBy=${approvedBy}&remarks=${encodeURIComponent(remarks)}`,
    {}
  );
}
  // =====================================================
  // DOCUMENT
  // =====================================================

  addDocument(
    data: DocumentRequest
  ): Observable<DocumentResponse> {
    return this.http.post<DocumentResponse>(
      `${this.baseUrl}/api/documents`,
      data
    );
  }

  updateDocument(
    documentId: number,
    data: DocumentRequest
  ): Observable<DocumentResponse> {
    return this.http.put<DocumentResponse>(
      `${this.baseUrl}/api/documents/${documentId}`,
      data
    );
  }

  getDocumentById(
    documentId: number
  ): Observable<DocumentResponse> {
    return this.http.get<DocumentResponse>(
      `${this.baseUrl}/api/documents/${documentId}`
    );
  }

  getAllDocuments(): Observable<DocumentResponse[]> {
    return this.http.get<DocumentResponse[]>(
      `${this.baseUrl}/api/documents`
    );
  }

  deleteDocument(
    documentId: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.baseUrl}/api/documents/${documentId}`
    );
  }

  getDocumentsByProjectStage(
    projectStageId: number
  ): Observable<DocumentResponse[]> {
    return this.http.get<DocumentResponse[]>(
      `${this.baseUrl}/api/documents/project-stage/${projectStageId}`
    );
  }

  // =====================================================
  // FACULTY REVIEW
  // =====================================================

  addFacultyReview(data: {
    projectStageId: number;
    facultyId: number;
    documentId?: number;
    reviewStatus: string;
    reviewComment: string;
  }): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/api/faculty-reviews`,
      data
    );
  }

  getReviewsByProjectStage(projectStageId: number): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.baseUrl}/api/faculty-reviews/project-stage/${projectStageId}`
    );
  }
}
