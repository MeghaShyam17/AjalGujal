import { Component, HostListener, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, NavigationEnd, Event as RouterEvent } from '@angular/router';
import { filter } from 'rxjs/operators';

import { NotificationService } from '../../core/services/notification.service';
import { Notification } from '../../core/models/notification';

@Component({
  selector: 'app-senior-faculty-layout',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './senior-faculty-layout.component.html',
  styleUrl: './senior-faculty-layout.component.css'
})
export class SeniorFacultyLayoutComponent implements OnInit {

  userName: string = sessionStorage.getItem('name') || sessionStorage.getItem('userName') || localStorage.getItem('name') || 'Senior Faculty';
  role: string = sessionStorage.getItem('role') || localStorage.getItem('role') || 'Senior Faculty';
  userEmail: string = sessionStorage.getItem('email') || localStorage.getItem('email') || 'seniorfaculty@ilp.edu';
  userPhone: string = sessionStorage.getItem('phone') || localStorage.getItem('phone') || '+91 98765 43210';
  userId: number = Number(sessionStorage.getItem('userId')) || Number(localStorage.getItem('userId')) || 1;

  isSidebarCollapsed: boolean = false;
  isSidebarOpenMobile: boolean = false;

  notifications: Notification[] = [];
  unreadCount: number = 0;
  dropdownOpen: boolean = false;
  notificationLoading: boolean = false;
  showProfilePopup: boolean = false;
  currentTitle: string = 'Dashboard';

  manageTeamOpen: boolean = false;
  manageLabOpen: boolean = false;

  constructor(
    private router: Router,
    @Optional() private notificationService?: NotificationService
  ) {}

  ngOnInit(): void {
    this.updateTitleFromUrl(this.router.url);
    this.router.events.pipe(
      filter((event: RouterEvent): event is NavigationEnd => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.updateTitleFromUrl(event.urlAfterRedirects || event.url);
      this.isSidebarOpenMobile = false;
    });

    this.loadNotifications();
    this.loadUnreadCount();
  }

  updateTitleFromUrl(url: string): void {
    if (url.includes('/senior-dashboard') || url.includes('/dashboard')) {
      this.currentTitle = 'Dashboard';
    } else if (url.includes('/add-profiles')) {
      this.currentTitle = 'Add Profiles';
    } else if (url.includes('/create-team')) {
      this.currentTitle = 'Create Team';
      this.manageTeamOpen = true;
    } else if (url.includes('/edit-team')) {
      this.currentTitle = 'Edit Team';
      this.manageTeamOpen = true;
    } else if (url.includes('/faculty-list')) {
      this.currentTitle = 'Faculty Directory';
    } else if (url.includes('/trainee-list')) {
      this.currentTitle = 'Trainee Directory';
    } else if (url.includes('/inventory')) {
      this.currentTitle = 'Lab Asset Management';
      this.manageLabOpen = true;
    } else if (url.includes('/tools')) {
      this.currentTitle = 'Tools';
      this.manageLabOpen = true;
    } else if (url.includes('/components')) {
      this.currentTitle = 'Components';
      this.manageLabOpen = true;
    } else if (url.includes('/equipment-tracking')) {
      this.currentTitle = 'Equipment Tracking';
      this.manageLabOpen = true;
    } else if (url.includes('/facrequests-status')) {
      this.currentTitle = 'Faculty Escalations';
      this.manageLabOpen = true;
    } else if (url.includes('/project-details')) {
      this.currentTitle = 'Project Details';
    } else if (url.includes('/profile')) {
      this.currentTitle = 'Profile';
    } else {
      this.currentTitle = 'Dashboard';
    }
  }

  toggleSidebar(): void {
    if (window.innerWidth <= 992) {
      this.isSidebarOpenMobile = !this.isSidebarOpenMobile;
    } else {
      this.isSidebarCollapsed = !this.isSidebarCollapsed;
    }
  }

  closeSidebarMobile(): void {
    this.isSidebarOpenMobile = false;
  }

  toggleManageTeam(event?: Event): void {
    event?.stopPropagation();
    this.manageTeamOpen = !this.manageTeamOpen;
  }

  toggleManageLab(event?: Event): void {
    event?.stopPropagation();
    this.manageLabOpen = !this.manageLabOpen;
  }

  openProfilePopup(): void {
    this.showProfilePopup = true;
  }

  closeProfilePopup(): void {
    this.showProfilePopup = false;
  }

  goToFullProfile(): void {
    this.closeProfilePopup();
    this.router.navigate(['/senior-faculty/profile']);
  }

  logout(): void {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch (e) {
      console.warn('Error clearing storage on logout:', e);
    }
    this.router.navigate(['/login']);
  }

  toggleNotificationDropdown(event: MouseEvent): void {
    event.stopPropagation();
    this.dropdownOpen = !this.dropdownOpen;

    if (this.dropdownOpen) {
      this.loadNotifications();
      this.loadUnreadCount();
    }
  }

  loadNotifications(): void {
    if (!this.notificationService) {
      this.loadFallbackNotifications();
      return;
    }
    this.notificationLoading = true;

    this.notificationService
      .getNotificationsByUserId(this.userId)
      .subscribe({
        next: (response) => {
          if (response && response.data && response.data.length > 0) {
            this.notifications = response.data;
          } else {
            this.loadFallbackNotifications();
          }
          this.notificationLoading = false;
        },
        error: () => {
          this.loadFallbackNotifications();
          this.notificationLoading = false;
        }
      });
  }

  private loadFallbackNotifications(): void {
    this.notifications = [
      {
        id: 1,
        userId: this.userId,
        title: 'Project Submission Pending',
        message: 'Team RoboArm has submitted Stage 2 for final approval.',
        notificationType: 'SUBMISSION',
        moduleName: 'PROJECT_STAGE',
        referenceId: '1',
        priority: 'HIGH',
        isRead: false,
        createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        createdBy: 'Student'
      },
      {
        id: 2,
        userId: this.userId,
        title: 'New Faculty Escalation',
        message: 'A component request escalation has been assigned for your review.',
        notificationType: 'APPROVAL',
        moduleName: 'FACULTY_ESCALATION',
        referenceId: '2',
        priority: 'MEDIUM',
        isRead: false,
        createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
        createdBy: 'Faculty'
      },
      {
        id: 3,
        userId: this.userId,
        title: 'Batch Schedule Updated',
        message: 'Batch 2026 milestone deadlines have been updated.',
        notificationType: 'APPROVED',
        moduleName: 'TEAMS',
        referenceId: '3',
        priority: 'LOW',
        isRead: true,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
        createdBy: 'Admin'
      }
    ];
    this.unreadCount = this.notifications.filter(n => !n.isRead).length;
  }

  loadUnreadCount(): void {
    if (!this.notificationService) {
      this.unreadCount = this.notifications.filter(n => !n.isRead).length;
      return;
    }

    this.notificationService
      .getUnreadCount(this.userId)
      .subscribe({
        next: (response) => {
          if (response && typeof response.data === 'number') {
            this.unreadCount = response.data;
          } else {
            this.unreadCount = this.notifications.filter(n => !n.isRead).length;
          }
        },
        error: () => {
          this.unreadCount = this.notifications.filter(n => !n.isRead).length;
        }
      });
  }

  onNotificationClick(notification: Notification): void {
    const notificationId = notification.notificationId || notification.id;

    if (!notification.isRead && notificationId && this.notificationService) {
      this.notificationService
        .markNotificationAsRead(notificationId)
        .subscribe({
          next: () => {
            notification.isRead = true;
            if (this.unreadCount > 0) this.unreadCount--;
            this.navigateByNotification(notification);
          },
          error: () => {
            notification.isRead = true;
            if (this.unreadCount > 0) this.unreadCount--;
            this.navigateByNotification(notification);
          }
        });
    } else {
      notification.isRead = true;
      if (this.unreadCount > 0) this.unreadCount--;
      this.navigateByNotification(notification);
    }

    this.dropdownOpen = false;
  }

  markAllNotificationsRead(event: MouseEvent): void {
    event.stopPropagation();

    const unreadNotifications = this.notifications.filter(n => !n.isRead);
    unreadNotifications.forEach(notification => {
      const notificationId = notification.notificationId || notification.id;
      if (notificationId && this.notificationService) {
        this.notificationService.markNotificationAsRead(notificationId).subscribe();
      }
      notification.isRead = true;
    });

    this.unreadCount = 0;
  }

  getNotificationIcon(notificationType: string): string {
    switch (notificationType) {
      case 'APPROVAL': return 'fa-clipboard-list';
      case 'SUBMISSION': return 'fa-file-lines';
      case 'APPROVED': return 'fa-circle-check';
      case 'REJECTED': return 'fa-circle-xmark';
      case 'ENQUIRY':
      case 'TICKET': return 'fa-ticket';
      case 'COMPONENT':
      case 'INVENTORY': return 'fa-box-open';
      case 'EQUIPMENT': return 'fa-location-dot';
      default: return 'fa-bell';
    }
  }

  getNotificationIconClass(notificationType: string): string {
    switch (notificationType) {
      case 'APPROVAL': return 'type-approval';
      case 'SUBMISSION': return 'type-submit';
      case 'APPROVED': return 'type-approved';
      case 'REJECTED': return 'type-rejected';
      case 'ENQUIRY':
      case 'TICKET': return 'type-ticket';
      case 'COMPONENT':
      case 'INVENTORY': return 'type-component';
      default: return 'type-default';
    }
  }

  getNotificationTimeAgo(createdAt: string): string {
    if (!createdAt) return '';
    const createdTime = new Date(createdAt).getTime();
    const currentTime = new Date().getTime();
    const difference = currentTime - createdTime;
    const minutes = Math.floor(difference / 60000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  }

  navigateByNotification(notification: Notification): void {
    switch (notification.moduleName) {
      case 'TEAMS':
        this.router.navigate(['/senior-faculty/create-team']);
        break;
      case 'PROJECT_STAGE':
        this.router.navigate(['/senior-faculty/project-details']);
        break;
      case 'EQUIPMENT':
        this.router.navigate(['/senior-faculty/equipment-tracking']);
        break;
      case 'INVENTORY':
      case 'COMPONENT_REQUEST':
        this.router.navigate(['/senior-faculty/inventory']);
        break;
      case 'FACULTY_ESCALATION':
        this.router.navigate(['/senior-faculty/facrequests-status']);
        break;
      default:
        this.router.navigate(['/senior-faculty/senior-dashboard']);
        break;
    }
  }

  @HostListener('document:click')
  closeNotificationDropdown(): void {
    this.dropdownOpen = false;
  }
}
