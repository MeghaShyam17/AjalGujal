import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

import { LoginComponent } from './pages/login/login.component';

/* Faculty Imports */
import { FacultyLayoutComponent } from './layouts/faculty-layout/faculty-layout.component';
import { FacultyDashboardComponent } from './pages/faculty/dashboard/faculty-dashboard.component';

import { EnquiryListComponent } from './pages/faculty/enquiries/enquiry-list/enquiry-list.component';
import { ReplyEnquiryComponent } from './pages/faculty/enquiries/reply-enquiry/reply-enquiry.component';
import { FacultyTeamsComponent } from './pages/faculty/teams/faculty-teams.component';
import { ComponentRequestsComponent } from './pages/faculty/component-inventory/component-inventory.component';
import { KnowledgeBaseComponent } from './pages/faculty/knowledge-base/knowledge-base.component';
import { ProfileComponent as FacultyProfileComponent } from './pages/faculty/profile/profile.component';

/* Student Imports */
import { StudentLayoutComponent } from './layouts/student-layout/student-layout.component';

/* Lab Incharge Imports */
import { LabInchargeLayoutComponent } from './layouts/lab-incharge-layout/lab-incharge-layout.component';

import { DashboardComponent as LabInchargeDashboardComponent } from './pages/lab-incharge/dashboard/dashboard.component';
import { InventoryComponent } from './pages/lab-incharge/inventory/inventory.component';

import { LowStockComponent } from './pages/lab-incharge/low-stock/low-stock.component';
import { MaterialReturnsComponent } from './pages/lab-incharge/material-returns/material-returns.component';
import { AssetExceptionsComponent } from './pages/lab-incharge/asset-exceptions/asset-exceptions.component';
import { RequestsStatusComponent } from './pages/lab-incharge/requests-status/requests-status.component';
import { ProfileComponent as LabInchargeProfileComponent } from './pages/lab-incharge/profile/profile.component';
import { EquipmentTrackingComponent } from './pages/lab-incharge/equipment-tracking/equipment-tracking.component';

/* Senior Faculty Imports */
import { SeniorFacultyLayoutComponent } from './layouts/senior-faculty-layout/senior-faculty-layout.component';

import { HomeComponent } from './pages/home/home.component';
import { PolicyComponent } from './pages/policy/policy.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';

/* Admin Imports */
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';

export const routes: Routes = [
  /* Public Routes */
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },

  {
    path: 'home',
    component: HomeComponent
  },

  {
    path: 'login',
    component: LoginComponent
  },

  {
    path: 'forgot-password',
    component: ForgotPasswordComponent
  },

  {
    path: 'change-password',
    loadComponent: () =>
      import('./pages/change-password/change-password.component')
        .then(m => m.ChangePasswordComponent)
  },

  {
    path: 'policy',
    component: PolicyComponent
  },

  /* Admin Routes */
  {
    path: 'admin',
    component: AdminLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/senior-faculty/dashboard/sfdashboard.component')
            .then(m => m.SfdashboardComponent)
      },
      {
        path: 'senior-dashboard',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'project-details',
        loadComponent: () =>
          import('./pages/senior-faculty/project-details/sfproject-details.component')
            .then(m => m.ProjectDetailsComponent)
      },
      {
        path: 'create-team',
        loadComponent: () =>
          import('./pages/senior-faculty/create-team/create-team.component')
            .then(m => m.CreateTeamComponent)
      },
      {
        path: 'add-profiles',
        loadComponent: () =>
          import('./pages/senior-faculty/add-profiles/add-profiles.component')
            .then(m => m.AddProfilesComponent)
      },
      {
        path: 'faculty-list',
        loadComponent: () =>
          import('./pages/senior-faculty/faculty-list/faculty-list.component')
            .then(m => m.FacultyListComponent)
      },
      {
        path: 'trainee-list',
        loadComponent: () =>
          import('./pages/senior-faculty/trainee-list/trainee-list.component')
            .then(m => m.TraineeListComponent)
      },
      {
        path: 'edit-team',
        loadComponent: () =>
          import('./pages/senior-faculty/edit-team/edit-team.component')
            .then(m => m.EditTeamComponent)
      },
      {
        path: 'inventory',
        loadComponent: () =>
          import('./pages/senior-faculty/inventory/inventory.component')
            .then(m => m.InventoryComponent)
      },
      {
        path: 'equipment-tracking',
        loadComponent: () =>
          import('./pages/senior-faculty/equipment-tracking/equipment-tracking.component')
            .then(m => m.EquipmentTrackingComponent)
      },
      {
        path: 'tools',
        loadComponent: () =>
          import('./pages/lab-incharge/tools/tools.component')
            .then(m => m.ToolsManagementComponent)
      },
      {
        path: 'components',
        loadComponent: () =>
          import('./pages/lab-incharge/components/components.component')
            .then(m => m.ComponentsManagementComponent)
      },
      {
        path: 'labrequests-status',
        redirectTo: 'tools',
        pathMatch: 'full'
      },
      {
        path: 'facrequests-status',
        redirectTo: 'components',
        pathMatch: 'full'
      },
      {
        path: 'profile',
        loadComponent: () =>
          import('./pages/senior-faculty/profile/profile.component')
            .then(m => m.ProfileComponent)
      }
    ]
  },

  /* Senior Faculty Routes */
  {
    path: 'senior-faculty',
    component: SeniorFacultyLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: '',
        redirectTo: 'senior-dashboard',
        pathMatch: 'full'
      },
      {
        path: 'senior-dashboard',
        loadComponent: () =>
          import('./pages/senior-faculty/dashboard/sfdashboard.component')
            .then(m => m.SfdashboardComponent)
      },
      {
        path: 'dashboard',
        redirectTo: 'senior-dashboard',
        pathMatch: 'full'
      },
      {
        path: 'project-details',
        loadComponent: () =>
          import('./pages/senior-faculty/project-details/sfproject-details.component')
            .then(m => m.ProjectDetailsComponent)
      },
      {
        path: 'create-team',
        loadComponent: () =>
          import('./pages/senior-faculty/create-team/create-team.component')
            .then(m => m.CreateTeamComponent)
      },
      {
        path: 'add-profiles',
        loadComponent: () =>
          import('./pages/senior-faculty/add-profiles/add-profiles.component')
            .then(m => m.AddProfilesComponent)
      },
      {
        path: 'faculty-list',
        loadComponent: () =>
          import('./pages/senior-faculty/faculty-list/faculty-list.component')
            .then(m => m.FacultyListComponent)
      },
      {
        path: 'trainee-list',
        loadComponent: () =>
          import('./pages/senior-faculty/trainee-list/trainee-list.component')
            .then(m => m.TraineeListComponent)
      },
      {
        path: 'edit-team',
        loadComponent: () =>
          import('./pages/senior-faculty/edit-team/edit-team.component')
            .then(m => m.EditTeamComponent)
      },
      {
        path: 'inventory',
        loadComponent: () =>
          import('./pages/senior-faculty/inventory/inventory.component')
            .then(m => m.InventoryComponent)
      },
      {
        path: 'equipment-tracking',
        loadComponent: () =>
          import('./pages/senior-faculty/equipment-tracking/equipment-tracking.component')
            .then(m => m.EquipmentTrackingComponent)
      },
      {
        path: 'tools',
        loadComponent: () =>
          import('./pages/lab-incharge/tools/tools.component')
            .then(m => m.ToolsManagementComponent)
      },
      {
        path: 'components',
        loadComponent: () =>
          import('./pages/lab-incharge/components/components.component')
            .then(m => m.ComponentsManagementComponent)
      },
      {
        path: 'labrequests-status',
        loadComponent: () =>
          import('./pages/senior-faculty/labrequests-status/requests-status.component')
            .then(m => m.RequestsStatusComponent)
      },
      {
        path: 'facrequests-status',
        loadComponent: () =>
          import('./pages/senior-faculty/facrequests-status/component-inventory.component')
            .then(m => m.ComponentRequestsComponent)
      },
      {
        path: 'profile',
        loadComponent: () =>
          import('./pages/senior-faculty/profile/profile.component')
            .then(m => m.ProfileComponent)
      },
      {
        path: 'stage-master',
        loadComponent: () =>
          import('./pages/senior-faculty/Stage-Master/stage-master.component')
            .then(m => m.StageMasterComponent)
      },
      {
        path: 'batch-master',
        loadComponent: () =>
          import('./pages/senior-faculty/Batch Management/batch-management.component')
            .then(m => m.BatchManagementComponent)
      },
      {
        path: 'stage-configure',
        loadComponent: () =>
          import('./pages/senior-faculty/batch-stage-configuration/batch-stage-configuration.component')
            .then(m => m.BatchStageConfigurationComponent)
      }
    ]
  },

  /* Aliases for Senior routes */
  {
    path: 'senior',
    redirectTo: 'senior-faculty',
    pathMatch: 'prefix'
  },

  /* Faculty Routes */
  {
    path: 'faculty',
    component: FacultyLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        component: FacultyDashboardComponent
      },
      {
        path: 'teams',
        component: FacultyTeamsComponent
      },
      {
        path: 'component-requests',
        component: ComponentRequestsComponent
      },
      {
        path: 'enquiries',
        component: EnquiryListComponent
      },
      {
        path: 'enquiries/:id',
        component: ReplyEnquiryComponent
      },
      {
        path: 'knowledge-base',
        component: KnowledgeBaseComponent
      },
      {
        path: 'profile',
        component: FacultyProfileComponent
      },
      {
        path: 'logs',
        loadComponent: () =>
          import('./pages/faculty/component-logs/component-logs.component')
            .then(m => m.ComponentLogsComponent)
      },
      {
        path: 'component-logs',
        redirectTo: 'logs',
        pathMatch: 'full'
      }
    ]
  },

  /* Student Routes */
  {
    path: 'student',
    component: StudentLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/student/dashboard/dashboard.component')
            .then(m => m.DashboardComponent)
      },
      {
        path: 'profile',
        loadComponent: () =>
          import('./pages/student/profile/profile.component')
            .then(m => m.ProfileComponent)
      },
      {
        path: 'projects/ongoing',
        loadComponent: () =>
          import('./pages/student/ongoing-projects/ongoing-projects.component')
            .then(m => m.OngoingProjectsComponent)
      },
      {
        path: 'projects/completed',
        loadComponent: () =>
          import('./pages/student/completed-projects/completed-projects.component')
            .then(m => m.CompletedProjectsComponent)
      },
      {
        path: 'support',
        loadComponent: () =>
          import('./pages/student/support/support.component')
            .then(m => m.SupportComponent)
      },
      {
        path: 'knowledge',
        loadComponent: () =>
          import('./pages/student/knowledge/knowledge.component')
            .then(m => m.KnowledgeComponent)
      },
  
    ]
  },

  /* Lab Incharge Routes */
  {
    path: 'lab-incharge',
    component: LabInchargeLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        component: LabInchargeDashboardComponent
      },
      {
        path: 'inventory',
        component: InventoryComponent
      },
  
      {
        path: 'tools',
        loadComponent: () =>
          import('./pages/lab-incharge/tools/tools.component')
            .then(m => m.ToolsManagementComponent)
      },
      {
        path: 'components',
        loadComponent: () =>
          import('./pages/lab-incharge/components/components.component')
            .then(m => m.ComponentsManagementComponent)
      },
      {
        path: 'low-stock',
        component: LowStockComponent
      },
      {
        path: 'material-returns',
        component: MaterialReturnsComponent
      },
      {
        path: 'asset-exceptions',
        component: AssetExceptionsComponent
      },
      {
        path: 'requests-status',
        redirectTo: 'tools',
        pathMatch: 'full'
      },
      {
        path: 'tool-requests',
        redirectTo: 'tools',
        pathMatch: 'full'
      },
      {
        path: 'tool-returns',
        redirectTo: 'tools',
        pathMatch: 'full'
      },
      {
        path: 'tool-logs',
        redirectTo: 'tools',
        pathMatch: 'full'
      },
      {
        path: 'component-requests',
        redirectTo: 'components',
        pathMatch: 'full'
      },
      {
        path: 'component-returns',
        redirectTo: 'components',
        pathMatch: 'full'
      },
      {
        path: 'component-logs',
        redirectTo: 'components',
        pathMatch: 'full'
      },
      {
        path: 'profile',
        component: LabInchargeProfileComponent
      },
      {
        path: 'equipment-tracking',
        component: EquipmentTrackingComponent
      }
    ]
  },

  /* 404 Page */
  {
    path: '**',
    component: NotFoundComponent
  }
];