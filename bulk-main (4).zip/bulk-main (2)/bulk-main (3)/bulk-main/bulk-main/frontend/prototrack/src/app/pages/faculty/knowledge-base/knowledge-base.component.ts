import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { DocumentKnowledgeService } from '../../../core/services/document-knowledge.service';
import { ToastService } from '../../../core/services/toast.service';
import {
  KnowledgeBaseRequest,
  KnowledgeBaseResponse,
  KnowledgeRequestResponse
} from '../../../core/models/document-knowledge.model';
import { StorageService } from '../../../core/services/storage.sevice';

type KbTab = 'browse' | 'requests' | 'history';

@Component({
  selector: 'app-knowledge-base',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './knowledge-base.component.html',
  styleUrl: './knowledge-base.component.css'
})
export class KnowledgeBaseComponent implements OnInit {

  // ---- current logged-in faculty (used for approve/reject/publish) ----
  

  // ---- data ----
  documents: KnowledgeBaseResponse[] = [];
  requests: KnowledgeRequestResponse[] = [];

  loadingDocs = false;
  loadingRequests = false;
  errorMsg = '';

  // ---- ui state ----
  activeTab: KbTab = 'browse';

  searchTerm = '';
  filterCategory = 'all';
  filterVisibility = 'all';

  categories = ['Reports', 'Technical', 'Presentations', 'Design'];
  visibilities = ['Public', 'Private', 'Restricted'];

  // ---- add document modal ----
  showAddModal = false;
  saving = false;
  newDoc: KnowledgeBaseRequest = this.emptyDoc();
  facultyId!:number;

  constructor(
    private storage: StorageService,
    private kbService: DocumentKnowledgeService,
    private toastService: ToastService
  ) {}

  ngOnInit(): void {
    this.facultyId = Number(this.storage.get('userId'));
    this.loadAll();
  }

  // =====================================================
  //  LOADING
  // =====================================================

  loadAll(): void {
    this.loadDocuments();
    this.loadRequests();
  }

  loadDocuments(): void {
    this.loadingDocs = true;
    this.errorMsg = '';
    this.kbService.getAllKnowledgeBase().subscribe({
      next: (data) => {
        this.documents = data ?? [];
        this.loadingDocs = false;
      },
      error: (err) => {
        console.error(err);
        this.errorMsg = 'Failed to load repository documents.';
        this.loadingDocs = false;
      }
    });
  }

  loadRequests(): void {
    this.loadingRequests = true;
    this.kbService.getAllRequests().subscribe({
      next: (data) => {
        this.requests = data ?? [];
        this.loadingRequests = false;
      },
      error: (err) => {
        console.error(err);
        this.loadingRequests = false;
      }
    });
  }

  // =====================================================
  //  STATS
  // =====================================================

  get totalDocs(): number {
    return this.documents.length;
  }

  get pendingRequests(): KnowledgeRequestResponse[] {
    return this.requests.filter(
      r => (r.requestStatus || '').toLowerCase() === 'pending'
    );
  }

  get approvedRequests(): KnowledgeRequestResponse[] {
    return this.requests.filter(
      r => (r.requestStatus || '').toLowerCase() === 'approved'
    );
  }

  get historyRequests(): KnowledgeRequestResponse[] {
    return this.requests.filter(
      r => (r.requestStatus || '').toLowerCase() !== 'pending'
    );
  }

  // =====================================================
  //  FILTERING
  // =====================================================

  get filteredDocs(): KnowledgeBaseResponse[] {
    const q = this.searchTerm.trim().toLowerCase();

    return this.documents.filter(doc => {
      const matchesSearch =
        !q ||
        (doc.title || '').toLowerCase().includes(q) ||
        (doc.category || '').toLowerCase().includes(q) ||
        (doc.description || '').toLowerCase().includes(q);

      const matchesCat =
        this.filterCategory === 'all' || doc.category === this.filterCategory;

      const matchesVis =
        this.filterVisibility === 'all' || doc.visibility === this.filterVisibility;

      return matchesSearch && matchesCat && matchesVis;
    });
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.filterCategory = 'all';
    this.filterVisibility = 'all';
  }

  // =====================================================
  //  TABS
  // =====================================================

  setTab(tab: KbTab): void {
    this.activeTab = tab;
  }

  // =====================================================
  //  ADD DOCUMENT (Knowledge Base entry)
  // =====================================================

  private emptyDoc(): KnowledgeBaseRequest {
    return {
      projectStageId: 0,
      documentId: 0,
      title: '',
      category: 'Reports',
      description: '',
      visibility: 'Public',
      publishedBy: this.facultyId
    };
  }

  openAddModal(): void {
    this.newDoc = this.emptyDoc();
    this.showAddModal = true;
  }

  closeAddModal(): void {
    this.showAddModal = false;
  }

  saveDocument(): void {
    if (!this.newDoc.title.trim()) {
      this.toastService.showWarning('Please enter a document title.');
      return;
    }

    this.saving = true;
    this.newDoc.publishedBy = this.facultyId;

    this.kbService.createKnowledgeBase(this.newDoc).subscribe({
      next: () => {
        this.saving = false;
        this.showAddModal = false;
        this.toastService.showSuccess('Document saved to Knowledge Base successfully!');
        this.loadDocuments();
      },
      error: (err) => {
        console.error(err);
        this.saving = false;
        this.toastService.showError('Failed to save document.');
      }
    });
  }

  async deleteDocument(doc: KnowledgeBaseResponse): Promise<void> {
    const confirmed = await this.toastService.confirm(
      `Are you sure you want to delete "${doc.title}"? This cannot be undone.`,
      'Delete Document',
      'Delete',
      'Cancel'
    );

    if (!confirmed) return;

    this.kbService.deleteKnowledgeBase(doc.knowledgeId).subscribe({
      next: () => {
        this.toastService.showSuccess('Document deleted successfully.');
        this.loadDocuments();
      },
      error: (err) => {
        console.error(err);
        this.toastService.showError('Failed to delete document.');
      }
    });
  }

  viewDocument(doc: KnowledgeBaseResponse): void {
    // hook this to your file/preview logic using doc.documentId
    console.log('View document', doc.knowledgeId, doc.documentId);
  }

  // =====================================================
  //  ACCESS REQUESTS
  // =====================================================

  approve(req: KnowledgeRequestResponse): void {
    this.kbService
      .approveRequest(req.requestId, this.facultyId, 'Approved by faculty')
      .subscribe({
        next: () => {
          this.toastService.showSuccess('Access request approved.');
          this.loadRequests();
        },
        error: (err) => {
          console.error(err);
          this.toastService.showError('Failed to approve request.');
        }
      });
  }

  reject(req: KnowledgeRequestResponse): void {
    this.kbService
      .rejectRequest(req.requestId, this.facultyId, 'Rejected by faculty')
      .subscribe({
        next: () => {
          this.toastService.showWarning('Access request rejected.');
          this.loadRequests();
        },
        error: (err) => {
          console.error(err);
          this.toastService.showError('Failed to reject request.');
        }
      });
  }

  statusClass(status: string | undefined): string {
    switch ((status || '').toLowerCase()) {
      case 'approved': return 'status-approved';
      case 'rejected': return 'status-rejected';
      default: return 'status-review';
    }
  }

  trackByDoc = (_: number, d: KnowledgeBaseResponse) => d.knowledgeId;
  trackByReq = (_: number, r: KnowledgeRequestResponse) => r.requestId;
}
