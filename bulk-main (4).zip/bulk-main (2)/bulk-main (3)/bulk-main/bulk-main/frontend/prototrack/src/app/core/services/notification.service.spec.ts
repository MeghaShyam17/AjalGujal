import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

import { NotificationService } from './notification.service';
import { Notification } from '../models/notification';
import { environment } from '../../../environments/environment';

describe('NotificationService', () => {
  let service: NotificationService;
  let httpMock: HttpTestingController;

  const apiUrl = `${environment.apiBaseUrl}/api/notifications`;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        NotificationService
      ]
    });

    service = TestBed.inject(NotificationService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch notifications by user id', () => {
    const mockNotifications: Notification[] = [
      {
        notificationId: 1,
        userId: 1,
        title: 'New Enquiry Received',
        message: 'Team Alpha has raised a new enquiry.',
        notificationType: 'ENQUIRY',
        moduleName: 'ENQUIRY_MANAGEMENT',
        referenceId: 'TCK-001',
        priority: 'HIGH',
        isRead: false,
        createdAt: '2026-08-07T10:00:00',
        createdBy: 'Student Portal'
      }
    ];

    const mockResponse = {
      success: true,
      message: 'Notifications fetched successfully',
      data: mockNotifications
    };

    service.getNotificationsByUserId(1).subscribe(response => {
      expect(response.success).toBeTrue();
      expect(response.data.length).toBe(1);
      expect(response.data[0].title).toBe('New Enquiry Received');
    });

    const req = httpMock.expectOne(`${apiUrl}/user/1`);
    expect(req.request.method).toBe('GET');

    req.flush(mockResponse);
  });

  it('should fetch unread count', () => {
    const mockResponse = {
      success: true,
      message: 'Unread notification count fetched successfully',
      data: 3
    };

    service.getUnreadCount(1).subscribe(response => {
      expect(response.success).toBeTrue();
      expect(response.data).toBe(3);
    });

    const req = httpMock.expectOne(`${apiUrl}/user/1/unread-count`);
    expect(req.request.method).toBe('GET');

    req.flush(mockResponse);
  });

  it('should mark notification as read', () => {
    const mockNotification: Notification = {
      notificationId: 1,
      userId: 1,
      title: 'New Enquiry Received',
      message: 'Team Alpha has raised a new enquiry.',
      notificationType: 'ENQUIRY',
      moduleName: 'ENQUIRY_MANAGEMENT',
      referenceId: 'TCK-001',
      priority: 'HIGH',
      isRead: true,
      createdAt: '2026-08-07T10:00:00',
      readAt: '2026-08-07T10:05:00',
      createdBy: 'Student Portal'
    };

    const mockResponse = {
      success: true,
      message: 'Notification marked as read',
      data: mockNotification
    };

    service.markNotificationAsRead(1).subscribe(response => {
      expect(response.success).toBeTrue();
      expect(response.data.isRead).toBeTrue();
    });

    const req = httpMock.expectOne(`${apiUrl}/read`);
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual({
      notificationId: 1
    });

    req.flush(mockResponse);
  });
});
