export const seedNotifications = [
  {
    id: 'notif-stage-1',
    title: 'Stage 1 approved by mentor',
    message: 'Your mentor has reviewed and approved the Stage 1 submission.',
    time: '2 hours ago',
    icon: 'fa-circle-check',
    iconColor: 'var(--success)',
    iconBg: '#dcfce7',
    unread: true
  },
  {
    id: 'notif-feedback',
    title: 'New feedback on your abstract',
    message: 'Please review the comments shared by your faculty mentor.',
    time: '5 hours ago',
    icon: 'fa-comment-dots',
    iconColor: 'var(--primary)',
    iconBg: '#eef2ff',
    unread: true
  },
  {
    id: 'notif-deadline',
    title: 'Stage 3 deadline in 2 days',
    message: 'Plan ahead so the next submission reaches your mentor on time.',
    time: '1 day ago',
    icon: 'fa-clock',
    iconColor: 'var(--warning)',
    iconBg: '#fef3c7',
    unread: false
  },
  {
    id: 'notif-feedback-2',
    title: 'New Damage Report has been recorded by the Lab Incharge',
    message: 'Please visit the Lab Incharge for further Concerns.',
    time: '5 hours ago',
    icon: 'fa-comment-dots',
    iconColor: 'var(--primary)',
    iconBg: '#eef2ff',
    unread: true
  }
];
