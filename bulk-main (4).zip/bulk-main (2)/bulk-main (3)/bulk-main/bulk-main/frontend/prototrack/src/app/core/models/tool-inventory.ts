export interface ToolRequestItemDto {
  toolRequestId?: number;
  itemId: number;
  requestedQuantity: number;
}

export interface ToolRequestDto {
  projectId: number;
  requestedBy: number;
  expectedReturnDate: string;
  remarks?: string;
  items: ToolRequestItemDto[];
}

export interface ToolRequestItemResponseDto {
  toolRequestItemId: number;
  toolRequestId: number;
  itemId: number;
  requestedQuantity: number;
  approvedQuantity: number;
  issuedQuantity: number;
  itemStatus: string;
}

export interface ToolRequestResponseDto {
  toolRequestId: number;
  projectId: number;
  requestedBy: number;
  requestDate: string;
  expectedReturnDate: string;
  approvalStatus: string;
  approvedBy: number | null;
  approvedOn: string | null;
  issuedBy: number | null;
  issuedOn: string | null;
  remarks: string | null;
  items: ToolRequestItemResponseDto[];
}

export interface ToolReturnItemDto {
  toolReturnId?: number;
  itemId: number;
  returnedQuantity: number;
  damagedQuantity: number;
  lostQuantity: number;
  condition: string;
  status?: string;
  returnedBy?: number;
  verifiedBy?: number;
  remarks?: string;
}

export interface ToolReturnDto {
  toolReturnId?: number;
  toolRequestId: number;
  returnedBy: number;
  receivedBy?: number;
  returnDate?: string;
  returnStatus?: string;
  remarks?: string;
  items: ToolReturnItemDto[];
}
