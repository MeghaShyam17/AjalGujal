import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  RegisterUserRequest,
  ResetPasswordRequest,
  UserResponse,
  Batch,
  Role,
  User
} from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  /*
   * The base URL comes from the active Angular environment file.
   * For local development, environment.apiBaseUrl should normally be:
   * http://localhost:8081
   */
  private readonly baseUrl = environment.apiBaseUrl;

  private readonly userUrl = `${this.baseUrl}/api/users`;
  private readonly roleUrl = `${this.baseUrl}/api/roles`;
  private readonly batchUrl = `${this.baseUrl}/api/batches`;
  private readonly authUrl = `${this.baseUrl}/api/auth`;

  constructor(
    private readonly http: HttpClient
  ) {}

  // ==========================================
  // AUTH
  // ==========================================

  registerUser(
    data: RegisterUserRequest
  ): Observable<string> {
    return this.http.post(
      `${this.authUrl}/register`,
      data,
      {
        responseType: 'text'
      }
    );
  }

  resetPassword(
    userId: number,
    data: ResetPasswordRequest
  ): Observable<string> {
    return this.http.put(
      `${this.authUrl}/reset-password/${userId}`,
      data,
      {
        responseType: 'text'
      }
    );
  }

  changePassword(
    userId: number,
    data: ResetPasswordRequest
  ): Observable<string> {
    return this.http.put(
      `${this.authUrl}/reset-password/${userId}`,
      data,
      {
        responseType: 'text'
      }
    );
  }

  // ==========================================
  // USER
  // ==========================================

  createUser(
    data: User
  ): Observable<UserResponse> {
    return this.http.post<UserResponse>(
      this.userUrl,
      data
    );
  }

  getUserById(
    userId: number
  ): Observable<UserResponse> {
    return this.http.get<UserResponse>(
      `${this.userUrl}/${userId}`
    );
  }

  getAllUsers(): Observable<UserResponse[]> {
    return this.http.get<UserResponse[]>(
      this.userUrl
    );
  }

  updateUser(
    userId: number,
    data: User
  ): Observable<UserResponse> {
    return this.http.put<UserResponse>(
      `${this.userUrl}/${userId}`,
      data
    );
  }

  softDeleteUser(
    userId: number
  ): Observable<string> {
    return this.http.put(
      `${this.userUrl}/soft-delete/${userId}`,
      {},
      {
        responseType: 'text'
      }
    );
  }

  hardDeleteUser(
    userId: number
  ): Observable<string> {
    return this.http.delete(
      `${this.userUrl}/${userId}`,
      {
        responseType: 'text'
      }
    );
  }

  uploadUsersBulk(
    file: File
  ): Observable<string> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post(
      `${this.userUrl}/upload`,
      formData,
      {
        responseType: 'text'
      }
    );
  }

  // ==========================================
  // ROLE
  // ==========================================

  createRole(
    data: Role
  ): Observable<Role> {
    return this.http.post<Role>(
      this.roleUrl,
      data
    );
  }

  getRoleById(
    roleId: number
  ): Observable<Role> {
    return this.http.get<Role>(
      `${this.roleUrl}/${roleId}`
    );
  }

  getAllRoles(): Observable<Role[]> {
    return this.http.get<Role[]>(
      this.roleUrl
    );
  }

  updateRole(
    roleId: number,
    data: Role
  ): Observable<Role> {
    return this.http.put<Role>(
      `${this.roleUrl}/${roleId}`,
      data
    );
  }

  deleteRole(
    roleId: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.roleUrl}/${roleId}`
    );
  }

  // ==========================================
  // BATCH
  // ==========================================

  createBatch(
    data: Batch
  ): Observable<Batch> {
    return this.http.post<Batch>(
      this.batchUrl,
      data
    );
  }

  getBatchById(
    batchId: number
  ): Observable<Batch> {
    return this.http.get<Batch>(
      `${this.batchUrl}/${batchId}`
    );
  }

  getAllBatches(): Observable<Batch[]> {
    return this.http.get<Batch[]>(
      this.batchUrl
    );
  }

  getBatchesByYear(
    year: number
  ): Observable<Batch[]> {
    const params = new HttpParams().set(
      'year',
      String(year)
    );

    return this.http.get<Batch[]>(
      this.batchUrl,
      {
        params
      }
    );
  }

  updateBatch(
    batchId: number,
    data: Batch
  ): Observable<Batch> {
    return this.http.put<Batch>(
      `${this.batchUrl}/${batchId}`,
      data
    );
  }

  deleteBatch(
    batchId: number
  ): Observable<string> {
    return this.http.delete(
      `${this.batchUrl}/${batchId}`,
      {
        responseType: 'text'
      }
    );
  }
}
