export interface Notification {
  notificationId?: number;
  id?: number;

  userId: number;

  title: string;
  message: string;

  notificationType: string;
  moduleName: string;
  referenceId: string;
  priority: string;

  isRead: boolean;

  createdAt: string;
  readAt?: string;

  createdBy: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}