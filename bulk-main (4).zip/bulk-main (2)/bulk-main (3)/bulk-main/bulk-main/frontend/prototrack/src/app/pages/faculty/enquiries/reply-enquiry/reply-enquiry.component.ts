import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

import { EnquiryManagementService } from '../../../../core/services/enquiry.service';
import { EnquiryResponse } from '../../../../core/models/enquiry';

@Component({
  selector: 'app-reply-enquiry',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './reply-enquiry.component.html',
  styleUrl: './reply-enquiry.component.css'
})
export class ReplyEnquiryComponent implements OnInit {

  enquiryId!: number;
  enquiry!: EnquiryResponse;

  replyForm!: FormGroup;

  loading = false;
  submitting = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private enquiryService: EnquiryManagementService
  ) {}

  ngOnInit(): void {
    this.replyForm = this.fb.group({
      facultyComment: ['', Validators.required]
    });

    this.enquiryId = Number(
      this.route.snapshot.paramMap.get('id')
    );

    if (!this.enquiryId) {
      this.errorMessage = 'Invalid enquiry ID.';
      return;
    }

    this.loadEnquiry();
  }

  loadEnquiry(): void {
    this.loading = true;
    this.errorMessage = '';

    this.enquiryService
      .getEnquiryById(this.enquiryId)
      .subscribe({
        next: (response: EnquiryResponse) => {
          this.enquiry = response;

          if (response.facultyComment) {
            this.replyForm.patchValue({
              facultyComment: response.facultyComment
            });
          }

          this.loading = false;
        },
        error: (error: any) => {
          console.error('Failed to load enquiry:', error);
          this.errorMessage = 'Failed to load enquiry.';
          this.loading = false;
        }
      });
  }

  submitReply(): void {
    if (this.replyForm.invalid) {
      this.replyForm.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.errorMessage = '';
    this.successMessage = '';

    const facultyComment: string =
      this.replyForm.value.facultyComment.trim();

    this.enquiryService
      .replyEnquiry(
        this.enquiryId,
        facultyComment
      )
      .subscribe({
        next: (response: EnquiryResponse) => {
          this.enquiry = response;
          this.successMessage = 'Reply sent successfully.';
          this.submitting = false;

          setTimeout(() => {
            this.router.navigate(['/faculty/enquiries']);
          }, 1000);
        },
        error: (error: any) => {
          console.error('Failed to submit reply:', error);
          this.errorMessage = 'Failed to submit reply.';
          this.submitting = false;
        }
      });
  }

  goBack(): void {
    this.router.navigate(['/faculty/enquiries']);
  }
}