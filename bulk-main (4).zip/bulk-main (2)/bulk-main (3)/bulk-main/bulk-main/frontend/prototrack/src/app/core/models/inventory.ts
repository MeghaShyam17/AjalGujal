export interface Inventory {
  itemId?: number;
  itemCode: string;
  itemName: string;
  itemCategory: string;
  make: string;
  specification: string;
  cost: number;
  returnTimeline: string;
  totalQuantity: number;
  availableQuantity: number;
  minimumStock: number;
  unit: string;
  lab: string;
  cupboard: string;
  shelf1: string;
  shelf1Count: number;
  shelf2: string;
  shelf2Count: number;
  purpose: string;
  comments: string;
  itemImage?: string | Blob;
  status: string;
  createdAt: string;
  updatedAt: string;
}

// export interface DamageReport {
//   damageId: number;
//   damageCode: string;
//   projectId: number;
//   itemId: number;
//   equipmentId: number;
//   toolReturnItemId: number;
//   componentReturnItemId: number;
//   reportedBy: number;
//   assignedTo: number;
//   damageType: string;
//   priority: string;
//   ticketStatus: string;
//   damageDescription: string;
//   resolutionNotes: string;
//   verifiedBy: number;
//   verifiedOn: string;
//   resolvedOn: string;
//   closedOn: string;
//   createdAt: string;
//   updatedAt: string;
// }

export interface DamageReport {
  damageId: number;
  damageCode: string;
  projectId: number;

  inventory?: {
    itemId: number;
    itemCode: string;
    itemName: string;
  };

  itemId: number;
  equipmentId: number;
  toolReturnItemId: number;
  componentReturnItemId: number;
  reportedBy: number;
  assignedTo: number;
  damageType: string;
  priority: string;
  ticketStatus: string;
  damageDescription: string;
  resolutionNotes: string;
  verifiedBy: number;
  verifiedOn: string;
  resolvedOn: string;
  closedOn: string;
  createdAt: string;
  updatedAt: string;
}

export interface BulkUploadResponse {
  totalRecords: number;
  successCount: number;
  failureCount: number;
  errors: string[];
}