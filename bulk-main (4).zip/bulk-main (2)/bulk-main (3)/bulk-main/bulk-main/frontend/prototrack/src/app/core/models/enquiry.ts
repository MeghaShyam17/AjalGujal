export interface EnquiryRequest {
  userId: number;
  projectId: number;
  userComment: string;
}

export interface EnquiryResponse {
  enquiryId: number;
  userId: number;
  projectId: number;
  projectName: string | null;
  facultyId: number | null;
  userComment: string;
  facultyComment: string | null;
  enquiryStatus: string;
  createdAt: string | null;
  repliedAt: string | null;
}

export interface FacultyReplyRequest {
  enquiryId: number;
  facultyComment: string;
}