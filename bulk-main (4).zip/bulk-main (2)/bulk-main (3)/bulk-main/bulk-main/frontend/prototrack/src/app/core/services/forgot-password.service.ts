import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface ForgotPasswordRequest {
  email: string;
}

export interface VerifyOtpRequest {
  email: string;
  otp: string;
}

export interface VerifyOtpResponse {
  validationToken: string;
  message: string;
}

export interface ResetPasswordRequest {
  validationToken: string;
  newPassword: string;
}

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  private readonly useMockApi = true;

  private readonly apiUrl = `${environment.apiBaseUrl}/api/auth`;

  constructor(private http: HttpClient) {}

  generateOtp(
    request: ForgotPasswordRequest
  ): Observable<{ message: string }> {

    if (this.useMockApi) {
      return of({
        message: 'OTP sent successfully'
      }).pipe(delay(1000));
    }

    return this.http.post<{ message: string }>(
      this.apiUrl + '/forgot-password',
      request
    );
  }

  verifyOtp(
    request: VerifyOtpRequest
  ): Observable<VerifyOtpResponse> {

    if (this.useMockApi) {
      if (!request.otp || request.otp.length !== 6) {
        return throwError(() => ({
          message: 'Invalid OTP'
        }));
      }

      return of({
        validationToken: 'mock-secure-token-123',
        message: 'OTP verified successfully'
      }).pipe(delay(1000));
    }

    return this.http.post<VerifyOtpResponse>(
      this.apiUrl + '/verify-otp',
      request
    );
  }

  resetPassword(
    request: ResetPasswordRequest
  ): Observable<{ message: string }> {

    if (this.useMockApi) {
      return of({
        message: 'Password reset successfully'
      }).pipe(delay(1000));
    }

    return this.http.post<{ message: string }>(
      this.apiUrl + '/reset-password',
      request
    );
  }
}