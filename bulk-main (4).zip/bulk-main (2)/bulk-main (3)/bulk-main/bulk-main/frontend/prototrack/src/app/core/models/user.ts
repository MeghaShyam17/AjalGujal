export interface RegisterUserRequest {
  userId?: number;
  dob?: string;
  roleId: number;
  batchId?: number;
  name: string;
  phone: string;
  email: string;
  gender: string;
  year?: number;
  password?: string;
}

export interface ResetPasswordRequest {
  oldPassword?: string;
  newPassword?: string;
  confirmPassword?: string;
}

export interface UserResponse {
  userId: number;
  name: string;
  email: string;
  phone: string;
  roleName: string;
  batchName?: string;
  dob?: string;
}
// changed by nithish
export interface Batch {
  batchId: number;
  batchName: string;
  year: number;
  startDate?: string | null;
  endDate?: string | null;
  createdAt?: string;
}

export interface Role {
  roleId: number;
  roleName: string;
}

export interface User {
  userId: number;
  role?: Role;
  batch?: Batch;
  name: string;
  phone: string;
  email: string;
  gender: string;
  year?: number;
  passwordHash?: string;
  profileImage?: string | Blob;
  status: string;
  createdAt?: string;
  updatedAt?: string;
  lastLogin?: string;
}
