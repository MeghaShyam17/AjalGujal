import { HttpInterceptorFn } from '@angular/common/http';
import {inject} from '@angular/core';
import { StorageService } from '../services/storage.sevice';
export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const storage = inject(StorageService);
  const token =
    storage.get('token');
  if (!token) {
    return next(request);
  }

  const authRequest = request.clone({
    setHeaders: {
      Authorization: `Bearer ${token}`
    }
  });

  return next(authRequest);
};