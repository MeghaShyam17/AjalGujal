export interface ProjectTeamDto {
  projectId?: number;
  projectName: string;
  description: string;
  teamLeaderId: number;
  facultyId: number;
  batchId: number;
  year: number;
  projectStartDate: string;
  deadline: string;
  projectStatus: string;
  createdAt?: string;
}

export interface ProjectStageDto {
  projectStageId?: number;
  projectId: number;
  stageId: number;
  versionNo: number;
  submissionStatus: string;
  status?: string;
  submittedBy?: number;
  submittedOn?: string;
  stageDeadline: string;
  reviewedBy?: number;
  reviewedOn?: string;
  currentStage: boolean;
  remarks?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface StageMasterDto {
  stageId?: number;
  stageNo: number;
  stageName: string;
  description: string;
}

export interface TeamMemberDto {
  teamMemberId?: number;
  projectId: number;
  traineeId: number;
  memberRole: string;
  isDeleted?: boolean;
}

/** Matches the Java BulkUploadResult record exactly. */
export interface BulkUploadResult {
  success: boolean;
  projectsInserted: number;
  membersInserted: number;
  message: string;
  generatedProjectIds: Record<string, number>;
}
