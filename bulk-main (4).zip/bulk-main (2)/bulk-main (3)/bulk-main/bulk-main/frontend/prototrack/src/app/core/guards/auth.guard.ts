import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { StorageService } from '../services/storage.sevice';  
export const authGuard: CanActivateFn = () => {
  const router = inject(Router);

  if (
    localStorage.getItem('firstTimeLogin') === 'true' ||
    sessionStorage.getItem('firstTimeLogin') === 'true'
  ) {
    router.navigate(['/change-password']);
    return false;
  }

  const storage = inject(StorageService);
  const token = storage.get('token');
  if (token) {
    return true;
  }
  router.navigate(['/login']);
  return false;
};