import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  ToolRequestDto,
  ToolRequestResponseDto,
  ToolReturnDto,
  ToolReturnItemDto
} from '../models/tool-inventory';

@Injectable({
  providedIn: 'root'
})
export class ToolInventoryService {

  /*
    Use API Gateway URL if 8080 is running:
    http://localhost:8080/api

    If API Gateway is not running, change this to the direct service port.
    Example:
    private baseUrl = 'http://localhost:8081/api';
  */
  private baseUrl = `${environment.apiBaseUrl}/api`;

  private toolRequestUrl = `${this.baseUrl}/tool-requests`;
  private toolRequestItemUrl = `${this.baseUrl}/tool-request-items`;
  private toolReturnUrl = `${this.baseUrl}/tool-returns`;
  private toolReturnItemUrl = `${this.baseUrl}/tool-return-items`;

  constructor(
    private http: HttpClient
  ) {}

  // =====================================================
  // TOOL REQUEST APIs
  // =====================================================

  createToolRequest(
    data: ToolRequestDto
  ): Observable<ToolRequestResponseDto> {
    return this.http.post<ToolRequestResponseDto>(
      this.toolRequestUrl,
      data
    );
  }

  getToolRequestById(
    id: number
  ): Observable<ToolRequestResponseDto> {
    return this.http.get<ToolRequestResponseDto>(
      `${this.toolRequestUrl}/${id}`
    );
  }

  getByToolRequestId(
    id: number
  ): Observable<ToolRequestResponseDto> {
    return this.getToolRequestById(id);
  }

  getToolRequests(
    filters?: {
      projectId?: number;
      requestedBy?: number;
      facultyId?: number;
      status?: string;
    }
  ): Observable<ToolRequestResponseDto[]> {
    if (filters?.projectId !== undefined) {
      return this.http.get<ToolRequestResponseDto[]>(
        `${this.toolRequestUrl}/project/${filters.projectId}`
      );
    }

    if (filters?.requestedBy !== undefined) {
      return this.http.get<ToolRequestResponseDto[]>(
        `${this.toolRequestUrl}/requestedBy/${filters.requestedBy}`
      );
    }

    let params = new HttpParams();

    if (filters?.status) {
      params = params.set(
        'status',
        filters.status
      );
    }

    return this.http.get<ToolRequestResponseDto[]>(
      this.toolRequestUrl,
      {
        params
      }
    );
  }

  approveRequest(
    id: number,
    approvedBy: number
  ): Observable<ToolRequestResponseDto> {
    return this.http.put<ToolRequestResponseDto>(
      `${this.toolRequestUrl}/${id}/approve?approvedBy=${approvedBy}`,
      {}
    );
  }

  rejectRequest(
    id: number,
    approvedBy: number,
    remarks?: string
  ): Observable<ToolRequestResponseDto> {
    return this.http.put<ToolRequestResponseDto>(
      `${this.toolRequestUrl}/${id}/reject?approvedBy=${approvedBy}`,
      {}
    );
  }

  issueRequest(
    id: number,
    issuedBy: number,
    payload: any[]
  ): Observable<ToolRequestResponseDto> {
    return this.http.put<ToolRequestResponseDto>(
      `${this.toolRequestUrl}/${id}/issue?issuedBy=${issuedBy}`,
      payload
    );
  }

  deleteToolRequest(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.toolRequestUrl}/${id}`
    );
  }

  // =====================================================
  // TOOL REQUEST ITEM APIs
  // =====================================================

  createToolRequestItem(
    data: any
  ): Observable<any> {
    return this.http.post<any>(
      this.toolRequestItemUrl,
      data
    );
  }

  getToolRequestItems(): Observable<any[]> {
    return this.http.get<any[]>(
      this.toolRequestItemUrl
    );
  }

  getToolRequestItemById(
    id: number
  ): Observable<any> {
    return this.http.get<any>(
      `${this.toolRequestItemUrl}/${id}`
    );
  }

  updateToolRequestItem(
    id: number,
    data: any
  ): Observable<any> {
    return this.http.put<any>(
      `${this.toolRequestItemUrl}/${id}`,
      data
    );
  }

  deleteToolRequestItem(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.toolRequestItemUrl}/${id}`
    );
  }

  // =====================================================
  // TOOL RETURN APIs
  // =====================================================

  createToolReturn(
    data: ToolReturnDto
  ): Observable<any> {
    return this.http.post<any>(
      this.toolReturnUrl,
      data
    );
  }

  getToolReturnById(
    id: number
  ): Observable<any> {
    return this.http.get<any>(
      `${this.toolReturnUrl}/${id}`
    );
  }

  getToolReturns(
    filters?: {
      projectId?: number;
      returnedBy?: number;
      receivedBy?: number;
      status?: string;
    }
  ): Observable<any[]> {
    if (filters?.projectId !== undefined) {
      return this.http.get<any[]>(
        `${this.toolReturnUrl}/project/${filters.projectId}`
      );
    }

    if (filters?.returnedBy !== undefined) {
      return this.http.get<any[]>(
        `${this.toolReturnUrl}/returnedBy/${filters.returnedBy}`
      );
    }

    if (filters?.status) {
      return this.http.get<any[]>(
        `${this.toolReturnUrl}/status/${filters.status}`
      );
    }

    let params = new HttpParams();

    if (filters?.receivedBy !== undefined) {
      params = params.set(
        'receivedBy',
        filters.receivedBy.toString()
      );
    }

    return this.http.get<any[]>(
      this.toolReturnUrl,
      {
        params
      }
    );
  }

  receiveReturn(
    id: number,
    receivedBy: number
  ): Observable<any> {
    return this.http.put<any>(
      `${this.toolReturnUrl}/${id}/complete?receivedBy=${receivedBy}`,
      {}
    );
  }

  receiveReturnByRequestId(
    requestId: number,
    receivedBy: number
  ): Observable<any> {
    return this.http.put<any>(
      `${this.toolReturnUrl}/request/${requestId}/complete?receivedBy=${receivedBy}`,
      {}
    );
  }

  updateToolReturn(
    id: number,
    data: ToolReturnDto
  ): Observable<any> {
    return this.http.put<any>(
      `${this.toolReturnUrl}/${id}`,
      data
    );
  }

  deleteToolReturn(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.toolReturnUrl}/${id}`
    );
  }

  // =====================================================
  // TOOL RETURN ITEM APIs
  // =====================================================

  createToolReturnItem(
    data: ToolReturnItemDto
  ): Observable<any> {
    return this.http.post<any>(
      this.toolReturnItemUrl,
      data
    );
  }

  getToolReturnItems(): Observable<any[]> {
    return this.http.get<any[]>(
      this.toolReturnItemUrl
    );
  }

  getToolReturnItemById(
    id: number
  ): Observable<any> {
    return this.http.get<any>(
      `${this.toolReturnItemUrl}/${id}`
    );
  }

  updateToolReturnItem(
    id: number,
    data: ToolReturnItemDto
  ): Observable<any> {
    return this.http.put<any>(
      `${this.toolReturnItemUrl}/${id}`,
      data
    );
  }

  deleteToolReturnItem(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.toolReturnItemUrl}/${id}`
    );
  }

}