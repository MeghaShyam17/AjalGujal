// =====================================================
// KNOWLEDGE BASE
// =====================================================

export interface KnowledgeBaseRequest {
  projectStageId: number;
  documentId: number;
  title: string;
  category: string;
  description: string;
  publishedBy: number;
  visibility: string;
}

export interface KnowledgeBaseResponse {
  knowledgeId: number;
  projectStageId: number;
  documentId: number;
  title: string;
  category: string;
  description: string;
  publishedBy: number;
  visibility: string;
  publishedOn: string;
}

// =====================================================
// KNOWLEDGE REQUEST
// =====================================================

export interface KnowledgeRequestRequest {
  knowledgeId: number;
  studentId: number;
  requestReason?: string;
}

export interface KnowledgeRequestResponse {
  requestId: number;
  knowledgeId: number;
  studentId: number;
  requestStatus: string;
  approvedBy?: number;
  approvedOn?: string;
  remarks?: string;
}

// =====================================================
// DOCUMENT
// =====================================================

export interface DocumentRequest {
  projectStageId: number;
  uploadedBy: number;
  versionNo: number;
  documentType: string;
  title: string;
  fileName: string;
  originalFileName: string;
  fileData: string;
  fileSize: number;
  description: string;
}

export interface DocumentResponse {
  documentId: number;
  projectStageId: number;
  uploadedBy: number;
  versionNo: number;
  documentType: string;
  title: string;
  fileName: string;
  originalFileName: string;
  fileSize: number;
  description: string;
  uploadedAt: string;
}