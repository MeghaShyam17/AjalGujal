import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { StorageService } from '../services/storage.sevice';
@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(private router: Router, 
    private storage: StorageService) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
    const token = this.storage.get('token');
    const role = this.storage.get('role');
    
    if (token && role) {
      // Check if route is restricted by role
      const expectedRoles = route.data['roles'] as Array<string>;
      
      if (expectedRoles && expectedRoles.length > 0) {
        // If current user role is not in the expected roles, redirect to unauthorized or home
        if (!expectedRoles.includes(role)) {
          this.router.navigate(['/unauthorized']);
          return false;
        }
      }
      
      return true;
    }

    // Not logged in, redirect to login page with the return url
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
}
