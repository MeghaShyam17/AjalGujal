import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class StorageService {

  /** Write — caller decides persistent (Remember Me) or not */
  set(key: string, value: string, persistent: boolean): void {
    // ensure token lives in ONLY one place
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);

    (persistent ? localStorage : sessionStorage).setItem(key, value);
  }

  update(key:string, value:string):void{
    if(localStorage.getItem('token')!==null){
        localStorage.setItem(key,value);
    }else{
        sessionStorage.setItem(key,value);
    }
  }
  /** Read — checks BOTH automatically */
  get(key: string): string | null {
    return sessionStorage.getItem(key) || localStorage.getItem(key);
  }

  /** Remove from both */
  remove(key: string): void {
    sessionStorage.removeItem(key);
    localStorage.removeItem(key);
  }

  /** Clear everything (logout) */
  clear(): void {
    sessionStorage.clear();
    localStorage.clear();
  }
}