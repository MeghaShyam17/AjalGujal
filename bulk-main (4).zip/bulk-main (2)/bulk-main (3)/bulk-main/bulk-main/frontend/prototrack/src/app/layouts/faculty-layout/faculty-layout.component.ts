import { Component, HostListener, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, NavigationEnd, Event as RouterEvent } from '@angular/router';
import { filter } from 'rxjs/operators';

import { NotificationService } from '../../core/services/notification.service';
import { Notification } from '../../core/models/notification';

@Component({
  selector: 'app-faculty-layout',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './faculty-layout.component.html',
  styleUrl: './faculty-layout.component.css'
})
export class FacultyLayoutComponent implements OnInit {

  userName: string = sessionStorage.getItem('name') || sessionStorage.getItem('userName') || localStorage.getItem('name') || 'Faculty';
  role: string = sessionStorage.getItem('role') || localStorage.getItem('role') || 'Technical Faculty';
  userEmail: string = sessionStorage.getItem('email') || localStorage.getItem('email') || 'faculty@ilp.edu';
  userPhone: string = sessionStorage.getItem('phone') || localStorage.getItem('phone') || '+91 98765 43210';
  userId: number = Number(sessionStorage.getItem('userId')) || Number(localStorage.getItem('userId')) || 1;

  isSidebarCollapsed: boolean = false;
  isSidebarOpenMobile: boolean = false;

  notifications: Notification[] = [];
  unreadCount: number = 0;
  dropdownOpen: boolean = false;
  notificationLoading: boolean = false;
  showProfilePopup: boolean = false;
  currentTitle: string = 'Dashboard';

  constructor(
    private router: Router,
    @Optional() private notificationService?: NotificationService
  ) {}

  ngOnInit(): void {
    this.updateTitleFromUrl(this.router.url);
    this.router.events.pipe(
      filter((event: RouterEvent): event is NavigationEnd => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.updateTitleFromUrl(event.urlAfterRedirects || event.url);
      this.isSidebarOpenMobile = false;
    });

    this.loadNotifications();
    this.loadUnreadCount();
  }

  updateTitleFromUrl(url: string): void {
    if (url.includes('/dashboard')) this.currentTitle = 'Dashboard';
    else if (url.includes('/teams')) this.currentTitle = 'My Teams';
    else if (url.includes('/component-requests')) this.currentTitle = 'Component Request';
    else if (url.includes('/logs') || url.includes('/component-logs')) this.currentTitle = 'Component Logs';
    else if (url.includes('/enquiries')) this.currentTitle = 'Enquiry';
    else if (url.includes('/knowledge-base')) this.currentTitle = 'Knowledge Base';
    else if (url.includes('/profile')) this.currentTitle = 'Profile';
    else this.currentTitle = 'Dashboard';
  }

  toggleSidebar(): void {
    if (window.innerWidth <= 992) {
      this.isSidebarOpenMobile = !this.isSidebarOpenMobile;
    } else {
      this.isSidebarCollapsed = !this.isSidebarCollapsed;
    }
  }

  closeSidebarMobile(): void {
    this.isSidebarOpenMobile = false;
  }

  openProfilePopup(): void {
    this.showProfilePopup = true;
  }

  closeProfilePopup(): void {
    this.showProfilePopup = false;
  }

  goToFullProfile(): void {
    this.closeProfilePopup();
    this.router.navigate(['/faculty/profile']);
  }

  logout(): void {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch (e) {
      console.warn('Error clearing storage on logout:', e);
    }
    this.router.navigate(['/login']);
  }

  toggleNotificationDropdown(event: MouseEvent): void {
    event.stopPropagation();
    this.dropdownOpen = !this.dropdownOpen;

    if (this.dropdownOpen) {
      this.loadNotifications();
      this.loadUnreadCount();
    }
  }

  loadNotifications(): void {
    if (!this.notificationService) {
      this.loadFallbackNotifications();
      return;
    }
    this.notificationLoading = true;

    this.notificationService
      .getNotificationsByUserId(this.userId)
      .subscribe({
        next: (response) => {
          if (response && response.data && response.data.length > 0) {
            this.notifications = response.data;
          } else {
            this.loadFallbackNotifications();
          }
          this.notificationLoading = false;
        },
        error: () => {
          this.loadFallbackNotifications();
          this.notificationLoading = false;
        }
      });
  }

  private loadFallbackNotifications(): void {
    this.notifications = [
      {
        id: 1,
        userId: this.userId,
        title: 'New Student Enquiry',
        message: 'A student has submitted an enquiry regarding Stage 2 documentation.',
        notificationType: 'ENQUIRY',
        moduleName: 'ENQUIRY_MANAGEMENT',
        referenceId: '1',
        priority: 'HIGH',
        isRead: false,
        createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        createdBy: 'Student'
      },
      {
        id: 2,
        userId: this.userId,
        title: 'Component Endorsement Required',
        message: 'Team CyberIoT requested 4x ESP32 modules awaiting your approval.',
        notificationType: 'COMPONENT',
        moduleName: 'COMPONENT_REQUEST',
        referenceId: '2',
        priority: 'HIGH',
        isRead: false,
        createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
        createdBy: 'Student'
      },
      {
        id: 3,
        userId: this.userId,
        title: 'Knowledge Base Published',
        message: 'Your guide "PCB Rapid Milling Checklist" is now live.',
        notificationType: 'APPROVED',
        moduleName: 'KNOWLEDGE_BASE',
        referenceId: '3',
        priority: 'LOW',
        isRead: true,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        createdBy: 'System'
      }
    ];
    this.unreadCount = this.notifications.filter(n => !n.isRead).length;
  }

  loadUnreadCount(): void {
    if (!this.notificationService) {
      this.unreadCount = this.notifications.filter(n => !n.isRead).length;
      return;
    }

    this.notificationService
      .getUnreadCount(this.userId)
      .subscribe({
        next: (response) => {
          if (response && typeof response.data === 'number') {
            this.unreadCount = response.data;
          } else {
            this.unreadCount = this.notifications.filter(n => !n.isRead).length;
          }
        },
        error: () => {
          this.unreadCount = this.notifications.filter(n => !n.isRead).length;
        }
      });
  }

  onNotificationClick(notification: Notification): void {
    const notificationId = notification.notificationId || notification.id;

    if (!notification.isRead && notificationId && this.notificationService) {
      this.notificationService
        .markNotificationAsRead(notificationId)
        .subscribe({
          next: () => {
            notification.isRead = true;
            if (this.unreadCount > 0) this.unreadCount--;
            this.navigateByNotification(notification);
          },
          error: () => {
            notification.isRead = true;
            if (this.unreadCount > 0) this.unreadCount--;
            this.navigateByNotification(notification);
          }
        });
    } else {
      notification.isRead = true;
      if (this.unreadCount > 0) this.unreadCount--;
      this.navigateByNotification(notification);
    }

    this.dropdownOpen = false;
  }

  markAllNotificationsRead(event: MouseEvent): void {
    event.stopPropagation();

    const unreadNotifications = this.notifications.filter(n => !n.isRead);
    unreadNotifications.forEach(notification => {
      const notificationId = notification.notificationId || notification.id;
      if (notificationId && this.notificationService) {
        this.notificationService.markNotificationAsRead(notificationId).subscribe();
      }
      notification.isRead = true;
    });

    this.unreadCount = 0;
  }

  getNotificationIcon(notificationType: string): string {
    switch (notificationType) {
      case 'APPROVAL': return 'fa-clipboard-list';
      case 'SUBMISSION': return 'fa-file-lines';
      case 'APPROVED': return 'fa-circle-check';
      case 'REJECTED': return 'fa-circle-xmark';
      case 'ENQUIRY':
      case 'TICKET': return 'fa-ticket';
      case 'COMPONENT':
      case 'INVENTORY': return 'fa-box-open';
      default: return 'fa-bell';
    }
  }

  getNotificationIconClass(notificationType: string): string {
    switch (notificationType) {
      case 'APPROVAL': return 'type-approval';
      case 'SUBMISSION': return 'type-submit';
      case 'APPROVED': return 'type-approved';
      case 'REJECTED': return 'type-rejected';
      case 'ENQUIRY':
      case 'TICKET': return 'type-ticket';
      case 'COMPONENT':
      case 'INVENTORY': return 'type-component';
      default: return 'type-default';
    }
  }

  getNotificationTimeAgo(createdAt: string): string {
    if (!createdAt) return '';
    const createdTime = new Date(createdAt).getTime();
    const currentTime = new Date().getTime();
    const difference = currentTime - createdTime;
    const minutes = Math.floor(difference / 60000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  }

  navigateByNotification(notification: Notification): void {
    switch (notification.moduleName) {
      case 'ENQUIRY_MANAGEMENT':
      case 'TICKET_MANAGEMENT':
        this.router.navigate(['/faculty/enquiries']);
        break;
      case 'COMPONENT_REQUEST':
        this.router.navigate(['/faculty/component-requests']);
        break;
      case 'TEAMS':
        this.router.navigate(['/faculty/teams']);
        break;
      case 'KNOWLEDGE_BASE':
        this.router.navigate(['/faculty/knowledge-base']);
        break;
      default:
        this.router.navigate(['/faculty/dashboard']);
        break;
    }
  }

  @HostListener('document:click')
  closeNotificationDropdown(): void {
    this.dropdownOpen = false;
  }
}