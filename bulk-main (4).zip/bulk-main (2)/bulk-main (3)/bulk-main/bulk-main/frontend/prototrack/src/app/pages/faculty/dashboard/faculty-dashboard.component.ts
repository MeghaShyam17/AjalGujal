import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

import { FacultyService } from '../../../core/services/faculty.service';
import { UserService } from '../../../core/services/user.service';
import {
  DashboardProjectView,
  DashboardStats,
  FacultyTeamView
} from '../../../core/models/faculty';
import { StorageService } from '../../../core/services/storage.sevice';


export interface BatchSummary {
  batchName: string;
  count: number;
}

@Component({
  selector: 'app-faculty-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './faculty-dashboard.component.html',
  styleUrl: './faculty-dashboard.component.css'
})
export class FacultyDashboardComponent implements OnInit {

  stats: DashboardStats = {
    totalTeams: 0,
    approvedCount: 0,
    pendingCount: 0,
    rejectedCount: 0
  };

  projects: DashboardProjectView[] = [];
  teams: FacultyTeamView[] = [];
  batches: BatchSummary[] = [];
  batchesMap = new Map<number, string>();
  totalBatches = 0;

  loading = false;
  errorMessage = '';
  facultyId!:number;

  

  constructor(
    private storage: StorageService,
    private facultyService: FacultyService,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.facultyId =
    Number(this.storage.get('userId'));

    this.userService.getAllBatches().subscribe({
      next: (batches: any[]) => {
        (batches || []).forEach(b => this.batchesMap.set(b.batchId, b.batchName));
      },
      error: err => console.warn('Failed to load batches for lookup:', err)
    });

    this.loadDashboard();
  }

  loadDashboard(): void {
    this.loading = true;
    this.errorMessage = '';

    this.facultyService.getFacultyTeams(this.facultyId).subscribe({
      next: (teams) => {
        this.teams = teams || [];
        this.computeBatches(this.teams);
        this.loadStats(this.teams);
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to load teams for dashboard:', err);
        this.errorMessage = 'Unable to load dashboard data from backend.';
        this.teams = [];
        this.batches = [];
        this.totalBatches = 0;
        this.loading = false;
      }
    });
  }

  computeBatches(teams: FacultyTeamView[]): void {
    const batchMap = new Map<string, number>();
    teams.forEach(t => {
      const batchName = this.getBatchName(t.project?.batchId);
      batchMap.set(batchName, (batchMap.get(batchName) || 0) + 1);
    });

    this.batches = Array.from(batchMap.entries()).map(([batchName, count]) => ({
      batchName,
      count
    }));
    this.totalBatches = this.batches.length;
  }

  loadStats(teams: FacultyTeamView[]): void {
    let approved = 0;
    let pending = 0;
    let rejected = 0;

    teams.forEach(t => {
      (t.stages || []).forEach(s => {
        const st = (s.submissionStatus || '').toUpperCase();
        if (st === 'APPROVED') approved++;
        else if (st === 'SUBMITTED' || st === 'IN_PROGRESS' || st === 'PENDING') pending++;
        else if (st === 'REJECTED' || st === 'REWORK_REQUIRED') rejected++;
      });
    });

    this.stats = {
      totalTeams: teams.length,
      approvedCount: approved,
      pendingCount: pending,
      rejectedCount: rejected
    };
  }

  getBatchName(batchId?: number): string {
    if (!batchId) return 'Not Assigned';
    return this.batchesMap.get(batchId) || `Batch ${batchId}`;
  }


  goToPage(route: string): void {
    this.router.navigate([route]);
  }

  viewProject(team: FacultyTeamView): void {
    this.router.navigate(['/faculty/teams'], {
      queryParams: {
        projectId: team.project?.projectId
      }
    });
  }
}