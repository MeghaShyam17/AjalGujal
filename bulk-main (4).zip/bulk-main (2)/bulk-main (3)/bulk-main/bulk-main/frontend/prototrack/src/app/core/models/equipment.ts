export interface EquipmentBookingRequestDto {
  equipmentId: number;
  projectId: number;
  requestedBy: number;
  bookingDate: string;
  fromTime: string;
  toTime: string;
  purpose: string;
  remarks?: string;
}

export interface EquipmentBookingResponseDto {
  bookingId: number;
  equipmentId: number;
  assetCode: string;
  projectId: number;
  requestedBy: number;
  bookingDate: string;
  fromTime: string;
  toTime: string;
  purpose: string;
  approvalStatus: string;
  approvedBy?: number;
  approvedOn?: string;
  remarks?: string;
  createdAt: string;
}

export interface EquipmentMaintenanceRequestDto {
  equipmentId: number;
  maintenanceType: string;
  maintenanceReason: string;
  maintenanceStatus: string;
  startDate: string;
  endDate: string;
  maintainedBy: number;
  remarks?: string;
}

export interface EquipmentMaintenanceResponseDto {
  maintenanceId: number;
  equipmentId: number;
  assetCode: string;
  maintenanceType: string;
  maintenanceReason: string;
  maintenanceStatus: string;
  startDate: string;
  endDate: string;
  maintainedBy: number;
  remarks?: string;
  createdAt: string;
}

export interface EquipmentRequestDto {
  equipmentMasterId?: number;
  assetCode: string;
  serialNumber: string;
  bookingStatus: string;
  maintenanceStatus: string;
  location: string;
  purchaseDate: string;
  remarks?: string;
}

export interface EquipmentResponseDto {
  equipmentId: number;
  equipmentMasterId: number;
  equipmentCode: string;
  equipmentName: string;
  assetCode: string;
  serialNumber: string;
  bookingStatus: string;
  maintenanceStatus: string;
  location: string;
  purchaseDate: string;
  remarks?: string;
  createdAt: string;
}

export interface EquipmentMasterRequestDto {
  equipmentCode: string;
  equipmentName: string;
  equipmentType: string;
  make: string;
  specification: string;
  totalQuantity: number;
  lab: string;
  cost: number;
  remarks?: string;
  status: string;
  equipmentImage?: string | Blob;
  equipments: EquipmentRequestDto[];
}

export interface EquipmentMasterResponseDto {
  equipmentMasterId: number;
  equipmentCode: string;
  equipmentName: string;
  equipmentType: string;
  make: string;
  specification: string;
  totalQuantity: number;
  lab: string;
  cost: number;
  remarks?: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  equipmentImage?: string | Blob;
  equipments: EquipmentResponseDto[];
}
