import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  Notification,
  ApiResponse
} from '../models/notification';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private readonly apiUrl = `${environment.apiBaseUrl}/api/notifications`;

  constructor(private http: HttpClient) {}

  getNotificationsByUserId(
    userId: number
  ): Observable<ApiResponse<Notification[]>> {
    return this.http.get<ApiResponse<Notification[]>>(
      `${this.apiUrl}/user/${userId}`
    );
  }

  getUnreadNotifications(
    userId: number
  ): Observable<ApiResponse<Notification[]>> {
    return this.http.get<ApiResponse<Notification[]>>(
      `${this.apiUrl}/user/${userId}/unread`
    );
  }

  getUnreadCount(
    userId: number
  ): Observable<ApiResponse<number>> {
    return this.http.get<ApiResponse<number>>(
      `${this.apiUrl}/user/${userId}/unread-count`
    );
  }

  markNotificationAsRead(
    notificationId: number
  ): Observable<ApiResponse<Notification>> {
    return this.http.put<ApiResponse<Notification>>(
      `${this.apiUrl}/read`,
      {
        notificationId: notificationId
      }
    );
  }
}
