export interface TeamMember {
  teamMemberId: number;
  projectId: number;
  traineeId: number;
  memberRole: string;
  isDeleted?: boolean;
}

export interface ProjectTeam {
  projectId: number;
  projectName: string;
  description: string;
  teamLeaderId: number;
  facultyId: number;
  batchId: number;
  year: number;
  deadline: string;
  projectStatus: string;
  createdAt: string;
  isDeleted?: boolean;
  teamMembers?: TeamMember[];
}

export interface StageMaster {
  stageId: number;
  stageNo: number;
  stageName: string;
  description: string;
}

export interface ProjectStage {
  projectStageId: number;
  projectId: number;
  stageMaster: StageMaster;
  versionNo: number;
  submissionStatus: string;
  submittedBy: number;
  submittedOn: string;
  stageDeadline: string;
  reviewedBy: number;
  reviewedOn: string;
  currentStage: boolean;
  isOverdue: boolean;
  isAcknowledged: boolean;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardStats {
  totalTeams: number;
  approvedCount: number;
  pendingCount: number;
  rejectedCount: number;
}

export interface DashboardProjectView {
  projectId: number;
  projectName: string;
  projectStatus: string;
  deadline: string;
  progress: number;
  studentUnlockedStage: number;
  currentStageName: string;
}

export interface DocumentResponse {
  documentId: number;
  projectStageId: number;
  uploadedBy: number;
  versionNo: number;
  documentType: string;
  title: string;
  fileName: string;
  originalFileName: string;
  fileSize: number;
  description: string;
  uploadedAt: string;
}

export interface DocumentRequest {
  projectStageId: number;
  uploadedBy: number;
  versionNo: number;
  documentType: string;
  title: string;
  fileName: string;
  originalFileName: string;
  fileSize: number;
  fileData: string;
  description: string;
}

export interface FacultyReviewRequest {
  projectStageId: number;
  facultyId: number;
  documentId: number;
  reviewStatus: string;
  reviewComment: string;
  reviewedOn: string;
}

export interface FacultyReviewResponse {
  reviewId: number;
  projectStageId: number;
  facultyId: number;
  documentId: number;
  reviewStatus: string;
  reviewComment: string;
  reviewedOn: string;
}

export interface ReviewActionPayload {
  stage: ProjectStage;
  facultyId: number;
  documentId: number;
  status: string;
  comment: string;
}

export interface StageReviewView {
  stage: ProjectStage;
  documents: DocumentResponse[];
  reviews: FacultyReviewResponse[];
  latestDocument: DocumentResponse | null;
  latestReview: FacultyReviewResponse | null;
}

export interface FacultyTeamView {
  project: ProjectTeam;
  stages: ProjectStage[];
  members: TeamMember[];
  progress: number;
  currentStageName: string;
  studentUnlockedStage: number;
  facultyName?: string;
}
