import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LabInchargeLayoutComponent } from './lab-incharge-layout.component';

describe('LabInchargeLayoutComponent', () => {
  let component: LabInchargeLayoutComponent;
  let fixture: ComponentFixture<LabInchargeLayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LabInchargeLayoutComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LabInchargeLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
