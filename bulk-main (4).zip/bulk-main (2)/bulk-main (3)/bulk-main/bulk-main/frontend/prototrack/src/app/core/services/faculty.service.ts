import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, map, Observable, switchMap } from 'rxjs';
import { ProjectService } from './project.service';
import { environment } from '../../../environments/environment';

import {
  DashboardProjectView,
  DashboardStats,
  DocumentResponse,
  FacultyReviewRequest,
  FacultyReviewResponse,
  FacultyTeamView,
  ProjectStage,
  ProjectTeam,
  ReviewActionPayload,
  TeamMember
} from '../models/faculty';

@Injectable({
  providedIn: 'root'
})
export class FacultyService {

  private readonly documentBaseUrl = `${environment.apiBaseUrl}/api/documents`;
  private readonly facultyReviewBaseUrl = `${environment.apiBaseUrl}/api/faculty-reviews`;

  constructor(
    private http: HttpClient,
    private projectService: ProjectService
  ) {}

  // ==========================================
  // SHARED BASE (Using ProjectService)
  // ==========================================

  getProjectsByFacultyId(facultyId: number): Observable<ProjectTeam[]> {
    return this.projectService.getProjectsByFacultyId(facultyId) as unknown as Observable<ProjectTeam[]>;
  }

  getAllProjectStages(): Observable<ProjectStage[]> {
    return this.projectService.getAllProjectStages() as unknown as Observable<ProjectStage[]>;
  }

  getProjectStageById(projectStageId: number): Observable<ProjectStage> {
    return this.projectService.getProjectStageById(projectStageId) as unknown as Observable<ProjectStage>;
  }

  updateProjectStage(stage: ProjectStage): Observable<ProjectStage> {
    return this.projectService.updateProjectStage(stage.projectStageId, stage as any) as unknown as Observable<ProjectStage>;
  }

  getAllTeamMembers(): Observable<TeamMember[]> {
    return this.projectService.getAllTeamMembers() as unknown as Observable<TeamMember[]>;
  }
  
  changeScrum(projectId: number, oldScrumId: number, newScrumId: number): Observable<string> {
    return this.projectService.changeScrum(projectId, oldScrumId, newScrumId);
  }

  // ==========================================
  // DASHBOARD LOGIC
  // ==========================================

  getFacultyDashboard(facultyId: number): Observable<{
    stats: DashboardStats;
    projects: DashboardProjectView[];
  }> {
    return forkJoin({
      projects: this.getProjectsByFacultyId(facultyId),
      stages: this.getAllProjectStages()
    }).pipe(
      map(({ projects, stages }) => {
        const activeProjects = projects.filter(project => project.isDeleted !== true);
        const facultyProjectIds = activeProjects.map(project => project.projectId);
        const facultyStages = stages.filter(stage => facultyProjectIds.includes(stage.projectId));

        const dashboardProjects: DashboardProjectView[] = activeProjects.map(project => {
          const projectStages = facultyStages.filter(stage => stage.projectId === project.projectId);
          return {
            projectId: project.projectId,
            projectName: project.projectName,
            projectStatus: project.projectStatus,
            deadline: project.deadline,
            progress: this.calculateProgress(projectStages),
            studentUnlockedStage: this.calculateStudentUnlockedStage(projectStages),
            currentStageName: this.getCurrentStageName(projectStages)
          };
        });

        return {
          stats: this.calculateStats(activeProjects, facultyStages),
          projects: dashboardProjects
        };
      })
    );
  }

  private calculateStats(projects: ProjectTeam[], stages: ProjectStage[]): DashboardStats {
    const approvedCount = stages.filter(stage => this.normalizeStatus(stage.submissionStatus) === 'APPROVED').length;
    const pendingCount = stages.filter(stage => {
      const status = this.normalizeStatus(stage.submissionStatus);
      return (status === 'SUBMITTED' || status === 'UNDER REVIEW' || status === 'PENDING' || status === 'DRAFT');
    }).length;
    const rejectedCount = stages.filter(stage => {
      const status = this.normalizeStatus(stage.submissionStatus);
      return (status === 'REJECTED' || status === 'REWORK REQUIRED');
    }).length;

    return {
      totalTeams: projects.length,
      approvedCount,
      pendingCount,
      rejectedCount
    };
  }

  // ==========================================
  // TEAMS LOGIC
  // ==========================================

  getFacultyTeams(facultyId: number): Observable<FacultyTeamView[]> {
    return forkJoin({
      projects: this.getProjectsByFacultyId(facultyId),
      stages: this.getAllProjectStages(),
      members: this.getAllTeamMembers()
    }).pipe(
      map(({ projects, stages, members }) => {
        const activeProjects = projects.filter(project => project.isDeleted !== true);

        return activeProjects.map(project => {
          const projectStages = stages
            .filter(stage => stage.projectId === project.projectId)
            .sort((a, b) => (a.stageMaster?.stageNo || 0) - (b.stageMaster?.stageNo || 0));

          const projectMembers = members.filter(
            member => member.projectId === project.projectId && member.isDeleted !== true
          );

          return {
            project,
            stages: projectStages,
            members: projectMembers,
            progress: this.calculateProgress(projectStages),
            currentStageName: this.getCurrentStageName(projectStages),
            studentUnlockedStage: this.calculateStudentUnlockedStage(projectStages)
          };
        });
      })
    );
  }

  private calculateProgress(stages: ProjectStage[]): number {
    if (!stages || stages.length === 0) return 0;
    const approvedStages = stages.filter(stage => this.normalizeStatus(stage.submissionStatus) === 'APPROVED').length;
    return Math.round((approvedStages / stages.length) * 100);
  }

  private getCurrentStageName(stages: ProjectStage[]): string {
    if (!stages || stages.length === 0) return 'Not Started';
    const currentStage = stages.find(stage => stage.currentStage === true);
    if (currentStage?.stageMaster?.stageName) return currentStage.stageMaster.stageName;

    const sortedStages = [...stages].sort((a, b) => (a.stageMaster?.stageNo || 0) - (b.stageMaster?.stageNo || 0));
    const firstIncomplete = sortedStages.find(stage => this.normalizeStatus(stage.submissionStatus) !== 'APPROVED');
    return firstIncomplete?.stageMaster?.stageName || 'Completed';
  }

  private calculateStudentUnlockedStage(stages: ProjectStage[]): number {
    if (!stages || stages.length === 0) return 1;
    let unlockedStage = 1;
    stages.forEach(stage => {
      const status = this.normalizeStatus(stage.submissionStatus);
      const stageNo = stage.stageMaster?.stageNo || 1;
      if (status === 'APPROVED') unlockedStage = stageNo + 1;
    });
    return unlockedStage > 10 ? 10 : unlockedStage;
  }

  private normalizeStatus(status: string | null | undefined): string {
    return (status || '').trim().toUpperCase();
  }

  // ==========================================
  // REVIEW AND DOCUMENTS LOGIC
  // ==========================================

  uploadStageDocument(projectStageId: number, uploadedBy: number, file: File, description: string): Observable<string> {
    const formData = new FormData();
    formData.append('projectStageId', projectStageId.toString());
    formData.append('uploadedBy', uploadedBy.toString());
    formData.append('file', file);
    formData.append('description', description);
    return this.http.post(`${environment.apiBaseUrl}/project-stage/upload-document`, formData, { responseType: 'text' });
  }

  getDocumentById(documentId: number): Observable<DocumentResponse> {
    return this.http.get<DocumentResponse>(`${this.documentBaseUrl}/${documentId}`);
  }

  getDocumentsByProjectStageId(projectStageId: number): Observable<DocumentResponse[]> {
    return this.http.get<DocumentResponse[]>(`${this.documentBaseUrl}/project-stage/${projectStageId}`);
  }

  getAllDocuments(): Observable<DocumentResponse[]> {
    return this.http.get<DocumentResponse[]>(this.documentBaseUrl);
  }

  createFacultyReview(request: FacultyReviewRequest): Observable<FacultyReviewResponse> {
    return this.http.post<FacultyReviewResponse>(this.facultyReviewBaseUrl, request);
  }

  getFacultyReviewById(reviewId: number): Observable<FacultyReviewResponse> {
    return this.http.get<FacultyReviewResponse>(`${this.facultyReviewBaseUrl}/${reviewId}`);
  }

  getAllFacultyReviews(): Observable<FacultyReviewResponse[]> {
    return this.http.get<FacultyReviewResponse[]>(this.facultyReviewBaseUrl);
  }

  getReviewsByProjectStageId(projectStageId: number): Observable<FacultyReviewResponse[]> {
    return this.http.get<FacultyReviewResponse[]>(`${this.facultyReviewBaseUrl}/project-stage/${projectStageId}`);
  }

  getReviewsByFacultyId(facultyId: number): Observable<FacultyReviewResponse[]> {
    return this.http.get<FacultyReviewResponse[]>(`${this.facultyReviewBaseUrl}/faculty/${facultyId}`);
  }

  getReviewsByDocumentId(documentId: number): Observable<FacultyReviewResponse[]> {
    return this.http.get<FacultyReviewResponse[]>(`${this.facultyReviewBaseUrl}/document/${documentId}`);
  }

  getReviewsByStatus(status: string): Observable<FacultyReviewResponse[]> {
    return this.http.get<FacultyReviewResponse[]>(`${this.facultyReviewBaseUrl}/status/${status}`);
  }

  updateFacultyReview(reviewId: number, request: FacultyReviewRequest): Observable<FacultyReviewResponse> {
    return this.http.put<FacultyReviewResponse>(`${this.facultyReviewBaseUrl}/${reviewId}`, request);
  }

  updateReviewStatus(reviewId: number, status: string): Observable<FacultyReviewResponse> {
    return this.http.patch<FacultyReviewResponse>(`${this.facultyReviewBaseUrl}/${reviewId}/status?status=${status}`, {});
  }

  deleteFacultyReview(reviewId: number): Observable<string> {
    return this.http.delete(`${this.facultyReviewBaseUrl}/${reviewId}`, { responseType: 'text' });
  }

  approveSubmission(payload: ReviewActionPayload): Observable<{ review: FacultyReviewResponse; stage: ProjectStage }> {
    const updatedStage: ProjectStage = {
      ...payload.stage,
      submissionStatus: 'APPROVED',
      reviewedBy: payload.facultyId,
      reviewedOn: new Date().toISOString(),
      remarks: payload.comment || 'Approved'
    };

    const reviewRequest: FacultyReviewRequest = {
      projectStageId: payload.stage.projectStageId,
      facultyId: payload.facultyId,
      documentId: payload.documentId,
      reviewStatus: 'APPROVED',
      reviewComment: payload.comment || 'Approved',
      reviewedOn: new Date().toISOString()
    };

    return this.createFacultyReview(reviewRequest).pipe(
      switchMap(review => this.updateProjectStage(updatedStage).pipe(
        switchMap(stage => forkJoin({
          review: this.getFacultyReviewById(review.reviewId),
          stage: this.getProjectStageById(stage.projectStageId)
        }))
      ))
    );
  }

  rejectSubmission(payload: ReviewActionPayload): Observable<{ review: FacultyReviewResponse; stage: ProjectStage }> {
    const updatedStage: ProjectStage = {
      ...payload.stage,
      submissionStatus: 'REJECTED',
      reviewedBy: payload.facultyId,
      reviewedOn: new Date().toISOString(),
      remarks: payload.comment
    };

    const reviewRequest: FacultyReviewRequest = {
      projectStageId: payload.stage.projectStageId,
      facultyId: payload.facultyId,
      documentId: payload.documentId,
      reviewStatus: 'REJECTED',
      reviewComment: payload.comment,
      reviewedOn: new Date().toISOString()
    };

    return this.createFacultyReview(reviewRequest).pipe(
      switchMap(review => this.updateProjectStage(updatedStage).pipe(
        switchMap(stage => forkJoin({
          review: this.getFacultyReviewById(review.reviewId),
          stage: this.getProjectStageById(stage.projectStageId)
        }))
      ))
    );
  }

  requestRework(payload: ReviewActionPayload): Observable<{ review: FacultyReviewResponse; stage: ProjectStage }> {
    const updatedStage: ProjectStage = {
      ...payload.stage,
      submissionStatus: 'REWORK_REQUIRED',
      reviewedBy: payload.facultyId,
      reviewedOn: new Date().toISOString(),
      remarks: payload.comment
    };

    const reviewRequest: FacultyReviewRequest = {
      projectStageId: payload.stage.projectStageId,
      facultyId: payload.facultyId,
      documentId: payload.documentId,
      reviewStatus: 'REWORK_REQUIRED',
      reviewComment: payload.comment,
      reviewedOn: new Date().toISOString()
    };

    return this.createFacultyReview(reviewRequest).pipe(
      switchMap(review => this.updateProjectStage(updatedStage).pipe(
        switchMap(stage => forkJoin({
          review: this.getFacultyReviewById(review.reviewId),
          stage: this.getProjectStageById(stage.projectStageId)
        }))
      ))
    );
  }
}
