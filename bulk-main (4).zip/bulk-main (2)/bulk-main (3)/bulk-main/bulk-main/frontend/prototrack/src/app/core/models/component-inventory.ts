// // =====================================================
// // COMPONENT REQUEST ITEM DTO
// // Used when creating component request
// // Backend: ComponentRequestItemDto
// // =====================================================

// export interface ComponentRequestItemDto {
//   itemId: number;
//   requestedQuantity: number;
//   approvedQuantity?: number;
//   issuedQuantity?: number;
//   itemStatus?: string;
//   facultyComments?: string;
// }

// // =====================================================
// // COMPONENT REQUEST ITEM RESPONSE DTO
// // Used when backend returns request item data
// // Backend: ComponentRequestItemResponseDto
// // =====================================================

// export interface ComponentRequestItemResponseDto {
//   requestItemId: number;
//   itemId: number;
//   requestedQuantity: number;
//   approvedQuantity: number;
//   issuedQuantity: number;
//   itemStatus: string;
//   facultyComments: string | null;
// }

// // =====================================================
// // COMPONENT REQUEST DTO
// // Used when creating component request
// // Backend: ComponentRequestDto
// // =====================================================

// export interface ComponentRequestDto {
//   projectId: number;
//   requestedBy: number;
//   facultyId: number;
//   remarks?: string;
//   requestItems: ComponentRequestItemDto[];
// }

// // =====================================================
// // COMPONENT REQUEST RESPONSE DTO
// // Used when backend returns component request data
// // Backend: ComponentRequestResponseDto
// // =====================================================

// export interface ComponentRequestResponseDto {
//   componentRequestId: number;
//   projectId: number;
//   requestedBy: number;
//   facultyId: number;
//   requestDate: string;
//   approvalStatus: string;
//   approvedBy: number | null;
//   approvedOn: string | null;
//   issuedBy: number | null;
//   issuedOn: string | null;
//   remarks: string | null;
//   createdAt: string;
//   requestItems: ComponentRequestItemResponseDto[];
// }

// // =====================================================
// // COMPONENT RETURN ITEM DTO
// // Used when creating component return
// // Backend: ComponentReturnItemDto
// // =====================================================

// export interface ComponentReturnItemDto {
//   itemId: number;
//   issuedQuantity: number;
//   returnedQuantity: number;
//   consumedQuantity: number;
//   damagedQuantity: number;
//   lostQuantity: number;
//   condition?: string;
//   remarks?: string;
// }

// // =====================================================
// // COMPONENT RETURN DTO
// // Used when creating component return
// // Backend: ComponentReturnDto
// // Note: returnCode is not here because backend generates it
// // =====================================================

// export interface ComponentReturnDto {
//   componentRequestId?: number;
//   projectId: number;
//   returnedBy: number;
//   remarks?: string;
//   returnItems: ComponentReturnItemDto[];
// }

// // =====================================================
// // COMPONENT RETURN ITEM RESPONSE DTO
// // Used when backend returns component return item data
// // Backend: ComponentReturnItemResponseDto
// // =====================================================

// export interface ComponentReturnItemResponseDto {
//   returnItemId: number;
//   itemId: number;
//   issuedQuantity: number;
//   returnedQuantity: number;
//   consumedQuantity: number;
//   damagedQuantity: number;
//   lostQuantity: number;
//   condition: string;
//   remarks: string | null;
// }

// // =====================================================
// // COMPONENT RETURN RESPONSE DTO
// // Used when backend returns component return data
// // Backend: ComponentReturnResponseDto
// // Note: returnCode is here because backend returns it
// // =====================================================

// export interface ComponentReturnResponseDto {
//   componentReturnId: number;
//   returnCode: string;
//   componentRequestId: number | null;
//   projectId: number;
//   returnedBy: number;
//   receivedBy: number | null;
//   returnDate: string;
//   returnStatus: string;
//   remarks: string | null;
//   createdAt: string;
//   returnItems: ComponentReturnItemResponseDto[];
// }
// =====================================================
// COMPONENT REQUEST ITEM DTO
// Used when creating component request
// Backend: ComponentRequestItemDto
// =====================================================

export interface ComponentRequestItemDto {
  itemId: number;
  requestedQuantity: number;
  approvedQuantity?: number;
  issuedQuantity?: number;
  itemStatus?: string;
  facultyComments?: string;
}

// =====================================================
// COMPONENT REQUEST ITEM RESPONSE DTO
// Used when backend returns request item data
// Backend: ComponentRequestItemResponseDto
// =====================================================

export interface ComponentRequestItemResponseDto {
  requestItemId: number;
  itemId: number;
  requestedQuantity: number;
  approvedQuantity: number;
  issuedQuantity: number;
  itemStatus: string;
  facultyComments: string | null;
}

// =====================================================
// COMPONENT REQUEST DTO
// Used when creating component request
// Backend: ComponentRequestDto
// =====================================================

export interface ComponentRequestDto {
  projectId: number;
  requestedBy: number;
  facultyId: number;
  remarks?: string;
  requestItems: ComponentRequestItemDto[];
}

// =====================================================
// COMPONENT REQUEST RESPONSE DTO
// Used when backend returns component request data
// Backend: ComponentRequestResponseDto
// =====================================================

export interface ComponentRequestResponseDto {
  componentRequestId: number;
  projectId: number;
  requestedBy: number;
  facultyId: number;
  requestDate: string;
  approvalStatus: string;
  approvedBy: number | null;
  approvedOn: string | null;
  issuedBy: number | null;
  issuedOn: string | null;
  remarks: string | null;
  createdAt: string;
  requestItems: ComponentRequestItemResponseDto[];
}

// =====================================================
// COMPONENT RETURN ITEM DTO
// Used when creating component return
// Backend: ComponentReturnItemDto
// =====================================================

export interface ComponentReturnItemDto {
  itemId: number;
  issuedQuantity: number;
  returnedQuantity: number;
  consumedQuantity: number;
  damagedQuantity: number;
  lostQuantity: number;
  condition?: string;
  remarks?: string;
}

// =====================================================
// COMPONENT RETURN DTO
// Used when creating component return
// Backend: ComponentReturnDto
// Note: returnCode is not here because backend generates it
// =====================================================

export interface ComponentReturnDto {
  componentRequestId?: number;
  projectId: number;
  returnedBy: number;
  remarks?: string;
  returnItems: ComponentReturnItemDto[];
}

// =====================================================
// COMPONENT RETURN ITEM RESPONSE DTO
// Used when backend returns component return item data
// Backend: ComponentReturnItemResponseDto
// =====================================================

export interface ComponentReturnItemResponseDto {
  returnItemId: number;
  itemId: number;
  issuedQuantity: number;
  returnedQuantity: number;
  consumedQuantity: number;
  damagedQuantity: number;
  lostQuantity: number;
  condition: string;
  remarks: string | null;
}

// =====================================================
// COMPONENT RETURN RESPONSE DTO
// Used when backend returns component return data
// Backend: ComponentReturnResponseDto
// Note: returnCode is here because backend returns it
// =====================================================

export interface ComponentReturnResponseDto {
  componentReturnId: number;
  returnCode: string;
  componentRequestId: number | null;
  projectId: number;
  returnedBy: number;
  receivedBy: number | null;
  returnDate: string;
  returnStatus: string;
  remarks: string | null;
  createdAt: string;
  returnItems: ComponentReturnItemResponseDto[];
}