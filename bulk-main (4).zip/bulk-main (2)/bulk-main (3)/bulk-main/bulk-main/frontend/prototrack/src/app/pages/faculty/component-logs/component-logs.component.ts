import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize, map } from 'rxjs/operators';

import { ComponentInventoryService } from '../../../core/services/component-inventory.service';
import { ToolInventoryService } from '../../../core/services/tool-inventory.service';
import { EquipmentService } from '../../../core/services/equipment.service';
import { FacultyService } from '../../../core/services/faculty.service';
import { UserService } from '../../../core/services/user.service';
import { UserResponse } from '../../../core/models/user';
import { ProjectTeam } from '../../../core/models/faculty';
import { StorageService } from '../../../core/services/storage.sevice';

export interface LogEntry {
  id: string;
  rawId: number;
  date: string;
  spoc: string;
  type: 'Handover (Request)' | 'Return';
  items: string;
  quantity: number;
  status: string;
  remarks: string;
}

export interface ProjectGroup {
  projectId: number;
  projectName: string;
  componentLogs: LogEntry[];
  toolLogs: LogEntry[];
  equipmentLogs: LogEntry[];
  filteredLogs: LogEntry[];
}

@Component({
  selector: 'app-component-logs',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './component-logs.component.html',
  styleUrls: ['./component-logs.component.css']
})
export class ComponentLogsComponent implements OnInit {
  isLoading = false;
  loadError = '';
  facultyId = 1;

  projectGroups: ProjectGroup[] = [];
  userNamesMap: Record<number, string> = {};

  activeTab: 'components' | 'tools' | 'equipment' = 'components';

  selectedProject: ProjectGroup | null = null;
  teamSearchTerm = '';

  // Filters
  searchTerm = '';
  statusFilter = 'all';
  

  constructor(
    private readonly facultyService: FacultyService,
    private readonly componentInventoryService: ComponentInventoryService,
    private readonly toolInventoryService: ToolInventoryService,
    private readonly equipmentService: EquipmentService,
    private readonly userService: UserService,
    private readonly cdr: ChangeDetectorRef,
    private storage: StorageService
  ) {}

  ngOnInit(): void {
    this.facultyId = Number(this.storage.get('userId')) || 1;
    this.loadData();
  }

  loadData(): void {
    this.isLoading = true;
    this.loadError = '';

    // Step 1: Load users first
    this.userService.getAllUsers().pipe(
      catchError(err => {
        console.error('Failed to load users in faculty logs. Continuing:', err);
        return of([] as UserResponse[]);
      })
    ).subscribe({
      next: (users) => {
        this.userNamesMap = {};
        users.forEach((u: any) => {
          const id = Number(u.userId || u.id);
          const name = u.name || u.userName || u.fullName || '';
          if (id) {
            this.userNamesMap[id] = name;
          }
        });
        this.fetchFacultyProjects();
      },
      error: () => this.fetchFacultyProjects()
    });
  }

  private fetchFacultyProjects(): void {
    this.facultyService.getProjectsByFacultyId(this.facultyId).pipe(
      catchError(err => {
        console.error('Failed to fetch faculty projects:', err);
        this.loadError = 'Failed to load projects associated with your account.';
        return of([] as ProjectTeam[]);
      })
    ).subscribe({
      next: (projects) => {
        if (!projects || projects.length === 0) {
          this.isLoading = false;
          this.projectGroups = [];
          this.cdr.markForCheck();
          return;
        }

        // Fetch logs for all projects in parallel
        const projectObservables = projects.map(proj => {
          const pId = Number(proj.projectId);
          return forkJoin({
            project: of(proj),
            componentRequests: this.componentInventoryService.getComponentRequests({ projectId: pId }).pipe(catchError(() => of([]))),
            componentReturns: this.componentInventoryService.getComponentReturns({ projectId: pId }).pipe(catchError(() => of([]))),
            toolRequests: this.toolInventoryService.getToolRequests({ projectId: pId }).pipe(catchError(() => of([]))),
            toolReturns: this.toolInventoryService.getToolReturns({ projectId: pId }).pipe(catchError(() => of([]))),
            equipmentBookings: this.equipmentService.getBookingsByProjectId(pId).pipe(catchError(() => of([])))
          });
        });

        forkJoin(projectObservables).pipe(
          finalize(() => {
            this.isLoading = false;
            this.applyFilters();
            this.cdr.markForCheck();
          })
        ).subscribe({
          next: (results) => {
            this.processProjectResults(results);
          },
          error: (err) => {
            console.error('Error fetching logs for projects:', err);
            this.loadError = 'Failed to retrieve transaction logs for your project teams.';
          }
        });
      }
    });
  }

  private processProjectResults(results: any[]): void {
    this.projectGroups = [];

    results.forEach(res => {
      const proj = res.project;
      const cLogs: LogEntry[] = [];
      const tLogs: LogEntry[] = [];
      const eLogs: LogEntry[] = [];

      // 1. Component Requests (Handovers)
      (res.componentRequests || []).forEach((req: any) => {
        cLogs.push({
          id: `REQ-CMP-${req.componentRequestId}`,
          rawId: req.componentRequestId,
          date: req.requestDate ? req.requestDate.split('T')[0] : 'N/A',
          spoc: this.userNamesMap[req.requestedBy] || `Student #${req.requestedBy}`,
          type: 'Handover (Request)',
          items: req.items?.map((i: any) => `${i.componentName || 'Component'} (x${i.approvedQuantity || i.requestedQuantity})`).join(', ') || 'N/A',
          quantity: req.items?.reduce((sum: number, i: any) => sum + (i.approvedQuantity || i.requestedQuantity || 0), 0) || 0,
          status: req.approvalStatus || 'Approved',
          remarks: req.remarks || 'No remarks'
        });
      });

      // 2. Component Returns
      (res.componentReturns || []).forEach((ret: any) => {
        cLogs.push({
          id: `RET-CMP-${ret.componentReturnId}`,
          rawId: ret.componentReturnId,
          date: ret.returnDate ? ret.returnDate.split('T')[0] : (ret.createdAt ? ret.createdAt.split('T')[0] : 'N/A'),
          spoc: this.userNamesMap[ret.returnedBy] || `Student #${ret.returnedBy}`,
          type: 'Return',
          items: ret.items?.map((i: any) => `${i.inventory?.itemName || i.componentName || 'Component'} (x${i.returnedQuantity})`).join(', ') || 'N/A',
          quantity: ret.items?.reduce((sum: number, i: any) => sum + (i.returnedQuantity || 0), 0) || 0,
          status: ret.returnStatus || 'Completed',
          remarks: ret.remarks || 'Returned'
        });
      });

      // 3. Tool Requests (Handovers)
      (res.toolRequests || []).forEach((req: any) => {
        tLogs.push({
          id: `REQ-TOL-${req.toolRequestId}`,
          rawId: req.toolRequestId,
          date: req.requestDate ? req.requestDate.split('T')[0] : 'N/A',
          spoc: this.userNamesMap[req.requestedBy] || `Student #${req.requestedBy}`,
          type: 'Handover (Request)',
          items: req.items?.map((i: any) => `${i.itemName || i.toolName || 'Tool'} (x${i.approvedQuantity || i.requestedQuantity})`).join(', ') || 'N/A',
          quantity: req.items?.reduce((sum: number, i: any) => sum + (i.approvedQuantity || i.requestedQuantity || 0), 0) || 0,
          status: req.approvalStatus || 'Approved',
          remarks: req.remarks || 'No remarks'
        });
      });

      // 4. Tool Returns
      (res.toolReturns || []).forEach((ret: any) => {
        tLogs.push({
          id: `RET-TOL-${ret.toolReturnId}`,
          rawId: ret.toolReturnId,
          date: ret.returnDate ? ret.returnDate.split('T')[0] : (ret.createdAt ? ret.createdAt.split('T')[0] : 'N/A'),
          spoc: this.userNamesMap[ret.returnedBy] || `Student #${ret.returnedBy}`,
          type: 'Return',
          items: ret.items?.map((i: any) => `${i.itemName || 'Tool'} (x${i.returnedQuantity})`).join(', ') || 'N/A',
          quantity: ret.items?.reduce((sum: number, i: any) => sum + (i.returnedQuantity || 0), 0) || 0,
          status: ret.returnStatus || 'Completed',
          remarks: ret.remarks || 'Returned'
        });
      });

      // 5. Equipment Bookings
      (res.equipmentBookings || []).forEach((bk: any) => {
        eLogs.push({
          id: `BKG-EQP-${bk.bookingId}`,
          rawId: bk.bookingId,
          date: bk.bookingDate ? bk.bookingDate.split('T')[0] : 'N/A',
          spoc: this.userNamesMap[bk.requestedBy] || `Student #${bk.requestedBy}`,
          type: 'Handover (Request)',
          items: `Equipment Booking (${bk.assetCode})`,
          quantity: 1,
          status: bk.approvalStatus || 'Approved',
          remarks: bk.purpose || bk.remarks || 'Equipment Booking'
        });
      });

      // Sort logs chronologically (latest first)
      cLogs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      tLogs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      eLogs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      this.projectGroups.push({
        projectId: Number(proj.projectId),
        projectName: proj.projectName,
        componentLogs: cLogs,
        toolLogs: tLogs,
        equipmentLogs: eLogs,
        filteredLogs: []
      });
    });
  }

  setTab(tab: 'components' | 'tools' | 'equipment'): void {
    this.activeTab = tab;
    this.applyFilters();
  }

  selectProject(group: ProjectGroup): void {
    this.selectedProject = group;
    this.searchTerm = '';
    this.statusFilter = 'all';
    this.applyFilters();
  }

  clearSelectedProject(): void {
    this.selectedProject = null;
  }

  filteredProjectGroups(): ProjectGroup[] {
    const term = this.teamSearchTerm.trim().toLowerCase();
    if (!term) return this.projectGroups;
    return this.projectGroups.filter(group =>
      group.projectName.toLowerCase().includes(term) ||
      String(group.projectId).includes(term)
    );
  }

  applyFilters(): void {
    const search = this.searchTerm.trim().toLowerCase();
    const status = this.statusFilter.toLowerCase();

    this.projectGroups.forEach(group => {
      let sourceLogs: LogEntry[] = [];
      if (this.activeTab === 'components') {
        sourceLogs = group.componentLogs;
      } else if (this.activeTab === 'tools') {
        sourceLogs = group.toolLogs;
      } else {
        sourceLogs = group.equipmentLogs;
      }

      group.filteredLogs = sourceLogs.filter(log => {
        const matchesSearch = !search ||
          log.id.toLowerCase().includes(search) ||
          log.spoc.toLowerCase().includes(search) ||
          log.items.toLowerCase().includes(search);

        const matchesStatus = status === 'all' || log.status.toLowerCase() === status;

        return matchesSearch && matchesStatus;
      });
    });

    if (this.selectedProject) {
      const match = this.projectGroups.find(g => g.projectId === this.selectedProject?.projectId);
      if (match) {
        this.selectedProject.filteredLogs = match.filteredLogs;
      }
    }
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.statusFilter = 'all';
    this.applyFilters();
  }

  getMathMin(a: number, b: number): number {
    return Math.min(a, b);
  }

  hasAnyLogs(): boolean {
    return this.projectGroups.some(g => g.filteredLogs.length > 0);
  }
}
