import { Component, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { ComponentInventoryService } from '../../../core/services/component-inventory.service';
import { InventoryService } from '../../../core/services/inventory.service';
import { FacultyService } from '../../../core/services/faculty.service';
import { StorageService } from '../../../core/services/storage.sevice';
import { ComponentRequestResponseDto } from '../../../core/models/component-inventory';
import { Inventory } from '../../../core/models/inventory';

export interface ComponentItemModel {
  requestItemId?: number;
  itemId: number;
  name: string;
  quantity: number;
  status: string;
  selected?: boolean;
}

export interface TeamComponentRequest {
  id: string;
  numericId: number;
  team: string;
  projectId: number;
  batch: string;
  purpose: string;
  status: string;
  requestedOn: string;
  deadline: string;
  rejectionComment?: string;
  components: ComponentItemModel[];
}

import { ToastService } from '../../../core/services/toast.service';
import { UserService } from '../../../core/services/user.service';

@Component({
  selector: 'app-component-requests',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './component-inventory.component.html',
  styleUrl: './component-inventory.component.css'
})
export class ComponentRequestsComponent implements OnInit {

  requests: TeamComponentRequest[] = [];
  filteredRequests: TeamComponentRequest[] = [];

  searchText = '';
  selectedBatch = 'all';
  selectedTeam = 'all';
  selectedStatus = 'all';

  batches: string[] = [];
  teamsList: string[] = [];

  selectedRequest: TeamComponentRequest | null = null;

  selectAll = false;
  feedbackText = '';
  toastMessage = '';
  loading = false;
  errorMessage = '';

  facultyId!:number;
  batchesMap = new Map<number, string>();
  

  constructor(
    private storage: StorageService,
    private toastService: ToastService,
    @Optional() private componentInventoryService?: ComponentInventoryService,
    @Optional() private inventoryService?: InventoryService,
    @Optional() private facultyService?: FacultyService,
    @Optional() private userService?: UserService
  ) {}

  ngOnInit(): void {
    const id = this.storage.get('userId');
    this.facultyId = id?Number(id):0;
    if (!this.facultyId) {
      this.errorMessage = 'Faculty ID not found. Please login again.';
      return;
    }

    if (this.userService) {
      this.userService.getAllBatches().subscribe({
        next: (batches: any[]) => {
          (batches || []).forEach(b => this.batchesMap.set(b.batchId, b.batchName));
        },
        error: err => console.warn('Failed to load batches for lookup:', err)
      });
    }

    this.loadRequests();
  }

  loadRequests(): void {
    this.loading = true;
    this.errorMessage = '';

    if (!this.componentInventoryService) {
      this.errorMessage = 'Component inventory service not available.';
      this.loading = false;
      return;
    }

    const requestsObs =
      this.componentInventoryService
        .getRequestsByFacultyId(this.facultyId)
        .pipe(
          catchError((err: any) => {
            console.error('Component request API failed:', err);
            return of([]);
          })
        );

    const inventoryObs =
      this.inventoryService
        ? this.inventoryService.getAllInventory().pipe(
            catchError((err: any) => {
              console.error('Inventory API failed:', err);
              return of([]);
            })
          )
        : of([]);

    const projectsObs =
      this.facultyService
        ? this.facultyService.getProjectsByFacultyId(this.facultyId).pipe(
            catchError((err: any) => {
              console.error('Projects API failed:', err);
              return of([]);
            })
          )
        : of([]);

    forkJoin({
      requests: requestsObs,
      inventory: inventoryObs,
      projects: projectsObs
    }).subscribe({
      next: ({
        requests,
        inventory,
        projects
      }: {
        requests: ComponentRequestResponseDto[];
        inventory: Inventory[];
        projects: any[];
      }) => {

        console.log('Component request response:', requests);
        console.log('Inventory response:', inventory);
        console.log('Projects response:', projects);

        const itemMap = new Map<number, string>();

        if (Array.isArray(inventory)) {
          inventory.forEach((inv: Inventory) => {
            if (inv.itemId !== undefined && inv.itemId !== null) {
              itemMap.set(inv.itemId, inv.itemName);
            }
          });
        }

        const projectMap = new Map<number, { name: string; batch: string }>();

        if (Array.isArray(projects)) {
          projects.forEach((project: any) => {
            projectMap.set(project.projectId, {
              name: project.projectName || `Team PRJ-${project.projectId}`,
              batch: this.getBatchName(project.batchId)
            });
          });
        }

        this.requests = (requests || []).map((request) => {
          const projectInfo = projectMap.get(request.projectId);

          return {
            id: `CRQ-${request.componentRequestId}`,
            numericId: request.componentRequestId,
            team: projectInfo?.name || `Team (PRJ-${request.projectId})`,
            projectId: request.projectId,
            batch: projectInfo?.batch || 'Batch 01',
            purpose: request.remarks || 'Hardware Prototyping Module',
            status: this.normalizeStatus(request.approvalStatus),
            requestedOn: request.requestDate
              ? new Date(request.requestDate).toLocaleDateString()
              : 'N/A',
            deadline: request.createdAt
              ? new Date(request.createdAt).toLocaleDateString()
              : 'N/A',
            rejectionComment: request.remarks || '',
            components: (request.requestItems || []).map((item) => ({
              requestItemId: item.requestItemId,
              itemId: item.itemId,
              name: itemMap.get(item.itemId) || `Item #${item.itemId}`,
              quantity: item.requestedQuantity,
              status: this.normalizeStatus(
                item.itemStatus || request.approvalStatus
              ),
              selected: false
            }))
          };
        });

        this.teamsList = Array.from(
          new Set(this.requests.map((request) => request.team))
        ).sort();

        this.batches = Array.from(
          new Set(this.requests.map((request) => request.batch))
        ).sort();

        this.applyFilters();

        console.log('Mapped requests:', this.requests);
        console.log('Filtered requests:', this.filteredRequests);

        this.loading = false;
      },

      error: (err: any) => {
        console.error('Failed to load component requests:', err);
        this.errorMessage = 'Unable to load component requests from backend.';
        this.loading = false;
      }
    });
  }

  applyFilters(): void {
    const q = this.searchText.toLowerCase().trim();

    this.filteredRequests = this.requests.filter((req) => {
      const componentsText = req.components
        .map((component) => component.name)
        .join(' ')
        .toLowerCase();

      const matchesSearch =
        !q ||
        req.id.toLowerCase().includes(q) ||
        req.team.toLowerCase().includes(q) ||
        req.purpose.toLowerCase().includes(q) ||
        componentsText.includes(q);

      const matchesTeam =
        this.selectedTeam === 'all' ||
        req.team === this.selectedTeam;

      const matchesBatch =
        this.selectedBatch === 'all' ||
        req.batch === this.selectedBatch;

      const matchesStatus =
        this.selectedStatus === 'all' ||
        req.status.toLowerCase() === this.selectedStatus.toLowerCase();

      return matchesSearch && matchesTeam && matchesBatch && matchesStatus;
    });
  }

  clearFilters(): void {
    this.searchText = '';
    this.selectedBatch = 'all';
    this.selectedTeam = 'all';
    this.selectedStatus = 'all';

    this.applyFilters();
  }

  get totalRequests(): number {
    return this.filteredRequests.length;
  }

  get pendingRequests(): number {
    return this.filteredRequests.filter(
      (request) => request.status.toLowerCase() === 'pending'
    ).length;
  }

  get approvedRequests(): number {
    return this.filteredRequests.filter(
      (request) => request.status.toLowerCase() === 'approved'
    ).length;
  }

  get rejectedRequests(): number {
    return this.filteredRequests.filter(
      (request) => request.status.toLowerCase() === 'rejected'
    ).length;
  }

  get groupedRequests(): { team: string; requests: TeamComponentRequest[] }[] {
    const map = new Map<string, TeamComponentRequest[]>();

    this.filteredRequests.forEach((request) => {
      if (!map.has(request.team)) {
        map.set(request.team, []);
      }

      map.get(request.team)?.push(request);
    });

    return Array.from(map.entries()).map(([team, requests]) => ({
      team,
      requests
    }));
  }

  openRequestModal(req: TeamComponentRequest): void {
    this.selectedRequest = req;
    this.selectAll = false;
    this.feedbackText = req.rejectionComment || '';

    req.components.forEach((component) => {
      component.selected = false;
    });
  }

  closeRequestModal(): void {
    this.selectedRequest = null;
    this.selectAll = false;
    this.feedbackText = '';
  }

  toggleSelectAll(): void {
    if (!this.selectedRequest) {
      return;
    }

    this.selectedRequest.components.forEach((component) => {
      if (component.status.toLowerCase() === 'pending') {
        component.selected = this.selectAll;
      }
    });
  }

  bulkAction(action: 'Approved' | 'Rejected' | 'SendBack'): void {
    if (!this.selectedRequest) {
      return;
    }

    if (action === 'SendBack') {
      if (!this.feedbackText.trim()) {
        this.toastService.showWarning('Please enter a feedback note for students.');
        return;
      }

      this.selectedRequest.status = 'Pending';
      this.selectedRequest.rejectionComment = this.feedbackText;

      this.toastService.showSuccess('Request sent back to students with feedback.');
      this.closeRequestModal();

      return;
    }

    if (action === 'Rejected' && !this.feedbackText.trim()) {
      this.toastService.showWarning('Please enter a rejection reason.');
      return;
    }

    if (!this.componentInventoryService) {
      this.toastService.showError('Component inventory service is not available.');
      return;
    }

    if (action === 'Approved') {
      this.componentInventoryService
        .approveRequest(
          this.selectedRequest.numericId,
          this.facultyId
        )
        .subscribe({
          next: () => {
            this.showToast(
              `Request ${this.selectedRequest?.id} approved successfully.`
            );

            this.closeRequestModal();
            this.loadRequests();
          },
          error: (err: any) => {
            console.error('Approval failed:', err);
            this.showToast('Unable to approve request.');
          }
        });

      return;
    }

    if (action === 'Rejected') {
      this.componentInventoryService
        .rejectRequest(
          this.selectedRequest.numericId,
          this.facultyId,
          this.feedbackText
        )
        .subscribe({
          next: () => {
            this.showToast(
              `Request ${this.selectedRequest?.id} rejected successfully.`
            );

            this.closeRequestModal();
            this.loadRequests();
          },
          error: (err: any) => {
            console.error('Rejection failed:', err);
            this.showToast('Unable to reject request.');
          }
        });
    }
  }

  getStatusClass(status: string): string {
    const s = (status || '').toLowerCase();

    if (s === 'issued' || s === 'delivered' || s === 'handed_over') {
      return 'status-pill status-issued';
    }

    if (s === 'approved' || s === 'faculty_approved') {
      return 'status-pill status-approved';
    }

    if (s === 'pending' || s === 'under_review') {
      return 'status-pill status-review';
    }

    if (s === 'rejected') {
      return 'status-pill status-rejected';
    }

    return 'status-pill status-draft';
  }

  getStatusLabel(status: string): string {
    const s = (status || '').toLowerCase();

    if (s === 'issued' || s === 'delivered' || s === 'handed_over') {
      return 'Delivered to Student ✓';
    }

    if (s === 'approved' || s === 'faculty_approved') {
      return 'Approved (Awaiting Lab Handover)';
    }

    if (s === 'pending' || s === 'under_review') {
      return 'Pending Faculty Review';
    }

    if (s === 'rejected') {
      return 'Rejected';
    }

    return status || 'Pending';
  }

  getBatchName(batchId?: number): string {
    if (!batchId) {
      return 'Not Assigned';
    }
    return this.batchesMap.get(batchId) || `Batch ${batchId}`;
  }

  private normalizeStatus(status?: string | null): string {
    const s = (status || 'Pending').toLowerCase();

    if (s === 'issued' || s === 'delivered' || s === 'handed_over') {
      return 'Issued';
    }

    if (s === 'approved' || s === 'faculty_approved') {
      return 'Approved';
    }

    if (s === 'rejected') {
      return 'Rejected';
    }

    return 'Pending';
  }

  showToast(message: string): void {
    this.toastMessage = message;

    setTimeout(() => {
      this.toastMessage = '';
    }, 3000);
  }

}