import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

import { UserService } from '../../core/services/user.service';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './change-password.component.html',
  styleUrl: './change-password.component.css'
})
export class ChangePasswordComponent {

  changeForm: FormGroup;
  loading = false;
  
  oldPasswordError = '';
  newPasswordError = '';
  confirmPasswordError = '';

  showOldPassword = false;
  showNewPassword = false;
  showConfirmPassword = false;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private authService: AuthService,
    private toastService: ToastService,
    private router: Router
  ) {

    this.changeForm = this.fb.group({
      oldPassword: [
        '',
        Validators.required
      ],
      newPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(6)
        ]
      ],
      confirmPassword: [
        '',
        Validators.required
      ]
    });

  }

  onSubmit(): void {
    this.oldPasswordError = '';
    this.newPasswordError = '';
    this.confirmPasswordError = '';

    if (this.changeForm.invalid) {
      this.changeForm.markAllAsTouched();

      if (this.changeForm.get('oldPassword')?.invalid) {
        this.oldPasswordError = 'Temporary password is required.';
      }

      if (this.changeForm.get('newPassword')?.invalid) {
        this.newPasswordError = 'New password must be at least 6 characters.';
      }

      if (this.changeForm.get('confirmPassword')?.invalid) {
        this.confirmPasswordError = 'Confirm password is required.';
      }

      return;
    }

    const oldPassword = this.changeForm.value.oldPassword;
    const newPassword = this.changeForm.value.newPassword;
    const confirmPassword = this.changeForm.value.confirmPassword;

    if (newPassword !== confirmPassword) {
      this.confirmPasswordError = 'Passwords do not match.';
      return;
    }

    const userIdStr = localStorage.getItem('userId') || sessionStorage.getItem('userId');
    if (!userIdStr) {
      this.toastService.showError('Session expired. Please log in again.');
      this.router.navigate(['/login']);
      return;
    }

    const userId = parseInt(userIdStr, 10);
    this.loading = true;

    this.userService.changePassword(userId, {
      oldPassword,
      newPassword,
      confirmPassword
    }).subscribe({
      next: (response: string) => {
        this.loading = false;
        
        if (response && response.includes('incorrect')) {
          this.oldPasswordError = response;
          this.toastService.showError(response);
          return;
        }

        if (response && response.includes('do not match')) {
          this.confirmPasswordError = response;
          this.toastService.showError(response);
          return;
        }

        this.toastService.showSuccess('Password updated successfully. Please log in with your new password.');
        this.authService.logout();
        this.router.navigate(['/login']);
      },
      error: (error) => {
        this.loading = false;
        console.error('Password change error:', error);
        
        let msg = 'Failed to update password. Please try again.';
        if (error.error && typeof error.error === 'string') {
          msg = error.error;
        } else if (error.message) {
          msg = error.message;
        }

        this.toastService.showError(msg);
      }
    });
  }

  toggleOldPassword(): void {
    this.showOldPassword = !this.showOldPassword;
  }

  toggleNewPassword(): void {
    this.showNewPassword = !this.showNewPassword;
  }

  toggleConfirmPassword(): void {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  get oldPasswordTouchedInvalid(): boolean {
    const control = this.changeForm.get('oldPassword');
    return !!(control && control.invalid && control.touched);
  }

  get newPasswordTouchedInvalid(): boolean {
    const control = this.changeForm.get('newPassword');
    return !!(control && control.invalid && control.touched);
  }

  get confirmPasswordTouchedInvalid(): boolean {
    const control = this.changeForm.get('confirmPassword');
    return !!(control && control.invalid && control.touched);
  }

}
