import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  Notification,
  ApiResponse
} from '../models/notification';

@Injectable({
  providedIn: 'root'
})
export class CreateNotificationService {

  private readonly apiUrl = `${environment.apiBaseUrl}/api/notifications`;

  constructor(private http: HttpClient) {}

  createNotification(
    notification: Notification
  ): Observable<ApiResponse<Notification>> {
    return this.http.post<ApiResponse<Notification>>(
      this.apiUrl,
      notification
    );
  }
}
