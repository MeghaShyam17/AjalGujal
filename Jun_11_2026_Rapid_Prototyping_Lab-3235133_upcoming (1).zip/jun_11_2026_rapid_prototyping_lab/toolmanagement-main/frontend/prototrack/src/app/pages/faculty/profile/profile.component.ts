import {
  CommonModule,
  Location
} from '@angular/common';

import {
  Component,
  OnInit
} from '@angular/core';

import {
  FormsModule
} from '@angular/forms';

import {
  RouterModule
} from '@angular/router';

import {
  StorageService
} from '../../../core/services/storage.sevice';

import {
  UserService
} from '../../../core/services/user.service';

import {
  User,
  UserResponse,
  ResetPasswordRequest
} from '../../../core/models/user';

interface FacultyProfile {
  name: string;
  email: string;
  phone: string;
  role: string;
  facultyId: string;
  avatar?: string;
}

interface ProfileUserResponse extends UserResponse {
  profileImage?: string | Blob;
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profile: FacultyProfile = {
    name: '',
    email: '',
    phone: '',
    role: 'Faculty',
    facultyId: ''
  };

  userId = 0;

  showEditModal = false;

  editModel:
    Partial<FacultyProfile> = {};

  showPwdModal = false;

  currentPwd = '';
  newPwd = '';
  confirmPwd = '';
  pwdError = '';

  toastMsg = '';

  private toastTimer?:
    ReturnType<typeof setTimeout>;

  constructor(
    private readonly userService:
      UserService,

    private readonly storage:
      StorageService,

    private readonly location:
      Location
  ) {}

  ngOnInit(): void {
    const storedUserId =
      this.storage.get('userId');

    this.userId =
      Number(storedUserId);

    if (
      Number.isFinite(this.userId) &&
      this.userId > 0
    ) {
      this.loadProfile();
      return;
    }

    this.showToast(
      'User ID not found. Please log in again.'
    );
  }

  get avatarLetter(): string {
    return (
      this.profile.name ||
      'Faculty'
    )
      .charAt(0)
      .toUpperCase();
  }

  goBack(): void {
    this.location.back();
  }

  loadProfile(): void {
    if (!this.isValidUserId()) {
      this.showToast(
        'User ID not found. Please log in again.'
      );

      return;
    }

    this.userService
      .getUserById(this.userId)
      .subscribe({
        next: (
          user: UserResponse
        ) => {
          const profileUser =
            user as ProfileUserResponse;

          this.profile = {
            name: this.formatName(
              user.name || ''
            ),

            email:
              user.email || '',

            phone:
              user.phone || '',

            role: this.formatRole(
              user.roleName ||
              this.storage.get('role') ||
              'Faculty'
            ),

            facultyId: String(
              user.userId ||
              this.userId
            ),

            avatar:
              this.getProfileImage(
                profileUser.profileImage
              )
          };

          this.updateStoredProfileDetails();
        },

        error: (
          error: unknown
        ) => {
          console.error(
            'Error loading profile:',
            error
          );

          this.showToast(
            this.getErrorMessage(
              error,
              'Failed to load profile'
            )
          );
        }
      });
  }

  openEdit(): void {
    this.editModel = {
      name: this.profile.name,
      email: this.profile.email,
      phone: this.profile.phone,
      role: this.profile.role
    };

    this.showEditModal = true;
  }

  closeEdit(): void {
    this.showEditModal = false;
    this.editModel = {};
  }

  saveEdit(): void {
    const name =
      this.formatName(
        this.editModel.name?.trim() ||
        ''
      );

    const email =
      this.editModel.email
        ?.trim()
        .toLowerCase() || '';

    const phone =
      this.editModel.phone?.trim() ||
      '';

    if (!name) {
      this.showToast(
        'Name is required'
      );

      return;
    }

    if (!email) {
      this.showToast(
        'Email is required'
      );

      return;
    }

    if (!this.isValidEmail(email)) {
      this.showToast(
        'Please enter a valid email address'
      );

      return;
    }

    if (!phone) {
      this.showToast(
        'Phone number is required'
      );

      return;
    }

    if (!this.isValidPhone(phone)) {
      this.showToast(
        'Please enter a valid phone number'
      );

      return;
    }

    if (!this.isValidUserId()) {
      this.showToast(
        'User ID not found. Please log in again.'
      );

      return;
    }

    const updateData: User = {
      userId: this.userId,
      name,
      email,
      phone,
      gender: 'Male',
      status: 'ACTIVE'
    };

    this.userService
      .updateUser(
        this.userId,
        updateData
      )
      .subscribe({
        next: (
          updatedUser: UserResponse
        ) => {
          this.profile = {
            ...this.profile,

            name: this.formatName(
              updatedUser.name ||
              name
            ),

            email:
              updatedUser.email ||
              email,

            phone:
              updatedUser.phone ||
              phone,

            role: this.formatRole(
              updatedUser.roleName ||
              this.profile.role ||
              'Faculty'
            ),

            facultyId: String(
              updatedUser.userId ||
              this.userId
            )
          };

          this.updateStoredProfileDetails();

          this.showEditModal = false;
          this.editModel = {};

          this.showToast(
            'Profile updated successfully'
          );
        },

        error: (
          error: unknown
        ) => {
          console.error(
            'Failed to update profile:',
            error
          );

          this.showToast(
            this.getErrorMessage(
              error,
              'Failed to update profile'
            )
          );
        }
      });
  }

  openPwd(): void {
    this.currentPwd = '';
    this.newPwd = '';
    this.confirmPwd = '';
    this.pwdError = '';
    this.showPwdModal = true;
  }

  closePwd(): void {
    this.showPwdModal = false;
    this.currentPwd = '';
    this.newPwd = '';
    this.confirmPwd = '';
    this.pwdError = '';
  }

  savePwd(): void {
    this.pwdError = '';

    const currentPassword =
      this.currentPwd.trim();

    const newPassword =
      this.newPwd.trim();

    const confirmPassword =
      this.confirmPwd.trim();

    if (!currentPassword) {
      this.pwdError =
        'Enter current password';

      return;
    }

    if (!newPassword) {
      this.pwdError =
        'Enter a new password';

      return;
    }

    if (newPassword.length < 6) {
      this.pwdError =
        'New password must be at least 6 characters';

      return;
    }

    if (!confirmPassword) {
      this.pwdError =
        'Confirm the new password';

      return;
    }

    if (
      newPassword !==
      confirmPassword
    ) {
      this.pwdError =
        'Passwords do not match';

      return;
    }

    if (
      newPassword ===
      currentPassword
    ) {
      this.pwdError =
        'New password cannot be the same as the current password';

      return;
    }

    if (!this.isValidUserId()) {
      this.pwdError =
        'User ID not found. Please log in again.';

      return;
    }

    const request:
      ResetPasswordRequest = {
        oldPassword:
          currentPassword,

        newPassword,

        confirmPassword
      };

    this.userService
      .resetPassword(
        this.userId,
        request
      )
      .subscribe({
        next: (
          response: string
        ) => {
          if (
            response &&
            response !==
              'Password reset successfully'
          ) {
            this.pwdError =
              response;

            return;
          }

          this.closePwd();

          this.showToast(
            'Password updated successfully'
          );
        },

        error: (
          error: unknown
        ) => {
          console.error(
            'Password update error:',
            error
          );

          this.pwdError =
            this.getErrorMessage(
              error,
              'Password update failed'
            );
        }
      });
  }

  onPhotoSelected(
    event: Event
  ): void {
    const input =
      event.target as
        HTMLInputElement;

    const file =
      input.files?.[0];

    if (!file) {
      return;
    }

    const supportedTypes = [
      'image/png',
      'image/jpeg',
      'image/webp'
    ];

    if (
      !supportedTypes.includes(
        file.type
      )
    ) {
      this.showToast(
        'Please select a PNG, JPG, or WebP image.'
      );

      input.value = '';
      return;
    }

    const maximumFileSize =
      5 * 1024 * 1024;

    if (
      file.size >
      maximumFileSize
    ) {
      this.showToast(
        'Please select an image smaller than 5 MB.'
      );

      input.value = '';
      return;
    }

    if (!this.isValidUserId()) {
      this.showToast(
        'User ID not found. Please log in again.'
      );

      input.value = '';
      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      if (
        typeof reader.result !==
        'string'
      ) {
        this.showToast(
          'Unable to read the selected image'
        );

        input.value = '';
        return;
      }

      const image =
        new Image();

      image.onload = () => {
        const maximumDimension =
          200;

        let width =
          image.width;

        let height =
          image.height;

        if (
          width > height &&
          width > maximumDimension
        ) {
          height = Math.round(
            (
              height *
              maximumDimension
            ) / width
          );

          width =
            maximumDimension;
        } else if (
          height >= width &&
          height > maximumDimension
        ) {
          width = Math.round(
            (
              width *
              maximumDimension
            ) / height
          );

          height =
            maximumDimension;
        }

        const canvas =
          document.createElement(
            'canvas'
          );

        canvas.width = width;
        canvas.height = height;

        const context =
          canvas.getContext('2d');

        if (!context) {
          this.showToast(
            'Unable to process the selected image'
          );

          input.value = '';
          return;
        }

        context.drawImage(
          image,
          0,
          0,
          width,
          height
        );

        const compressedDataUrl =
          canvas.toDataURL(
            'image/jpeg',
            0.7
          );

        const base64String =
          compressedDataUrl
            .split(',')[1];

        if (!base64String) {
          this.showToast(
            'Unable to process the selected image'
          );

          input.value = '';
          return;
        }

        const updateData: User = {
          userId: this.userId,
          name: this.profile.name,
          email: this.profile.email,
          phone: this.profile.phone,
          gender: 'Male',
          status: 'ACTIVE',
          profileImage:
            base64String
        };

        this.userService
          .updateUser(
            this.userId,
            updateData
          )
          .subscribe({
            next: () => {
              this.profile = {
                ...this.profile,
                avatar:
                  compressedDataUrl
              };

              this.showToast(
                'Profile image updated'
              );

              input.value = '';
            },

            error: (
              error: unknown
            ) => {
              console.error(
                'Failed to upload profile image:',
                error
              );

              this.showToast(
                this.getErrorMessage(
                  error,
                  'Failed to update profile image'
                )
              );

              input.value = '';
            }
          });
      };

      image.onerror = () => {
        this.showToast(
          'Unable to process the selected image'
        );

        input.value = '';
      };

      image.src =
        reader.result;
    };

    reader.onerror = () => {
      this.showToast(
        'Unable to read the selected image'
      );

      input.value = '';
    };

    reader.readAsDataURL(file);
  }

  private formatName(
    name: string
  ): string {
    return (name || '')
      .trim()
      .toLowerCase()
      .replace(
        /\b\w/g,
        character =>
          character.toUpperCase()
      );
  }

  private formatRole(
    role: string
  ): string {
    const formattedRole =
      (role || '')
        .trim()
        .replace(/_/g, ' ')
        .toLowerCase()
        .replace(
          /\b\w/g,
          character =>
            character.toUpperCase()
        );

    return (
      formattedRole ||
      'Faculty'
    );
  }

  private isValidUserId():
    boolean {
    return (
      Number.isFinite(this.userId) &&
      this.userId > 0
    );
  }

  private updateStoredProfileDetails():
    void {
    this.storage.update(
      'userId',
      String(this.userId)
    );

    this.storage.update(
      'name',
      this.profile.name
    );

    this.storage.update(
      'userName',
      this.profile.name
    );

    this.storage.update(
      'email',
      this.profile.email
    );

    this.storage.update(
      'phone',
      this.profile.phone
    );

    this.storage.update(
      'role',
      this.profile.role ||
      'Faculty'
    );
  }

  private getProfileImage(
    profileImage?: string | Blob
  ): string | undefined {
    if (
      typeof profileImage !==
        'string' ||
      !profileImage.trim()
    ) {
      return undefined;
    }

    const image =
      profileImage.trim();

    if (
      image.startsWith(
        'data:image/'
      )
    ) {
      return image;
    }

    return (
      'data:image/jpeg;base64,' +
      image
    );
  }

  private isValidEmail(
    email: string
  ): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
      email
    );
  }

  private isValidPhone(
    phone: string
  ): boolean {
    return /^[0-9+\-\s()]{10,15}$/.test(
      phone
    );
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    if (
      typeof error === 'object' &&
      error !== null
    ) {
      const httpError =
        error as {
          error?:
            | string
            | {
                message?: string;
              };
          message?: string;
        };

      if (
        typeof httpError.error ===
          'object' &&
        httpError.error?.message
      ) {
        return (
          httpError.error.message
        );
      }

      if (
        typeof httpError.error ===
          'string' &&
        httpError.error
      ) {
        return httpError.error;
      }

      if (httpError.message) {
        return httpError.message;
      }
    }

    return fallbackMessage;
  }

  private showToast(
    message: string
  ): void {
    if (this.toastTimer) {
      clearTimeout(
        this.toastTimer
      );
    }

    this.toastMsg = message;

    this.toastTimer =
      setTimeout(() => {
        this.toastMsg = '';
      }, 2500);
  }
}