import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ActivatedRoute,
  Router,
  RouterModule
} from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { ToolInventoryService } from '../../../core/services/tool-inventory.service';
import { InventoryService } from '../../../core/services/inventory.service';
import { RequestsStatusComponent } from '../requests-status/requests-status.component';
import { MaterialReturnsComponent } from '../material-returns/material-returns.component';
import { AssetLogsComponent } from '../asset-logs/asset-logs.component';

type ToolsTab = 'requests' | 'returns' | 'logs';

@Component({
  selector: 'app-tools-management',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    RequestsStatusComponent,
    MaterialReturnsComponent,
    AssetLogsComponent
  ],
  templateUrl: './tools.component.html',
  styleUrls: ['./tools.component.css']
})
export class ToolsManagementComponent implements OnInit {

  // Available tabs: requests, returns, logs
  activeTab: ToolsTab = 'requests';

  requestsAwaitingHandover = 0;
  currentlyBorrowed = 0;
  returnsPendingVerification = 0;
  completedToday = 0;

  isLoading = false;

  constructor(
    private readonly toolInventoryService: ToolInventoryService,
    private readonly inventoryService: InventoryService,
    private readonly activatedRoute: ActivatedRoute,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.listenForTabNavigation();
    this.loadMetrics();
  }

  /**
   * Reads the selected Tools tab from the URL.
   *
   * Supported URLs:
   * /lab-incharge/tools?tab=requests
   * /lab-incharge/tools?tab=returns
   * /lab-incharge/tools?tab=logs
   */
  private listenForTabNavigation(): void {
    this.activatedRoute.queryParamMap.subscribe(params => {
      const requestedTab = params.get('tab');

      if (this.isValidTab(requestedTab)) {
        this.activeTab = requestedTab;
      }
    });
  }

  /**
   * Checks whether the tab value from the URL is valid.
   */
  private isValidTab(tab: string | null): tab is ToolsTab {
    return (
      tab === 'requests' ||
      tab === 'returns' ||
      tab === 'logs'
    );
  }

  loadMetrics(): void {
    this.isLoading = true;

    forkJoin({
      inventory: this.inventoryService
        .getAllInventory()
        .pipe(
          catchError(error => {
            console.error('Error loading inventory:', error);
            return of([]);
          })
        ),

      requests: this.toolInventoryService
        .getToolRequests()
        .pipe(
          catchError(error => {
            console.error('Error loading tool requests:', error);
            return of([]);
          })
        ),

      returns: this.toolInventoryService
        .getToolReturns()
        .pipe(
          catchError(error => {
            console.error('Error loading tool returns:', error);
            return of([]);
          })
        )
    })
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: res => {
          /*
           * Calculate requests awaiting handover.
           *
           * Included statuses:
           * PENDING
           * PARTIAL
           * Ready for Handover
           * Partially Handed Over
           */
          const pendingRequests = res.requests.filter(
            (request: any) =>
              request.approvalStatus === 'PENDING' ||
              request.approvalStatus === 'PARTIAL' ||
              request.approvalStatus === 'Ready for Handover' ||
              request.approvalStatus === 'Partially Handed Over'
          );

          this.requestsAwaitingHandover =
            pendingRequests.length;

          /*
           * Calculate currently borrowed tools.
           */
          const tools = res.inventory.filter(
            (item: any) => {
              const category =
                item.itemCategory?.toLowerCase() || '';

              return (
                category.includes('tool') ||
                category.includes('assembly') ||
                category.includes('testing') ||
                item.itemCategory === 'Tool'
              );
            }
          );

          const totalQuantity = tools.reduce(
            (sum: number, item: any) =>
              sum + Number(item.totalQuantity || 0),
            0
          );

          const availableQuantity = tools.reduce(
            (sum: number, item: any) =>
              sum + Number(item.availableQuantity || 0),
            0
          );

          this.currentlyBorrowed = Math.max(
            0,
            totalQuantity - availableQuantity
          );

          /*
           * Calculate returns pending verification.
           */
          const pendingReturns = res.returns.filter(
            (toolReturn: any) =>
              toolReturn.returnStatus === 'PENDING' ||
              toolReturn.returnStatus === 'Pending' ||
              toolReturn.returnStatus ===
                'Awaiting Verification'
          );

          this.returnsPendingVerification =
            pendingReturns.length;

          /*
           * Calculate requests and returns completed today.
           *
           * This creates the local date rather than using
           * toISOString(), which uses UTC and can return the
           * previous date in some time zones.
           */
          const today = new Date();

          const todayString = [
            today.getFullYear(),
            String(today.getMonth() + 1).padStart(2, '0'),
            String(today.getDate()).padStart(2, '0')
          ].join('-');

          const completedRequests = res.requests.filter(
            (request: any) => {
              const completedStatus =
                request.approvalStatus === 'ISSUED' ||
                request.approvalStatus === 'COMPLETED' ||
                request.approvalStatus ===
                  'Fully Handed Over';

              const completedToday =
                request.requestDate?.startsWith(todayString);

              return completedStatus && completedToday;
            }
          ).length;

          const completedReturns = res.returns.filter(
            (toolReturn: any) => {
              const completedStatus =
                toolReturn.returnStatus === 'COMPLETED' ||
                toolReturn.returnStatus === 'Completed';

              const completedToday =
                toolReturn.returnDate?.startsWith(todayString);

              return completedStatus && completedToday;
            }
          ).length;

          this.completedToday =
            completedRequests + completedReturns;
        },

        error: error => {
          console.error(
            'Error loading tools metrics:',
            error
          );
        }
      });
  }

  /**
   * Changes the active Tools tab and updates the URL.
   */
  selectTab(tab: ToolsTab): void {
    this.activeTab = tab;

    this.router.navigate([], {
      relativeTo: this.activatedRoute,
      queryParams: {
        tab
      },
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }
}