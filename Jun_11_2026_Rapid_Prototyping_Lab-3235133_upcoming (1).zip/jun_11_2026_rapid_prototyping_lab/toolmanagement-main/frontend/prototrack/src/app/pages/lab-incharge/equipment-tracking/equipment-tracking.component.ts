import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ActivatedRoute,
  Router,
  RouterModule
} from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import * as XLSX from 'xlsx';
import { StorageService } from '../../../core/services/storage.sevice';
import { EquipmentService } from '../../../core/services/equipment.service';
import {
  EquipmentMasterResponseDto,
  EquipmentResponseDto,
  EquipmentBookingResponseDto,
  EquipmentMaintenanceResponseDto,
  EquipmentMaintenanceRequestDto,
  EquipmentBookingResponseDto as BookingResponse,
  EquipmentMasterRequestDto,
  EquipmentRequestDto
} from '../../../core/models/equipment';
type EquipmentTrackingTab =
  | 'dashboard'
  | 'directory'
  | 'schedule'
  | 'maintenance'
  | 'approvals';
type ApprovalSubTab = 'pending' | 'history';
@Component({
  selector: 'app-equipment-tracking',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './equipment-tracking.component.html',
  styleUrl: './equipment-tracking.component.css'
})
export class EquipmentTrackingComponent implements OnInit {

  // Loading & Error States
  isLoading = false;
  loadError = '';
  actionMessage = '';
  actionError = '';

  // Core Data Lists
  equipmentMasters: EquipmentMasterResponseDto[] = [];
  equipments: EquipmentResponseDto[] = [];
  bookings: EquipmentBookingResponseDto[] = [];
  maintenanceRecords: EquipmentMaintenanceResponseDto[] = [];

// Active page tab
activeTab: EquipmentTrackingTab = 'dashboard';

// Approval Center sub-tab
approvalSubTab: ApprovalSubTab = 'pending';
  // Statistics
  stats = {
    totalMachines: 0,
    inUse: 0,
    available: 0,
    inMaintenance: 0,
    scheduledMaintenance: 0,
    pendingApproval: 0
  };

  // Search & Filter state for Directory
  searchQuery = '';
  selectedCategory: number | null = null;
  selectedStatusFilter = 'all'; // 'all', 'available', 'booked', 'maintenance'

  // Booking & Rejection details
  selectedBooking: EquipmentBookingResponseDto | null = null;
  rejectionReason = '';
  showRejectionModal = false;
  proposeAlternativeSlot = false;
  altBookingDate = '';
  altFromTime = '';
  altToTime = '';

  // New Maintenance Form state
  maintenanceForm = {
    equipmentMasterId: '',
    equipmentId: '',
    maintenanceType: 'Routine',
    maintenanceReason: '',
    startDate: '',
    endDate: '',
    remarks: ''
  };

  // Filtered lists
  filteredUnits: EquipmentResponseDto[] = [];

  // ==========================================
  // NEW FORMS & UPLOADER STATES
  // ==========================================
  showCreateMasterModal = false;
  showCreateUnitModal = false;
  showBulkUploadModal = false;

  newMasterForm = {
    equipmentCode: '',
    equipmentName: '',
    equipmentType: '',
    make: '',
    specification: '',
    lab: '',
    cost: '',
    remarks: '',
    status: 'Active'
  };

  newEquipmentForm = {
    equipmentMasterId: '',
    assetCode: '',
    serialNumber: '',
    location: '',
    purchaseDate: '',
    remarks: ''
  };

  selectedUploadFile: File | null = null;
  bulkUploadErrors: string[] = [];
  bulkUploadSuccessCount = 0;
  bulkUploadFailureCount = 0;

  // ==========================================
  // VISUAL CALENDAR SCHEDULING STATE
  // ==========================================
  calendarView: 'week' | 'day' = 'week';
  currentCalendarDate: Date = new Date();
  isSidebarCollapsed = false;
  activeSmartFilter: string | null = null;
  selectedClassFilters = new Set<string>();

  timelineHours = [
    { hour: 8, label: '08:00 AM' },
    { hour: 9, label: '09:00 AM' },
    { hour: 10, label: '10:00 AM' },
    { hour: 11, label: '11:00 AM' },
    { hour: 12, label: '12:00 PM' },
    { hour: 13, label: '01:00 PM' },
    { hour: 14, label: '02:00 PM' },
    { hour: 15, label: '03:00 PM' },
    { hour: 16, label: '04:00 PM' },
    { hour: 17, label: '05:00 PM' },
    { hour: 18, label: '06:00 PM' },
    { hour: 19, label: '07:00 PM' }
  ];

  timelineDays: any[] = [];
  miniCalendarDays: any[] = [];
  miniCalendarTitle = '';
  timelineHeading = '';

 constructor(
  private storage: StorageService,
  private readonly equipmentService: EquipmentService,
  private readonly activatedRoute: ActivatedRoute,
  private readonly router: Router
) {}

  ngOnInit(): void {
  this.listenForTabNavigation();

  this.initCalendarCategories();
  this.updateTimelineDays();
  this.updateMiniCalendar();
  this.loadData();
}
  loadData(): void {
  this.isLoading = true;
  this.loadError = '';

  forkJoin({
    masters: this.equipmentService
      .getEquipmentMasters()
      .pipe(catchError(() => of([]))),

    equipments: this.equipmentService
      .getEquipments()
      .pipe(catchError(() => of([]))),

    bookings: this.equipmentService
      .getBookings()
      .pipe(catchError(() => of([]))),

    maintenances: this.equipmentService
      .getMaintenanceRecords()
      .pipe(catchError(() => of([])))
  })
    .pipe(
      finalize(() => {
        this.isLoading = false;
      })
    )
    .subscribe({
      next: res => {
        this.equipmentMasters = res.masters;
        this.equipments = res.equipments;
        this.bookings = res.bookings;
        this.maintenanceRecords = res.maintenances;

        this.initCalendarCategories();
        this.calculateStats();
        this.updateTimelineDays();
        this.updateMiniCalendar();

        if (
          this.activeTab === 'directory' &&
          this.equipmentMasters.length > 0 &&
          !this.selectedCategory
        ) {
          this.selectedCategory =
            this.equipmentMasters[0].equipmentMasterId;
        }
      },

      error: err => {
        console.error(
          'Error loading equipment data:',
          err
        );

        this.loadError =
          'Failed to load equipment tracking data from backend.';
      }
    });
}

  calculateStats(): void {
    const total = this.equipments.length;
    const booked = this.equipments.filter(e => e.bookingStatus?.toUpperCase() === 'BOOKED').length;
    const free = this.equipments.filter(e => e.bookingStatus?.toUpperCase() === 'AVAILABLE').length;
    const maintenance = this.equipments.filter(e => e.maintenanceStatus?.toUpperCase() === 'UNDER_MAINTENANCE' || e.bookingStatus?.toUpperCase() === 'MAINTENANCE').length;
    
    const pendingAppr = this.bookings.filter(b => b.approvalStatus?.toLowerCase() === 'pending').length;
    const activeMaint = this.maintenanceRecords.filter(m => m.maintenanceStatus?.toUpperCase() !== 'COMPLETED').length;

    this.stats = {
      totalMachines: total,
      inUse: booked,
      available: free,
      inMaintenance: maintenance,
      scheduledMaintenance: activeMaint,
      pendingApproval: pendingAppr
    };
  }
private listenForTabNavigation(): void {
  this.activatedRoute.queryParamMap.subscribe(params => {
    const requestedTab = params.get('tab');

    if (this.isValidTab(requestedTab)) {
      this.applyTab(requestedTab);
    }
  });
}

private isValidTab(
  tab: string | null
): tab is EquipmentTrackingTab {
  return (
    tab === 'dashboard' ||
    tab === 'directory' ||
    tab === 'schedule' ||
    tab === 'maintenance' ||
    tab === 'approvals'
  );
}

private applyTab(tab: EquipmentTrackingTab): void {
  this.activeTab = tab;
  this.clearAlerts();

  if (tab === 'approvals') {
    this.approvalSubTab = 'pending';
  }

  if (
    tab === 'directory' &&
    this.equipmentMasters.length > 0 &&
    !this.selectedCategory
  ) {
    this.selectedCategory =
      this.equipmentMasters[0].equipmentMasterId;
  }

  if (tab === 'schedule') {
    this.updateTimelineDays();
    this.updateMiniCalendar();
  }
}

setTab(tab: EquipmentTrackingTab): void {
  this.applyTab(tab);

  this.router.navigate([], {
    relativeTo: this.activatedRoute,
    queryParams: {
      tab
    },
    queryParamsHandling: 'merge',
    replaceUrl: true
  });
}

  clearAlerts(): void {
    this.actionMessage = '';
    this.actionError = '';
  }

  getCurrentUserId(): number {
    
      const storedId = this.storage.get('userId');
      if (storedId && !isNaN(Number(storedId))) {
        return Number(storedId);
      }
      return 0;
    }


  selectCategory(masterId: number): void {
    this.selectedCategory = masterId;
  }

  get filteredEquipments(): EquipmentResponseDto[] {
    let list = this.equipments;

    if (this.selectedCategory) {
      list = list.filter(e => e.equipmentMasterId === this.selectedCategory);
    }

    if (this.selectedStatusFilter !== 'all') {
      list = list.filter(e => e.bookingStatus?.toLowerCase() === this.selectedStatusFilter);
    }

    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase();
      list = list.filter(e => 
        e.assetCode?.toLowerCase().includes(q) || 
        e.serialNumber?.toLowerCase().includes(q) ||
        e.equipmentName?.toLowerCase().includes(q) ||
        e.location?.toLowerCase().includes(q)
      );
    }

    return list;
  }

  onMaintenanceCategoryChange(): void {
    const masterId = Number(this.maintenanceForm.equipmentMasterId);
    if (!masterId) {
      this.filteredUnits = [];
      this.maintenanceForm.equipmentId = '';
      return;
    }
    this.filteredUnits = this.equipments.filter(e => e.equipmentMasterId === masterId);
    this.maintenanceForm.equipmentId = '';
  }

  scheduleMaintenance(): void {
    this.clearAlerts();
    const f = this.maintenanceForm;
    if (!f.equipmentId || !f.startDate || !f.endDate || !f.maintenanceReason) {
      this.actionError = 'Please fill all required fields marked with *';
      return;
    }

    const payload: EquipmentMaintenanceRequestDto = {
      equipmentId: Number(f.equipmentId),
      maintenanceType: f.maintenanceType,
      maintenanceReason: f.maintenanceReason,
      maintenanceStatus: 'Scheduled',
      startDate: f.startDate,
      endDate: f.endDate,
      maintainedBy: this.getCurrentUserId(),
      remarks: f.remarks || ''
    };

    this.isLoading = true;
    this.equipmentService.createMaintenance(payload)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (res) => {
          this.actionMessage = `Maintenance successfully scheduled for equipment unit #${res.equipmentId} (${res.assetCode})`;
          this.resetMaintenanceForm();
          this.loadData();
        },
        error: (err) => {
          console.error(err);
          this.actionError = err.error?.message || 'Error occurred while scheduling maintenance on the server.';
        }
      });
  }

  resetMaintenanceForm(): void {
    this.maintenanceForm = {
      equipmentMasterId: '',
      equipmentId: '',
      maintenanceType: 'Routine',
      maintenanceReason: '',
      startDate: '',
      endDate: '',
      remarks: ''
    };
    this.filteredUnits = [];
  }

  // ==========================================
  // CREATE EQUIPMENT CATEGORY (MASTER)
  // ==========================================
  openCreateMasterModal(): void {
    this.clearAlerts();
    this.newMasterForm = {
      equipmentCode: '',
      equipmentName: '',
      equipmentType: '',
      make: '',
      specification: '',
      lab: '',
      cost: '',
      remarks: '',
      status: 'Active'
    };
    this.showCreateMasterModal = true;
  }

  closeCreateMasterModal(): void {
    this.showCreateMasterModal = false;
  }

  submitCreateMaster(): void {
    this.clearAlerts();
    const f = this.newMasterForm;
    if (!f.equipmentCode || !f.equipmentName || !f.equipmentType || !f.make || !f.lab || !f.cost) {
      this.actionError = 'Please fill in all mandatory fields (*).';
      return;
    }

    const payload: EquipmentMasterRequestDto = {
      equipmentCode: f.equipmentCode,
      equipmentName: f.equipmentName,
      equipmentType: f.equipmentType,
      make: f.make,
      specification: f.specification,
      lab: f.lab,
      cost: Number(f.cost),
      remarks: f.remarks,
      status: f.status,
      totalQuantity: 0,
      equipmentImage: undefined, // Optional
      equipments: [] // Empty initial list of units
    };

    this.isLoading = true;
    this.equipmentService.createEquipmentMaster(payload)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (res) => {
          this.actionMessage = `New Equipment Category "${res.equipmentName}" created successfully with Code: ${res.equipmentCode}`;
          this.closeCreateMasterModal();
          this.loadData();
        },
        error: (err) => {
          console.error(err);
          this.actionError = err.error?.message || 'Failed to create new Equipment category.';
        }
      });
  }

  // ==========================================
  // CREATE SPECIFIC EQUIPMENT UNIT (ITEM)
  // ==========================================
  openCreateUnitModal(): void {
    this.clearAlerts();
    this.newEquipmentForm = {
      equipmentMasterId: this.selectedCategory ? this.selectedCategory.toString() : '',
      assetCode: '',
      serialNumber: '',
      location: '',
      purchaseDate: '',
      remarks: ''
    };
    this.showCreateUnitModal = true;
  }

  closeCreateUnitModal(): void {
    this.showCreateUnitModal = false;
  }

  submitCreateUnit(): void {
    this.clearAlerts();
    const f = this.newEquipmentForm;
    if (!f.equipmentMasterId || !f.assetCode || !f.serialNumber || !f.location || !f.purchaseDate) {
      this.actionError = 'Please fill in all mandatory fields (*).';
      return;
    }

    const payload: EquipmentRequestDto = {
      equipmentMasterId: Number(f.equipmentMasterId),
      assetCode: f.assetCode,
      serialNumber: f.serialNumber,
      bookingStatus: 'AVAILABLE', // Defaults to Available
      maintenanceStatus: 'OK', // Defaults to OK
      location: f.location,
      purchaseDate: f.purchaseDate,
      remarks: f.remarks
    };

    this.isLoading = true;
    this.equipmentService.createEquipment(payload)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (res) => {
          this.actionMessage = `Specific Equipment Unit created successfully with Asset Code: ${res.assetCode}`;
          this.closeCreateUnitModal();
          this.loadData();
        },
        error: (err) => {
          console.error(err);
          this.actionError = err.error?.message || 'Failed to register the specific equipment unit.';
        }
      });
  }

  // ==========================================
  // BULK UPLOAD FLOWS
  // ==========================================
  openBulkUploadModal(): void {
    this.clearAlerts();
    this.selectedUploadFile = null;
    this.bulkUploadErrors = [];
    this.bulkUploadSuccessCount = 0;
    this.bulkUploadFailureCount = 0;
    this.showBulkUploadModal = true;
  }

  closeBulkUploadModal(): void {
    this.showBulkUploadModal = false;
  }

  onFileSelected(event: any): void {
    const file: File = event.target.files[0];
    if (file) {
      this.selectedUploadFile = file;
    }
  }

  submitBulkUpload(): void {
    this.clearAlerts();
    this.bulkUploadErrors = [];
    if (!this.selectedUploadFile) {
      this.actionError = 'Please choose a file to upload first.';
      return;
    }

    this.isLoading = true;
    this.equipmentService.bulkUpload(this.selectedUploadFile)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (res) => {
          this.bulkUploadSuccessCount = res.successCount || 0;
          this.bulkUploadFailureCount = res.failureCount || 0;
          this.bulkUploadErrors = res.errors || [];
          
          if (this.bulkUploadFailureCount === 0) {
            this.actionMessage = `Bulk upload complete! Successfully imported ${this.bulkUploadSuccessCount} records.`;
            this.closeBulkUploadModal();
            this.loadData();
          } else {
            this.actionError = `Bulk upload completed with warnings. Imported: ${this.bulkUploadSuccessCount}, Failed: ${this.bulkUploadFailureCount}`;
          }
        },
        error: (err) => {
          console.error(err);
          this.actionError = err.error?.message || 'Failed to complete bulk upload. Ensure excel format is valid.';
        }
      });
  }

  // ==========================================
  // DOWNLOAD TEMPLATE EXCEL
  // ==========================================
  downloadTemplate(): void {
    const headers = [
      "Equipment Code", "Equipment Name", "Equipment Type", "Make", "Specification",
      "Lab", "Cost", "Status", "Asset Code", "Serial Number", "Booking Status",
      "Maintenance Status", "Location", "Purchase Date", "Remarks"
    ];

    const sampleRow = [
      "CREALITY-3D", "Creality Ender 3D Printer", "3D Printer", "Creality", "Print Volume: 220x220x250mm",
      "Rapid Prototyping Lab", 399.99, "Active", "EQ-3DP-99", "SN-CRE99-8877", "AVAILABLE",
      "OK", "Room 204", "2026-08-10", "Initial bulk upload batch unit"
    ];

    const worksheet = XLSX.utils.aoa_to_sheet([headers, sampleRow]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Template");

    XLSX.writeFile(workbook, "equipment_bulk_upload_template.xlsx");
    this.actionMessage = 'Equipment Excel upload template downloaded successfully!';
  }

  // ==========================================
  // BOOKING DETAILS / ACTIONS
  // ==========================================
  openBookingDetails(booking: EquipmentBookingResponseDto): void {
    this.selectedBooking = booking;
  }

  closeBookingDetails(): void {
    this.selectedBooking = null;
  }

  approveBooking(bookingId: number): void {
    this.clearAlerts();
    this.isLoading = true;
    const userId = this.getCurrentUserId();
    
    this.equipmentService.approveBooking(bookingId, userId)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (res) => {
          this.actionMessage = `Booking request #${bookingId} has been APPROVED successfully.`;
          this.closeBookingDetails();
          this.loadData();
        },
        error: (err) => {
          console.error(err);
          this.actionError = err.error?.message || 'Failed to approve booking request.';
        }
      });
  }

  openRejectionModal(booking: EquipmentBookingResponseDto): void {
    this.selectedBooking = booking;
    this.rejectionReason = '';
    this.proposeAlternativeSlot = false;
    this.altBookingDate = booking.bookingDate || '';
    this.altFromTime = booking.fromTime || '';
    this.altToTime = booking.toTime || '';
    this.showRejectionModal = true;
  }

  closeRejectionModal(): void {
    this.showRejectionModal = false;
    this.rejectionReason = '';
    this.proposeAlternativeSlot = false;
    this.altBookingDate = '';
    this.altFromTime = '';
    this.altToTime = '';
  }

  timeToMinutes(timeStr: string): number {
    if (!timeStr) return 0;
    const cleanTime = timeStr.trim().toUpperCase();
    const parts = cleanTime.split(':');
    let h = parseInt(parts[0], 10);
    let m = 0;
    if (parts[1]) {
      const minParts = parts[1].split(' ');
      m = parseInt(minParts[0], 10) || 0;
      const isPm = cleanTime.includes('PM');
      const isAm = cleanTime.includes('AM');
      if (isPm && h < 12) h += 12;
      if (isAm && h === 12) h = 0;
    }
    return h * 60 + m;
  }

  isSlotAvailable(equipmentId: number, dateStr: string, fromTime: string, toTime: string, skipBookingId: number): boolean {
    const proposedStart = this.timeToMinutes(fromTime);
    const proposedEnd = this.timeToMinutes(toTime);
    if (proposedStart >= proposedEnd) return false;

    const targetDate = new Date(dateStr);
    if (isNaN(targetDate.getTime())) return false;
    const targetDateKey = this.formatDateKey(targetDate);

    const overlappingBooking = this.bookings.find(b => {
      if (b.bookingId === skipBookingId) return false;
      if (b.equipmentId !== equipmentId) return false;

      const status = (b.approvalStatus || '').toLowerCase();
      if (status === 'rejected' || status === 'cancelled') return false;

      if (!b.bookingDate) return false;
      const bDateKey = this.formatDateKey(new Date(b.bookingDate));
      if (bDateKey !== targetDateKey) return false;

      const bStart = this.timeToMinutes(b.fromTime);
      const bEnd = this.timeToMinutes(b.toTime);

      return proposedStart < bEnd && proposedEnd > bStart;
    });

    return !overlappingBooking;
  }

  submitRejection(): void {
    this.clearAlerts();
    if (!this.selectedBooking) return;

    if (!this.proposeAlternativeSlot && !this.rejectionReason.trim()) {
      this.actionError = 'Rejection reason is required.';
      return;
    }

    const bookingId = this.selectedBooking.bookingId;
    const userId = this.getCurrentUserId();

    if (this.proposeAlternativeSlot) {
      if (!this.altBookingDate || !this.altFromTime || !this.altToTime) {
        this.actionError = 'Please specify all fields for the alternative slot (Date, From, To).';
        return;
      }

      // Check slot availability
      const available = this.isSlotAvailable(
        this.selectedBooking.equipmentId,
        this.altBookingDate,
        this.altFromTime,
        this.altToTime,
        bookingId
      );

      if (!available) {
        this.actionError = 'The proposed alternative slot conflicts with an existing booking. Please choose another date or time.';
        return;
      }

      const payload = {
        equipmentId: this.selectedBooking.equipmentId,
        projectId: this.selectedBooking.projectId,
        requestedBy: this.selectedBooking.requestedBy,
        bookingDate: this.altBookingDate,
        fromTime: this.altFromTime,
        toTime: this.altToTime,
        purpose: this.selectedBooking.purpose,
        remarks: `Rescheduled by Incharge: ${this.rejectionReason || 'Alternative slot assigned'}`
      };

      this.isLoading = true;
      this.equipmentService.updateBooking(bookingId, payload).subscribe({
        next: () => {
          this.equipmentService.approveBooking(bookingId, userId)
            .pipe(finalize(() => this.isLoading = false))
            .subscribe({
              next: () => {
                this.actionMessage = `Booking request #${bookingId} has been successfully rescheduled and APPROVED.`;
                this.closeRejectionModal();
                this.closeBookingDetails();
                this.loadData();
              },
              error: (err) => {
                console.error(err);
                this.actionError = err.error?.message || 'Slot was updated, but automatic approval failed.';
              }
            });
        },
        error: (err) => {
          console.error(err);
          this.actionError = err.error?.message || 'Failed to update booking to alternative slot.';
          this.isLoading = false;
        }
      });

    } else {
      this.isLoading = true;
      this.equipmentService.rejectBooking(bookingId, userId)
        .pipe(finalize(() => this.isLoading = false))
        .subscribe({
          next: (res) => {
            this.actionMessage = `Booking request #${bookingId} has been REJECTED.`;
            this.closeRejectionModal();
            this.closeBookingDetails();
            this.loadData();
          },
          error: (err) => {
            console.error(err);
            this.actionError = err.error?.message || 'Failed to reject booking request.';
          }
        });
    }
  }



  get pendingBookingsList(): EquipmentBookingResponseDto[] {
    return this.bookings.filter(b => b.approvalStatus?.toLowerCase() === 'pending');
  }

  get historyBookingsList(): EquipmentBookingResponseDto[] {
    return this.bookings.filter(b => b.approvalStatus?.toLowerCase() !== 'pending');
  }

  getStatusClass(status: string): string {
    if (!status) return 'badge--available';
    const s = status.toLowerCase();
    if (s === 'approved' || s === 'confirmed' || s === 'available' || s === 'ok' || s === 'issued') {
      return 'badge--available'; // Green
    }
    if (s === 'pending' || s === 'submitted' || s === 'waiting') {
      return 'badge--pending'; // Orange
    }
    if (s === 'rejected' || s === 'cancelled' || s === 'declined') {
      return 'badge--rejected'; // Red
    }
    if (s === 'booked' || s === 'in-use') {
      return 'badge--booked';
    }
    if (s === 'under_maintenance' || s === 'maintenance') {
      return 'badge--maintenance';
    }
    return 'badge--pending';
  }

  getCategoryName(masterId: number): string {
    const cat = this.equipmentMasters.find(m => m.equipmentMasterId === masterId);
    return cat ? cat.equipmentName : 'Equipment';
  }

  getUnitAssetCode(equipmentId: number): string {
    const eq = this.equipments.find(e => e.equipmentId === equipmentId);
    return eq ? eq.assetCode : `#${equipmentId}`;
  }

  // ==========================================================================
  // VISUAL CALENDAR TIMELINE & OVERLAP COLLISION ENGINE (100% DYNAMIC FROM DB)
  // ==========================================================================
  initCalendarCategories(): void {
    if (this.equipmentMasters && this.equipmentMasters.length > 0) {
      this.selectedClassFilters = new Set(this.equipmentMasters.map(m => String(m.equipmentMasterId)));
    }
  }

  get equipmentCategoriesList(): any[] {
    if (!this.equipmentMasters || this.equipmentMasters.length === 0) {
      return [];
    }

    const colorPalette = [
      'color-dot--blue',
      'color-dot--orange',
      'color-dot--green',
      'color-dot--purple',
      'color-dot--cyan',
      'color-dot--red',
      'color-dot--indigo'
    ];
    const classKeyPalette = [
      'eq-3d',
      'eq-laser',
      'eq-router',
      'eq-milling',
      'eq-lathe',
      'eq-saw',
      'eq-vacuum'
    ];

    return this.equipmentMasters.map((m, idx) => ({
      id: String(m.equipmentMasterId),
      name: m.equipmentName,
      colorClass: colorPalette[idx % colorPalette.length],
      classKey: classKeyPalette[idx % classKeyPalette.length]
    }));
  }

  updateTimelineDays(): void {
    this.timelineDays = [];
    const todayStr = this.formatDateKey(new Date());

    if (this.calendarView === 'week') {
      const current = new Date(this.currentCalendarDate);
      const dayOfWeek = current.getDay();
      const sunday = new Date(current);
      sunday.setDate(current.getDate() - dayOfWeek);

      for (let i = 0; i < 7; i++) {
        const d = new Date(sunday);
        d.setDate(sunday.getDate() + i);
        const dKey = this.formatDateKey(d);
        this.timelineDays.push({
          date: d,
          dateKey: dKey,
          dayName: d.toLocaleDateString('en-US', { weekday: 'short' }),
          dayNumber: d.getDate(),
          isToday: dKey === todayStr
        });
      }

      const start = this.timelineDays[0].date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const end = this.timelineDays[6].date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      this.timelineHeading = `${start} – ${end}`;
    } else {
      const dKey = this.formatDateKey(this.currentCalendarDate);
      this.timelineDays.push({
        date: new Date(this.currentCalendarDate),
        dateKey: dKey,
        dayName: this.currentCalendarDate.toLocaleDateString('en-US', { weekday: 'short' }),
        dayNumber: this.currentCalendarDate.getDate(),
        isToday: dKey === todayStr
      });
      this.timelineHeading = this.currentCalendarDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    }
  }

  updateMiniCalendar(): void {
    const y = this.currentCalendarDate.getFullYear();
    const m = this.currentCalendarDate.getMonth();
    this.miniCalendarTitle = this.currentCalendarDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

    const firstDay = new Date(y, m, 1).getDay();
    const totalDays = new Date(y, m + 1, 0).getDate();
    const prevMonthTotalDays = new Date(y, m, 0).getDate();
    const todayStr = this.formatDateKey(new Date());
    const selectedStr = this.formatDateKey(this.currentCalendarDate);

    const days: any[] = [];

    // Prev month padding
    for (let i = firstDay; i > 0; i--) {
      days.push({
        dayNumber: prevMonthTotalDays - i + 1,
        disabled: true,
        isToday: false,
        isSelected: false
      });
    }

    // Current month active days
    for (let d = 1; d <= totalDays; d++) {
      const dObj = new Date(y, m, d);
      const dKey = this.formatDateKey(dObj);
      days.push({
        dayNumber: d,
        date: dObj,
        disabled: false,
        isToday: dKey === todayStr,
        isSelected: dKey === selectedStr
      });
    }

    this.miniCalendarDays = days;
  }

  onMiniDayClick(dayItem: any): void {
    if (dayItem.disabled || !dayItem.date) return;
    this.currentCalendarDate = new Date(dayItem.date);
    this.updateMiniCalendar();
    this.updateTimelineDays();
  }

  navigateTimeline(step: number): void {
    const offset = this.calendarView === 'week' ? step * 7 : step;
    this.currentCalendarDate.setDate(this.currentCalendarDate.getDate() + offset);
    this.updateTimelineDays();
    this.updateMiniCalendar();
  }

  navigateMiniMonth(step: number): void {
    this.currentCalendarDate.setMonth(this.currentCalendarDate.getMonth() + step);
    this.updateMiniCalendar();
    this.updateTimelineDays();
  }

  resetToToday(): void {
    this.currentCalendarDate = new Date();
    this.updateTimelineDays();
    this.updateMiniCalendar();
  }

  toggleSmartFilter(filter: string): void {
    this.activeSmartFilter = this.activeSmartFilter === filter ? null : filter;
  }

  toggleClassFilter(catKey: string): void {
    if (this.selectedClassFilters.has(catKey)) {
      this.selectedClassFilters.delete(catKey);
    } else {
      this.selectedClassFilters.add(catKey);
    }
  }

  toggleAllClassFilters(): void {
    if (this.isAllClassFiltersSelected()) {
      this.selectedClassFilters.clear();
    } else {
      this.equipmentCategoriesList.forEach(c => this.selectedClassFilters.add(c.id));
    }
  }

  isAllClassFiltersSelected(): boolean {
    return this.equipmentCategoriesList.length > 0 && this.selectedClassFilters.size === this.equipmentCategoriesList.length;
  }

  // ==========================================================================
  // SIDE-BY-SIDE OVERLAP POSITIONING FOR SIMULTANEOUS BOOKINGS (DYNAMIC)
  // ==========================================================================
  getDayBookingsPositioned(dateKey: string): any[] {
    const dayBookings = this.bookings.filter(b => {
      if (!b.bookingDate) return false;
      const bDate = this.formatDateKey(new Date(b.bookingDate));
      if (bDate !== dateKey) return false;

      // Smart filter check
      if (this.activeSmartFilter === 'confirmed' && b.approvalStatus?.toLowerCase() !== 'approved' && b.approvalStatus?.toLowerCase() !== 'confirmed') {
        return false;
      }
      if (this.activeSmartFilter === 'pending' && b.approvalStatus?.toLowerCase() !== 'pending') {
        return false;
      }

      // Dynamic class filter check via equipment's master ID
      const eq = this.equipments.find(e => e.equipmentId === b.equipmentId);
      if (eq && eq.equipmentMasterId && this.selectedClassFilters.size > 0) {
        if (!this.selectedClassFilters.has(String(eq.equipmentMasterId))) {
          return false;
        }
      }

      return true;
    });

    if (dayBookings.length === 0) return [];

    // Parse start hour & duration dynamically
    const parsed = dayBookings.map(b => {
      const startHour = this.parseHour(b.fromTime) || 9;
      const endHour = this.parseHour(b.toTime) || (startHour + 2);
      const duration = Math.max(1, endHour - startHour);
      return { booking: b, startHour, duration };
    });

    // Sort by start hour
    parsed.sort((a, b) => a.startHour - b.startHour || b.duration - a.duration);

    // Group overlapping clusters
    const clusters: any[][] = [];
    let currentCluster: any[] = [];
    let clusterEnd = -1;

    parsed.forEach(item => {
      const end = item.startHour + item.duration;
      if (currentCluster.length === 0 || item.startHour < clusterEnd) {
        currentCluster.push(item);
        clusterEnd = Math.max(clusterEnd, end);
      } else {
        clusters.push(currentCluster);
        currentCluster = [item];
        clusterEnd = end;
      }
    });
    if (currentCluster.length > 0) clusters.push(currentCluster);

    // Calculate side-by-side widths and left offsets dynamically
    const result: any[] = [];
    clusters.forEach(cluster => {
      const totalCols = cluster.length;
      cluster.forEach((item, colIdx) => {
        const widthPct = totalCols > 1 ? (100 / totalCols) - 1.2 : 96;
        const leftPct = totalCols > 1 ? (colIdx * (100 / totalCols)) + 0.6 : 2;
        const topPx = (item.startHour - 8) * 64 + 2;
        const heightPx = Math.max(36, item.duration * 64 - 4);

        // Resolve dynamic classKey from matching equipmentMaster in DB
        let classKey = 'eq-3d';
        const eq = this.equipments.find(e => e.equipmentId === item.booking.equipmentId);
        if (eq && eq.equipmentMasterId) {
          const masterCat = this.equipmentCategoriesList.find(c => c.id === String(eq.equipmentMasterId));
          if (masterCat) {
            classKey = masterCat.classKey;
          }
        }

        const rawStatus = (item.booking.approvalStatus || 'APPROVED').toLowerCase();
        let statusTagClass = 'approved';
        if (rawStatus === 'pending' || rawStatus === 'submitted' || rawStatus === 'waiting') {
          statusTagClass = 'pending';
        } else if (rawStatus === 'rejected' || rawStatus === 'cancelled' || rawStatus === 'declined') {
          statusTagClass = 'rejected';
        } else {
          statusTagClass = 'approved';
        }

        result.push({
          booking: item.booking,
          topPx,
          heightPx,
          widthPct,
          leftPct,
          isOverlapping: totalCols > 1,
          classKey,
          statusTagClass
        });
      });
    });

    return result;
  }

  parseHour(timeStr: string): number {
    if (!timeStr) return 9;
    const parts = timeStr.split(':');
    let h = parseInt(parts[0], 10);
    if (timeStr.toUpperCase().includes('PM') && h < 12) h += 12;
    if (timeStr.toUpperCase().includes('AM') && h === 12) h = 0;
    return isNaN(h) ? 9 : h;
  }

  formatDateKey(date: Date): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  onEmptySlotClick(day: any, hourObj: any): void {
    this.maintenanceForm.startDate = `${day.dateKey}T${String(hourObj.hour).padStart(2, '0')}:00`;
    this.setTab('maintenance');
  }
}
