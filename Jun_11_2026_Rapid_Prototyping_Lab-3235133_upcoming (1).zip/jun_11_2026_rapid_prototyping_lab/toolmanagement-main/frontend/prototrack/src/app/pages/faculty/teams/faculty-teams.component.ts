import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, forkJoin, of } from 'rxjs';


import { FacultyService } from '../../../core/services/faculty.service';
import { DocumentKnowledgeService } from '../../../core/services/document-knowledge.service';
import { ProjectService } from '../../../core/services/project.service';
import { UserService } from '../../../core/services/user.service';
import { environment } from '../../../../environments/environment';

import {
  FacultyTeamView,
  ProjectStage,
  TeamMember,
  DocumentResponse
} from '../../../core/models/faculty';

import {
  UserResponse
} from '../../../core/models/user';

import { ToastService } from '../../../core/services/toast.service';
import { StorageService } from '../../../core/services/storage.sevice';

@Component({
  selector: 'app-faculty-teams',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './faculty-teams.component.html',
  styleUrl: './faculty-teams.component.css'
})
export class FacultyTeamsComponent implements OnInit {

  teams: FacultyTeamView[] = [];
  filteredTeams: FacultyTeamView[] = [];

  selectedTeam: FacultyTeamView | null = null;
  selectedStage: ProjectStage | null = null;

  reviewMode: 'view' | 'review' = 'view';
  reviewComment = '';

  selectedBatch = 'all';
  batches: string[] = [];
  searchText = '';

  selectedMember: TeamMember | null = null;
  showMemberModal = false;

  showKbConfirmModal = false;
  pendingKbStage: ProjectStage | null = null;

  editingDeadlineStageNo: number | null = null;
  tempDeadline = '';

  isInitializingStages = false;
  toastMessage = '';
  loading = false;
  errorMessage = '';

  stageDocuments: DocumentResponse[] = [];
  loadingDoc = false;

  usersById = new Map<number, UserResponse>();
  facultyId!:number;
  

  constructor(
    private storage: StorageService,
    private facultyService: FacultyService,
    private documentKnowledgeService: DocumentKnowledgeService,
    private projectService: ProjectService,
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private toastService: ToastService
  ) {}

  ngOnInit(): void {
    this.facultyId = Number(this.storage.get('userId'));
    this.loadTeams();
  }

  loadTeams(): void {
    this.loading = true;
    this.errorMessage = '';

    forkJoin({
      teams: this.facultyService.getFacultyTeams(this.facultyId),
      users: this.userService.getAllUsers().pipe(
        catchError(error => {
          console.warn(
            'Unable to load users for name mapping:',
            error
          );

          return of([] as UserResponse[]);
        })
      )
    }).subscribe({
      next: ({ teams, users }) => {
        this.usersById.clear();

        for (const user of users || []) {
          this.usersById.set(Number(user.userId), user);
        }

        this.teams = teams;
        this.extractBatches(teams);
        this.filterTeams();
        this.loading = false;

        this.route.queryParams.subscribe(params => {
          if (params['projectId']) {
            const target = this.teams.find(
              team =>
                team.project.projectId ===
                Number(params['projectId'])
            );

            if (target) {
              this.openTeam(target);
            }
          }
        });
      },
      error: (err) => {
        console.error('Failed to load teams:', err);
        this.errorMessage = 'Unable to load teams from backend.';
        this.loading = false;
      }
    });
  }

  extractBatches(teams: FacultyTeamView[]): void {
    const set = new Set<string>();

    teams.forEach(team => {
      set.add(this.getBatchName(team.project?.batchId));
    });

    this.batches = Array.from(set).sort();
  }

  filterTeams(): void {
    const query = this.searchText.trim().toLowerCase();

    this.filteredTeams = this.teams.filter(team => {
      const batch = this.getBatchName(team.project?.batchId);

      const matchesBatch =
        this.selectedBatch === 'all' ||
        batch === this.selectedBatch;

      const matchesQuery =
        !query ||
        team.project.projectName.toLowerCase().includes(query) ||
        team.project.projectId.toString().includes(query) ||
        (team.project.description || '').toLowerCase().includes(query);

      return matchesBatch && matchesQuery;
    });
  }

  onBatchChange(): void {
    this.filterTeams();
  }

  searchTeams(): void {
    this.filterTeams();
  }

  clearSearch(): void {
    this.searchText = '';
    this.selectedBatch = 'all';
    this.filterTeams();
  }

  openTeam(team: FacultyTeamView): void {
    this.selectedTeam = team;
    this.selectedStage = null;
  }

  closeTeam(): void {
    this.selectedTeam = null;
    this.selectedStage = null;
  }

  openStageModal(
    stage: ProjectStage,
    mode: 'view' | 'review' = 'view'
  ): void {
    this.selectedStage = stage;
    this.reviewMode = mode;

    /*
     * Faculty feedback should not be pre-filled.
     * Faculty must enter fresh remarks for every review.
     */
    this.reviewComment = '';

    this.stageDocuments = [];
    this.loadingDoc = true;

    this.facultyService
      .getDocumentsByProjectStageId(stage.projectStageId)
      .subscribe({
        next: (docs) => {
          this.stageDocuments = docs || [];
          this.loadingDoc = false;
        },
        error: (err) => {
          console.error(
            'Failed to load documents for stage:',
            err
          );

          this.stageDocuments = [];
          this.loadingDoc = false;
        }
      });
  }

  closeStageModal(): void {
    this.selectedStage = null;
    this.reviewComment = '';
    this.stageDocuments = [];
    this.loadingDoc = false;
  }

  get stageDocumentsByVersion(): {
    versionNo: number;
    documents: DocumentResponse[];
  }[] {
    const versionMap =
      new Map<number, DocumentResponse[]>();

    for (const document of this.stageDocuments || []) {
      const versionNo =
        Math.max(1, Number(document.versionNo) || 1);

      const documents =
        versionMap.get(versionNo) || [];

      versionMap.set(versionNo, [
        ...documents,
        document
      ]);
    }

    return Array.from(versionMap.entries())
      .sort(
        ([firstVersion], [secondVersion]) =>
          secondVersion - firstVersion
      )
      .map(([versionNo, documents]) => ({
        versionNo,
        documents: documents.sort(
          (first, second) =>
            this.getDateValue(second.uploadedAt) -
            this.getDateValue(first.uploadedAt)
        )
      }));
  }

  viewUploadedDocument(doc?: DocumentResponse): void {
    const filename =
      doc?.fileName ||
      doc?.originalFileName ||
      this.getDocPreviewName();

    this.showToast(`Opening document: ${filename}`);

    if (doc?.documentId) {
      window.open(
        `${environment.apiBaseUrl}/api/documents/${doc.documentId}/view`,
        '_blank'
      );
    }
  }

  startEditDeadline(event: Event, stage: ProjectStage): void {
    event.stopPropagation();

    this.editingDeadlineStageNo =
      stage.stageMaster?.stageNo || 0;

    this.tempDeadline = stage.stageDeadline || '';
  }

  cancelEditDeadline(event: Event): void {
    event.stopPropagation();

    this.editingDeadlineStageNo = null;
    this.tempDeadline = '';
  }

  saveDeadline(event: Event, stage: ProjectStage): void {
    event.stopPropagation();

    if (!this.tempDeadline) {
      return;
    }

    stage.stageDeadline = this.tempDeadline;

    this.facultyService.updateProjectStage(stage).subscribe({
      next: () => {
        this.showToast(
          `Deadline updated for Stage ${stage.stageMaster?.stageNo}.`
        );

        this.editingDeadlineStageNo = null;
      },
      error: (err) => {
        console.error('Failed to update deadline:', err);
        this.showToast('Failed to update deadline.');
      }
    });
  }

  reviewSubmission(newStatus: string): void {
    if (!this.selectedStage || !this.selectedTeam) {
      return;
    }

    const normalizedStatus =
      (newStatus || '').trim().toUpperCase();

    const requiresFeedback =
      normalizedStatus === 'APPROVED' ||
      normalizedStatus === 'REJECTED';

    if (requiresFeedback && !this.reviewComment.trim()) {
      this.toastService.showWarning('Please enter remarks before submitting review.');
      return;
    }

    const stageNo =
      this.selectedStage.stageMaster?.stageNo;

    const isLast =
      this.isFinalStage(this.selectedStage, this.selectedTeam);

    const updatedStage: ProjectStage = {
      ...this.selectedStage,
      submissionStatus: normalizedStatus,
      reviewedBy: this.facultyId,
      reviewedOn: new Date().toISOString(),
      remarks: this.reviewComment.trim()
    };

    /*
     * Do not increment version number in frontend.
     * Backend Project_Stage_Service_Implementation handles version increment
     * when faculty rejects the submitted version.
     */
    const currentVersion =
      Math.max(
        1,
        Number(this.selectedStage.versionNo) || 1
      );

    const currentVersionDocuments =
      this.stageDocuments.filter(
        document =>
          Math.max(
            1,
            Number(document.versionNo) || 1
          ) === currentVersion
      );

    const reviewTargetDocument =
      currentVersionDocuments.length > 0
        ? currentVersionDocuments[0]
        : this.getLatestDocument();

    const docId =
      reviewTargetDocument?.documentId ?? 1;

    this.documentKnowledgeService.addFacultyReview({
      projectStageId: this.selectedStage.projectStageId,
      facultyId: this.facultyId,
      documentId: docId,
      reviewStatus: normalizedStatus,
      reviewComment: this.reviewComment.trim()
    }).subscribe({
      next: (response) => {
        console.log(
          'Saved to faculty_review table successfully:',
          response
        );
      },
      error: (error) => {
        console.warn(
          'faculty_review table insert note:',
          error
        );
      }
    });

    this.facultyService.updateProjectStage(updatedStage).subscribe({
      next: (savedStage) => {
        this.selectedStage!.submissionStatus = normalizedStatus;
        this.selectedStage!.remarks = this.reviewComment.trim();

        if (savedStage?.versionNo !== undefined) {
          this.selectedStage!.versionNo = savedStage.versionNo;
        }

        if (this.selectedTeam) {
          const approvedCount =
            this.selectedTeam.stages.filter(
              stage =>
                (stage.submissionStatus || '').toUpperCase() ===
                'APPROVED'
            ).length;

          this.selectedTeam.progress =
            Math.round(
              (approvedCount / this.selectedTeam.stages.length) * 100
            );
        }

        this.closeStageModal();

        if (normalizedStatus === 'APPROVED') {
          if (isLast) {
            this.pendingKbStage = updatedStage;
            this.showKbConfirmModal = true;
          } else {
            this.toastService.showSuccess(`Stage ${stageNo} approved. Student can proceed to next stage.`);
          }
        } else if (newStatus === 'REJECTED') {
          this.toastService.showWarning(`Stage ${stageNo} rejected. Student must resubmit.`);
        } else {
          this.toastService.showInfo(`Stage ${stageNo} marked for rework.`);
        }
      },
      error: (err) => {
        console.error('Failed to update stage review:', err);
        this.toastService.showError('Failed to submit stage review.');
      }
    });
  }

  private getLatestDocument(): DocumentResponse | undefined {
    return [...this.stageDocuments]
      .sort(
        (first, second) =>
          this.getDateValue(second.uploadedAt) -
          this.getDateValue(first.uploadedAt)
      )[0];
  }

  confirmKbUpload(): void {
    if (this.selectedTeam && this.pendingKbStage) {
      const docTitle =
        `${this.pendingKbStage.stageMaster?.stageName || 'Final-Report'}-` +
        `${this.selectedTeam.project.projectName}.pdf`;

      this.showToast(
        `Saved "${docTitle}" to Knowledge Base!`
      );
    }

    this.showKbConfirmModal = false;
    this.pendingKbStage = null;
  }

  skipKbUpload(): void {
    this.showToast('Skipped uploading to Knowledge Base.');
    this.showKbConfirmModal = false;
    this.pendingKbStage = null;
  }

  openMemberModal(member: TeamMember): void {
    this.selectedMember = member;
    this.showMemberModal = true;
  }

  closeMemberModal(): void {
    this.selectedMember = null;
    this.showMemberModal = false;
  }

  promoteToSPOC(member: TeamMember): void {
    if (!this.selectedTeam) {
      return;
    }

    const currentScrum =
      this.getScrumMember(this.selectedTeam.members);

    if (currentScrum) {
      this.facultyService
        .changeScrum(
          this.selectedTeam.project.projectId,
          currentScrum.traineeId,
          member.traineeId
        )
        .subscribe({
          next: () => {
            currentScrum.memberRole = 'Member';
            member.memberRole = 'Scrum';

            this.showToast(
              `${this.getMemberDisplayName(member)} is now Scrum.`
            );

            this.closeMemberModal();
          },
          error: (err) => {
            console.error('Failed to set Scrum:', err);

            currentScrum.memberRole = 'Member';
            member.memberRole = 'Scrum';

            this.showToast(
              `${this.getMemberDisplayName(member)} is now Scrum.`
            );

            this.closeMemberModal();
          }
        });
    } else {
      member.memberRole = 'Scrum';

      this.showToast(
        `${this.getMemberDisplayName(member)} is now Scrum.`
      );

      this.closeMemberModal();
    }
  }

  get currentTeams(): FacultyTeamView[] {
    return this.filteredTeams.filter(
      team => team.progress < 100
    );
  }

  get completedTeams(): FacultyTeamView[] {
    return this.filteredTeams.filter(
      team => team.progress === 100
    );
  }

  get completedCount(): number {
    return this.teams.filter(
      team => team.progress === 100
    ).length;
  }

  get inProgressCount(): number {
    return this.teams.filter(
      team =>
        team.progress > 0 &&
        team.progress < 100
    ).length;
  }

  get notStartedCount(): number {
    return this.teams.filter(
      team => team.progress === 0
    ).length;
  }

  getApprovedStagesCount(team: FacultyTeamView): number {
    return team.stages.filter(
      stage =>
        (stage.submissionStatus || '').toUpperCase() ===
        'APPROVED'
    ).length;
  }

  isFinalStage(
    stage: ProjectStage,
    team: FacultyTeamView
  ): boolean {
    if (!team.stages || team.stages.length === 0) {
      return false;
    }

    const maxStageNo =
      Math.max(
        ...team.stages.map(
          item => item.stageMaster?.stageNo || 0
        )
      );

    return (stage.stageMaster?.stageNo || 0) === maxStageNo;
  }

  getStatusClass(status: string): string {
    const normalized =
      (status || '').trim().toUpperCase();

    if (normalized === 'APPROVED') {
      return 'status-approved';
    }

    if (normalized === 'SUBMITTED') {
      return 'status-submitted';
    }

    if (
      normalized === 'IN_PROGRESS' ||
      normalized === 'UNDER REVIEW'
    ) {
      return 'status-review';
    }

    if (normalized === 'REJECTED') {
      return 'status-rejected';
    }

    if (normalized === 'REWORK_REQUIRED') {
      return 'status-rework';
    }

    if (
      normalized === 'NOT_STARTED' ||
      normalized === 'LOCKED'
    ) {
      return 'status-locked';
    }

    return 'status-draft';
  }

  getStatusLabel(status: string): string {
    const st = (status || '').trim().toUpperCase();
    if (st === 'APPROVED') return 'Approved';
    if (st === 'IN_PROGRESS') return 'In Progress';
    if (st === 'UNDER REVIEW') return 'Under Review';
    if (st === 'SUBMITTED') return 'Uploaded & Awaiting Review';
    if (st === 'REJECTED') return 'Rejected';
    if (st === 'REWORK_REQUIRED') return 'Rework Required';
    if (st === 'NOT_STARTED' || st === 'LOCKED') return 'Locked';
    return status || 'Draft';
  }

  isScrumMember(
    member: TeamMember | null | undefined
  ): boolean {
    const role =
      (member?.memberRole || '').trim().toLowerCase();

    return role === 'scrum' || role === 'spoc';
  }

  getScrumMember(members: TeamMember[]): TeamMember | null {
    if (!members) {
      return null;
    }

    return members.find(
      member => this.isScrumMember(member)
    ) || null;
  }

  getScrumDisplayName(members: TeamMember[]): string {
    const scrumMember =
      this.getScrumMember(members);

    if (!scrumMember) {
      return 'Not Assigned';
    }

    return this.getUserDisplayNameById(
      scrumMember.traineeId,
      'Not Assigned'
    );
  }

  getMemberDisplayName(member: TeamMember): string {
    return this.getUserDisplayNameById(
      member.traineeId,
      `Trainee #${member.traineeId}`
    );
  }

  getFacultyDisplayName(
    team: FacultyTeamView | null
  ): string {
    if (!team?.project?.facultyId) {
      return 'Not Assigned';
    }

    return this.getUserDisplayNameById(
      team.project.facultyId,
      'Not Assigned'
    );
  }

  getLoggedInFacultyDisplayName(): string {
    return this.getUserDisplayNameById(
      this.facultyId,
      'Faculty'
    );
  }

  getMemberRoleLabel(
    role: string | null | undefined
  ): string {
    const normalized =
      (role || '').trim().toLowerCase();

    if (
      normalized === 'spoc' ||
      normalized === 'scrum'
    ) {
      return 'Scrum';
    }

    return this.toTitleCase(role || 'Member');
  }

  getMemberInitials(member: TeamMember): string {
    const name =
      this.getMemberDisplayName(member);

    if (!name || name.startsWith('Trainee #')) {
      return `T${member.traineeId}`;
    }

    return name
      .split(' ')
      .filter(part => part.trim())
      .slice(0, 2)
      .map(part => part.charAt(0).toUpperCase())
      .join('');
  }

  getUserDisplayNameById(
    userId: number | null | undefined,
    fallback = 'Not Available'
  ): string {
    if (!userId) {
      return fallback;
    }

    const user =
      this.usersById.get(Number(userId));

    if (!user?.name) {
      return fallback;
    }

    return this.toTitleCase(user.name);
  }

  toTitleCase(
    value: string | null | undefined
  ): string {
    if (!value || !value.trim()) {
      return 'Not Available';
    }

    return value
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .map(word =>
        word.charAt(0).toUpperCase() + word.slice(1)
      )
      .join(' ');
  }

  getBatchName(batchId?: number): string {
    if (!batchId) {
      return 'Batch 01';
    }

    const padded =
      batchId < 10
        ? `0${batchId}`
        : `${batchId}`;

    return `Batch ${padded}`;
  }

  getDocPreviewName(): string {
    if (!this.selectedStage?.stageMaster?.stageName) {
      return 'document.pdf';
    }

    const cleanStage =
      this.selectedStage.stageMaster.stageName
        .replace(/\s+/g, '-');

    const cleanProject =
      (this.selectedTeam?.project?.projectName || 'Project')
        .replace(/\s+/g, '-');

    return `${cleanStage}-${cleanProject}.pdf`;
  }

  showToast(msg: string): void {
    this.toastMessage = msg;

    setTimeout(() => {
      this.toastMessage = '';
    }, 3000);
  }

  initializeProjectStages(projectId: number): void {
    if (!projectId || this.isInitializingStages) {
      return;
    }

    this.isInitializingStages = true;

    this.projectService.initializeProjectStages(projectId).subscribe({
      next: (response) => {
        console.log(
          `Project ${projectId} stages initialized successfully:`,
          response
        );

        this.isInitializingStages = false;

        this.showToast(
          'Project stages initialized successfully! Workflow is now active.'
        );

        this.loadTeams();

        if (this.selectedTeam) {
          this.facultyService
            .getFacultyTeams(this.facultyId)
            .subscribe(teams => {
              const updated =
                teams.find(
                  team =>
                    team.project.projectId === projectId
                );

              if (updated) {
                this.selectedTeam = updated;
              }
            });
        }
      },
      error: (err) => {
        console.error(
          'Failed to initialize project stages:',
          err
        );

        this.isInitializingStages = false;
        const msg = typeof err.error === 'string' ? err.error : err.error?.message || 'Stages may already be initialized.';
        this.toastService.showError(msg);
      }
    });
  }

  private getDateValue(
    dateValue: string | Date | null | undefined
  ): number {
    if (!dateValue) {
      return 0;
    }

    const value =
      new Date(dateValue).getTime();

    return Number.isNaN(value) ? 0 : value;
  }
}