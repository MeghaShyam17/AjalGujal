import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  Input,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import { ComponentInventoryService } from
  '../../../core/services/component-inventory.service';
import { ToolInventoryService } from
  '../../../core/services/tool-inventory.service';
import { UserService } from
  '../../../core/services/user.service';
import { ProjectService } from
  '../../../core/services/project.service';
import { InventoryService } from
  '../../../core/services/inventory.service';
import { StorageService } from '../../../core/services/storage.sevice';

export type RequestType = 'tool' | 'component';

export type RequestStatus =
  | 'Ready for Handover'
  | 'Partially Handed Over'
  | 'Fully Handed Over';

export interface RequestMaterial {
  materialId: string;
  name: string;
  category: string;
  requestedQty: number;
  handedOverQty: number;
  remainingQty: number;
  unit: string;
}

export interface HandoverLog {
  handoverNumber: number;
  timestamp: string;
  handedOverBy: string;
  materials: Array<{
    materialId: string;
    name: string;
    qty: number;
  }>;
}

export interface MaterialRequest {
  requestId: string;
  rawId?: number;
  requestDate: string;
  requestTime?: string;
  teamId: string;
  teamName: string;
  teamLeader: string;
  faculty: string;
  project: string;
  materials: RequestMaterial[];
  handoverHistory?: HandoverLog[];
}

export interface RequestCounts {
  pending: number;
  partial: number;
  completed: number;
}

type MainView = 'dashboard' | 'queue';

type DialogView =
  | 'none'
  | 'verification'
  | 'confirmation'
  | 'history'
  | 'success';

@Component({
  selector: 'app-requests-status',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './requests-status.component.html',
  styleUrls: ['./requests-status.component.css']
})
export class RequestsStatusComponent implements OnInit {
  @Input() type: RequestType = 'tool';
  @Input() isEmbedded = false;

  view: MainView = 'dashboard';
  dialog: DialogView = 'none';

  activeType: RequestType = 'tool';
  isDirectRoute = false;

  toolRequests: MaterialRequest[] = [];
  componentRequests: MaterialRequest[] = [];

  selectedRequest: MaterialRequest | null = null;

  quantities: Record<string, number> = {};
  confirmedPhysicalHandover = false;

  searchTerm = '';
  facultyFilter = 'all';
  statusFilter = 'all';
  dateFilter = '';
  sortOrder: 'oldest' | 'latest' = 'oldest';

  currentPage = 1;
  readonly pageSize = 10;

  todayHandedOverItems = 0;

  isLoading = false;
  isHandoverSubmitting = false;

  loadError = '';
  handoverError = '';

  userNamesMap: Record<number, string> = {};
  projectNamesMap: Record<number, string> = {};

  inventoryStockMap: Record<string, number> = {};
  inventoryNamesMap: Record<number, string> = {};

  constructor(
    private storage: StorageService,
    private componentInventoryService: ComponentInventoryService,
    private toolInventoryService: ToolInventoryService,
    private userService: UserService,
    private projectService: ProjectService,
    private inventoryService: InventoryService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    if (this.isEmbedded) {
      this.activeType = this.type;
      this.view = 'queue';
      this.isDirectRoute = true;
    } else {
      const currentUrl = window.location.pathname;

      if (currentUrl.includes('tool-requests')) {
        this.activeType = 'tool';
        this.view = 'queue';
        this.isDirectRoute = true;
      } else if (
        currentUrl.includes('component-requests')
      ) {
        this.activeType = 'component';
        this.view = 'queue';
        this.isDirectRoute = true;
      }
    }

    this.loadRequests();
  }

  private loadRequests(): void {
    this.isLoading = true;
    this.loadError = '';

    this.userService.getAllUsers().subscribe({
      next: (users: any[]) => {
        this.userNamesMap = {};

        (users || []).forEach((user: any) => {
          const id = Number(
            user.userId || user.id
          );

          const name =
            user.name ||
            user.userName ||
            user.fullName ||
            user.email ||
            '';

          if (id) {
            this.userNamesMap[id] =
              name || `User #${id}`;
          }
        });

        this.loadProjectsAndInventory();
      },

      error: (error: any) => {
        console.error(
          'Failed to load users:',
          error
        );

        this.loadProjectsAndInventory();
      }
    });
  }

  private loadProjectsAndInventory(): void {
    this.projectService.getAllProjects().subscribe({
      next: (projects: any[]) => {
        this.projectNamesMap = {};

        (projects || []).forEach((project: any) => {
          const id = Number(
            project.projectId || project.id
          );

          const name =
            project.projectName ||
            project.name ||
            '';

          if (id) {
            this.projectNamesMap[id] =
              name || `Project #${id}`;
          }
        });

        this.loadInventoryAndRequestQueues();
      },

      error: (error: any) => {
        console.error(
          'Failed to load projects:',
          error
        );

        this.loadInventoryAndRequestQueues();
      }
    });
  }

  private loadInventoryAndRequestQueues(): void {
    this.inventoryService
      .getAllInventory()
      .subscribe({
        next: (items: any[]) => {
          this.inventoryStockMap = {};
          this.inventoryNamesMap = {};

          (items || []).forEach((item: any) => {
            const id = Number(
              item.itemId || item.id
            );

            const availableStock = Number(
              item.availableQuantity ??
              item.availableStock ??
              item.available ??
              0
            );

            const name =
              item.itemName ||
              item.name ||
              '';

            if (id) {
              this.inventoryStockMap[String(id)] =
                Math.max(availableStock, 0);

              this.inventoryNamesMap[id] =
                name || `Item ${id}`;
            }
          });

          this.loadComponentRequests();
          this.loadToolRequests();
        },

        error: (error: any) => {
          console.error(
            'Failed to load inventory:',
            error
          );

          this.inventoryStockMap = {};
          this.inventoryNamesMap = {};

          this.loadComponentRequests();
          this.loadToolRequests();
        }
      });
  }

  private loadComponentRequests(): void {
    this.componentInventoryService
      .getComponentRequests()
      .subscribe({
        next: (response: any) => {
          const data = Array.isArray(response)
            ? response
            : response?.data || [];

          this.componentRequests = data.map(
            (request: any) =>
              this.mapComponentRequest(request)
          );

          this.isLoading = false;
          this.cdr.markForCheck();
        },

        error: (error: any) => {
          console.error(
            'Component request error:',
            error
          );

          this.loadError =
            'Failed to load component requests.';

          this.isLoading = false;
          this.cdr.markForCheck();
        }
      });
  }

  private loadToolRequests(): void {
    this.toolInventoryService
      .getToolRequests()
      .subscribe({
        next: (response: any) => {
          const data = Array.isArray(response)
            ? response
            : response?.data || [];

          this.toolRequests = data.map(
            (request: any) =>
              this.mapToolRequest(request)
          );

          this.isLoading = false;
          this.cdr.markForCheck();
        },

        error: (error: any) => {
          console.error(
            'Tool request error:',
            error
          );

          this.loadError =
            'Failed to load tool requests.';

          this.isLoading = false;
          this.cdr.markForCheck();
        }
      });
  }

  private mapComponentRequest(
    request: any
  ): MaterialRequest {
    return {
      requestId:
        `REQ-CMP-${request.componentRequestId}`,

      rawId: Number(
        request.componentRequestId
      ),

      requestDate: request.requestDate
        ? request.requestDate.split('T')[0]
        : '',

      requestTime: request.requestDate
        ? new Date(
            request.requestDate
          ).toLocaleTimeString('en-IN')
        : '',

      teamId:
        `TEAM-${request.projectId}`,

      teamName:
        this.projectNamesMap[
          Number(request.projectId)
        ] || `Project #${request.projectId}`,

      teamLeader:
        this.userNamesMap[
          Number(request.requestedBy)
        ] || `Student #${request.requestedBy}`,

      faculty:
        this.userNamesMap[
          Number(request.facultyId)
        ] || `Faculty #${request.facultyId}`,

      project:
        this.projectNamesMap[
          Number(request.projectId)
        ] || `Project #${request.projectId}`,

      materials: this.extractRequestItems(
        request
      ).map(
        (item: any, index: number) =>
          this.mapRequestMaterial(
            item,
            index,
            'Component'
          )
      ),

      handoverHistory:
        request.handoverHistory || []
    };
  }
  private firstPositiveNumber(
  ...values: unknown[]
): number {
  for (const value of values) {
    const parsedValue = Number(value);

    if (
      Number.isFinite(parsedValue) &&
      parsedValue > 0
    ) {
      return parsedValue;
    }
  }

  return 0;
}

private mapToolRequest(request: any): MaterialRequest {
  const requestItems = this.extractRequestItems(request);

  const projectId = Number(
    request.project?.projectId ??
    request.projectId ??
    0
  );

  const facultyId = Number(
    request.project?.facultyId ??
    request.facultyId ??
    0
  );

  const teamLeaderId = Number(
    request.project?.teamLeaderId ??
    request.teamLeaderId ??
    request.requestedBy ??
    0
  );

  const projectName =
    request.project?.projectName ??
    request.projectName ??
    this.projectNamesMap[projectId] ??
    `Project #${projectId}`;

  const facultyName =
    facultyId > 0
      ? this.userNamesMap[facultyId] ?? `Faculty #${facultyId}`
      : 'Not Assigned';

  const teamLeaderName =
    teamLeaderId > 0
      ? this.userNamesMap[teamLeaderId] ??
        request.user?.name ??
        `User #${teamLeaderId}`
      : request.user?.name ?? 'Not Assigned';

  return {
    requestId: `REQ-TOL-${request.toolRequestId}`,

    rawId: Number(request.toolRequestId),

    requestDate: request.requestDate
      ? request.requestDate.split('T')[0]
      : '',

    requestTime: request.requestDate
      ? new Date(request.requestDate).toLocaleTimeString(
          'en-IN',
          {
            hour: 'numeric',
            minute: '2-digit',
            second: '2-digit'
          }
        )
      : '',

    teamId: projectId > 0
      ? `TEAM-${projectId}`
      : 'TEAM-N/A',

    teamName: projectName,

    teamLeader: teamLeaderName,

    faculty: facultyName,

    project: projectName,

    materials: requestItems.map(
      (item: any, index: number) => {
        const requestedQty =
          this.firstPositiveNumber(
            item.approvedQuantity,
            item.requestedQuantity,
            item.approvedQty,
            item.requestedQty,
            item.requestQuantity,
            item.quantityRequested,
            item.toolQuantity,
            item.approved_quantity,
            item.requested_quantity,
            item.quantity
          );

        const handedOverQty = Math.max(
          Number(
            item.issuedQuantity ??
            item.handedOverQuantity ??
            item.issuedQty ??
            item.handedOverQty ??
            item.issueQuantity ??
            0
          ),
          0
        );

        const rawItemId =
          item.itemId ??
          item.inventoryItemId ??
          item.toolItemId ??
          item.toolId ??
          item.materialId ??
          index + 1;

        const itemId = Number(rawItemId);

        const mappedName =
          this.inventoryNamesMap[itemId];

        const name =
          item.itemName ??
          item.toolName ??
          item.name ??
          mappedName ??
          `Tool ${itemId}`;

        return {
          materialId: String(itemId),
          name,
          category: 'Tool',
          requestedQty,
          handedOverQty,

          remainingQty: Math.max(
            requestedQty - handedOverQty,
            0
          ),

          unit:
            item.unit ??
            item.unitName ??
            'Nos'
        };
      }
    ),

    handoverHistory:
      request.handoverHistory ?? []
  };
}

  private mapRequestMaterial(
    item: any,
    index: number,
    category: 'Component' | 'Tool'
  ): RequestMaterial {
    /*
     * Nullish coalescing is important here.
     * A valid quantity of zero must not fall through
     * to another property.
     */
    const requestedQty = Number(
      item.approvedQuantity ??
      item.requestedQuantity ??
      item.quantity ??
      0
    );

    const handedOverQty = Number(
      item.issuedQuantity ??
      item.handedOverQuantity ??
      0
    );

    const rawItemId =
      item.itemId ??
      item.componentId ??
      item.toolId ??
      item.materialId ??
      index + 1;

    const itemId = Number(rawItemId);

    const mappedName =
      this.inventoryNamesMap[itemId];

    const name =
      item.itemName ??
      item.componentName ??
      item.toolName ??
      item.name ??
      mappedName ??
      `${category} ${itemId}`;

    return {
      materialId: String(itemId),
      name,
      category,
      requestedQty,
      handedOverQty,

      remainingQty: Math.max(
        requestedQty - handedOverQty,
        0
      ),

      unit: item.unit ?? 'Nos'
    };
  }

  private extractRequestItems(
    request: any
  ): any[] {
    const items =
      request.requestItems ??
      request.items ??
      request.componentRequestItems ??
      request.toolRequestItems ??
      request.materials ??
      [];

    return Array.isArray(items)
      ? items
      : [];
  }

  get activeRequests(): MaterialRequest[] {
    return this.activeType === 'tool'
      ? this.toolRequests
      : this.componentRequests;
  }

  get toolCounts(): RequestCounts {
    return this.counts(this.toolRequests);
  }

  get componentCounts(): RequestCounts {
    return this.counts(
      this.componentRequests
    );
  }

  get faculties(): string[] {
    const faculties = [
      ...this.toolRequests,
      ...this.componentRequests
    ]
      .map(
        (request: MaterialRequest) =>
          request.faculty
      )
      .filter(Boolean);

    return [...new Set(faculties)].sort();
  }

  get toolSummary(): number {
    return (
      this.toolCounts.pending +
      this.toolCounts.partial
    );
  }

  get componentSummary(): number {
    return (
      this.componentCounts.pending +
      this.componentCounts.partial
    );
  }

  get awaitingItems(): number {
    return [
      ...this.toolRequests,
      ...this.componentRequests
    ].reduce(
      (
        requestTotal: number,
        request: MaterialRequest
      ) =>
        requestTotal +
        request.materials.reduce(
          (
            materialTotal: number,
            material: RequestMaterial
          ) =>
            materialTotal +
            material.remainingQty,
          0
        ),
      0
    );
  }

  get filteredRequests(): MaterialRequest[] {
    const query =
      this.searchTerm.trim().toLowerCase();

    return this.activeRequests
      .filter(
        (request: MaterialRequest) => {
          const searchableContent = [
            request.requestId,
            request.teamId,
            request.teamName,
            request.teamLeader,
            request.project,
            request.faculty
          ]
            .join(' ')
            .toLowerCase();

          const currentStatus =
            this.status(request);

          const matchesSearch =
            !query ||
            searchableContent.includes(query);

          const matchesFaculty =
            this.facultyFilter === 'all' ||
            request.faculty ===
              this.facultyFilter;

          const matchesStatus =
            this.statusFilter === 'all' ||
            this.statusKey(currentStatus) ===
              this.statusFilter;

          const matchesDate =
            !this.dateFilter ||
            request.requestDate ===
              this.dateFilter;

          return (
            matchesSearch &&
            matchesFaculty &&
            matchesStatus &&
            matchesDate
          );
        }
      )
      .sort(
        (
          first: MaterialRequest,
          second: MaterialRequest
        ) => {
          const comparison =
            first.requestDate.localeCompare(
              second.requestDate
            );

          return this.sortOrder === 'latest'
            ? comparison * -1
            : comparison;
        }
      );
  }

  get totalPages(): number {
    return Math.max(
      1,
      Math.ceil(
        this.filteredRequests.length /
        this.pageSize
      )
    );
  }

  get pagedRequests(): MaterialRequest[] {
    const startIndex =
      (this.currentPage - 1) *
      this.pageSize;

    return this.filteredRequests.slice(
      startIndex,
      startIndex + this.pageSize
    );
  }

  get pageStart(): number {
    if (
      this.filteredRequests.length === 0
    ) {
      return 0;
    }

    return (
      (this.currentPage - 1) *
        this.pageSize +
      1
    );
  }

  get pageEnd(): number {
    return Math.min(
      this.currentPage * this.pageSize,
      this.filteredRequests.length
    );
  }

  get pages(): number[] {
    const visiblePageCount = Math.min(
      5,
      this.totalPages
    );

    const maximumStartPage = Math.max(
      1,
      this.totalPages -
        visiblePageCount +
        1
    );

    const startPage = Math.max(
      1,
      Math.min(
        this.currentPage - 2,
        maximumStartPage
      )
    );

    return Array.from(
      { length: visiblePageCount },
      (_, index: number) =>
        startPage + index
    );
  }

  openQueue(type: RequestType): void {
    this.activeType = type;
    this.resetFilters();
    this.view = 'queue';
  }

  backToDashboard(): void {
    if (this.isDirectRoute) {
      return;
    }

    this.view = 'dashboard';
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.facultyFilter = 'all';
    this.statusFilter = 'all';
    this.dateFilter = '';
    this.sortOrder = 'oldest';
    this.currentPage = 1;
  }

  filtersChanged(): void {
    this.currentPage = 1;
  }

  goToPage(page: number): void {
    this.currentPage = Math.min(
      Math.max(page, 1),
      this.totalPages
    );
  }

  status(
    request: MaterialRequest
  ): RequestStatus {
    const totalHandedOver =
      request.materials.reduce(
        (
          total: number,
          material: RequestMaterial
        ) =>
          total +
          Number(
            material.handedOverQty || 0
          ),
        0
      );

    const totalRemaining =
      request.materials.reduce(
        (
          total: number,
          material: RequestMaterial
        ) =>
          total +
          Number(material.remainingQty || 0),
        0
      );

    if (totalHandedOver === 0) {
      return 'Ready for Handover';
    }

    if (totalRemaining === 0) {
      return 'Fully Handed Over';
    }

    return 'Partially Handed Over';
  }

  statusKey(
    status: RequestStatus
  ): 'ready' | 'partial' | 'completed' {
    if (status === 'Ready for Handover') {
      return 'ready';
    }

    if (
      status === 'Partially Handed Over'
    ) {
      return 'partial';
    }

    return 'completed';
  }

  statusLabel(
    request: MaterialRequest
  ): string {
    const currentStatus =
      this.status(request);

    if (
      currentStatus ===
      'Ready for Handover'
    ) {
      return 'Awaiting Handover';
    }

    if (
      currentStatus ===
      'Partially Handed Over'
    ) {
      return 'Partial';
    }

    return 'Handed Over';
  }

  statusClass(
    request: MaterialRequest
  ): string {
    const key = this.statusKey(
      this.status(request)
    );

    return key === 'completed'
      ? 'badge badge-done'
      : `badge badge-${key}`;
  }

  actionLabel(
    request: MaterialRequest
  ): string {
    const currentStatus =
      this.status(request);

    if (
      currentStatus ===
      'Fully Handed Over'
    ) {
      return 'View';
    }

    if (
      currentStatus ===
      'Partially Handed Over'
    ) {
      return 'Continue';
    }

    return this.activeType === 'tool'
      ? 'Hand Over Tools'
      : 'Hand Over Components';
  }

  openRequest(
    request: MaterialRequest
  ): void {
    this.selectedRequest = request;
    this.handoverError = '';
    this.isHandoverSubmitting = false;

    if (
      this.status(request) ===
      'Fully Handed Over'
    ) {
      this.dialog = 'history';
      return;
    }

    this.quantities = {};

    request.materials.forEach(
      (material: RequestMaterial) => {
        this.quantities[
          material.materialId
        ] = 0;
      }
    );

    this.confirmedPhysicalHandover =
      false;

    this.dialog = 'verification';
  }

  closeDialog(): void {
    if (this.isHandoverSubmitting) {
      return;
    }

    this.dialog = 'none';
    this.selectedRequest = null;
    this.quantities = {};
    this.confirmedPhysicalHandover =
      false;
    this.handoverError = '';
  }

  getAvailableStock(
    material: RequestMaterial
  ): number {
    const stock = Number(
      this.inventoryStockMap[
        material.materialId
      ] ?? 0
    );

    return Math.max(stock, 0);
  }

  isOutOfStock(
    material: RequestMaterial
  ): boolean {
    return (
      this.getAvailableStock(material) <= 0
    );
  }
  canSelectMaterial(
  material: RequestMaterial
): boolean {
  const availableStock =
    this.getAvailableStock(material);

  const remainingQuantity =
    Number(material.remainingQty) || 0;

  return (
    availableStock > 0 &&
    remainingQuantity > 0 &&
    !this.isHandoverSubmitting
  );
}

  maxHandover(
    material: RequestMaterial
  ): number {
    const availableStock =
      this.getAvailableStock(material);

    const remainingQuantity = Math.max(
      Number(material.remainingQty) || 0,
      0
    );

    return Math.min(
      remainingQuantity,
      availableStock
    );
  }

 quantityChanged(
  material: RequestMaterial
): void {
  const materialId =
    material.materialId;

  if (!this.canSelectMaterial(material)) {
    this.quantities[materialId] = 0;
    return;
  }

  const enteredQuantity = Number(
    this.quantities[materialId]
  ) || 0;

  const maximumAllowed =
    this.maxHandover(material);

  this.quantities[materialId] =
    Math.min(
      Math.max(
        Math.floor(enteredQuantity),
        0
      ),
      maximumAllowed
    );

  this.handoverError = '';
}
toggleMaterial(
  material: RequestMaterial,
  checked: boolean
): void {
  if (
    checked &&
    !this.canSelectMaterial(material)
  ) {
    this.quantities[
      material.materialId
    ] = 0;

    if (this.isOutOfStock(material)) {
      this.handoverError =
        `${material.name} is out of stock and cannot be handed over.`;
    } else {
      this.handoverError =
        `${material.name} has no remaining requested quantity to hand over.`;
    }

    return;
  }

  this.quantities[
    material.materialId
  ] = checked
    ? this.maxHandover(material)
    : 0;

  this.handoverError = '';
}

  get selectedMaterials(): RequestMaterial[] {
    if (!this.selectedRequest) {
      return [];
    }

    return this.selectedRequest.materials.filter(
      (material: RequestMaterial) =>
        Number(
          this.quantities[
            material.materialId
          ]
        ) > 0
    );
  }

  get canContinue(): boolean {
    if (this.isHandoverSubmitting) {
      return false;
    }

    if (
      this.selectedMaterials.length === 0
    ) {
      return false;
    }

    return this.selectedMaterials.every(
      (material: RequestMaterial) => {
        const quantity = Number(
          this.quantities[
            material.materialId
          ]
        ) || 0;

        return (
          quantity > 0 &&
          !this.isOutOfStock(material) &&
          quantity <=
            this.maxHandover(material)
        );
      }
    );
  }

  get totalRequested(): number {
    return (
      this.selectedRequest?.materials.reduce(
        (
          total: number,
          material: RequestMaterial
        ) =>
          total +
          Number(
            material.requestedQty || 0
          ),
        0
      ) ?? 0
    );
  }

  get totalAlready(): number {
    return (
      this.selectedRequest?.materials.reduce(
        (
          total: number,
          material: RequestMaterial
        ) =>
          total +
          Number(
            material.handedOverQty || 0
          ),
        0
      ) ?? 0
    );
  }

  get totalToday(): number {
    return Object.values(
      this.quantities
    ).reduce(
      (
        total: number,
        quantity: number
      ) =>
        total +
        (Number(quantity) || 0),
      0
    );
  }

  get totalRemaining(): number {
    return Math.max(
      this.totalRequested -
        this.totalAlready -
        this.totalToday,
      0
    );
  }

  remainingAfterHandover(
    material: RequestMaterial
  ): number {
    const quantity = Number(
      this.quantities[
        material.materialId
      ]
    ) || 0;

    return Math.max(
      material.remainingQty - quantity,
      0
    );
  }

  private validateSelectedMaterials():
    string | null {
    if (
      this.selectedMaterials.length === 0
    ) {
      return 'Select at least one material to hand over.';
    }

    for (
      const material of
      this.selectedMaterials
    ) {
      const availableStock =
        this.getAvailableStock(material);

      const quantity = Number(
        this.quantities[
          material.materialId
        ]
      ) || 0;

      const maximumAllowed =
        this.maxHandover(material);

      if (availableStock <= 0) {
        this.quantities[
          material.materialId
        ] = 0;

        return `${material.name} is out of stock and cannot be handed over.`;
      }

      if (quantity <= 0) {
        return `Enter a valid handover quantity for ${material.name}.`;
      }

      if (quantity > availableStock) {
        this.quantities[
          material.materialId
        ] = availableStock;

        return `${material.name} has only ${availableStock} ${material.unit} available.`;
      }

      if (
        quantity >
        material.remainingQty
      ) {
        this.quantities[
          material.materialId
        ] = material.remainingQty;

        return `${material.name} has only ${material.remainingQty} ${material.unit} remaining in this request.`;
      }

      if (quantity > maximumAllowed) {
        this.quantities[
          material.materialId
        ] = maximumAllowed;

        return `The maximum quantity allowed for ${material.name} is ${maximumAllowed} ${material.unit}.`;
      }
    }

    return null;
  }

  showConfirmation(): void {
    this.handoverError = '';

    const validationError =
      this.validateSelectedMaterials();

    if (validationError) {
      this.handoverError =
        validationError;

      return;
    }

    this.confirmedPhysicalHandover =
      false;

    this.dialog = 'confirmation';
  }

  backToVerification(): void {
    if (this.isHandoverSubmitting) {
      return;
    }

    this.handoverError = '';
    this.confirmedPhysicalHandover =
      false;
    this.dialog = 'verification';
  }
confirmHandover(): void {
  this.handoverError = '';

  if (!this.selectedRequest) {
    this.handoverError =
      'No request is selected.';
    return;
  }

  if (!this.confirmedPhysicalHandover) {
    this.handoverError =
      'Confirm the physical handover before continuing.';
    return;
  }

  if (this.isHandoverSubmitting) {
    return;
  }

  const validationError =
    this.validateSelectedMaterials();

  if (validationError) {
    this.handoverError =
      validationError;

    this.confirmedPhysicalHandover =
      false;

    this.dialog = 'verification';
    return;
  }

  const selectedRequest =
    this.selectedRequest;

  const rawId =
    selectedRequest.rawId ||
    Number(
      selectedRequest.requestId.replace(
        /\D/g,
        ''
      )
    );

  if (!rawId) {
    this.handoverError =
      'Invalid request ID.';
    return;
  }

  const loggedInUserId = Number(
    this.storage.get('userId')
  );

  if (!loggedInUserId) {
    this.handoverError =
      'Logged-in user information is unavailable. Please sign in again.';
    return;
  }

  const isTool =
    selectedRequest.requestId.includes(
      'TOL'
    );

  /*
   * Create a copy of the selected materials.
   * Do not update the request or inventory before
   * the backend API confirms success.
   */
  const handedMaterials =
    this.selectedMaterials.map(
      (material: RequestMaterial) => ({
        materialId:
          material.materialId,

        name:
          material.name,

        qty: Number(
          this.quantities[
            material.materialId
          ]
        )
      })
    );

  const payload =
    handedMaterials.map(
      material => ({
        itemId: Number(
          material.materialId
        ),

        qty:
          material.qty
      })
    );

  this.isHandoverSubmitting = true;

  /*
   * Shared success handler.
   */
  const handleSuccess = (): void => {
    this.isHandoverSubmitting = false;

    this.completeSuccessfulHandover(
      selectedRequest,
      handedMaterials,
      loggedInUserId
    );

    this.cdr.markForCheck();
  };

  /*
   * Shared error handler.
   */
  const handleError = (
    error: any
  ): void => {
    console.error(
      'Handover API failed:',
      error
    );

    this.isHandoverSubmitting = false;
    this.confirmedPhysicalHandover =
      false;

    this.handoverError =
      this.getHandoverErrorMessage(
        error
      );

    /*
     * Return to material verification so the Lab
     * Incharge can correct the selected quantities.
     */
    this.dialog = 'verification';

    this.cdr.markForCheck();
  };

  /*
   * Do not store both Observable types in one variable.
   *
   * Tool and component issueRequest methods may return
   * different response DTO types. Keeping the subscriptions
   * in separate branches prevents an incompatible union type.
   */
  if (isTool) {
    this.toolInventoryService
      .issueRequest(
        rawId,
        loggedInUserId,
        payload
      )
      .subscribe({
        next: () => {
          handleSuccess();
        },

        error: (
          error: any
        ) => {
          handleError(error);
        }
      });
  } else {
    this.componentInventoryService
      .issueRequest(
        rawId,
        loggedInUserId,
        payload
      )
      .subscribe({
        next: () => {
          handleSuccess();
        },

        error: (
          error: any
        ) => {
          handleError(error);
        }
      });
  }
}
  private completeSuccessfulHandover(
    selectedRequest: MaterialRequest,
    handedMaterials: Array<{
      materialId: string;
      name: string;
      qty: number;
    }>,
    loggedInUserId: number
  ): void {
    handedMaterials.forEach(
      (handedMaterial) => {
        const requestMaterial =
          selectedRequest.materials.find(
            (
              material: RequestMaterial
            ) =>
              material.materialId ===
              handedMaterial.materialId
          );

        if (!requestMaterial) {
          return;
        }

        requestMaterial.handedOverQty +=
          handedMaterial.qty;

        requestMaterial.remainingQty =
          Math.max(
            requestMaterial.remainingQty -
              handedMaterial.qty,
            0
          );

        const currentStock = Number(
          this.inventoryStockMap[
            handedMaterial.materialId
          ] ?? 0
        );

        this.inventoryStockMap[
          handedMaterial.materialId
        ] = Math.max(
          currentStock -
            handedMaterial.qty,
          0
        );
      }
    );

    if (
      !selectedRequest.handoverHistory
    ) {
      selectedRequest.handoverHistory =
        [];
    }

    selectedRequest.handoverHistory.push({
      handoverNumber:
        selectedRequest.handoverHistory
          .length + 1,

      timestamp:
        new Date().toLocaleString(
          'en-IN'
        ),

      handedOverBy:
        this.userNamesMap[
          loggedInUserId
        ] || `User #${loggedInUserId}`,

      materials: handedMaterials
    });

    this.todayHandedOverItems +=
      handedMaterials.reduce(
        (total: number, material) =>
          total + material.qty,
        0
      );

    this.handoverError = '';
    this.dialog = 'success';

    /*
     * Reload fresh request and stock data.
     */
    this.loadRequests();
  }

  private getHandoverErrorMessage(
    error: any
  ): string {
    if (
      typeof error?.error === 'string'
    ) {
      return error.error;
    }

    if (error?.error?.message) {
      return error.error.message;
    }

    if (error?.message) {
      return error.message;
    }

    return 'The handover could not be completed. Please check the available stock and try again.';
  }

  closeSuccess(): void {
    if (this.isHandoverSubmitting) {
      return;
    }

    this.dialog = 'none';
    this.selectedRequest = null;
    this.quantities = {};
    this.confirmedPhysicalHandover =
      false;
    this.handoverError = '';
  }

  formatDate(value: string): string {
    if (!value) {
      return '—';
    }

    const parsedDate =
      new Date(value);

    if (
      Number.isNaN(
        parsedDate.getTime()
      )
    ) {
      return value;
    }

    return new Intl.DateTimeFormat(
      'en-GB',
      {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }
    ).format(parsedDate);
  }

  private counts(
    requests: MaterialRequest[]
  ): RequestCounts {
    return requests.reduce<RequestCounts>(
      (
        requestCounts: RequestCounts,
        request: MaterialRequest
      ) => {
        const currentStatus =
          this.status(request);

        if (
          currentStatus ===
          'Ready for Handover'
        ) {
          requestCounts.pending++;
        } else if (
          currentStatus ===
          'Partially Handed Over'
        ) {
          requestCounts.partial++;
        } else {
          requestCounts.completed++;
        }

        return requestCounts;
      },
      {
        pending: 0,
        partial: 0,
        completed: 0
      }
    );
  }
}