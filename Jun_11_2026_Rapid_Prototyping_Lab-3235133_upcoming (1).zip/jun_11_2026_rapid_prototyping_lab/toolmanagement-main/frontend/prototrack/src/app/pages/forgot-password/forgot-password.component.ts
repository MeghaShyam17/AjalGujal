import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { RouterModule } from '@angular/router';

import { ForgotPasswordService } from '../../core/services/forgot-password.service';

type ForgotPasswordStep =
  'email'
  | 'otp'
  | 'password'
  | 'success';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent {

  currentStep: ForgotPasswordStep = 'email';

  emailForm: FormGroup;
  otpForm: FormGroup;
  passwordForm: FormGroup;

  validationToken = '';

  loading = false;

  emailError = '';
  otpError = '';
  passwordError = '';
  confirmError = '';

  showNewPassword = false;
  showConfirmPassword = false;

  constructor(
    private fb: FormBuilder,
    private forgotPasswordService: ForgotPasswordService
  ) {

    this.emailForm = this.fb.group({
      email: [
        '',
        [
          Validators.required,
          Validators.email
        ]
      ]
    });

    this.otpForm = this.fb.group({
      otp: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[0-9]{6}$/)
        ]
      ]
    });

    this.passwordForm = this.fb.group({
      newPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(6)
        ]
      ],
      confirmPassword: [
        '',
        Validators.required
      ]
    });

  }

  generateOtp(): void {
    this.emailError = '';

    if (this.emailForm.invalid) {
      this.emailForm.markAllAsTouched();
      this.emailError = 'Enter a valid registered email address.';
      return;
    }

    this.loading = true;

    const email = this.emailForm.value.email.trim();

    this.forgotPasswordService
      .generateOtp({
        email
      })
      .subscribe({
        next: () => {
          this.loading = false;
          this.currentStep = 'otp';
        },
        error: () => {
          this.loading = false;
          this.emailError = 'Failed to send OTP. Try again later.';
        }
      });
  }

  verifyOtp(): void {
    this.otpError = '';

    if (this.otpForm.invalid) {
      this.otpForm.markAllAsTouched();
      this.otpError = 'Enter a valid 6-digit OTP.';
      return;
    }

    this.loading = true;

    this.forgotPasswordService
      .verifyOtp({
        email: this.emailForm.value.email.trim(),
        otp: this.otpForm.value.otp.trim()
      })
      .subscribe({
        next: (response) => {
          this.loading = false;
          this.validationToken = response.validationToken;
          this.currentStep = 'password';
        },
        error: () => {
          this.loading = false;
          this.otpError = 'Invalid OTP.';
        }
      });
  }

  savePassword(): void {
    this.passwordError = '';
    this.confirmError = '';

    if (this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched();

      if (this.passwordForm.get('newPassword')?.invalid) {
        this.passwordError = 'Password must be at least 6 characters.';
      }

      if (this.passwordForm.get('confirmPassword')?.invalid) {
        this.confirmError = 'Confirm Password is required.';
      }

      return;
    }

    const newPassword =
      this.passwordForm.value.newPassword;

    const confirmPassword =
      this.passwordForm.value.confirmPassword;

    if (newPassword !== confirmPassword) {
      this.confirmError = 'Passwords do not match.';
      return;
    }

    this.loading = true;

    this.forgotPasswordService
      .resetPassword({
        validationToken: this.validationToken,
        newPassword
      })
      .subscribe({
        next: () => {
          this.loading = false;
          this.currentStep = 'success';
        },
        error: () => {
          this.loading = false;
          this.passwordError = 'Failed to reset password.';
        }
      });
  }

  toggleNewPassword(): void {
    this.showNewPassword = !this.showNewPassword;
  }

  toggleConfirmPassword(): void {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  get emailTouchedInvalid(): boolean {
    const control = this.emailForm.get('email');

    return !!(
      control &&
      control.invalid &&
      control.touched
    );
  }

  get otpTouchedInvalid(): boolean {
    const control = this.otpForm.get('otp');

    return !!(
      control &&
      control.invalid &&
      control.touched
    );
  }

  get newPasswordTouchedInvalid(): boolean {
    const control = this.passwordForm.get('newPassword');

    return !!(
      control &&
      control.invalid &&
      control.touched
    );
  }

  get confirmPasswordTouchedInvalid(): boolean {
    const control = this.passwordForm.get('confirmPassword');

    return !!(
      control &&
      control.invalid &&
      control.touched
    );
  }
}