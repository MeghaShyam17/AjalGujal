import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { InventoryService } from '../../../core/services/inventory.service';
import { EquipmentService } from '../../../core/services/equipment.service';
import { UserService } from '../../../core/services/user.service';
import { DamageReport } from '../../../core/models/inventory';
import { EquipmentMaintenanceResponseDto } from '../../../core/models/equipment';
import { UserResponse } from '../../../core/models/user';

export type AssetExceptionStatus = 'Open' | 'Waiting Approval' | 'Closed';

export interface ExceptionTimelineItem {
  stage?: string;
  date?: string;
  user?: string;
  detail?: string;
  time?: string;
  type?: string;
  title?: string;
  desc?: string;
}

export interface ExceptionDecision {
  type: string;
  decisionBy: string;
  date: string;
  remarks: string;
  attachment?: string;
}

export interface AssetException {
  id: string;
  asset: string;
  assetName?: string;
  assetId: string;
  category: string;
  team: string;
  project: string;
  faculty: string;
  reportedOn: string;
  reportedBy?: string;
  returnedOn?: string;
  returnId?: string;
  daysOpen?: number;
  remarks?: string;
  type: 'Missing' | 'Damaged';
  status: AssetExceptionStatus;
  timeline: ExceptionTimelineItem[];
  details: {
    description: string;
    reportedBy: string;
    images?: string[];
  };
  decision?: ExceptionDecision;
}

type ViewName = 'list' | 'details' | 'decision';
type ExceptionTypeFilter = 'All' | 'Missing' | 'Damaged';
type StatusFilter = 'All' | AssetExceptionStatus;

@Component({
  selector: 'app-asset-exceptions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './asset-exceptions.component.html',
  styleUrl: './asset-exceptions.component.css'
})
export class AssetExceptionsComponent implements OnInit {
  exceptions: AssetException[] = [];
  selectedException: AssetException | null = null;
  currentView: ViewName = 'list';

  searchText = '';
  selectedFaculty = 'All';
  selectedStatus: StatusFilter = 'All';
  selectedType: ExceptionTypeFilter = 'All';
  selectedDate = '';
  isLoading = false;
  loadError = '';
  userNamesMap: Record<number, string> = {};

  constructor(
    private readonly inventoryService: InventoryService,
    private readonly equipmentService: EquipmentService,
    private readonly userService: UserService
  ) {}

  ngOnInit(): void {
    this.loadUsersAndExceptions();
  }

  loadUsersAndExceptions(): void {
    this.isLoading = true;
    this.userService.getAllUsers()
      .pipe(
        catchError(() => of([] as UserResponse[]))
      )
      .subscribe({
        next: (users) => {
          if (users && users.length > 0) {
            users.forEach(u => {
              this.userNamesMap[u.userId] = u.name;
            });
          }
          this.loadAssetExceptions();
        },
        error: () => {
          this.loadAssetExceptions();
        }
      });
  }

  get filteredExceptions(): AssetException[] {
    const query = this.searchText.trim().toLowerCase();

    return this.exceptions.filter((item: AssetException) => {
      const searchableText = [
        item.id,
        item.asset,
        item.assetName,
        item.assetId,
        item.team,
        item.project,
        item.returnId
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      const matchesSearch =
        !query || searchableText.includes(query);

      const matchesFaculty =
        this.selectedFaculty === 'All' ||
        item.faculty === this.selectedFaculty;

      const matchesStatus =
        this.selectedStatus === 'All' ||
        item.status === this.selectedStatus;

      const matchesType =
        this.selectedType === 'All' ||
        item.type === this.selectedType;

      const matchesDate =
        !this.selectedDate ||
        this.toIsoDate(item.reportedOn) === this.selectedDate;

      return (
        matchesSearch &&
        matchesFaculty &&
        matchesStatus &&
        matchesType &&
        matchesDate
      );
    });
  }

  get openCount(): number {
    return this.exceptions.filter(
      (item: AssetException) => item.status === 'Open'
    ).length;
  }

  get waitingCount(): number {
    return this.exceptions.filter(
      (item: AssetException) =>
        item.status === 'Waiting Approval'
    ).length;
  }

  get closedCount(): number {
    return this.exceptions.filter(
      (item: AssetException) => item.status === 'Closed'
    ).length;
  }

  get faculties(): string[] {
    return [
      ...new Set(
        this.exceptions
          .map((item: AssetException) => item.faculty)
          .filter(Boolean)
      )
    ].sort();
  }

  applyFilters(): void {
    // Filtering is performed by the filteredExceptions getter.
    // This method is used by the template's ngModelChange events.
  }

  clearFilters(): void {
    this.searchText = '';
    this.selectedFaculty = 'All';
    this.selectedStatus = 'All';
    this.selectedType = 'All';
    this.selectedDate = '';
  }

  filterByStatus(status: AssetExceptionStatus): void {
    this.selectedStatus =
      this.selectedStatus === status ? 'All' : status;
  }

  isStatusFilterActive(status: AssetExceptionStatus): boolean {
    return this.selectedStatus === status;
  }

  openException(item: AssetException): void {
    this.selectedException = item;
    this.currentView =
      item.status === 'Waiting Approval' ? 'decision' : 'details';
    this.scrollPageToTop();
  }

  showDetails(item: AssetException): void {
    this.selectedException = item;
    this.currentView = 'details';
    this.scrollPageToTop();
  }

  showDecision(item: AssetException): void {
    this.selectedException = item;
    this.currentView = 'decision';
    this.scrollPageToTop();
  }

  backToList(): void {
    this.currentView = 'list';
    this.selectedException = null;
    this.scrollPageToTop();
  }

  typeClass(item: AssetException): string {
    return item.type === 'Missing'
      ? 'badge missing'
      : 'badge damaged';
  }

  statusClass(status: AssetExceptionStatus): string {
    if (status === 'Waiting Approval') {
      return 'badge-status pending';
    }

    if (status === 'Closed') {
      return 'badge-status closed';
    }

    return 'badge-status open';
  }

  getDecisionBadgeClass(): 'open' | 'pending' | 'closed' {
    const decision = this.selectedException?.decision;

    if (!decision) {
      return 'pending';
    }

    return decision.type === 'Accepted' ? 'closed' : 'open';
  }

  getDecisionTitle(): string {
    return this.selectedException?.decision?.type ?? 'Under Review';
  }

  getDecisionBy(): string {
    return (
      this.selectedException?.decision?.decisionBy ??
      this.selectedException?.faculty ??
      'Not assigned'
    );
  }

  getDecisionDate(): string {
    return (
      this.selectedException?.decision?.date ??
      'Decision pending'
    );
  }

  getDecisionRemarks(): string {
    return (
      this.selectedException?.decision?.remarks ??
      'Senior Faculty review is in progress. No decision has been logged yet.'
    );
  }

  trackByExceptionId(
    index: number,
    item: AssetException
  ): string {
    return item.id;
  }

  trackByTimelineIndex(index: number): number {
    return index;
  }

  private loadAssetExceptions(): void {
    this.isLoading = true;
    this.loadError = '';

    forkJoin({
      damageReports: this.inventoryService.getAllDamageReports().pipe(
        catchError(() => of([]))
      ),
      maintenance: this.equipmentService.getMaintenanceRecords().pipe(
        catchError(() => of([]))
      ),
      inventory: this.inventoryService.getAllInventory().pipe(
        catchError(() => of([]))
      ),
      equipments: this.equipmentService.getEquipments().pipe(
        catchError(() => of([]))
      )
    })
    .pipe(finalize(() => this.isLoading = false))
    .subscribe({
      next: (res) => {
        const inventoryMap = new Map<number, any>();
        (res.inventory || []).forEach((item: any) => {
          if (item?.itemId) {
            inventoryMap.set(item.itemId, item);
          }
        });

        const equipmentMap = new Map<number, any>();
        (res.equipments || []).forEach((eq: any) => {
          if (eq?.equipmentId) {
            equipmentMap.set(eq.equipmentId, eq);
          }
        });

        const damageExceptions: AssetException[] = (res.damageReports || []).map((dr: DamageReport, index: number) => {
          let status: AssetExceptionStatus = 'Open';
          if (dr.ticketStatus === 'APPROVED' || dr.ticketStatus === 'CLOSED') {
            status = 'Closed';
          } else if (dr.ticketStatus === 'PENDING' || dr.ticketStatus === 'WAITING') {
            status = 'Waiting Approval';
          }

          const inv = (dr as any).inventory || (dr.itemId ? inventoryMap.get(dr.itemId) : null);
          const rawId = inv?.itemId || inv?.id || dr.itemId || (dr as any).inventoryId || dr.toolReturnItemId || dr.componentReturnItemId || dr.damageId || (index + 1);
          const cat = inv?.itemCategory || inv?.category || (dr.toolReturnItemId ? 'Tool' : (dr.componentReturnItemId ? 'Component' : 'Component'));
          const isTool = String(cat).toLowerCase().includes('tool') || !!dr.toolReturnItemId;
          const isComponent = String(cat).toLowerCase().includes('comp') || !!dr.componentReturnItemId;

          let assetLabel = '';
          if (isTool) {
            assetLabel = `Tool #${rawId}`;
          } else if (isComponent) {
            assetLabel = `Component #${rawId}`;
          } else {
            assetLabel = `Item #${rawId}`;
          }

          const assetName = inv?.itemName || (isTool ? `Tool Item #${rawId}` : `Component Item #${rawId}`);
          const assetCode = inv?.itemCode || (isTool ? `TOOL-${rawId}` : `COMP-${rawId}`);
          const displayCategory = isTool ? 'Tool' : (isComponent ? 'Component' : (cat || 'Component'));

          return {
            id: `EXP-DR-${dr.damageId || index + 1}`,
            // asset: assetLabel,
            asset: dr.inventory?.itemName || 'Unknown Asset',
            assetId: dr.inventory?.itemCode || 'N/A',
            // assetName: assetName,
            // assetId: assetCode,
            category: displayCategory,
            team: dr.projectId ? `Project #${dr.projectId}` : (dr.reportedBy ? (this.userNamesMap[dr.reportedBy] ? `${this.userNamesMap[dr.reportedBy]} Team` : `Team #${dr.reportedBy}`) : 'Lab Team'),
            project: `Project #${dr.projectId || 'N/A'}`,
            faculty: dr.assignedTo ? (this.userNamesMap[dr.assignedTo] || `User #${dr.assignedTo}`) : (dr.verifiedBy ? (this.userNamesMap[dr.verifiedBy] || `User #${dr.verifiedBy}`) : 'Lab Supervisor'),
            reportedOn: dr.createdAt ? this.toIsoDate(dr.createdAt) : '2026-08-01',
            reportedBy: dr.reportedBy ? (this.userNamesMap[dr.reportedBy] || `User #${dr.reportedBy}`) : 'Student',
            returnedOn: dr.closedOn || dr.verifiedOn || 'N/A',
            daysOpen: 2,
            remarks: dr.damageDescription || dr.resolutionNotes || '',
            type: dr.damageType?.toLowerCase().includes('missing') ? 'Missing' : 'Damaged',
            status: status,
            timeline: [
              {
                stage: 'Reported',
                date: dr.createdAt || 'Recently',
                user: dr.reportedBy ? (this.userNamesMap[dr.reportedBy] || `User #${dr.reportedBy}`) : 'Student',
                detail: dr.damageDescription || 'Damage report submitted.',
                time: dr.createdAt || 'Recently',
                title: 'Reported',
                desc: dr.damageDescription || 'Damage report submitted.',
                type: 'completed'
              }
            ],
            details: {
              description: dr.damageDescription || 'No detailed description provided.',
              reportedBy: dr.reportedBy ? (this.userNamesMap[dr.reportedBy] || `User #${dr.reportedBy}`) : 'Student'
            },
            decision: dr.resolutionNotes ? {
              type: dr.ticketStatus || 'Reviewed',
              decisionBy: dr.verifiedBy ? (this.userNamesMap[dr.verifiedBy] || `User #${dr.verifiedBy}`) : 'Faculty',
              date: dr.verifiedOn || dr.createdAt || 'Recently',
              remarks: dr.resolutionNotes
            } : undefined
          };
        });

        const maintenanceExceptions: AssetException[] = (res.maintenance || []).map((m: EquipmentMaintenanceResponseDto, index: number) => {
          let status: AssetExceptionStatus = 'Open';
          if (m.maintenanceStatus === 'COMPLETED' || m.maintenanceStatus === 'CLOSED') {
            status = 'Closed';
          } else if (m.maintenanceStatus === 'PENDING') {
            status = 'Waiting Approval';
          }

          const eq = equipmentMap.get(m.equipmentId);
          const eqName = eq?.equipmentName || (m as any).equipmentName || `Equipment Unit #${m.equipmentId || index + 1}`;

          return {
            id: `EXP-EQ-${m.maintenanceId || index + 1}`,
            // asset: `Equipment #${m.equipmentId || index + 1}`,
            asset: m.assetCode || `Equipment #${m.equipmentId}`,
            assetName: eqName,
            assetId: `EQ-${m.equipmentId || index + 1}`,
            category: 'Equipment',
            team: 'Maintenance Team',
            project: 'Equipment Maintenance',
            faculty: 'Lab Supervisor',
            reportedOn: m.startDate ? this.toIsoDate(m.startDate) : '2026-08-01',
            reportedBy: m.maintainedBy ? (this.userNamesMap[m.maintainedBy] || `User #${m.maintainedBy}`) : 'Technician',
            returnedOn: m.endDate || 'N/A',
            daysOpen: 1,
            remarks: m.maintenanceReason || m.remarks || '',
            type: 'Damaged',
            status: status,
            timeline: [
              {
                stage: 'Maintenance Logged',
                date: m.startDate || 'Recently',
                user: m.maintainedBy ? (this.userNamesMap[m.maintainedBy] || `User #${m.maintainedBy}`) : 'Admin',
                detail: m.maintenanceReason || m.maintenanceType || 'Maintenance logged',
                time: m.startDate || 'Recently',
                title: 'Maintenance Logged',
                desc: m.maintenanceReason || m.maintenanceType || 'Maintenance logged',
                type: 'completed'
              }
            ],
            details: {
              description: m.maintenanceReason || `Type: ${m.maintenanceType || 'General Maintenance'}`,
              reportedBy: m.maintainedBy ? (this.userNamesMap[m.maintainedBy] || `User #${m.maintainedBy}`) : 'Technician'
            },
            decision: m.remarks ? {
              type: m.maintenanceStatus || 'Under Review',
              decisionBy: 'Technician',
              date: m.endDate || m.startDate || 'Recently',
              remarks: m.remarks
            } : undefined
          };
        });

        this.exceptions = [...damageExceptions, ...maintenanceExceptions];
      },
      error: (err) => {
        console.error('Unable to load asset exceptions:', err);
        this.exceptions = [];
        this.loadError = 'Unable to load asset exceptions from backend.';
      }
    });
  }

  private toIsoDate(value: string): string {
    if (!value) {
      return '';
    }

    const isoDatePattern = /^\d{4}-\d{2}-\d{2}$/;
    if (isoDatePattern.test(value)) {
      return value;
    }

    const parsedDate = new Date(value);

    if (Number.isNaN(parsedDate.getTime())) {
      return '';
    }

    const year = parsedDate.getFullYear();
    const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
    const day = String(parsedDate.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  private scrollPageToTop(): void {
    const pageContent = document.querySelector<HTMLElement>('.page-content');

    if (pageContent) {
      pageContent.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
