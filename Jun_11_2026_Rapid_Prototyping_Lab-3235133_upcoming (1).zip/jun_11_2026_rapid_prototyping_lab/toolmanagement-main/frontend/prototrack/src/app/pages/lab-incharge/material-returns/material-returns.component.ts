import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { environment } from '../../../../environments/environment';
import { of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { StorageService } from '../../../core/services/storage.sevice';
import { ComponentInventoryService } from '../../../core/services/component-inventory.service';
import { ToolInventoryService } from '../../../core/services/tool-inventory.service';
import { UserService } from '../../../core/services/user.service';
import { UserResponse } from '../../../core/models/user';

export type ReturnCategory = 'tool' | 'component';

type MaterialReturnView = 'dashboard' | 'queue' | 'verify' | 'success';

export interface ReturnItem {
  itemId: number;
  requestItemId?: number;
  name: string;
  issued: number;
  alreadyReturned: number;
  returnedToday: number;
  good: number;
  damaged: number;
  missing: number;
  remarks: string;
}

export interface MaterialReturn {
  id: string;
  rawId: number;
  category: ReturnCategory;

  team: string;
  project: string;
  leader: string;
  faculty: string;

  issuedDate: string;
  expectedReturn: string;

  items: ReturnItem[];

  status: string;
  verifiedOn: string;

  projectId?: number;
  returnedBy?: number;
  receivedBy?: number;
  toolRequestId?: number;
  componentRequestId?: number;
}

export interface ReturnFilters {
  search: string;
  faculty: string;
  status: string;
  date: string;
}

export interface ExceptionTarget {
  itemIndex: number;
  type: 'damaged' | 'missing';
}

@Component({
  selector: 'app-material-returns',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './material-returns.component.html',
  styleUrls: ['./material-returns.component.css']
})
export class MaterialReturnsComponent implements OnInit {
  @Input() category: ReturnCategory = 'tool';
  @Input() isEmbedded = false;

  private readonly apiBaseUrl = `${environment.apiBaseUrl}/api`;

  currentView: MaterialReturnView = 'dashboard';
  activeCategory: ReturnCategory = 'tool';
  activeReturnId: string | null = null;
  activeExceptionTarget: ExceptionTarget | null = null;

  returnFilters: ReturnFilters = {
    search: '',
    faculty: 'All',
    status: 'All',
    date: ''
  };

  showDamagedModal = false;
  showMissingModal = false;
  showConfirmVerificationModal = false;

  damagedRemarks = '';
  missingRemarks = '';

  toastMessage = '';
  toastType: 'success' | 'error' = 'success';
  showToastBox = false;

  isLoading = false;
  isSubmitting = false;
  loadError = '';

  toolReturns: MaterialReturn[] = [];
  componentReturns: MaterialReturn[] = [];

  userNamesMap: Record<number, string> = {};

  private latestToolRequests: any[] = [];
  private latestToolReturns: any[] = [];

  constructor(
    private storage: StorageService,
    private readonly componentInventoryService: ComponentInventoryService,
    private readonly toolInventoryService: ToolInventoryService,
    private readonly userService: UserService,
    private readonly http: HttpClient
  ) {}

  isDirectRoute = false;

  ngOnInit(): void {
    if (this.isEmbedded) {
      this.activeCategory = this.category;
      this.currentView = 'queue';
      this.isDirectRoute = true;
    } else {
      const currentUrl = window.location.pathname;
      if (currentUrl.includes('tool-returns')) {
        this.activeCategory = 'tool';
        this.currentView = 'queue';
        this.isDirectRoute = true;
      } else if (currentUrl.includes('component-returns')) {
        this.activeCategory = 'component';
        this.currentView = 'queue';
        this.isDirectRoute = true;
      }
    }
    this.loadUsersAndReturns();
  }

  loadUsersAndReturns(): void {
    this.isLoading = true;
    this.loadError = '';

    this.userService.getAllUsers()
      .pipe(
        catchError((err) => {
          console.error('Users API failed. Continuing without names:', err);
          return of([] as UserResponse[]);
        })
      )
      .subscribe({
        next: (users: UserResponse[]) => {
          this.userNamesMap = {};

          if (users && users.length > 0) {
            users.forEach((user: any) => {
              const id = Number(user.userId || user.id);
              const name =
                user.name ||
                user.userName ||
                user.fullName ||
                user.email ||
                '';

              if (id) {
                this.userNamesMap[id] = name || `User #${id}`;
              }
            });
          }

          this.loadReturns();
        },
        error: () => {
          this.loadReturns();
        }
      });
  }

  loadReturns(): void {
    this.isLoading = true;
    this.loadError = '';

    this.loadComponentReturns();
    this.loadToolRequestsForReturnQueue();
    this.loadToolReturnsOptional();
  }

  private loadComponentReturns(): void {
    this.componentInventoryService.getComponentReturns()
      .pipe(
        catchError((err) => {
          console.error('Component returns API failed:', err);
          return of([] as any[]);
        })
      )
      .subscribe({
        next: (res: any) => {
          console.log('Component Returns API Response:', res);

          const data = Array.isArray(res)
            ? res
            : res?.data || [];

          this.componentReturns = this.mapComponentReturns(data);

          console.log('Mapped Component Returns:', this.componentReturns);

          this.isLoading = false;
        },
        error: (err) => {
          console.error('Error loading component returns:', err);
          this.loadError = 'Failed to load component returns from backend.';
          this.isLoading = false;
        }
      });
  }

  private loadToolRequestsForReturnQueue(): void {
    this.http.get<any[]>(`${this.apiBaseUrl}/tool-requests`)
      .pipe(
        catchError((err) => {
          console.error('Tool requests API failed:', err);
          return of([] as any[]);
        })
      )
      .subscribe({
        next: (res: any) => {
          console.log('Tool Requests API Response:', res);

          const data = Array.isArray(res)
            ? res
            : res?.data || [];

          this.latestToolRequests = data;
          this.rebuildToolReturns();

          console.log('Mapped Tool Returns from Tool Requests:', this.toolReturns);

          this.isLoading = false;
        },
        error: (err) => {
          console.error('Error loading tool requests:', err);
          this.loadError = 'Failed to load tool requests from backend.';
          this.isLoading = false;
        }
      });
  }

  private loadToolReturnsOptional(): void {
    this.toolInventoryService.getToolReturns()
      .pipe(
        catchError((err) => {
          console.error('Tool returns API failed. Continuing without existing return history:', err);
          return of([] as any[]);
        })
      )
      .subscribe({
        next: (res: any) => {
          console.log('Tool Returns API Response:', res);

          const data = Array.isArray(res)
            ? res
            : res?.data || [];

          this.latestToolReturns = data;
          this.rebuildToolReturns();

          console.log('Mapped Tool Returns after Tool Return Data:', this.toolReturns);
        },
        error: (err) => {
          console.error('Error loading tool returns:', err);
        }
      });
  }

  private rebuildToolReturns(): void {
    this.toolReturns = this.mapIssuedToolRequestsToReturnQueue(
      this.latestToolRequests,
      this.latestToolReturns
    );
  }

  private mapComponentReturns(componentReturns: any[]): MaterialReturn[] {
    return componentReturns.map((cr: any, index: number) => {
      const returnId = Number(cr.componentReturnId || cr.id || index + 1);
      const projectId = Number(cr.projectId || cr.project?.projectId || 0);
      const returnedBy = Number(cr.returnedBy || cr.returnedById || 0);
      const receivedBy = Number(cr.receivedBy || cr.receivedById || 0);

      const rawItems =
        cr.items ||
        cr.returnItems ||
        cr.componentReturnItems ||
        [];

      const items: ReturnItem[] = rawItems.length > 0
        ? rawItems.map((item: any) => {
            const returnedQty = Number(
              item.returnedQuantity ||
              item.quantity ||
              item.issuedQuantity ||
              0
            );

            const isCompleted =
              cr.returnStatus === 'RECEIVED' ||
              cr.returnStatus === 'COMPLETED' ||
              cr.status === 'COMPLETED';

            return {
              itemId: Number(item.itemId || item.componentId || item.materialId || 0),
              name:
                item.itemName ||
                item.componentName ||
                item.name ||
                `Component #${item.itemId || item.componentId || 'N/A'}`,
              issued: Number(item.issuedQuantity || returnedQty || 0),
              alreadyReturned: isCompleted ? returnedQty : 0,
              returnedToday: isCompleted ? 0 : returnedQty,
              good: isCompleted ? 0 : returnedQty,
              damaged: Number(item.damagedQuantity || item.damaged || 0),
              missing: Number(item.lostQuantity || item.missingQuantity || item.missing || 0),
              remarks: item.remarks || cr.remarks || ''
            };
          })
        : [
            {
              itemId: 0,
              name: `Component Request #${cr.componentRequestId || 'N/A'}`,
              issued: 1,
              alreadyReturned:
                cr.returnStatus === 'RECEIVED' ||
                cr.returnStatus === 'COMPLETED' ||
                cr.status === 'COMPLETED'
                  ? 1
                  : 0,
              returnedToday:
                cr.returnStatus === 'RECEIVED' ||
                cr.returnStatus === 'COMPLETED' ||
                cr.status === 'COMPLETED'
                  ? 0
                  : 1,
              good:
                cr.returnStatus === 'RECEIVED' ||
                cr.returnStatus === 'COMPLETED' ||
                cr.status === 'COMPLETED'
                  ? 0
                  : 1,
              damaged: 0,
              missing: 0,
              remarks: cr.remarks || ''
            }
          ];

      const isCompleted =
        cr.returnStatus === 'RECEIVED' ||
        cr.returnStatus === 'COMPLETED' ||
        cr.status === 'COMPLETED';

      return {
        id: `CR-RET-${returnId}`,
        rawId: returnId,
        category: 'component',
        team: `Project #${projectId}`,
        project:
          cr.project?.projectName ||
          cr.projectName ||
          `Project #${projectId}`,
        leader: returnedBy
          ? this.userNamesMap[returnedBy] || `User #${returnedBy}`
          : 'Student',
        faculty: receivedBy
          ? this.userNamesMap[receivedBy] || `Faculty #${receivedBy}`
          : 'Pending',
        issuedDate: this.formatDateTime(cr.createdAt || cr.returnDate),
        expectedReturn: 'Project Completion',
        items,
        status: isCompleted ? 'Completed' : 'Pending',
        verifiedOn: cr.returnDate || '',
        projectId,
        returnedBy,
        receivedBy,
        componentRequestId: cr.componentRequestId
      };
    });
  }

  private mapIssuedToolRequestsToReturnQueue(
    toolRequests: any[],
    toolReturns: any[]
  ): MaterialReturn[] {
    const returnedQtyByRequestAndItem: Record<string, number> = {};
    const completedReturnReqIds = new Set<number>();
    const toolReturnByRequestId = new Map<number, any>();

    toolReturns.forEach((toolReturn: any) => {
      const requestId = Number(
        toolReturn.toolRequestId ||
        toolReturn.toolRequest?.toolRequestId ||
        0
      );

      if (requestId > 0) {
        toolReturnByRequestId.set(requestId, toolReturn);
      }

      const returnStatus = String(
        toolReturn.returnStatus ||
        toolReturn.status ||
        ''
      ).toUpperCase();

      const isCompleted =
        returnStatus === 'COMPLETED' ||
        returnStatus === 'VERIFIED' ||
        returnStatus === 'RECEIVED';

      if (isCompleted) {
        completedReturnReqIds.add(requestId);
      }

      const items =
        toolReturn.items ||
        toolReturn.returnItems ||
        toolReturn.toolReturnItems ||
        [];

      if (isCompleted) {
        items.forEach((item: any) => {
          const itemId = Number(item.itemId || item.toolId || item.materialId || 0);
          const key = `${requestId}_${itemId}`;

          const retQty = Number(item.returnedQuantity || item.quantity || 0);

          returnedQtyByRequestAndItem[key] =
            (returnedQtyByRequestAndItem[key] || 0) + retQty;
        });
      }
    });

    const mappedFromRequests: MaterialReturn[] = toolRequests
      .filter((request: any) => {
        const status = String(
          request.approvalStatus ||
          request.status ||
          request.requestStatus ||
          ''
        ).toUpperCase();

        return status === 'ISSUED' ||
          status === 'APPROVED' ||
          status === 'HANDED_OVER' ||
          status === 'PARTIALLY_ISSUED' ||
          status === 'COMPLETED' ||
          status === 'RETURNED';
      })
      .map((request: any) => {
        const requestId = Number(request.toolRequestId || request.id || 0);
        const projectId = Number(request.projectId || request.project?.projectId || 0);
        const requestedBy = Number(request.requestedBy || request.requestedById || 0);
        const receivedBy = Number(request.issuedBy || request.receivedBy || 0);

        const matchingReturn = toolReturnByRequestId.get(requestId);
        const rawItems =
          (matchingReturn && (matchingReturn.items || matchingReturn.returnItems || matchingReturn.toolReturnItems)) ||
          request.items ||
          request.requestItems ||
          request.toolRequestItems ||
          [];

        const isCompleted =
          completedReturnReqIds.has(requestId) ||
          String(request.approvalStatus || request.status || '').toUpperCase() === 'COMPLETED' ||
          String(request.approvalStatus || request.status || '').toUpperCase() === 'RETURNED' ||
          (matchingReturn && ['COMPLETED', 'VERIFIED', 'RECEIVED'].includes(String(matchingReturn.returnStatus || matchingReturn.status || '').toUpperCase()));

        const items: ReturnItem[] = rawItems.map((item: any) => {
          const itemId = Number(item.itemId || item.toolId || item.materialId || 0);

          const issuedQty = Number(
            item.issuedQuantity ||
            item.approvedQuantity ||
            item.requestedQuantity ||
            item.quantity ||
            0
          );

          const alreadyReturned = isCompleted
            ? (Number(item.returnedQuantity || issuedQty) || issuedQty)
            : (returnedQtyByRequestAndItem[`${requestId}_${itemId}`] || 0);

          const remaining = isCompleted ? 0 : Math.max(issuedQty - alreadyReturned, 0);

          return {
            itemId,
            requestItemId: Number(item.toolRequestItemId || item.requestItemId || 0),
            name:
              item.itemName ||
              item.toolName ||
              item.name ||
              `Tool Item #${itemId || 'N/A'}`,
            issued: issuedQty || (isCompleted ? alreadyReturned : 1),
            alreadyReturned,
            returnedToday: remaining,
            good: remaining,
            damaged: Number(item.damagedQuantity || 0),
            missing: Number(item.lostQuantity || item.missingQuantity || 0),
            remarks: item.remarks || ''
          };
        });

        return {
          id: `TR-REQ-${requestId}`,
          rawId: requestId,
          category: 'tool' as ReturnCategory,
          toolRequestId: requestId,
          projectId,
          returnedBy: requestedBy,
          receivedBy,
          team: `Project #${projectId}`,
          project:
            request.projectName ||
            request.project?.projectName ||
            `Project #${projectId}`,
          leader: request.teamLeaderId
            ? this.userNamesMap[Number(request.teamLeaderId)] ||
              `User #${request.teamLeaderId}`
            : requestedBy
              ? this.userNamesMap[requestedBy] || `User #${requestedBy}`
              : 'Student',
          faculty: receivedBy
            ? this.userNamesMap[receivedBy] || `Faculty #${receivedBy}`
            : 'Lab In-Charge',
          issuedDate: this.formatDateTime(
            request.issuedOn ||
            request.issuedDate ||
            request.requestDate ||
            request.createdAt
          ),
          expectedReturn: this.formatDate(
            request.expectedReturnDate ||
            request.returnDate ||
            ''
          ),
          items,
          status: isCompleted ? 'Completed' : 'Pending',
          verifiedOn: matchingReturn?.returnDate || ''
        };
      });

    const processedRequestIds = new Set(mappedFromRequests.map(r => r.toolRequestId));

    toolReturns.forEach((tr: any, idx: number) => {
      const requestId = Number(tr.toolRequestId || tr.toolRequest?.toolRequestId || 0);
      if (requestId > 0 && processedRequestIds.has(requestId)) {
        return;
      }

      const returnId = Number(tr.toolReturnId || tr.id || idx + 1);
      const projectId = Number(tr.projectId || tr.project?.projectId || tr.toolRequest?.projectId || 0);
      const returnedBy = Number(tr.returnedBy || 0);
      const receivedBy = Number(tr.receivedBy || 0);
      const returnStatus = String(tr.returnStatus || tr.status || '').toUpperCase();
      const isCompleted = returnStatus === 'COMPLETED' || returnStatus === 'VERIFIED' || returnStatus === 'RECEIVED';

      const rawItems = tr.items || tr.returnItems || tr.toolReturnItems || [];
      const items: ReturnItem[] = rawItems.map((item: any) => {
        const itemId = Number(item.itemId || item.toolId || 0);
        const retQty = Number(item.returnedQuantity || item.quantity || 1);
        return {
          itemId,
          name: item.itemName || item.toolName || item.name || `Tool Item #${itemId || 'N/A'}`,
          issued: retQty,
          alreadyReturned: isCompleted ? retQty : 0,
          returnedToday: isCompleted ? 0 : retQty,
          good: isCompleted ? 0 : retQty,
          damaged: Number(item.damagedQuantity || 0),
          missing: Number(item.lostQuantity || 0),
          remarks: item.remarks || ''
        };
      });

      mappedFromRequests.push({
        id: `TR-RET-${returnId}`,
        rawId: returnId,
        category: 'tool',
        toolRequestId: requestId,
        projectId,
        returnedBy,
        receivedBy,
        team: `Project #${projectId}`,
        project: tr.projectName || tr.project?.projectName || `Project #${projectId}`,
        leader: returnedBy ? (this.userNamesMap[returnedBy] || `User #${returnedBy}`) : 'Student',
        faculty: receivedBy ? (this.userNamesMap[receivedBy] || `Faculty #${receivedBy}`) : 'Lab In-Charge',
        issuedDate: this.formatDateTime(tr.createdAt || tr.returnDate),
        expectedReturn: 'Daily',
        items,
        status: isCompleted ? 'Completed' : 'Pending',
        verifiedOn: tr.returnDate || ''
      });
    });

    return mappedFromRequests;
  }

  get activeDataset(): MaterialReturn[] {
    return this.activeCategory === 'tool'
      ? this.toolReturns
      : this.componentReturns;
  }

  get activeReturn(): MaterialReturn | undefined {
    return this.activeDataset.find((item) => item.id === this.activeReturnId);
  }

  get activeCategoryTitle(): string {
    return this.activeCategory === 'tool'
      ? 'Tool Returns'
      : 'Component Returns';
  }

  get activeItemLabel(): string {
    return this.activeCategory === 'tool'
      ? 'Tool'
      : 'Component';
  }

  get toolPendingCount(): number {
    return this.toolReturns.filter((item) => item.status === 'Pending').length;
  }

  get toolCompletedCount(): number {
    return this.toolReturns.filter((item) => item.status === 'Completed').length;
  }

  get componentPendingCount(): number {
    return this.componentReturns.filter((item) => item.status === 'Pending').length;
  }

  get componentCompletedCount(): number {
    return this.componentReturns.filter((item) => item.status === 'Completed').length;
  }

  get faculties(): string[] {
    const allFaculties = [
      ...this.toolReturns.map((returnItem) => returnItem.faculty),
      ...this.componentReturns.map((returnItem) => returnItem.faculty)
    ].filter((faculty) => faculty && faculty !== 'Pending');

    return [...new Set(allFaculties)].sort();
  }

  get totalReturnsExpectedToday(): number {
    return this.toolPendingCount + this.componentPendingCount;
  }

  get outstandingTodayCount(): number {
    return [...this.toolReturns, ...this.componentReturns]
      .filter((returnItem) => returnItem.status === 'Pending')
      .reduce((returnTotal, returnItem) => {
        return returnTotal + returnItem.items.reduce(
          (itemTotal, item) => itemTotal + this.getOutstanding(item),
          0
        );
      }, 0);
  }

  get exceptionTodayCount(): number {
    return [...this.toolReturns, ...this.componentReturns]
      .reduce((returnTotal, returnItem) => {
        return returnTotal + returnItem.items.reduce(
          (itemTotal, item) => itemTotal + item.damaged + item.missing,
          0
        );
      }, 0);
  }

  get filteredReturns(): MaterialReturn[] {
    const query = this.returnFilters.search.trim().toLowerCase();

    return this.activeDataset.filter((returnItem) => {
      const matchesSearch =
        !query ||
        returnItem.id.toLowerCase().includes(query) ||
        returnItem.team.toLowerCase().includes(query) ||
        returnItem.project.toLowerCase().includes(query) ||
        returnItem.leader.toLowerCase().includes(query) ||
        returnItem.items.some((item) =>
          item.name.toLowerCase().includes(query)
        );

      const matchesFaculty =
        this.returnFilters.faculty === 'All' ||
        returnItem.faculty === this.returnFilters.faculty;

      const matchesStatus =
        this.returnFilters.status === 'All' ||
        returnItem.status === this.returnFilters.status;

      const matchesDate =
        this.activeCategory === 'component'
          ? true
          : this.matchesExpectedDate(
              returnItem.expectedReturn,
              this.returnFilters.date
            );

      return matchesSearch &&
        matchesFaculty &&
        matchesStatus &&
        matchesDate;
    });
  }

  get returnedTodayTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + item.returnedToday,
      0
    ) ?? 0;
  }

  get goodTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + item.good,
      0
    ) ?? 0;
  }

  get damagedTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + item.damaged,
      0
    ) ?? 0;
  }

  get missingTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + item.missing,
      0
    ) ?? 0;
  }

  get outstandingTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + this.getOutstanding(item),
      0
    ) ?? 0;
  }

  get exceptionsTotal(): number {
    return this.damagedTotal + this.missingTotal;
  }

  get successIssuedTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + item.issued,
      0
    ) ?? 0;
  }

  get successAlreadyReturnedTotal(): number {
    return this.activeReturn?.items.reduce(
      (sum, item) => sum + Math.max(item.alreadyReturned - item.returnedToday, 0),
      0
    ) ?? 0;
  }

  get exceptionItems(): ReturnItem[] {
    return this.activeReturn?.items.filter(
      (item) => item.damaged > 0 || item.missing > 0
    ) ?? [];
  }

  openQueue(category: ReturnCategory): void {
    this.activeCategory = category;
    this.currentView = 'queue';

    this.returnFilters = {
      search: '',
      faculty: 'All',
      status: 'All',
      date: ''
    };
  }

  backToDashboard(): void {
    if (this.isDirectRoute) return;
    this.currentView = 'dashboard';
    this.activeReturnId = null;
  }

  switchCategory(category: ReturnCategory): void {
    this.activeCategory = category;
    this.resetFilters();
  }

  resetFilters(): void {
    this.returnFilters = {
      search: '',
      faculty: 'All',
      status: 'All',
      date: ''
    };

    this.showToast('Return filters cleared.');
  }

  verifyReturn(returnId: string): void {
    this.activeReturnId = returnId;
    this.currentView = 'verify';
  }

  viewSuccessDetails(returnId: string): void {
    this.activeReturnId = returnId;
    this.currentView = 'success';
  }

  backToQueue(): void {
    this.currentView = 'queue';
  }

  cancelVerification(): void {
    this.currentView = 'queue';
    this.showToast('Verification cancelled.', 'error');
  }

  getPendingItemsText(returnItem: MaterialReturn): string {
    return returnItem.items
      .map((item) => {
        const remaining = Math.max(item.issued - item.alreadyReturned, 0);
        return `${item.name} (${remaining})`;
      })
      .join(', ');
  }

  getOutstanding(item: ReturnItem): number {
    return Math.max(
      item.issued - item.alreadyReturned - item.returnedToday,
      0
    );
  }

  getMaxReturnable(item: ReturnItem): number {
    return Math.max(item.issued - item.alreadyReturned, 0);
  }

  updateReturnedToday(item: ReturnItem): void {
    const maxValue = this.getMaxReturnable(item);

    if (!item.returnedToday || item.returnedToday < 0) {
      item.returnedToday = 0;
    }

    if (item.returnedToday > maxValue) {
      item.returnedToday = maxValue;
    }

    item.good = item.returnedToday;
    item.damaged = 0;
    item.missing = 0;
    item.remarks = '';
  }

  updateGood(item: ReturnItem, itemIndex: number): void {
    if (!item.good || item.good < 0) {
      item.good = 0;
    }

    if (item.good > item.returnedToday) {
      item.good = item.returnedToday;
    }

    const difference = item.returnedToday - item.good;

    item.damaged = 0;
    item.missing = difference;

    if (difference > 0) {
      this.openExceptionModal(itemIndex, 'missing');
    }
  }

  updateDamaged(item: ReturnItem, itemIndex: number): void {
    if (!item.damaged || item.damaged < 0) {
      item.damaged = 0;
    }

    if (item.damaged > item.returnedToday) {
      item.damaged = item.returnedToday;
    }

    if (item.damaged + item.missing > item.returnedToday) {
      item.missing = item.returnedToday - item.damaged;
    }

    item.good = item.returnedToday - item.damaged - item.missing;

    if (item.damaged > 0) {
      this.openExceptionModal(itemIndex, 'damaged');
    }
  }

  updateMissing(item: ReturnItem, itemIndex: number): void {
    if (!item.missing || item.missing < 0) {
      item.missing = 0;
    }

    if (item.missing > item.returnedToday) {
      item.missing = item.returnedToday;
    }

    if (item.damaged + item.missing > item.returnedToday) {
      item.damaged = item.returnedToday - item.missing;
    }

    item.good = item.returnedToday - item.damaged - item.missing;

    if (item.missing > 0) {
      this.openExceptionModal(itemIndex, 'missing');
    }
  }

  openExceptionModal(
    itemIndex: number,
    type: 'damaged' | 'missing'
  ): void {
    this.activeExceptionTarget = {
      itemIndex,
      type
    };

    const item = this.activeReturn?.items[itemIndex];

    if (!item) {
      return;
    }

    if (type === 'damaged') {
      this.damagedRemarks = item.remarks || '';
      this.showDamagedModal = true;
    } else {
      this.missingRemarks = item.remarks || '';
      this.showMissingModal = true;
    }
  }

  saveDamagedRemarks(): void {
    this.saveExceptionRemarks('damaged');
  }

  saveMissingRemarks(): void {
    this.saveExceptionRemarks('missing');
  }

  saveExceptionRemarks(type: 'damaged' | 'missing'): void {
    if (!this.activeExceptionTarget || !this.activeReturn) {
      return;
    }

    const item =
      this.activeReturn.items[this.activeExceptionTarget.itemIndex];

    const remarks =
      type === 'damaged'
        ? this.damagedRemarks.trim()
        : this.missingRemarks.trim();

    if (!remarks) {
      this.showToast(
        type === 'damaged'
          ? 'Please enter remarks explaining the damage.'
          : 'Please enter remarks explaining the missing status.',
        'error'
      );

      return;
    }

    item.remarks = remarks;

    this.closeExceptionModals();

    this.showToast(`Saved remarks for ${item.name}!`);
  }

  cancelExceptionModal(type: 'damaged' | 'missing'): void {
    if (this.activeExceptionTarget && this.activeReturn) {
      const item =
        this.activeReturn.items[this.activeExceptionTarget.itemIndex];

      if (type === 'damaged') {
        item.damaged = 0;
      } else {
        item.missing = 0;
      }

      item.good = item.returnedToday - item.damaged - item.missing;
    }

    this.closeExceptionModals();
  }

  closeExceptionModals(): void {
    this.showDamagedModal = false;
    this.showMissingModal = false;
    this.activeExceptionTarget = null;
    this.damagedRemarks = '';
    this.missingRemarks = '';
  }

  requestCompleteVerification(): void {
    if (!this.activeReturn) {
      return;
    }

    if (this.returnedTodayTotal === 0) {
      this.showToast(
        'Cannot complete verification with 0 items returned today.',
        'error'
      );
      return;
    }

    const missingRemarks = this.activeReturn.items.some(
      (item) =>
        (item.damaged > 0 || item.missing > 0) &&
        !item.remarks
    );

    if (missingRemarks) {
      this.showToast(
        'Please fill in the remarks for all missing or damaged items.',
        'error'
      );
      return;
    }

    this.showConfirmVerificationModal = true;
  }

  closeConfirmVerificationModal(): void {
    this.showConfirmVerificationModal = false;
  }

  completeVerification(): void {
    if (!this.activeReturn) {
      return;
    }

    if (this.activeCategory === 'tool') {
      this.completeToolReturnVerification();
      return;
    }

    this.completeComponentReturnLocally();
  }

  private completeToolReturnVerification(): void {
    if (!this.activeReturn) {
      return;
    }

    const loggedInUserId = Number(
      this.storage.get('userId') ||
      this.storage.get('id') ||
      this.storage.get('loggedInUserId') ||
      1
    );

    const returnedBy =
      this.activeReturn.returnedBy ||
      loggedInUserId ||
      1;

    const receivedBy =
      this.activeReturn.receivedBy ||
      loggedInUserId ||
      1;

    const targetRequestId = Number(
      this.activeReturn.toolRequestId ||
      (typeof this.activeReturn.id === 'string' && this.activeReturn.id.startsWith('TR-REQ-') ? this.activeReturn.rawId : 0) ||
      0
    );

    const targetReturnId = Number(
      (typeof this.activeReturn.id === 'string' && this.activeReturn.id.startsWith('TR-RET-') ? this.activeReturn.rawId : 0) ||
      0
    );

    const payload = {
      toolRequestId: targetRequestId,
      returnedBy,
      receivedBy,
      returnDate: new Date().toISOString().slice(0, 19),
      returnStatus: 'COMPLETED',
      remarks: `Return verification completed for ${this.activeReturn.project || 'Project'}.`,
      items: this.activeReturn.items
        .map((item) => ({
          itemId: item.itemId,
          returnedQuantity: item.returnedToday || item.good || (item.issued - item.alreadyReturned),
          damagedQuantity: item.damaged || 0,
          lostQuantity: item.missing || 0,
          condition: item.damaged > 0
            ? 'DAMAGED'
            : item.missing > 0
              ? 'LOST'
              : 'GOOD',
          returnedBy,
          verifiedBy: receivedBy,
          remarks: item.remarks || 'Returned in good condition'
        }))
    };

    // 1. Immediately update local UI state
    this.activeReturn.status = 'Completed';
    this.activeReturn.verifiedOn = this.getCurrentDateTime();
    this.activeReturn.items.forEach((item) => {
      item.alreadyReturned += (item.returnedToday || item.good || (item.issued - item.alreadyReturned));
      item.returnedToday = 0;
    });

    this.showConfirmVerificationModal = false;
    this.currentView = 'success';

    this.showToast(
      `Successfully verified and completed return for ${this.activeReturn.id}!`,
      'success'
    );

    // 2. Determine if there are exceptions (damaged/lost items or custom quantities)
    const hasExceptions = this.activeReturn.items.some(item =>
      (item.damaged || 0) > 0 ||
      (item.missing || 0) > 0 ||
      (item.returnedToday !== 0 && item.returnedToday !== (item.issued - item.alreadyReturned))
    );

    // 3. Perform backend syncing
    if (hasExceptions) {
      this.http.post<any>(`${this.apiBaseUrl}/tool-returns`, payload).subscribe({
        next: () => this.loadReturns(),
        error: (err) => {
          console.error('Failed to complete tool return verification:', err);
          this.showToast(`Sync Error: ${err.message || err.error?.message || 'Failed to sync exceptions with backend'}`, 'error');
          this.loadReturns();
        }
      });
    } else {
      if (targetReturnId > 0) {
        this.toolInventoryService.receiveReturn(targetReturnId, receivedBy).subscribe({
          next: () => this.loadReturns(),
          error: (err) => {
            console.error('Failed to complete tool return verification:', err);
            this.showToast(`Sync Error: ${err.message || err.error?.message || 'Failed to complete return record'}`, 'error');
            this.loadReturns();
          }
        });
      } else if (targetRequestId > 0) {
        this.toolInventoryService.receiveReturnByRequestId(targetRequestId, receivedBy).subscribe({
          next: () => this.loadReturns(),
          error: (err) => {
            console.error('Failed to complete tool return by request ID:', err);
            this.showToast(`Sync Error: ${err.message || err.error?.message || 'Failed to complete return request'}`, 'error');
            this.loadReturns();
          }
        });
      } else {
        this.http.post<any>(`${this.apiBaseUrl}/tool-returns`, payload).subscribe({
          next: () => this.loadReturns(),
          error: (err) => {
            console.error('Failed to complete tool return verification:', err);
            this.showToast(`Sync Error: ${err.message || err.error?.message || 'Failed to complete return'}`, 'error');
            this.loadReturns();
          }
        });
      }
    }
  }

  private completeComponentReturnLocally(): void {
    if (!this.activeReturn) {
      return;
    }

    const rawId = Number(this.activeReturn.rawId || this.activeReturn.id.replace(/\D/g, ''));
    const loggedInUserId = Number(
      this.storage.get('userId') ||
      this.storage.get('id') ||
      0
    );

    if (rawId) {
      this.componentInventoryService.receiveReturn(rawId, loggedInUserId).subscribe({
        next: () => {
          this.loadReturns();
        },
        error: (err) => console.warn('Component receive return error:', err)
      });
    }

    this.activeReturn.status = 'Completed';
    this.activeReturn.verifiedOn = this.getCurrentDateTime();

    this.activeReturn.items.forEach((item) => {
      item.alreadyReturned += item.returnedToday;
    });

    this.showConfirmVerificationModal = false;
    this.currentView = 'success';

    this.showToast(
      `Successfully verified and recorded return ${this.activeReturn.id}!`
    );
  }

  showToast(
    message: string,
    type: 'success' | 'error' = 'success'
  ): void {
    this.toastMessage = message;
    this.toastType = type;
    this.showToastBox = true;

    setTimeout(() => {
      this.showToastBox = false;
    }, 3000);
  }

  getCurrentDateTime(): string {
    const now = new Date();

    const date = now.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });

    const time = now.toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit'
    });

    return `${date} ${time}`;
  }

  formatDate(value: string | null | undefined): string {
    if (!value) {
      return '-';
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  }

  formatDateTime(value: string | null | undefined): string {
    if (!value) {
      return '-';
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    return date.toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  private matchesExpectedDate(
    expectedReturn: string,
    filterDate: string
  ): boolean {
    if (!filterDate) {
      return true;
    }

    if (!expectedReturn || expectedReturn === '-') {
      return true;
    }

    const directDate = new Date(expectedReturn);

    if (!Number.isNaN(directDate.getTime())) {
      const year = directDate.getFullYear();
      const month = String(directDate.getMonth() + 1).padStart(2, '0');
      const day = String(directDate.getDate()).padStart(2, '0');

      return `${year}-${month}-${day}` === filterDate;
    }

    const parts = expectedReturn.split(' ');

    if (parts.length < 3) {
      return true;
    }

    const months: Record<string, string> = {
      Jan: '01',
      Feb: '02',
      Mar: '03',
      Apr: '04',
      May: '05',
      Jun: '06',
      Jul: '07',
      Aug: '08',
      Sep: '09',
      Oct: '10',
      Nov: '11',
      Dec: '12'
    };

    const day = parts[0].padStart(2, '0');
    const month = months[parts[1]] || '01';
    const year = parts[2];

    return `${year}-${month}-${day}` === filterDate;
  }
}