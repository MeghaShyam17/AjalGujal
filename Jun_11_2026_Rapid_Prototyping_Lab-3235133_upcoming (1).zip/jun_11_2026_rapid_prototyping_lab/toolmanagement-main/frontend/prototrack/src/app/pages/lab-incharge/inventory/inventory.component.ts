import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { catchError, finalize } from 'rxjs/operators';
import { forkJoin, Observable, of } from 'rxjs';
import * as XLSX from 'xlsx';

import { InventoryService } from '../../../core/services/inventory.service';
import { BulkUploadResponse, Inventory } from '../../../core/models/inventory';
import { EquipmentService } from '../../../core/services/equipment.service';
import {
  EquipmentMasterRequestDto,
  EquipmentMasterResponseDto,
  EquipmentRequestDto,
  EquipmentResponseDto
} from '../../../core/models/equipment';

export interface Asset {
  id: number;
  assetName: string;
  category: string;
  assetType?: string;
  make: string;
  specification: string;
  cost: number | string;
  returnTimeline: string;
  total: number;
  available: number;
  issued: number;
  componentType: string;
  lab: string;
  cupboard: string;
  shelf1: string;
  count1: number | string;
  shelf2: string;
  count2: number | string;
  purpose: string;
  comments: string;
  remarks: string;
  status: string;
  minQty?: number;
  itemCode?: string;
  unit?: string;
  itemImage?: string | Blob;
  createdAt?: string;
  updatedAt?: string;
  assetCode?: string;
  serialNumber?: string;
  bookingStatus?: string;
  maintenanceStatus?: string;
  location?: string;
  purchaseDate?: string;
  equipmentMasterId?: number;
  sourceType?: 'inventory' | 'equipment';
}

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit, OnDestroy {
  inventory: Asset[] = [];
  filteredInventory: Asset[] = [];

  readonly labs = [
    'IoT Lab', 'Electronics Lab', 'Fabrication Lab', 'Manufacturing Lab',
    'Embedded Lab', 'AI Lab', 'Robotics Lab', 'Software Development Lab'
  ];

  currentPage = 1;
  rowsPerPage = 10;
  selectedCategory = 'Component';
  activeQuickFilter = 'All';
  currentSearchTerm = '';
  selectedExport = 'all';

  editingAssetId: number | null = null;
  deleteAssetId: number | null = null;
  deleteAssetName = '';

  isLoading = false;
  isSubmitting = false;
  isDeleting = false;
  isAddModalOpen = false;
  isViewModalOpen = false;
  isEditModalOpen = false;
  isBulkUploadModalOpen = false;
  isDeleteModalOpen = false;
  isExportModalOpen = false;
  isSidebarOpen = false;

  searchText = '';
  categoryFilter = '';
  statusFilter = '';

  viewAsset: Asset | null = null;
  editAsset: Asset | null = null;
  newAsset: Asset = this.getEmptyAsset();

  selectedFile: File | null = null;
  bulkUploadFile: File | null = null;

  rawInventoryData: Inventory[] = [];
  rawEquipmentData: EquipmentResponseDto[] = [];
  rawEquipmentMasterData: EquipmentMasterResponseDto[] = [];

  constructor(
    private inventoryService: InventoryService,
    private equipmentService: EquipmentService
  ) {}

  ngOnInit(): void { this.loadAllAssets(); }
  ngOnDestroy(): void { document.body.style.overflow = ''; }

  normalizeCategory(category: string | null | undefined): string {
    const value = (category || '').toUpperCase();
    if (value === 'COMPONENT') return 'Component';
    if (value === 'TOOL') return 'Tool';
    if (value === 'EQUIPMENT') return 'Equipment';
    return category || 'Component';
  }

  loadAllAssets(): void {
    this.isLoading = true;
    forkJoin({
      inventory: this.inventoryService.getAllInventory().pipe(catchError(error => {
        console.error('Inventory API failed:', error); return of([] as Inventory[]);
      })),
      equipment: this.equipmentService.getEquipments().pipe(catchError(error => {
        console.error('Equipment API failed:', error); return of([] as EquipmentResponseDto[]);
      })),
      equipmentMasters: this.equipmentService.getEquipmentMasters().pipe(catchError(error => {
        console.error('Equipment master API failed:', error); return of([] as EquipmentMasterResponseDto[]);
      }))
    }).pipe(finalize(() => this.isLoading = false)).subscribe({
      next: result => {
        this.rawInventoryData = result.inventory;
        this.rawEquipmentData = result.equipment;
        this.rawEquipmentMasterData = result.equipmentMasters;
        this.inventory = [
          ...result.inventory.map(item => this.mapInventoryToAsset(item)),
          ...result.equipment.map(item => this.mapEquipmentToAsset(item, result.equipmentMasters))
        ];
        this.applyFilters(false);
      },
      error: error => {
        console.error('Error loading assets:', error);
        this.inventory = [];
        this.filteredInventory = [];
        this.showToast('Failed to load assets.', 'error');
      }
    });
  }

  mapInventoryToAsset(item: Inventory): Asset {
    const total = Number(item.totalQuantity || 0);
    const available = Number(item.availableQuantity || 0);
    const category = this.normalizeCategory(item.itemCategory);
    let status = item.status || 'Available';
    if (available === 0) status = 'Out of Stock';
    else if (Number(item.minimumStock || 0) > 0 && available <= Number(item.minimumStock)) status = 'Low Stock';
    else status = 'Available';

    return {
      id: Number(item.itemId || 0), assetName: item.itemName || '', category,
      make: item.make || '', specification: item.specification || '', cost: item.cost || '',
      returnTimeline: item.returnTimeline || 'Daily', total, available, issued: total - available,
      componentType: category, lab: item.lab || '', cupboard: item.cupboard || '',
      shelf1: item.shelf1 || '', count1: item.shelf1Count || '', shelf2: item.shelf2 || '',
      count2: item.shelf2Count || '', purpose: item.purpose || '', comments: item.comments || '',
      remarks: (item as any).remarks || item.comments || '', status,
      minQty: Number(item.minimumStock || 0), itemCode: item.itemCode, unit: item.unit,
      itemImage: item.itemImage, createdAt: item.createdAt, updatedAt: item.updatedAt,
      sourceType: 'inventory'
    };
  }

  mapEquipmentToAsset(equipment: EquipmentResponseDto, masters: EquipmentMasterResponseDto[]): Asset {
    const master = masters.find(m => m.equipmentMasterId === equipment.equipmentMasterId);
    let status = 'Available';
    if (equipment.maintenanceStatus?.toLowerCase() === 'maintenance') status = 'Maintenance';
    else if (equipment.bookingStatus?.toLowerCase() === 'booked') status = 'Issued';

    return {
      id: equipment.equipmentId, assetName: equipment.equipmentName || master?.equipmentName || 'Unknown Equipment',
      category: 'Equipment', make: master?.make || '', specification: master?.specification || equipment.serialNumber || '',
      cost: master?.cost || '', returnTimeline: 'Project Completion', total: 1,
      available: equipment.bookingStatus?.toLowerCase() === 'available' ? 1 : 0,
      issued: equipment.bookingStatus?.toLowerCase() === 'booked' ? 1 : 0,
      componentType: 'Equipment', lab: master?.lab || equipment.location || '', cupboard: '', shelf1: '',
      count1: '', shelf2: '', count2: '', purpose: '', comments: '',
      remarks: equipment.remarks || master?.remarks || '', status, minQty: 0,
      itemCode: equipment.assetCode || equipment.serialNumber || `EQ-${equipment.equipmentId}`,
      unit: 'unit', itemImage: master?.equipmentImage, createdAt: equipment.createdAt,
      updatedAt: equipment.createdAt, assetCode: equipment.assetCode, serialNumber: equipment.serialNumber,
      bookingStatus: equipment.bookingStatus, maintenanceStatus: equipment.maintenanceStatus,
      location: equipment.location, purchaseDate: equipment.purchaseDate,
      equipmentMasterId: equipment.equipmentMasterId, sourceType: 'equipment'
    };
  }

  mapAssetToInventory(asset: Asset): Inventory {
    const total = Number(asset.total || 0);
    const available = asset.available === null || asset.available === undefined ? total : Number(asset.available);
    const data: Inventory = {
      itemCode: asset.itemCode?.trim() || `ITEM-${Date.now()}`,
      itemName: asset.assetName?.trim() || '', itemCategory: asset.category?.toUpperCase() || 'COMPONENT',
      make: asset.make?.trim() || '', specification: asset.specification?.trim() || '',
      cost: typeof asset.cost === 'string' ? Number(asset.cost) || 0 : asset.cost || 0,
      returnTimeline: asset.returnTimeline || 'Daily', totalQuantity: total, availableQuantity: available,
      minimumStock: Number(asset.minQty || 0), unit: asset.unit?.trim() || 'nos', lab: asset.lab || 'IoT Lab',
      cupboard: String(asset.cupboard || ''), shelf1: String(asset.shelf1 || ''),
      shelf1Count: Number(asset.count1 || 0), shelf2: String(asset.shelf2 || ''),
      shelf2Count: Number(asset.count2 || 0), purpose: asset.purpose?.trim() || '',
      comments: asset.comments?.trim() || '', itemImage: asset.itemImage, status: asset.status || 'Available',
      createdAt: asset.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    if (asset.id > 0) data.itemId = asset.id;
    return data;
  }

  getEmptyAsset(): Asset {
    return { id: 0, assetName: '', category: 'Component', make: '', specification: '', cost: '',
      returnTimeline: 'Daily', total: 0, available: 0, issued: 0, componentType: '', lab: 'IoT Lab',
      cupboard: '', shelf1: '', count1: '', shelf2: '', count2: '', purpose: '', comments: '',
      remarks: '', status: 'Available', minQty: 0, itemCode: '', unit: 'nos', sourceType: 'inventory' };
  }

  highlightText(text: string, term: string): string {
    if (!text || !term?.trim()) return text || '';
    const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return text.replace(new RegExp(`(${escaped})`, 'gi'), '<span class="search-highlight">$1</span>');
  }

  getTotalInventory(): number { return this.inventory.reduce((s, i) => s + i.total, 0); }
  getAvailableInventory(): number { return this.inventory.reduce((s, i) => s + i.available, 0); }
  getIssuedInventory(): number { return this.inventory.reduce((s, i) => s + i.issued, 0); }
  getLowStockCount(): number { return this.inventory.filter(i => i.status === 'Low Stock' && i.category !== 'Equipment').length; }
  getComponentTotal(): number { return this.sumBy('Component', 'total'); }
  getToolTotal(): number { return this.sumBy('Tool', 'total'); }
  getEquipmentTotal(): number { return this.inventory.filter(i => i.category === 'Equipment').length; }
  getAvailableComponents(): number { return this.sumBy('Component', 'available'); }
  getAvailableTools(): number { return this.sumBy('Tool', 'available'); }
  getAvailableEquipments(): number { return this.inventory.filter(i => i.category === 'Equipment' && i.available === 1).length; }
  getIssuedComponents(): number { return this.sumBy('Component', 'issued'); }
  getIssuedTools(): number { return this.sumBy('Tool', 'issued'); }
  getIssuedEquipments(): number { return this.inventory.filter(i => i.category === 'Equipment' && i.status === 'Issued').length; }
  getLowComponents(): number { return this.inventory.filter(i => i.category === 'Component' && i.status === 'Low Stock').length; }
  getLowTools(): number { return this.inventory.filter(i => i.category === 'Tool' && i.status === 'Low Stock').length; }
  private sumBy(category: string, field: 'total' | 'available' | 'issued'): number {
    return this.inventory.filter(i => i.category === category).reduce((s, i) => s + Number(i[field] || 0), 0);
  }

  applyFilters(resetPage = true): void {
    const search = this.searchText.toLowerCase().trim();
    this.filteredInventory = this.inventory.filter(asset => {
      const matchesSearch = [asset.assetName, asset.make, asset.specification, asset.itemCode,
        asset.assetCode, asset.serialNumber].some(v => (v || '').toLowerCase().includes(search));
      const matchesCategory = !this.categoryFilter || asset.category === this.categoryFilter;
      const matchesStatus = !this.statusFilter || asset.status === this.statusFilter;
      const quick: Record<string, boolean> = {
        Components: asset.category === 'Component', Tools: asset.category === 'Tool',
        Equipments: asset.category === 'Equipment', 'Low Stock': asset.status === 'Low Stock',
        'Out of Stock': asset.status === 'Out of Stock', Maintenance: asset.status === 'Maintenance'
      };
      return matchesSearch && matchesCategory && matchesStatus && (this.activeQuickFilter === 'All' || quick[this.activeQuickFilter]);
    });
    this.currentSearchTerm = search;
    if (resetPage) this.currentPage = 1;
    if (this.currentPage > this.getTotalPages()) this.currentPage = this.getTotalPages();
  }

  onSearch(): void { this.applyFilters(); }
  onCategoryFilterChange(): void { this.applyFilters(); }
  onStatusFilterChange(): void { this.applyFilters(); }
  setQuickFilter(filter: string): void { this.activeQuickFilter = filter; this.applyFilters(); }
  resetFilters(): void { this.searchText = ''; this.categoryFilter = ''; this.statusFilter = ''; this.activeQuickFilter = 'All'; this.applyFilters(); }
  getPaginatedData(): Asset[] { const start = (this.currentPage - 1) * this.rowsPerPage; return this.filteredInventory.slice(start, start + this.rowsPerPage); }
  getTotalPages(): number { return Math.max(1, Math.ceil(this.filteredInventory.length / this.rowsPerPage)); }
  getStartIndex(): number { return this.filteredInventory.length ? (this.currentPage - 1) * this.rowsPerPage + 1 : 0; }
  getEndIndex(): number { return Math.min(this.currentPage * this.rowsPerPage, this.filteredInventory.length); }
  prevPage(): void { if (this.currentPage > 1) this.currentPage--; }
  nextPage(): void { if (this.currentPage < this.getTotalPages()) this.currentPage++; }

  openModal(type: string): void {
    if (type === 'add') this.isAddModalOpen = true;
    else if (type === 'view') this.isViewModalOpen = true;
    else if (type === 'edit') this.isEditModalOpen = true;
    else if (type === 'bulk') this.isBulkUploadModalOpen = true;
    else if (type === 'delete') this.isDeleteModalOpen = true;
    else if (type === 'export') this.isExportModalOpen = true;
    document.body.style.overflow = 'hidden';
  }

  closeModal(type: string): void {
    if (type === 'delete' && this.isDeleting) return;
    if (type === 'add') { this.isAddModalOpen = false; this.selectedFile = null; }
    else if (type === 'view') { this.isViewModalOpen = false; this.viewAsset = null; }
    else if (type === 'edit') { this.isEditModalOpen = false; this.editAsset = null; this.editingAssetId = null; this.selectedFile = null; }
    else if (type === 'bulk') this.isBulkUploadModalOpen = false;
    else if (type === 'delete') { this.isDeleteModalOpen = false; this.deleteAssetId = null; this.deleteAssetName = ''; }
    else if (type === 'export') this.isExportModalOpen = false;
    if (!this.hasOpenModal()) document.body.style.overflow = '';
  }

  private hasOpenModal(): boolean {
    return this.isAddModalOpen || this.isViewModalOpen || this.isEditModalOpen ||
      this.isBulkUploadModalOpen || this.isDeleteModalOpen || this.isExportModalOpen;
  }

  closeAllModals(): void {
    if (this.isDeleting) return;
    this.isAddModalOpen = this.isViewModalOpen = this.isEditModalOpen = false;
    this.isBulkUploadModalOpen = this.isDeleteModalOpen = this.isExportModalOpen = false;
    this.viewAsset = this.editAsset = null;
    this.editingAssetId = this.deleteAssetId = null;
    this.deleteAssetName = '';
    document.body.style.overflow = '';
  }

  @HostListener('document:keydown.escape') onEscapePress(): void { if (!this.isDeleting) this.closeAllModals(); }
  refreshAssets(): void { this.loadAllAssets(); }
  resetAssetForm(): void { this.newAsset = this.getEmptyAsset(); this.selectedCategory = 'Component'; this.selectedFile = null; }
  openAddModal(): void { this.resetAssetForm(); this.openModal('add'); }
  selectCategory(category: string): void { this.selectedCategory = category; this.newAsset.category = category; }
  isCategorySelected(category: string): boolean { return this.selectedCategory === category; }
  showComponentToolFields(): boolean { return this.selectedCategory !== 'Equipment'; }
  showEquipmentFields(): boolean { return this.selectedCategory === 'Equipment'; }

  onFileSelected(event: Event): void { this.selectedFile = (event.target as HTMLInputElement).files?.[0] || null; }
  onEditFileSelected(event: Event): void { this.selectedFile = (event.target as HTMLInputElement).files?.[0] || null; }

  saveAsset(): void {
    const asset = this.newAsset;
    const name = asset.assetName.trim();
    const total = Number(asset.total);
    if (!name) { this.showToast('Asset Name is required.', 'error'); return; }
    if (!Number.isFinite(total) || total <= 0) { this.showToast('Please enter Total Count.', 'error'); return; }
    this.isSubmitting = true;

    if (this.selectedCategory === 'Equipment') {
      const master: EquipmentMasterRequestDto = {
        equipmentCode: asset.itemCode || asset.assetCode || `EQ-${Date.now()}`,
        equipmentName: name, equipmentType: 'Equipment', make: asset.make || 'Generic',
        specification: asset.specification || '', lab: asset.lab || 'IoT Lab',
        cost: Number(asset.cost || 0), remarks: asset.remarks || asset.comments || '',
        status: 'Active', totalQuantity: total, equipments: []
      };
      this.equipmentService.createEquipmentMaster(master).subscribe({
        next: created => {
          const requests: Observable<EquipmentResponseDto>[] = [];
          for (let i = 1; i <= total; i++) {
            const unit: EquipmentRequestDto = {
              equipmentMasterId: created.equipmentMasterId, assetCode: `${created.equipmentCode}-${i}`,
              serialNumber: `SN-${created.equipmentMasterId}-${i}-${Date.now()}`, bookingStatus: 'AVAILABLE',
              maintenanceStatus: 'OK', location: asset.lab || 'IoT Lab',
              purchaseDate: new Date().toISOString().split('T')[0], remarks: asset.remarks || ''
            };
            requests.push(this.equipmentService.createEquipment(unit));
          }
          forkJoin(requests).pipe(finalize(() => this.isSubmitting = false)).subscribe({
            next: () => { this.closeModal('add'); this.showToast(`Equipment "${name}" added successfully.`); this.loadAllAssets(); },
            error: err => { console.error(err); this.showToast('Equipment master created, but units failed.', 'warning'); this.loadAllAssets(); }
          });
        },
        error: error => { this.isSubmitting = false; console.error(error); this.showToast(`Failed to add equipment "${name}".`, 'error'); }
      });
      return;
    }

    const payload = this.mapAssetToInventory({ ...asset, total, available: Number(asset.available || total) });
    payload.status = Number(payload.availableQuantity || 0) === 0 ? 'Out of Stock' :
      Number(payload.availableQuantity || 0) <= Number(payload.minimumStock || 0) ? 'Low Stock' : 'Available';
    this.inventoryService.saveInventory(payload).pipe(finalize(() => this.isSubmitting = false)).subscribe({
      next: saved => { this.closeModal('add'); this.showToast(`"${name}" added successfully.`); if (this.selectedFile && saved.itemId) this.uploadImage(saved.itemId, this.selectedFile); else this.loadAllAssets(); },
      error: error => { console.error(error); this.showToast(`Failed to add "${name}".`, 'error'); }
    });
  }

  uploadImage(itemId: number, file: File): void {
    this.inventoryService.uploadImage(itemId, file).subscribe({
      next: () => { this.showToast('Image uploaded successfully.'); this.loadAllAssets(); },
      error: error => { console.error(error); this.showToast('Failed to upload image.', 'error'); this.loadAllAssets(); }
    });
  }

  viewAssetDetails(asset: Asset): void { this.viewAsset = { ...asset }; this.openModal('view'); }
  isEquipmentView(): boolean { return this.viewAsset?.category === 'Equipment'; }
  isComponentToolView(): boolean { return this.viewAsset?.category !== 'Equipment'; }

  openEditModal(asset: Asset): void {
    if (asset.sourceType === 'equipment') { this.showToast('Equipment can only be edited from the Equipment module.', 'warning'); return; }
    if (!Number.isInteger(Number(asset.id)) || Number(asset.id) <= 0) { this.showToast('Invalid asset ID.', 'error'); return; }
    this.editingAssetId = Number(asset.id);
    this.editAsset = { ...asset };
    this.selectedFile = null;
    this.openModal('edit');
  }

  isEquipmentEdit(): boolean { return this.editAsset?.category === 'Equipment'; }
  isComponentToolEdit(): boolean { return this.editAsset?.category !== 'Equipment'; }

  saveChanges(): void {
    if (!this.editAsset) return;
    this.isSubmitting = true;
    const payload = this.mapAssetToInventory(this.editAsset);
    payload.status = Number(payload.availableQuantity || 0) === 0 ? 'Out of Stock' :
      Number(payload.availableQuantity || 0) <= Number(payload.minimumStock || 0) ? 'Low Stock' : 'Available';
    this.inventoryService.updateInventory(payload).pipe(finalize(() => this.isSubmitting = false)).subscribe({
      next: updated => { const name = updated.itemName || this.editAsset?.assetName || 'Asset'; this.closeModal('edit'); this.showToast(`"${name}" updated successfully.`); if (this.selectedFile && updated.itemId) this.uploadImage(updated.itemId, this.selectedFile); else this.loadAllAssets(); },
      error: error => { console.error(error); this.showToast('Failed to update asset.', 'error'); }
    });
  }

  confirmDelete(): void {
    if (this.isDeleting) return;
    const asset = this.editAsset;
    if (!asset) { this.showToast('No asset selected to delete.', 'error'); return; }
    const id = Number(asset.id);
    if (!Number.isInteger(id) || id <= 0) { this.showToast('Invalid asset ID.', 'error'); return; }
    if (asset.sourceType === 'equipment') { this.showToast('Equipment can only be deleted from the Equipment module.', 'warning'); return; }

    // Capture the delete details before closeModal('edit') clears editAsset/editingAssetId.
    this.deleteAssetId = id;
    this.deleteAssetName = asset.assetName?.trim() || `Asset ${id}`;
    this.closeModal('edit');
    this.openModal('delete');
  }

  deleteAsset(): void {
    if (this.isDeleting) return;
    const id = this.deleteAssetId;
    const name = this.deleteAssetName;
    if (id === null || !Number.isInteger(id) || id <= 0) { this.showToast('No valid asset selected to delete.', 'error'); return; }

    this.isDeleting = true;
    this.inventoryService.deleteInventory(id).pipe(finalize(() => this.isDeleting = false)).subscribe({
      next: response => {
        console.log('Delete response:', response);
        this.inventory = this.inventory.filter(item => !(item.sourceType === 'inventory' && Number(item.id) === id));
        this.applyFilters(false);
        this.isDeleteModalOpen = false;
        this.deleteAssetId = null;
        this.deleteAssetName = '';
        document.body.style.overflow = '';
        this.showToast(`"${name}" has been deleted successfully.`);
        this.loadAllAssets();
      },
      error: error => {
        console.error('Delete failed:', error);
        const message = typeof error?.error === 'string' ? error.error :
          error?.error?.message || (error?.status === 404 ? 'Delete endpoint or asset was not found.' :
          error?.status === 0 ? 'Cannot connect to the inventory service.' : `Failed to delete "${name}".`);
        this.showToast(message, 'error');
      }
    });
  }

  onBulkFileSelected(event: Event): void { this.bulkUploadFile = (event.target as HTMLInputElement).files?.[0] || null; }
  clearBulkFileInput(): void { const input = document.getElementById('excelFile') as HTMLInputElement | null; if (input) input.value = ''; }
  downloadTemplate(): void {
    const sheet = XLSX.utils.aoa_to_sheet([
      ['itemCode', 'itemName', 'itemCategory', 'quantity'],
      ['COMP-101', 'Arduino Uno R3', 'Component', 50],
      ['TL-201', 'Digital Multimeter', 'Tool', 10]
    ]);
    const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, 'InventoryTemplate');
    XLSX.writeFile(book, 'inventory_bulk_upload_template.xlsx');
  }

  importAssets(): void {
    if (!this.bulkUploadFile) { this.showToast('Please choose an Excel file.', 'warning'); return; }
    this.isSubmitting = true;
    this.inventoryService.bulkUpload(this.bulkUploadFile).pipe(finalize(() => this.isSubmitting = false)).subscribe({
      next: (response: BulkUploadResponse) => { this.showToast(`Upload complete. ${response.successCount ?? 0} succeeded, ${response.failureCount ?? 0} failed.`, (response.failureCount ?? 0) > 0 ? 'warning' : 'success'); this.bulkUploadFile = null; this.clearBulkFileInput(); this.closeModal('bulk'); this.loadAllAssets(); },
      error: error => { console.error(error); this.showToast('Bulk upload failed.', 'error'); }
    });
  }

  openExportModal(): void { this.selectedExport = 'all'; this.openModal('export'); }
  selectExport(type: string): void { this.selectedExport = type; }
  isExportSelected(type: string): boolean { return this.selectedExport === type; }
  getExportCount(type: string): number { return type === 'all' ? this.inventory.length : this.inventory.filter(i => i.category === type).length; }
  confirmExport(): void {
    const data = this.selectedExport === 'all' ? [...this.inventory] : this.inventory.filter(i => i.category === this.selectedExport);
    if (!data.length) { this.showToast('No assets found to export.', 'warning'); return; }
    this.exportToCSV(data, this.selectedExport === 'all' ? 'All_Assets' : `${this.selectedExport}s`);
    this.closeModal('export');
  }

  exportToCSV(data: Asset[], fileName: string): void {
    const headers = ['Asset ID','Asset Name','Category','Make','Specification','Cost','Total Count','Available','Issued','Status','Lab','Cupboard','Shelf 1','Count 1','Shelf 2','Count 2','Return Timeline','Purpose','Comments','Remarks','Item Code','Unit','Created At','Updated At'];
    const rows = data.map(a => [a.id,a.assetName,a.category,a.make,a.specification,a.cost,a.total,a.category === 'Equipment' ? '-' : a.available,a.category === 'Equipment' ? '-' : a.issued,a.status,a.lab,a.cupboard,a.shelf1,a.count1,a.shelf2,a.count2,a.returnTimeline,a.purpose,a.comments,a.remarks,a.itemCode,a.unit,a.createdAt,a.updatedAt]);
    const escape = (value: unknown) => { const s = String(value ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const csv = [headers, ...rows].map(row => row.map(escape).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    const link = document.createElement('a'); link.href = url; link.download = `${fileName}_${new Date().toISOString().split('T')[0]}.csv`; link.click(); URL.revokeObjectURL(url);
  }

  showToast(message: string, type = 'success'): void {
    document.querySelector('.toast-notification')?.remove();
    const toast = document.createElement('div'); toast.className = `toast-notification ${type}`;
    const icon = document.createElement('i');
    icon.className = ({ success: 'fa-solid fa-check-circle', error: 'fa-solid fa-circle-exclamation', warning: 'fa-solid fa-triangle-exclamation', info: 'fa-solid fa-circle-info' } as Record<string,string>)[type] || 'fa-solid fa-check-circle';
    const text = document.createElement('span'); text.textContent = message;
    toast.append(icon, text); document.body.appendChild(toast); requestAnimationFrame(() => toast.classList.add('show'));
    setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); }, 3000);
  }

  toggleSidebar(): void { this.isSidebarOpen = !this.isSidebarOpen; }
  @HostListener('window:resize') onResize(): void { if (window.innerWidth > 992) this.isSidebarOpen = false; }
  flipCard(event: Event): void { (event.currentTarget as HTMLElement)?.closest('.flip-card')?.classList.toggle('flipped'); }
}
