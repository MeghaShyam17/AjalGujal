import {
  CommonModule,
  Location
} from '@angular/common';

import {
  Component,
  OnInit
} from '@angular/core';

import {
  FormsModule,
  NgForm
} from '@angular/forms';

import {
  UserService
} from '../../../core/services/user.service';

import {
  User,
  UserResponse,
  ResetPasswordRequest
} from '../../../core/models/user';

import {
  StorageService
} from '../../../core/services/storage.sevice';

interface ProfileUser {
  username: string;
  name: string;
  role: string;
  avatar: string;
  status: string;
  location: string;
  timezone: string;
  email: string;
  phone: string;
  gender: string;
  id: string;
}

interface ProfileUserResponse extends UserResponse {
  profileImage?: string | Blob;
}

type ProfileDialog =
  | 'edit'
  | 'password'
  | 'success'
  | null;

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  readonly databaseKey = 'rplms_db';

  readonly fallbackAvatar =
    'data:image/svg+xml;charset=UTF-8,' +
    encodeURIComponent(`
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 240 240"
      >
        <circle
          cx="120"
          cy="120"
          r="120"
          fill="#6366f1"
        />

        <text
          x="120"
          y="145"
          text-anchor="middle"
          font-family="Arial, sans-serif"
          font-size="76"
          font-weight="700"
          fill="#ffffff"
        >
          L
        </text>
      </svg>
    `);

  user: ProfileUser =
    this.getDefaultUser();

  editModel = {
    name: '',
    email: '',
    phone: '',
    role: ''
  };

  passwordModel = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };

  activeDialog: ProfileDialog = null;

  editError = '';
  passwordError = '';

  showCurrentPassword = false;
  showNewPassword = false;
  showConfirmPassword = false;

  toastVisible = false;
  toastMessage = '';

  toastType:
    | 'success'
    | 'error' = 'success';

  private toastTimer?:
    ReturnType<typeof setTimeout>;

  constructor(
    private readonly storage:
      StorageService,

    private readonly location:
      Location,

    private readonly userService:
      UserService
  ) {}

  ngOnInit(): void {
    this.loadUser();
  }

  get displayAvatar(): string {
    const avatar =
      this.user.avatar?.trim();

    if (
      !avatar ||
      avatar.includes('<a ') ||
      avatar.includes('<') ||
      avatar.includes('target=')
    ) {
      return this.fallbackAvatar;
    }

    return avatar;
  }

  goBack(): void {
    this.location.back();
  }

  openEditProfile(): void {
    this.editModel = {
      name: this.user.name || '',
      email: this.user.email || '',
      phone: this.user.phone || '',
      role:
        this.user.role ||
        'Lab Incharge'
    };

    this.editError = '';
    this.activeDialog = 'edit';
  }

  saveProfile(
    form: NgForm
  ): void {
    this.editError = '';

    const name =
      this.formatName(
        this.editModel.name.trim()
      );

    const email =
      this.editModel.email
        .trim()
        .toLowerCase();

    const phone =
      this.editModel.phone.trim();

    if (
      form.invalid ||
      !name ||
      !email ||
      !phone
    ) {
      form.control.markAllAsTouched();

      this.editError =
        'Please enter a valid name, email address, and phone number.';

      return;
    }

    if (!this.isValidEmail(email)) {
      this.editError =
        'Please enter a valid email address.';

      return;
    }

    if (!this.isValidPhone(phone)) {
      this.editError =
        'Please enter a valid phone number.';

      return;
    }

    const userId =
      this.getLoggedInUserId();

    if (!userId) {
      this.editError =
        'User ID not found. Please log in again.';

      return;
    }

    const updateData: User = {
      userId,
      name,
      email,
      phone,
      gender:
        this.user.gender ||
        'Female',
      status: 'ACTIVE'
    };

    this.userService
      .updateUser(
        userId,
        updateData
      )
      .subscribe({
        next: (
          updatedUser: UserResponse
        ) => {
          this.user = {
            ...this.user,

            username:
              updatedUser.email ||
              updatedUser.name ||
              email,

            name: this.formatName(
              updatedUser.name ||
              name
            ),

            email:
              updatedUser.email ||
              email,

            phone:
              updatedUser.phone ||
              phone,

            role: this.formatRole(
              updatedUser.roleName ||
              this.editModel.role ||
              this.user.role ||
              'Lab Incharge'
            ),

            status: 'Active',

            id: String(
              updatedUser.userId ||
              userId
            )
          };

          this.updateStoredUserDetails();
          this.persistUser();
          this.closeDialog();

          this.showToast(
            'Profile details updated successfully!'
          );
        },

        error: (
          error: unknown
        ) => {
          console.error(
            'Profile update error:',
            error
          );

          this.editError =
            this.getErrorMessage(
              error,
              'Unable to update profile. Please try again.'
            );
        }
      });
  }

  openChangePassword(): void {
    this.resetPasswordForm();
    this.activeDialog = 'password';
  }

  updatePassword(
    form: NgForm
  ): void {
    this.passwordError = '';

    const currentPassword =
      this.passwordModel
        .currentPassword
        .trim();

    const newPassword =
      this.passwordModel
        .newPassword
        .trim();

    const confirmPassword =
      this.passwordModel
        .confirmPassword
        .trim();

    if (
      form.invalid ||
      !currentPassword ||
      !newPassword ||
      !confirmPassword
    ) {
      form.control.markAllAsTouched();

      this.passwordError =
        'All password fields are required.';

      return;
    }

    if (
      !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(
        newPassword
      )
    ) {
      this.passwordError =
        'Password must contain at least 8 characters, one uppercase letter, one lowercase letter, and one number.';

      return;
    }

    if (
      newPassword !==
      confirmPassword
    ) {
      this.passwordError =
        'The new passwords do not match.';

      return;
    }

    if (
      newPassword ===
      currentPassword
    ) {
      this.passwordError =
        'The new password cannot be the same as the current password.';

      return;
    }

    const userId =
      this.getLoggedInUserId();

    if (!userId) {
      this.passwordError =
        'User ID not found. Please log in again.';

      return;
    }

    const payload:
      ResetPasswordRequest = {
        oldPassword:
          currentPassword,

        newPassword,

        confirmPassword
      };

    this.userService
      .changePassword(
        userId,
        payload
      )
      .subscribe({
        next: (
          response: string
        ) => {
          if (
            response &&
            response !==
              'Password reset successfully'
          ) {
            this.passwordError =
              response;

            return;
          }

          this.resetPasswordForm();

          this.activeDialog =
            'success';
        },

        error: (
          error: unknown
        ) => {
          console.error(
            'Password change error:',
            error
          );

          this.passwordError =
            this.getErrorMessage(
              error,
              'Unable to update password. Please check the current password.'
            );
        }
      });
  }

  onPhotoSelected(
    event: Event
  ): void {
    const input =
      event.target as
        HTMLInputElement;

    const file =
      input.files?.[0];

    if (!file) {
      return;
    }

    const allowedTypes = [
      'image/png',
      'image/jpeg',
      'image/webp'
    ];

    if (
      !allowedTypes.includes(
        file.type
      )
    ) {
      this.showToast(
        'Please select a PNG, JPG, or WebP image.',
        'error'
      );

      input.value = '';
      return;
    }

    const maximumFileSize =
      5 * 1024 * 1024;

    if (
      file.size >
      maximumFileSize
    ) {
      this.showToast(
        'Please select an image smaller than 5 MB.',
        'error'
      );

      input.value = '';
      return;
    }

    const userId =
      this.getLoggedInUserId();

    if (!userId) {
      this.showToast(
        'User ID not found. Please log in again.',
        'error'
      );

      input.value = '';
      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      if (
        typeof reader.result !==
        'string'
      ) {
        this.showToast(
          'Unable to read the selected image.',
          'error'
        );

        input.value = '';
        return;
      }

      const image =
        new Image();

      image.onload = () => {
        const maxDimension = 200;

        let width =
          image.width;

        let height =
          image.height;

        if (
          width > height &&
          width > maxDimension
        ) {
          height = Math.round(
            (
              height *
              maxDimension
            ) / width
          );

          width =
            maxDimension;
        } else if (
          height >= width &&
          height > maxDimension
        ) {
          width = Math.round(
            (
              width *
              maxDimension
            ) / height
          );

          height =
            maxDimension;
        }

        const canvas =
          document.createElement(
            'canvas'
          );

        canvas.width = width;
        canvas.height = height;

        const context =
          canvas.getContext('2d');

        if (!context) {
          this.showToast(
            'Unable to process the selected image.',
            'error'
          );

          input.value = '';
          return;
        }

        context.drawImage(
          image,
          0,
          0,
          width,
          height
        );

        const compressedDataUrl =
          canvas.toDataURL(
            'image/jpeg',
            0.7
          );

        const base64String =
          compressedDataUrl
            .split(',')[1];

        if (!base64String) {
          this.showToast(
            'Unable to process the selected image.',
            'error'
          );

          input.value = '';
          return;
        }

        const updateData: User = {
          userId,
          name: this.user.name,
          email: this.user.email,
          phone: this.user.phone,
          gender:
            this.user.gender ||
            'Female',
          status: 'ACTIVE',
          profileImage:
            base64String
        };

        this.userService
          .updateUser(
            userId,
            updateData
          )
          .subscribe({
            next: () => {
              this.user = {
                ...this.user,
                avatar:
                  compressedDataUrl
              };

              this.persistUser();

              this.showToast(
                'Profile picture updated successfully!'
              );

              input.value = '';
            },

            error: (
              error: unknown
            ) => {
              console.error(
                'Failed to update profile image:',
                error
              );

              this.showToast(
                this.getErrorMessage(
                  error,
                  'Failed to update profile picture.'
                ),
                'error'
              );

              input.value = '';
            }
          });
      };

      image.onerror = () => {
        this.showToast(
          'Unable to process the selected image.',
          'error'
        );

        input.value = '';
      };

      image.src =
        reader.result;
    };

    reader.onerror = () => {
      this.showToast(
        'Unable to read the selected image.',
        'error'
      );

      input.value = '';
    };

    reader.readAsDataURL(file);
  }

  useFallbackAvatar(
    event: Event
  ): void {
    const image =
      event.target as
        HTMLImageElement;

    image.onerror = null;

    image.src =
      this.fallbackAvatar;
  }

  closeDialog(): void {
    this.activeDialog = null;

    this.editError = '';
    this.passwordError = '';

    this.showCurrentPassword =
      false;

    this.showNewPassword =
      false;

    this.showConfirmPassword =
      false;
  }

  private loadUser(): void {
    const database =
      this.readDatabase();

    const locallyStoredUser =
      database['currentUser'];

    if (
      this.isProfileUser(
        locallyStoredUser
      )
    ) {
      this.user = {
        ...this.getDefaultUser(),
        ...locallyStoredUser,

        name: this.formatName(
          locallyStoredUser.name ||
          'User'
        ),

        role: this.formatRole(
          locallyStoredUser.role ||
          'Lab Incharge'
        ),

        status:
          this.formatStatus(
            locallyStoredUser.status
          )
      };
    } else {
      this.user =
        this.getDefaultUser();
    }

    if (
      this.user.avatar?.includes(
        '<a '
      ) ||
      this.user.avatar?.includes(
        '<'
      ) ||
      this.user.avatar?.includes(
        'target='
      )
    ) {
      this.user.avatar = '';
    }

    const userId =
      this.getLoggedInUserId();

    if (!userId) {
      console.error(
        'Logged-in user ID was not found in storage.'
      );

      this.showToast(
        'User ID not found. Please log in again.',
        'error'
      );

      return;
    }

    this.userService
      .getUserById(userId)
      .subscribe({
        next: (
          response: UserResponse
        ) => {
          const loggedInUser =
            response as
              ProfileUserResponse;

          const profileImage =
            this.getProfileImage(
              loggedInUser
                .profileImage
            );

          this.user = {
            ...this.user,

            username:
              loggedInUser.email ||
              loggedInUser.name ||
              this.user.username,

            name: this.formatName(
              loggedInUser.name ||
              this.user.name ||
              'User'
            ),

            email:
              loggedInUser.email ||
              this.user.email,

            phone:
              loggedInUser.phone ||
              this.user.phone,

            role: this.formatRole(
              loggedInUser.roleName ||
              this.storage.get(
                'role'
              ) ||
              this.user.role ||
              'Lab Incharge'
            ),

            status: 'Active',

            avatar:
              profileImage ||
              this.user.avatar,

            id: String(
              loggedInUser.userId ||
              userId
            )
          };

          this.updateStoredUserDetails();
          this.persistUser();
        },

        error: (
          error: unknown
        ) => {
          console.error(
            'Unable to load profile from backend:',
            error
          );

          this.showToast(
            'Using locally saved profile details.',
            'error'
          );
        }
      });
  }

  private updateStoredUserDetails():
    void {
    const userId =
      this.getLoggedInUserId();

    if (userId) {
      this.storage.update(
        'userId',
        String(userId)
      );
    }

    this.storage.update(
      'name',
      this.user.name
    );

    this.storage.update(
      'userName',
      this.user.name
    );

    this.storage.update(
      'email',
      this.user.email
    );

    this.storage.update(
      'phone',
      this.user.phone
    );

    this.storage.update(
      'role',
      this.user.role
    );
  }

  private getLoggedInUserId():
    number {
    const storedUserId =
      this.storage.get(
        'userId'
      ) ||
      this.storage.get('id') ||
      this.storage.get(
        'loggedInUserId'
      );

    const userId =
      Number(storedUserId);

    return (
      Number.isFinite(userId) &&
      userId > 0
    )
      ? userId
      : 0;
  }

  private readDatabase():
    Record<string, unknown> {
    try {
      const storedDatabase =
        this.storage.get(
          this.databaseKey
        );

      if (!storedDatabase) {
        return {};
      }

      const parsedDatabase =
        JSON.parse(
          storedDatabase
        );

      if (
        parsedDatabase &&
        typeof parsedDatabase ===
          'object' &&
        !Array.isArray(
          parsedDatabase
        )
      ) {
        return parsedDatabase as
          Record<string, unknown>;
      }

      return {};
    } catch {
      return {};
    }
  }

  private persistUser(): void {
    const database =
      this.readDatabase();

    database['currentUser'] =
      this.user;

    this.storage.update(
      this.databaseKey,
      JSON.stringify(database)
    );

    window.dispatchEvent(
      new CustomEvent(
        'rplms-user-updated',
        {
          detail: this.user
        }
      )
    );
  }

  private resetPasswordForm():
    void {
    this.passwordModel = {
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    };

    this.passwordError = '';

    this.showCurrentPassword =
      false;

    this.showNewPassword =
      false;

    this.showConfirmPassword =
      false;
  }

  private formatName(
    name: string
  ): string {
    return (name || '')
      .trim()
      .toLowerCase()
      .replace(
        /\b\w/g,
        character =>
          character.toUpperCase()
      );
  }

  private formatRole(
    role: string
  ): string {
    const formattedRole =
      (role || '')
        .trim()
        .replace(/_/g, ' ')
        .toLowerCase()
        .replace(
          /\b\w/g,
          character =>
            character.toUpperCase()
        );

    return (
      formattedRole ||
      'Lab Incharge'
    );
  }

  private formatStatus(
    status?: string
  ): string {
    const normalizedStatus =
      (status || 'ACTIVE')
        .trim()
        .toLowerCase();

    if (
      normalizedStatus ===
      'active'
    ) {
      return 'Active';
    }

    return this.formatName(
      status || 'Active'
    );
  }

  private isValidEmail(
    email: string
  ): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
      email
    );
  }

  private isValidPhone(
    phone: string
  ): boolean {
    return /^[0-9+\-\s()]{10,15}$/.test(
      phone
    );
  }

  private getProfileImage(
    image?: string | Blob
  ): string {
    if (
      typeof image !== 'string' ||
      !image.trim()
    ) {
      return '';
    }

    return this.toImageDataUrl(
      image.trim()
    );
  }

  private toImageDataUrl(
    image: string
  ): string {
    if (
      image.startsWith(
        'data:image/'
      )
    ) {
      return image;
    }

    return (
      'data:image/jpeg;base64,' +
      image
    );
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    if (
      typeof error === 'object' &&
      error !== null
    ) {
      const httpError =
        error as {
          error?:
            | {
                message?: string;
              }
            | string;
          message?: string;
        };

      if (
        typeof httpError.error ===
          'object' &&
        httpError.error?.message
      ) {
        return (
          httpError.error.message
        );
      }

      if (
        typeof httpError.error ===
          'string' &&
        httpError.error
      ) {
        return httpError.error;
      }

      if (httpError.message) {
        return httpError.message;
      }
    }

    return fallbackMessage;
  }

  private isProfileUser(
    value: unknown
  ): value is Partial<ProfileUser> {
    return (
      typeof value ===
        'object' &&
      value !== null &&
      !Array.isArray(value)
    );
  }

  private showToast(
    message: string,
    type:
      | 'success'
      | 'error' = 'success'
  ): void {
    if (this.toastTimer) {
      clearTimeout(
        this.toastTimer
      );
    }

    this.toastMessage =
      message;

    this.toastType =
      type;

    this.toastVisible =
      true;

    this.toastTimer =
      setTimeout(() => {
        this.toastVisible =
          false;
      }, 3500);
  }

  private getDefaultUser():
    ProfileUser {
    return {
      username: '',
      name: 'User',
      role: 'Lab Incharge',
      avatar: '',
      status: 'Active',
      location:
        'Main Lab Complex',
      timezone:
        'IST (UTC+5:30)',
      email: '',
      phone: '',
      gender: 'Female',
      id: ''
    };
  }
}