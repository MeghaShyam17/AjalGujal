import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { InventoryService } from '../../../core/services/inventory.service';
import { EquipmentService } from '../../../core/services/equipment.service';
import { ProjectService } from '../../../core/services/project.service';
import { ComponentInventoryService } from '../../../core/services/component-inventory.service';
import { ToolInventoryService } from '../../../core/services/tool-inventory.service';

interface InventoryCard {
  type: string;
  label: string;
  total: number;
  available: number;
  inUse: number;
  percentage: number;
  color: string;
  icon: string;
}

interface InUseItem {
  name: string;
  team: string;
  qty: number;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {

  isLoading = false;
  loadError = '';

  inventoryCards: InventoryCard[] = [
    {
      type: 'Tools',
      label: 'Tools',
      total: 0,
      available: 0,
      inUse: 0,
      percentage: 0,
      color: 'blue',
      icon: 'fas fa-wrench'
    },
    {
      type: 'Components',
      label: 'Components',
      total: 0,
      available: 0,
      inUse: 0,
      percentage: 0,
      color: 'purple',
      icon: 'fas fa-microchip'
    },
    {
      type: 'Equipment',
      label: 'Equipment',
      total: 0,
      available: 0,
      inUse: 0,
      percentage: 0,
      color: 'green',
      icon: 'fas fa-desktop'
    }
  ];

  pendingToolRequests = 0;
  pendingToolReturns = 0;
  pendingBookings = 0;
  pendingComponentRequests = 0;
  pendingComponentReturns = 0;
  equipmentMaintenance = 0;

  modalOpen = false;
  currentModalType = '';

  searchTerm = '';

  currentPage = 1;
  itemsPerPage = 5;

  mockInUseData: Record<string, InUseItem[]> = {
    Tools: [],
    Components: [],
    Equipment: []
  };

  constructor(
    private inventoryService: InventoryService,
    private equipmentService: EquipmentService,
    private projectService: ProjectService,
    private componentInventoryService: ComponentInventoryService,
    private toolInventoryService: ToolInventoryService
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    this.isLoading = true;
    this.loadError = '';

    forkJoin({
      inventory: this.inventoryService.getAllInventory().pipe(catchError(() => of([]))),
      equipments: this.equipmentService.getEquipments().pipe(catchError(() => of([]))),
      bookings: this.equipmentService.getBookings().pipe(catchError(() => of([]))),
      maintenances: this.equipmentService.getMaintenanceRecords().pipe(catchError(() => of([]))),
      projects: this.projectService.getAllProjects().pipe(catchError(() => of([]))),
      componentRequests: this.componentInventoryService.getComponentRequests({ status: 'PENDING' }).pipe(catchError(() => of([]))),
      toolRequests: this.toolInventoryService.getToolRequests({ status: 'PENDING' }).pipe(catchError(() => of([]))),
      componentReturns: this.componentInventoryService.getComponentReturns({ status: 'PENDING' }).pipe(catchError(() => of([]))),
      toolReturns: this.toolInventoryService.getToolReturns({ status: 'PENDING' }).pipe(catchError(() => of([])))
    })
    .pipe(finalize(() => this.isLoading = false))
    .subscribe({
      next: (res) => {
        // Process Inventory (Tools vs Components)
        const tools = res.inventory.filter(i => 
          i.itemCategory?.toLowerCase().includes('tool') || 
          i.itemCategory?.toLowerCase().includes('assembly') || 
          i.itemCategory?.toLowerCase().includes('testing') || 
          i.itemCategory === 'Tool'
        );
        const components = res.inventory.filter(i => 
          !i.itemCategory?.toLowerCase().includes('tool') && 
          !i.itemCategory?.toLowerCase().includes('assembly') && 
          !i.itemCategory?.toLowerCase().includes('testing')
        );

        const toolTotal = tools.reduce((sum, item) => sum + (item.totalQuantity || 0), 0);
        const toolAvail = tools.reduce((sum, item) => sum + (item.availableQuantity || 0), 0);
        const toolInUse = toolTotal - toolAvail;
        const toolPct = toolTotal > 0 ? Math.round((toolAvail / toolTotal) * 100) : 0;

        const compTotal = components.reduce((sum, item) => sum + (item.totalQuantity || 0), 0);
        const compAvail = components.reduce((sum, item) => sum + (item.availableQuantity || 0), 0);
        const compInUse = compTotal - compAvail;
        const compPct = compTotal > 0 ? Math.round((compAvail / compTotal) * 100) : 0;

        // Process Equipment
        const eqTotal = res.equipments.length;
        const eqAvail = res.equipments.filter(e => e.bookingStatus?.toLowerCase() === 'available').length;
        const eqInUse = res.equipments.filter(e => e.bookingStatus?.toLowerCase() === 'booked').length;
        const eqPct = eqTotal > 0 ? Math.round((eqAvail / eqTotal) * 100) : 0;

        this.inventoryCards = [
          {
            type: 'Tools',
            label: 'Tools',
            total: toolTotal,
            available: toolAvail,
            inUse: toolInUse,
            percentage: toolPct,
            color: 'blue',
            icon: 'fas fa-wrench'
          },
          {
            type: 'Components',
            label: 'Components',
            total: compTotal,
            available: compAvail,
            inUse: compInUse,
            percentage: compPct,
            color: 'purple',
            icon: 'fas fa-microchip'
          },
          {
            type: 'Equipment',
            label: 'Equipment',
            total: eqTotal,
            available: eqAvail,
            inUse: eqInUse,
            percentage: eqPct,
            color: 'green',
            icon: 'fas fa-desktop'
          }
        ];

        // Pending Actions
        this.pendingToolRequests = (res.toolRequests || []).filter((r: any) =>
          r.approvalStatus === 'PENDING' || r.approvalStatus === 'PARTIAL' || r.status === 'PENDING' || !r.approvalStatus
        ).length || (res.toolRequests?.length || 0);

        this.pendingToolReturns = (res.toolReturns || []).filter((r: any) =>
          r.returnStatus === 'PENDING' || r.returnStatus === 'Pending' || r.returnStatus === 'Awaiting Verification' || !r.returnStatus
        ).length || (res.toolReturns?.length || 0);

        const pendingB = res.bookings ? res.bookings.filter(b => b.approvalStatus === 'PENDING' || b.approvalStatus === 'Upcoming' || b.approvalStatus === 'Pending') : [];
        this.pendingBookings = pendingB.length;

        this.pendingComponentRequests = (res.componentRequests || []).filter((r: any) =>
          r.approvalStatus === 'PENDING' || r.approvalStatus === 'PARTIAL' || r.status === 'PENDING' || !r.approvalStatus
        ).length || (res.componentRequests?.length || 0);

        this.pendingComponentReturns = (res.componentReturns || []).filter((r: any) =>
          r.returnStatus === 'PENDING' || r.returnStatus === 'Pending' || r.returnStatus === 'Awaiting Verification' || !r.returnStatus
        ).length || (res.componentReturns?.length || 0);

        this.equipmentMaintenance = (res.maintenances || []).filter((m: any) =>
          m.maintenanceStatus?.toUpperCase() !== 'COMPLETED'
        ).length || (res.maintenances?.length || 0);

        // Populate in-use items
        this.mockInUseData = {
          Tools: tools.filter(t => (t.totalQuantity || 0) - (t.availableQuantity || 0) > 0).map(t => ({
            name: t.itemName,
            team: t.lab || 'Lab Incharge',
            qty: (t.totalQuantity || 0) - (t.availableQuantity || 0)
          })),
          Components: components.filter(c => (c.totalQuantity || 0) - (c.availableQuantity || 0) > 0).map(c => ({
            name: c.itemName,
            team: c.lab || 'Lab Incharge',
            qty: (c.totalQuantity || 0) - (c.availableQuantity || 0)
          })),
          Equipment: res.equipments.filter(e => e.bookingStatus?.toLowerCase() === 'booked').map(e => ({
            name: e.equipmentName || `Equipment #${e.equipmentId}`,
            team: e.location || 'In Use',
            qty: 1
          }))
        };
      },
      error: (err) => {
        console.error('Error loading dashboard data:', err);
        this.loadError = 'Failed to load dashboard statistics from backend.';
      }
    });
  }

  openInUseModal(type: string) {
    this.currentModalType = type;
    this.searchTerm = '';
    this.currentPage = 1;
    this.modalOpen = true;
  }

  closeInUseModal() {
    this.modalOpen = false;
  }

  get filteredItems(): InUseItem[] {
    return (
      this.mockInUseData[this.currentModalType] || []
    ).filter(
      item =>
        item.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        item.team.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  get paginatedItems(): InUseItem[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredItems.slice(start, start + this.itemsPerPage);
  }

  get pageInfo() {
    const start =
      this.filteredItems.length === 0
        ? 0
        : (this.currentPage - 1) * this.itemsPerPage + 1;

    const end = Math.min(
      this.currentPage * this.itemsPerPage,
      this.filteredItems.length
    );

    return `Showing ${start}-${end} of ${this.filteredItems.length}`;
  }

  nextPage() {
    const totalPages =
      Math.ceil(this.filteredItems.length / this.itemsPerPage);

    if (this.currentPage < totalPages) {
      this.currentPage++;
    }
  }

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
}
