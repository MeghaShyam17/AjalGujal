import {
  AfterViewInit,
  Component,
  HostListener
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements AfterViewInit {

  mobileMenuOpen = false;
  stickyHeader = false;
  showBackToTop = false;
  activeSection = 'home';

  ngAfterViewInit(): void {
    this.revealOnScroll();
    this.updateActiveSection();
  }

  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
  }

  closeMobileMenu(): void {
    this.mobileMenuOpen = false;
  }

  scrollToSection(
    sectionId: string
  ): void {

    const target =
      document.getElementById(sectionId);

    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }

    this.activeSection = sectionId;
    this.closeMobileMenu();
  }

  scrollToTop(): void {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }

  @HostListener('window:scroll')
  onWindowScroll(): void {
    this.stickyHeader = window.scrollY > 50;
    this.showBackToTop = window.scrollY > 400;

    this.updateActiveSection();
    this.revealOnScroll();
  }

  private updateActiveSection(): void {
    const sections =
      document.querySelectorAll('section[id]');

    let currentSection = 'home';

    sections.forEach((section) => {
      const element =
        section as HTMLElement;

      const sectionTop =
        element.offsetTop - 120;

      if (window.scrollY >= sectionTop) {
        currentSection =
          element.getAttribute('id') || 'home';
      }
    });

    this.activeSection = currentSection;
  }

  private revealOnScroll(): void {
    const revealElements =
      document.querySelectorAll(
        '.about-card, .role-card, .feature-card, .stat-card, .workflow-step, .contact-card'
      );

    revealElements.forEach((element) => {
      const htmlElement =
        element as HTMLElement;

      const elementTop =
        htmlElement.getBoundingClientRect().top;

      const windowHeight =
        window.innerHeight;

      if (elementTop < windowHeight - 100) {
        htmlElement.classList.add('show');
      }
    });
  }
}