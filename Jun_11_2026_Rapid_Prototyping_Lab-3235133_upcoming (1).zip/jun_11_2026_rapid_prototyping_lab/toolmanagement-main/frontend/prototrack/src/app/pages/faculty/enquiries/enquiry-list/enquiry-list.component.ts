import {
  Component,
  OnDestroy,
  OnInit,
  Optional
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
  catchError,
  finalize,
  forkJoin,
  map,
  Observable,
  of,
  Subscription,
  switchMap
} from 'rxjs';

import { EnquiryManagementService } from '../../../../core/services/enquiry.service';
import { FacultyService } from '../../../../core/services/faculty.service';
import { ToastService } from '../../../../core/services/toast.service';
import { UserService } from '../../../../core/services/user.service';
import { EnquiryResponse } from '../../../../core/models/enquiry';

type FacultyEnquiryTab =
  | 'pending'
  | 'answered';

export interface EnquiryItem {
  id: number;
  question: string;
  sender: string;
  senderRole: string;
  stageNo: number;
  stageName: string;
  status: 'Pending' | 'Answered';
  time: string;
  response?: string;
  respondedOn?: string;
  replyText?: string;
}

export interface TeamEnquiryGroup {
  team: string;
  projectId: number;
  batch: string;
  enquiries: EnquiryItem[];
}

interface UserLookup {
  userId: number;
  name: string;
  roleName: string;
}

interface EnquiryLoadResult {
  rawEnquiries: EnquiryResponse[];
  rawProjects: unknown[];
  userMap: Map<number, UserLookup>;
}

@Component({
  selector: 'app-enquiry-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  templateUrl: './enquiry-list.component.html',
  styleUrl: './enquiry-list.component.css'
})
export class EnquiryListComponent
  implements OnInit, OnDestroy {

  teamGroups: TeamEnquiryGroup[] = [];
  filteredGroups: TeamEnquiryGroup[] = [];

  selectedGroup: TeamEnquiryGroup | null = null;
  selectedEnquiry: EnquiryItem | null = null;

  activeTab: FacultyEnquiryTab = 'pending';

  selectedBatch = 'all';
  searchText = '';
  batches: string[] = [];

  readonly teamPageSize = 8;
  readonly enquiryPageSize = 10;

  teamCurrentPage = 1;
  pendingCurrentPage = 1;
  answeredCurrentPage = 1;

  loading = false;
  toastMessage = '';
  errorMessage = '';

  facultyId = 0;

  private isSubmittingReply = false;

  private toastTimer:
    ReturnType<typeof setTimeout> | null = null;

  private readonly subscriptions =
    new Subscription();

  constructor(
    private readonly toastService: ToastService,
    private readonly userService: UserService,
    @Optional()
    private readonly enquiryService?:
      EnquiryManagementService,
    @Optional()
    private readonly facultyService?:
      FacultyService
  ) {}

  ngOnInit(): void {
    this.facultyId =
      this.resolveCurrentFacultyId();

    if (!this.facultyId) {
      this.errorMessage =
        'Faculty ID not found. Please login again.';

      return;
    }

    this.loadEnquiries();
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();

    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
    }

    this.unlockBodyScroll();
  }

  get paginatedGroups():
    TeamEnquiryGroup[] {

    const startIndex =
      (this.teamCurrentPage - 1) *
      this.teamPageSize;

    return this.filteredGroups.slice(
      startIndex,
      startIndex + this.teamPageSize
    );
  }

  get teamTotalPages(): number {
    return Math.max(
      1,
      Math.ceil(
        this.filteredGroups.length /
        this.teamPageSize
      )
    );
  }

  get teamPageNumbers(): number[] {
    return this.createPageNumbers(
      this.teamCurrentPage,
      this.teamTotalPages
    );
  }

  get teamStartItem(): number {
    if (this.filteredGroups.length === 0) {
      return 0;
    }

    return (
      (this.teamCurrentPage - 1) *
      this.teamPageSize
    ) + 1;
  }

  get teamEndItem(): number {
    return Math.min(
      this.teamCurrentPage *
      this.teamPageSize,
      this.filteredGroups.length
    );
  }

  get pendingEnquiries(): EnquiryItem[] {
    if (!this.selectedGroup) {
      return [];
    }

    return this.selectedGroup.enquiries.filter(
      (enquiry: EnquiryItem) =>
        enquiry.status === 'Pending'
    );
  }

  get answeredEnquiries(): EnquiryItem[] {
    if (!this.selectedGroup) {
      return [];
    }

    return this.selectedGroup.enquiries.filter(
      (enquiry: EnquiryItem) =>
        enquiry.status === 'Answered'
    );
  }

  get paginatedPendingEnquiries():
    EnquiryItem[] {

    const startIndex =
      (this.pendingCurrentPage - 1) *
      this.enquiryPageSize;

    return this.pendingEnquiries.slice(
      startIndex,
      startIndex + this.enquiryPageSize
    );
  }

  get paginatedAnsweredEnquiries():
    EnquiryItem[] {

    const startIndex =
      (this.answeredCurrentPage - 1) *
      this.enquiryPageSize;

    return this.answeredEnquiries.slice(
      startIndex,
      startIndex + this.enquiryPageSize
    );
  }

  get pendingTotalPages(): number {
    return Math.max(
      1,
      Math.ceil(
        this.pendingEnquiries.length /
        this.enquiryPageSize
      )
    );
  }

  get answeredTotalPages(): number {
    return Math.max(
      1,
      Math.ceil(
        this.answeredEnquiries.length /
        this.enquiryPageSize
      )
    );
  }

  get pendingPageNumbers(): number[] {
    return this.createPageNumbers(
      this.pendingCurrentPage,
      this.pendingTotalPages
    );
  }

  get answeredPageNumbers(): number[] {
    return this.createPageNumbers(
      this.answeredCurrentPage,
      this.answeredTotalPages
    );
  }

  get pendingStartItem(): number {
    if (this.pendingEnquiries.length === 0) {
      return 0;
    }

    return (
      (this.pendingCurrentPage - 1) *
      this.enquiryPageSize
    ) + 1;
  }

  get pendingEndItem(): number {
    return Math.min(
      this.pendingCurrentPage *
      this.enquiryPageSize,
      this.pendingEnquiries.length
    );
  }

  get answeredStartItem(): number {
    if (this.answeredEnquiries.length === 0) {
      return 0;
    }

    return (
      (this.answeredCurrentPage - 1) *
      this.enquiryPageSize
    ) + 1;
  }

  get answeredEndItem(): number {
    return Math.min(
      this.answeredCurrentPage *
      this.enquiryPageSize,
      this.answeredEnquiries.length
    );
  }

  loadEnquiries(): void {
    if (this.loading) {
      return;
    }

    if (!this.enquiryService) {
      this.errorMessage =
        'Enquiry service is currently not available.';

      return;
    }

    this.loading = true;
    this.errorMessage = '';

    const enquiriesObservable =
      this.enquiryService
        .getEnquiriesByFacultyId(
          this.facultyId
        );

    const projectsObservable =
      this.facultyService
        ? this.facultyService
            .getProjectsByFacultyId(
              this.facultyId
            )
            .pipe(
              catchError(
                (error: unknown) => {
                  console.warn(
                    'Unable to load faculty projects. Enquiry project information will be used instead.',
                    error
                  );

                  return of([]);
                }
              )
            )
        : of([]);

    const subscription = forkJoin({
      enquiries: enquiriesObservable,
      projects: projectsObservable
    })
      .pipe(
        switchMap((result: {
          enquiries:
            EnquiryResponse[] | unknown;
          projects:
            unknown[] | unknown;
        }) => {
          const rawEnquiries =
            this.extractArray<EnquiryResponse>(
              result.enquiries,
              [
                'data',
                'content',
                'enquiries',
                'body'
              ]
            );

          const rawProjects =
            this.extractArray<unknown>(
              result.projects,
              [
                'data',
                'content',
                'projects',
                'body'
              ]
            );

          return this.resolveStudentDetails(
            rawEnquiries,
            rawProjects
          );
        }),
        finalize(() => {
          this.loading = false;
        })
      )
      .subscribe({
        next: (
          result: EnquiryLoadResult
        ) => {
          this.buildTeamGroups(
            result.rawEnquiries,
            result.rawProjects,
            result.userMap
          );

          this.filterGroups();
          this.normalizeAllPagination();
        },

        error: (error: unknown) => {
          console.error(
            'Failed to fetch enquiries from backend:',
            error
          );

          this.errorMessage =
            'Could not load enquiries from the backend server.';
        }
      });

    this.subscriptions.add(subscription);
  }

  onFilterChange(): void {
    this.teamCurrentPage = 1;
    this.filterGroups();
  }

  clearSearch(): void {
    this.searchText = '';
    this.teamCurrentPage = 1;
    this.filterGroups();
  }

  clearFilters(): void {
    this.searchText = '';
    this.selectedBatch = 'all';
    this.teamCurrentPage = 1;

    this.filterGroups();
  }

  filterGroups(): void {
    const query =
      this.searchText
        .trim()
        .toLowerCase();

    this.filteredGroups =
      this.teamGroups.filter(
        (group: TeamEnquiryGroup) => {
          const matchesBatch =
            this.selectedBatch === 'all' ||
            group.batch ===
              this.selectedBatch;

          const searchableEnquiryText =
            group.enquiries
              .map(
                (
                  enquiry:
                    EnquiryItem
                ) => {
                  return [
                    enquiry.question,
                    enquiry.response ?? '',
                    enquiry.sender,
                    enquiry.senderRole,
                    enquiry.stageName
                  ].join(' ');
                }
              )
              .join(' ')
              .toLowerCase();

          const matchesSearch =
            !query ||
            group.team
              .toLowerCase()
              .includes(query) ||
            group.projectId
              .toString()
              .includes(query) ||
            group.batch
              .toLowerCase()
              .includes(query) ||
            `prj-${group.projectId}`
              .includes(query) ||
            searchableEnquiryText
              .includes(query);

          return (
            matchesBatch &&
            matchesSearch
          );
        }
      );

    this.normalizeTeamPagination();
  }

  openTeam(
    group: TeamEnquiryGroup,
    tab: FacultyEnquiryTab = 'pending'
  ): void {
    this.selectedGroup = group;
    this.selectedEnquiry = null;
    this.activeTab = tab;

    this.pendingCurrentPage = 1;
    this.answeredCurrentPage = 1;

    this.scrollPageToTop();
  }

  closeTeam(): void {
    this.selectedGroup = null;
    this.selectedEnquiry = null;

    this.activeTab = 'pending';
    this.pendingCurrentPage = 1;
    this.answeredCurrentPage = 1;

    this.unlockBodyScroll();
    this.normalizeTeamPagination();
    this.scrollPageToTop();
  }

  setTab(
    tab: FacultyEnquiryTab
  ): void {
    this.activeTab = tab;
    this.selectedEnquiry = null;

    if (tab === 'pending') {
      this.pendingCurrentPage = 1;
    } else {
      this.answeredCurrentPage = 1;
    }

    this.unlockBodyScroll();
  }

  viewEnquiry(
    enquiry: EnquiryItem
  ): void {
    this.selectedEnquiry = enquiry;
    this.lockBodyScroll();
  }

  closeEnquiry(): void {
    this.selectedEnquiry = null;
    this.unlockBodyScroll();
  }

  getPendingCount(
    group: TeamEnquiryGroup
  ): number {
    return group.enquiries.filter(
      (enquiry: EnquiryItem) =>
        enquiry.status === 'Pending'
    ).length;
  }

  getAnsweredCount(
    group: TeamEnquiryGroup
  ): number {
    return group.enquiries.filter(
      (enquiry: EnquiryItem) =>
        enquiry.status === 'Answered'
    ).length;
  }

  goToTeamPage(page: number): void {
    const validPage =
      this.clampPage(
        page,
        this.teamTotalPages
      );

    if (
      validPage ===
      this.teamCurrentPage
    ) {
      return;
    }

    this.teamCurrentPage =
      validPage;

    this.scrollToElement(
      '.team-list-summary'
    );
  }

  goToPendingPage(
    page: number
  ): void {
    const validPage =
      this.clampPage(
        page,
        this.pendingTotalPages
      );

    if (
      validPage ===
      this.pendingCurrentPage
    ) {
      return;
    }

    this.pendingCurrentPage =
      validPage;

    this.scrollToElement(
      '.query-panel'
    );
  }

  goToAnsweredPage(
    page: number
  ): void {
    const validPage =
      this.clampPage(
        page,
        this.answeredTotalPages
      );

    if (
      validPage ===
      this.answeredCurrentPage
    ) {
      return;
    }

    this.answeredCurrentPage =
      validPage;

    this.scrollToElement(
      '.query-panel'
    );
  }

  sendReply(
    enquiry: EnquiryItem
  ): void {
    if (this.isSubmittingReply) {
      return;
    }

    const replyContent =
      enquiry.replyText?.trim() ?? '';

    if (!replyContent) {
      this.toastService.showWarning(
        'Please enter a response before submitting.'
      );

      return;
    }

    if (replyContent.length > 2000) {
      this.toastService.showWarning(
        'Faculty response cannot exceed 2000 characters.'
      );

      return;
    }

    if (!this.enquiryService) {
      this.toastService.showError(
        'Enquiry service is currently not available.'
      );

      return;
    }

    this.isSubmittingReply = true;

    const subscription =
      this.enquiryService
        .facultyReply(
          enquiry.id,
          replyContent
        )
        .pipe(
          finalize(() => {
            this.isSubmittingReply =
              false;
          })
        )
        .subscribe({
          next: (
            response:
              EnquiryResponse
          ) => {
            enquiry.status =
              'Answered';

            enquiry.response =
              response.facultyComment?.trim() ||
              replyContent;

            enquiry.respondedOn =
              response.repliedAt
                ? this.formatDate(
                    response.repliedAt
                  )
                : 'Just Now';

            enquiry.replyText = '';

            this.activeTab =
              'answered';

            this.answeredCurrentPage =
              1;

            this.normalizeEnquiryPagination();
            this.closeEnquiry();

            this.showToast(
              `Response submitted successfully for ${enquiry.sender}.`
            );
          },

          error: (
            error: unknown
          ) => {
            console.error(
              'Backend reply failed:',
              error
            );

            this.toastService.showError(
              `Failed to submit the response for ${enquiry.sender}.`
            );

            this.showToast(
              `Failed to submit the response for ${enquiry.sender}.`
            );
          }
        });

    this.subscriptions.add(subscription);
  }

  showToast(message: string): void {
    this.toastMessage = message;

    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
    }

    this.toastTimer = setTimeout(
      () => {
        this.toastMessage = '';
        this.toastTimer = null;
      },
      3000
    );
  }

  getShortSubject(
    question:
      string | null | undefined
  ): string {
    const originalText =
      (question ?? '').trim();

    if (!originalText) {
      return 'Project Query';
    }

    const firstMeaningfulLine =
      originalText
        .split(/\r?\n/)
        .map(
          (line: string) =>
            line
              .replace(/\s+/g, ' ')
              .trim()
        )
        .find(
          (line: string) =>
            line.length > 0
        ) ?? '';

    const normalizedText =
      firstMeaningfulLine ||
      originalText
        .replace(/\s+/g, ' ')
        .trim();

    const firstSentence =
      normalizedText
        .split(/[.!?]/)[0]
        .trim();

    const sourceText =
      firstSentence ||
      normalizedText;

    const maximumLength = 40;

    if (
      sourceText.length <=
      maximumLength
    ) {
      return this.toTitleCase(
        sourceText
      );
    }

    const shortenedText =
      sourceText
        .slice(0, maximumLength)
        .replace(/\s+\S*$/, '')
        .trim();

    const finalText =
      shortenedText ||
      sourceText
        .slice(0, maximumLength)
        .trim();

    return `${this.toTitleCase(
      finalText
    )}...`;
  }

  getInitials(
    name:
      string | null | undefined
  ): string {
    if (!name?.trim()) {
      return 'NA';
    }

    const ignoredTitles = [
      'dr',
      'dr.',
      'mr',
      'mr.',
      'mrs',
      'mrs.',
      'ms',
      'ms.'
    ];

    const words = name
      .trim()
      .split(/\s+/)
      .filter(
        (word: string) =>
          !ignoredTitles.includes(
            word.toLowerCase()
          )
      );

    if (words.length === 0) {
      return 'NA';
    }

    if (words.length === 1) {
      return words[0]
        .slice(0, 2)
        .toUpperCase();
    }

    return (
      words[0].charAt(0) +
      words[
        words.length - 1
      ].charAt(0)
    ).toUpperCase();
  }

  trackByProjectId(
    _index: number,
    group: TeamEnquiryGroup
  ): number {
    return group.projectId;
  }

  trackByEnquiryId(
    _index: number,
    enquiry: EnquiryItem
  ): number {
    return enquiry.id;
  }

  private resolveStudentDetails(
    rawEnquiries:
      EnquiryResponse[],
    rawProjects:
      unknown[]
  ): Observable<EnquiryLoadResult> {

    const userIds = Array.from(
      new Set(
        rawEnquiries
          .map(
            (
              enquiry:
                EnquiryResponse
            ) =>
              Number(
                enquiry.userId
              )
          )
          .filter(
            (
              userId:
                number
            ) =>
              Number.isFinite(
                userId
              ) &&
              userId > 0
          )
      )
    );

    if (userIds.length === 0) {
      return of({
        rawEnquiries,
        rawProjects,
        userMap:
          new Map<
            number,
            UserLookup
          >()
      });
    }

    const userRequests =
      userIds.map(
        (userId: number) =>
          this.loadUserSafely(
            userId
          )
      );

    return forkJoin(
      userRequests
    ).pipe(
      map(
        (
          users:
            UserLookup[]
        ) => {
          const userMap =
            new Map<
              number,
              UserLookup
            >();

          users.forEach(
            (
              user:
                UserLookup
            ) => {
              userMap.set(
                user.userId,
                user
              );
            }
          );

          return {
            rawEnquiries,
            rawProjects,
            userMap
          };
        }
      )
    );
  }

  private loadUserSafely(
    userId: number
  ): Observable<UserLookup> {
    return this.userService
      .getUserById(userId)
      .pipe(
        map((response: unknown) =>
          this.mapUserResponse(
            response,
            userId
          )
        ),
        catchError(
          (error: unknown) => {
            console.warn(
              `Failed to fetch user details for userId ${userId}:`,
              error
            );

            return of({
              userId,
              name:
                `Trainee #${userId}`,
              roleName:
                'Student'
            });
          }
        )
      );
  }

  private buildTeamGroups(
    rawEnquiries:
      EnquiryResponse[],
    rawProjects:
      unknown[],
    userMap:
      Map<number, UserLookup>
  ): void {

    const groupMap =
      new Map<
        number,
        TeamEnquiryGroup
      >();

    rawProjects.forEach(
      (project: unknown) => {
        const projectRecord =
          this.toRecord(project);

        const projectId =
          Number(
            projectRecord[
              'projectId'
            ] ??
            projectRecord['id']
          );

        if (
          !Number.isFinite(
            projectId
          ) ||
          projectId <= 0
        ) {
          return;
        }

        const projectName =
          this.toTitleCase(
            String(
              projectRecord[
                'projectName'
              ] ??
              projectRecord[
                'name'
              ] ??
              `Project ${projectId}`
            )
          );

        const batchName =
          this.resolveBatchName(
            projectRecord
          );

        groupMap.set(
          projectId,
          {
            team:
              projectName ||
              `Project ${projectId}`,
            projectId,
            batch:
              batchName,
            enquiries: []
          }
        );
      }
    );

    rawEnquiries.forEach(
      (
        enquiry:
          EnquiryResponse
      ) => {
        const projectId =
          Number(
            enquiry.projectId
          );

        if (
          !Number.isFinite(
            projectId
          ) ||
          projectId <= 0
        ) {
          console.warn(
            'Skipping enquiry because projectId is missing:',
            enquiry
          );

          return;
        }

        if (
          !groupMap.has(
            projectId
          )
        ) {
          groupMap.set(
            projectId,
            {
              team:
                this.toTitleCase(
                  enquiry.projectName
                ) ||
                `Project ${projectId}`,
              projectId,
              batch:
                'Batch Not Assigned',
              enquiries: []
            }
          );
        }

        const group =
          groupMap.get(
            projectId
          );

        if (!group) {
          return;
        }

        const userId =
          Number(
            enquiry.userId
          );

        const user =
          userMap.get(userId);

        const enquiryItem =
          this.mapEnquiryToItem(
            enquiry,
            user
          );

        group.enquiries.push(
          enquiryItem
        );
      }
    );

    this.teamGroups =
      Array.from(
        groupMap.values()
      )
        .map(
          (
            group:
              TeamEnquiryGroup
          ) => ({
            ...group,
            team:
              this.toTitleCase(
                group.team
              ),
            batch:
              this.toTitleCase(
                group.batch
              ),
            enquiries:
              [...group.enquiries]
                .sort(
                  (
                    first:
                      EnquiryItem,
                    second:
                      EnquiryItem
                  ) =>
                    second.id -
                    first.id
                )
          })
        )
        .sort(
          (
            first:
              TeamEnquiryGroup,
            second:
              TeamEnquiryGroup
          ) =>
            first.projectId -
            second.projectId
        );

    const batchSet =
      new Set<string>(
        this.teamGroups
          .map(
            (
              group:
                TeamEnquiryGroup
            ) =>
              group.batch
          )
          .filter(
            (
              batch:
                string
            ) =>
              Boolean(
                batch
              ) &&
              batch !==
                'Batch Not Assigned'
          )
      );

    this.batches =
      Array.from(
        batchSet
      ).sort(
        (
          first: string,
          second: string
        ) =>
          first.localeCompare(
            second,
            undefined,
            {
              numeric: true,
              sensitivity: 'base'
            }
          )
      );

    if (
      this.selectedBatch !== 'all' &&
      !this.batches.includes(
        this.selectedBatch
      )
    ) {
      this.selectedBatch = 'all';
    }
  }

  private mapEnquiryToItem(
    enquiry: EnquiryResponse,
    user:
      UserLookup | undefined
  ): EnquiryItem {

    const normalizedStatus =
      (enquiry.enquiryStatus ?? '')
        .trim()
        .toUpperCase();

    const isAnswered =
      Boolean(
        enquiry.facultyComment
          ?.trim()
      ) ||
      normalizedStatus ===
        'RESOLVED' ||
      normalizedStatus ===
        'ANSWERED' ||
      normalizedStatus ===
        'CLOSED' ||
      normalizedStatus ===
        'REPLIED';

    const studentName =
      user?.name ||
      `Trainee #${enquiry.userId}`;

    const studentRole =
      user?.roleName ||
      'Student';

    return {
      id:
        Number(
          enquiry.enquiryId
        ),
      question:
        enquiry.userComment
          ?.trim() ||
        'Project technical query submitted by student.',
      sender:
        this.toTitleCase(
          studentName
        ),
      senderRole:
        this.toTitleCase(
          studentRole
        ),
      stageNo: 1,
      stageName:
        this.toTitleCase(
          'Project Query'
        ),
      status:
        isAnswered
          ? 'Answered'
          : 'Pending',
      time:
        this.formatDate(
          enquiry.createdAt
        ),
      response:
        enquiry.facultyComment
          ?.trim() ||
        undefined,
      respondedOn:
        enquiry.repliedAt
          ? this.formatDate(
              enquiry.repliedAt
            )
          : undefined,
      replyText: ''
    };
  }

  private mapUserResponse(
    response: unknown,
    fallbackUserId: number
  ): UserLookup {
    const responseRecord =
      this.toRecord(response);

    const data =
      responseRecord['data'];

    const source =
      data &&
      typeof data === 'object'
        ? this.toRecord(data)
        : responseRecord;

    const role =
      source['role'];

    const roleObject =
      role &&
      typeof role === 'object'
        ? this.toRecord(role)
        : {};

    const userId =
      Number(
        source['userId'] ??
        source['id'] ??
        fallbackUserId
      ) ||
      fallbackUserId;

    const name =
      String(
        source['name'] ??
        source['fullName'] ??
        source['userName'] ??
        source['username'] ??
        ''
      ).trim();

    const roleName =
      String(
        source['roleName'] ??
        roleObject[
          'roleName'
        ] ??
        'Student'
      ).trim();

    return {
      userId,
      name:
        this.toTitleCase(
          name
        ) ||
        `Trainee #${fallbackUserId}`,
      roleName:
        this.toTitleCase(
          roleName
        ) ||
        'Student'
    };
  }

  private resolveBatchName(
    project:
      Record<string, unknown>
  ): string {
    const batchValue =
      project['batch'];

    const batchObject =
      batchValue &&
      typeof batchValue === 'object'
        ? this.toRecord(
            batchValue
          )
        : {};

    const batchName =
      String(
        project['batchName'] ??
        project['batchTitle'] ??
        project['batchCode'] ??
        batchObject['batchName'] ??
        batchObject['name'] ??
        batchObject['batchTitle'] ??
        batchObject['batchCode'] ??
        (
          typeof batchValue === 'string'
            ? batchValue
            : ''
        )
      ).trim();

    if (batchName) {
      return this.toTitleCase(
        batchName
      );
    }

    const batchId =
      Number(
        project['batchId'] ??
        batchObject['batchId'] ??
        batchObject['id']
      );

    if (
      Number.isFinite(
        batchId
      ) &&
      batchId > 0
    ) {
      return `Batch ${batchId}`;
    }

    return 'Batch Not Assigned';
  }

  private extractArray<T>(
    response: unknown,
    keys: string[]
  ): T[] {
    if (Array.isArray(response)) {
      return response as T[];
    }

    if (
      !response ||
      typeof response !== 'object'
    ) {
      return [];
    }

    const record =
      this.toRecord(response);

    for (const key of keys) {
      const value =
        record[key];

      if (Array.isArray(value)) {
        return value as T[];
      }
    }

    return [];
  }

  private toRecord(
    value: unknown
  ): Record<string, unknown> {
    if (
      value &&
      typeof value === 'object'
    ) {
      return value as
        Record<string, unknown>;
    }

    return {};
  }

  private createPageNumbers(
    currentPage: number,
    totalPages: number
  ): number[] {
    const maximumVisiblePages = 5;

    if (
      totalPages <=
      maximumVisiblePages
    ) {
      return Array.from(
        {
          length: totalPages
        },
        (
          _value: unknown,
          index: number
        ) =>
          index + 1
      );
    }

    let startPage =
      Math.max(
        1,
        currentPage - 2
      );

    let endPage =
      Math.min(
        totalPages,
        startPage +
          maximumVisiblePages -
          1
      );

    if (
      endPage -
        startPage +
        1 <
      maximumVisiblePages
    ) {
      startPage =
        Math.max(
          1,
          endPage -
            maximumVisiblePages +
            1
        );
    }

    return Array.from(
      {
        length:
          endPage -
          startPage +
          1
      },
      (
        _value: unknown,
        index: number
      ) =>
        startPage + index
    );
  }

  private clampPage(
    page: number,
    totalPages: number
  ): number {
    return Math.min(
      Math.max(page, 1),
      Math.max(totalPages, 1)
    );
  }

  private normalizeTeamPagination(): void {
    this.teamCurrentPage =
      this.clampPage(
        this.teamCurrentPage,
        this.teamTotalPages
      );
  }

  private normalizeEnquiryPagination(): void {
    this.pendingCurrentPage =
      this.clampPage(
        this.pendingCurrentPage,
        this.pendingTotalPages
      );

    this.answeredCurrentPage =
      this.clampPage(
        this.answeredCurrentPage,
        this.answeredTotalPages
      );
  }

  private normalizeAllPagination(): void {
    this.normalizeTeamPagination();
    this.normalizeEnquiryPagination();
  }

  private resolveCurrentFacultyId(): number {
    const storageKeys = [
      'userId',
      'facultyId',
      'currentUserId',
      'loggedInUserId'
    ];

    for (
      const key of storageKeys
    ) {
      const sessionValue =
        sessionStorage.getItem(
          key
        );

      const localValue =
        localStorage.getItem(
          key
        );

      const facultyId =
        Number(
          sessionValue ??
          localValue
        );

      if (
        Number.isFinite(
          facultyId
        ) &&
        facultyId > 0
      ) {
        return facultyId;
      }
    }

    const objectKeys = [
      'currentUser',
      'user',
      'authUser',
      'loggedInUser'
    ];

    for (
      const key of objectKeys
    ) {
      const storedValue =
        sessionStorage.getItem(
          key
        ) ??
        localStorage.getItem(
          key
        );

      if (!storedValue) {
        continue;
      }

      try {
        const user =
          JSON.parse(
            storedValue
          ) as
            Record<
              string,
              unknown
            >;

        const facultyId =
          Number(
            user['userId'] ??
            user['facultyId'] ??
            user['id']
          );

        if (
          Number.isFinite(
            facultyId
          ) &&
          facultyId > 0
        ) {
          return facultyId;
        }
      } catch {
        continue;
      }
    }

    return 0;
  }

  private formatDate(
    value:
      string | null | undefined
  ): string {
    if (!value) {
      return 'Not Available';
    }

    const date =
      new Date(value);

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return value;
    }

    return new Intl.DateTimeFormat(
      'en-IN',
      {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }
    ).format(date);
  }

  private toTitleCase(
    value:
      string | null | undefined
  ): string {
    if (!value) {
      return '';
    }

    const preservedWords =
      new Set([
        'API',
        'CSS',
        'HTML',
        'HTTP',
        'HTTPS',
        'ID',
        'ILP',
        'JSON',
        'PRJ',
        'SPOC',
        'SQL',
        'UI',
        'URL',
        'UX'
      ]);

    return value
      .toString()
      .trim()
      .split(/\s+/)
      .filter(
        (word: string) =>
          word.length > 0
      )
      .map(
        (word: string) => {
          const cleanWord =
            word.trim();

          const punctuationMatch =
            cleanWord.match(
              /^([^A-Za-z0-9]*)(.*?)([^A-Za-z0-9]*)$/
            );

          const prefix =
            punctuationMatch?.[1] ??
            '';

          const coreWord =
            punctuationMatch?.[2] ??
            cleanWord;

          const suffix =
            punctuationMatch?.[3] ??
            '';

          if (!coreWord) {
            return cleanWord;
          }

          const upperCore =
            coreWord.toUpperCase();

          if (
            preservedWords.has(
              upperCore
            ) ||
            /^[A-Z]{2,}\d*$/.test(
              coreWord
            ) ||
            /^PRJ-\d+$/i.test(
              coreWord
            )
          ) {
            return (
              prefix +
              upperCore +
              suffix
            );
          }

          if (
            coreWord.length === 1
          ) {
            return (
              prefix +
              coreWord.toUpperCase() +
              suffix
            );
          }

          return (
            prefix +
            coreWord
              .charAt(0)
              .toUpperCase() +
            coreWord
              .slice(1)
              .toLowerCase() +
            suffix
          );
        }
      )
      .join(' ');
  }

  private scrollPageToTop(): void {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }

  private scrollToElement(
    selector: string
  ): void {
    window.setTimeout(
      () => {
        const element =
          document.querySelector(
            selector
          );

        if (!element) {
          return;
        }

        const top =
          element
            .getBoundingClientRect()
            .top +
          window.scrollY -
          20;

        window.scrollTo({
          top,
          behavior: 'smooth'
        });
      }
    );
  }

  private lockBodyScroll(): void {
    document.body.style.overflow =
      'hidden';
  }

  private unlockBodyScroll(): void {
    document.body.style.overflow =
      '';
  }
}