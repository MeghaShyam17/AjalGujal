import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetExceptionsComponent } from './asset-exceptions.component';

describe('AssetExceptionsComponent', () => {
  let component: AssetExceptionsComponent;
  let fixture: ComponentFixture<AssetExceptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetExceptionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetExceptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
