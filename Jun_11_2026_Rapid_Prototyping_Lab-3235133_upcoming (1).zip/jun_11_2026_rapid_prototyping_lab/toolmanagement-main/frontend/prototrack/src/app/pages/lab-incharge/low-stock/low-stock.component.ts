import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs/operators';
import { InventoryService } from '../../../core/services/inventory.service';
import { Inventory } from '../../../core/models/inventory';

export interface LowStockItem {
  id: string;
  name: string;
  category: 'Component' | 'Tool';
  specification: string;
  availableQty: number;
  minQty: number;
  requiredQty: number;
  unit: string;
}

@Component({
  selector: 'app-low-stock',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './low-stock.component.html',
  styleUrl: './low-stock.component.css'
})
export class LowStockComponent implements OnInit {   
  toastMessage = '';
  toastType: 'success' | 'error' = 'success';
  showToastBox = false;  

  currentView: 'list' | 'review' = 'list';

  searchText = '';
  selectedCategory: 'All' | 'Component' | 'Tool' = 'All';
  sortBy: 'lowest-qty' | 'highest-qty' | 'asset-id' | 'asset-name' = 'lowest-qty';
  currentLowStockPage = 1;
  lowStockPageSize = 10;

  selectedIds = new Set<string>();

  isLoading = false;
  loadError = '';

  items: LowStockItem[] = [];

  filteredItems: LowStockItem[] = [];

  constructor(
    private inventoryService: InventoryService
  ) {}

  ngOnInit(): void {
    this.loadLowStockData();
  }

  loadLowStockData(): void {
    this.isLoading = true;
    this.loadError = '';

    this.inventoryService.getAllInventory()
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: (data: Inventory[]) => {
          // Filter low stock items: strictly numeric availableQuantity <= minimumStock or availableQuantity === 0
          const lowStockInventory = (data || []).filter(item => {
            const avail = Number(item.availableQuantity ?? 0);
            const min = Number(item.minimumStock ?? 0);
            return (min > 0 && avail <= min) || avail === 0;
          });

          this.items = lowStockInventory.map(item => this.mapInventoryToLowStockItem(item));
          
          // Default selection of all low stock items
          this.selectedIds = new Set(this.items.map(i => i.id));
          this.applyFilters();
        },
        error: (err) => {
          console.error('Error fetching low stock items:', err);
          this.loadError = 'Failed to load low stock items from backend.';
          this.items = [];
          this.filteredItems = [];
        }
      });
  }

  private mapInventoryToLowStockItem(item: Inventory): LowStockItem {
    const avail = Number(item.availableQuantity ?? 0);
    const min = Number(item.minimumStock ?? 0);
    const req = Math.max(1, (min * 2) - avail);

    const catStr = (item.itemCategory || '').trim().toLowerCase();
    const isTool = catStr.includes('tool') || (item.itemCode && item.itemCode.toUpperCase().startsWith('TL'));
    const category: 'Component' | 'Tool' = isTool ? 'Tool' : 'Component';

    return {
      id: item.itemCode || `CMP-${item.itemId}`,
      name: item.itemName || 'Unnamed Asset',
      category: category,
      specification: item.specification || item.make || '',
      availableQty: avail,
      minQty: min,
      requiredQty: req,
      unit: item.unit || 'Nos'
    };
  }

  get totalItems(): number {
    return this.items.length;
  }

  get componentCount(): number {
    return this.items.filter(item => item.category === 'Component').length;
  }

  get toolCount(): number {
    return this.items.filter(item => item.category === 'Tool').length;
  }

  get selectedCount(): number {
    return this.selectedIds.size;
  }

  get visibleCount(): number {
    return this.filteredItems.length;
  }

  get lowStockTotalPages(): number {
  return Math.max(
    1,
    Math.ceil(this.filteredItems.length / this.lowStockPageSize)
  );}

  get paginatedFilteredItems(): LowStockItem[] {
    const startIndex =
      (this.currentLowStockPage - 1) * this.lowStockPageSize;

    return this.filteredItems.slice(
      startIndex,
      startIndex + this.lowStockPageSize
    );
  }

  get lowStockShowingFrom(): number {
    if (this.filteredItems.length === 0) {
      return 0;
    }

    return (this.currentLowStockPage - 1) * this.lowStockPageSize + 1;
  }

  get lowStockShowingTo(): number {
    return Math.min(
      this.currentLowStockPage * this.lowStockPageSize,
      this.filteredItems.length
    );
  }

  get reviewItems(): LowStockItem[] {
    return this.items.filter(item => this.selectedIds.has(item.id));
  }

  // get isAllVisibleSelected(): boolean {
  //   return (
  //     this.filteredItems.length > 0 &&
  //     this.filteredItems.every(item => this.selectedIds.has(item.id))
  //   );
  // }

  get isAllVisibleSelected(): boolean {
  return (
    this.paginatedFilteredItems.length > 0 &&
    this.paginatedFilteredItems.every(item =>
      this.selectedIds.has(item.id)
    )
  );}

  applyFilters(): void {
    const searchValue = this.searchText.trim().toLowerCase();

    this.filteredItems = this.items.filter(item => {
      const matchesSearch =
        !searchValue ||
        (item.id || '').toLowerCase().includes(searchValue) ||
        (item.name || '').toLowerCase().includes(searchValue) ||
        (item.specification || '').toLowerCase().includes(searchValue);

      const matchesCategory =
        this.selectedCategory === 'All' ||
        item.category.toLowerCase() === this.selectedCategory.toLowerCase();

      return matchesSearch && matchesCategory;
    });

    this.sortFilteredItems();
    this.currentLowStockPage = 1;
  }

  sortFilteredItems(): void {
    switch (this.sortBy) {
      case 'lowest-qty':
        this.filteredItems.sort((a, b) => a.availableQty - b.availableQty);
        break;

      case 'highest-qty':
        this.filteredItems.sort((a, b) => b.availableQty - a.availableQty);
        break;

      case 'asset-id':
        this.filteredItems.sort((a, b) => a.id.localeCompare(b.id));
        break;

      case 'asset-name':
        this.filteredItems.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }
  }

  isSelected(itemId: string): boolean {
    return this.selectedIds.has(itemId);
  }

  toggleSelection(itemId: string): void {
    if (this.selectedIds.has(itemId)) {
      this.selectedIds.delete(itemId);
    } else {
      this.selectedIds.add(itemId);
    }
  }

  selectAll(event: Event): void {
  const checked = (event.target as HTMLInputElement).checked;

  this.paginatedFilteredItems.forEach(item => {
    if (checked) {
      this.selectedIds.add(item.id);
    } else {
      this.selectedIds.delete(item.id);
    }
  });
  }

  clearSelection(): void {
    this.selectedIds.clear();
    this.showToast('Selection cleared.');
  }

  resetFilters(): void {
    this.searchText = '';
    this.selectedCategory = 'All';
    this.sortBy = 'lowest-qty';
    this.applyFilters();
    this.showToast('Filters cleared.');
  }

  goToPreviousLowStockPage(): void {
  if (this.currentLowStockPage > 1) {
    this.currentLowStockPage--;
  }
}

  goToNextLowStockPage(): void {
    if (this.currentLowStockPage < this.lowStockTotalPages) {
      this.currentLowStockPage++;
    }
  }


  goToReview(): void {
    if (this.selectedIds.size === 0) {
      return;
    }

    this.currentView = 'review';
    this.showToast('Proceeding to required quantity review.');
  }

  backToList(): void {
    this.currentView = 'list';
    this.applyFilters();
  }

  removeItem(itemId: string): void {
    this.selectedIds.delete(itemId);
    this.showToast('Item removed from report selection.');

    if (this.selectedIds.size === 0) {
      this.currentView = 'list';
      this.applyFilters();
    }
  }

  decreaseQty(item: LowStockItem): void {
    if (item.requiredQty > 1) {
      item.requiredQty--;
    }
  }

  increaseQty(item: LowStockItem): void {
    if (item.requiredQty < 999) {
      item.requiredQty++;
    }
  }

  validateRequiredQty(item: LowStockItem): void {
    if (!item.requiredQty || item.requiredQty < 1) {
      item.requiredQty = 1;
    }

    if (item.requiredQty > 999) {
      item.requiredQty = 999;
    }
  }

  clearAllReview(): void {
    this.selectedIds.clear();
    this.currentView = 'list';
    this.showToast('Cleared all review items.');
    this.applyFilters();
  }

  downloadReport(): void {
    const selectedItems = this.reviewItems;

    if (selectedItems.length === 0) {
      return;
    }

    let csvContent =
      'Asset ID,Asset Name,Category,Specification / Model,Available Quantity,Minimum Quantity,Required Quantity,Unit\n';

    selectedItems.forEach(item => {
      const id = this.escapeCsv(item.id);
      const name = this.escapeCsv(item.name);
      const category = this.escapeCsv(item.category);
      const specification = this.escapeCsv(item.specification);
      const unit = this.escapeCsv(item.unit);

      csvContent +=
        `"${id}","${name}","${category}","${specification}",${item.availableQty},${item.minQty},${item.requiredQty},"${unit}"\n`;
    });

    const blob = new Blob(
      [csvContent],
      { type: 'text/csv;charset=utf-8;' }
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    link.href = url;
    link.download =
      `Prototrack_Low_Stock_Report_${new Date().toISOString().slice(0, 10)}.csv`;

    link.click();

    URL.revokeObjectURL(url);
    this.showToast(`Successfully downloaded Low Stock Report (${selectedItems.length} items included)!`);
  }

  private escapeCsv(value: string): string {
    return value.replace(/"/g, '""');
  }

  showToast(
    message: string,
    type: 'success' | 'error' = 'success'
    ): void {
    this.toastMessage = message;
    this.toastType = type;
    this.showToastBox = true;

    setTimeout(() => {
        this.showToastBox = false;
    }, 3000);
    }
}