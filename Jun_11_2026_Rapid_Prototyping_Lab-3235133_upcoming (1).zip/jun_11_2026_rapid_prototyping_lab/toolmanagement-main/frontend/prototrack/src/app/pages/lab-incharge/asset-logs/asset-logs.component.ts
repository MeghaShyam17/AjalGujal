import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { ToolInventoryService } from '../../../core/services/tool-inventory.service';
import { ComponentInventoryService } from '../../../core/services/component-inventory.service';
import { UserService } from '../../../core/services/user.service';
import { ProjectService } from '../../../core/services/project.service';
import { UserResponse } from '../../../core/models/user';
import { ProjectTeamDto } from '../../../core/models/project';

export interface LogEntry {
  id: string;
  rawId: number;
  date: string;
  project: string;
  projectIdVal: number;
  spoc: string;
  type: 'Handover (Request)' | 'Return';
  items: string;
  quantity: number;
  status: string;
  condition?: string;
  remarks?: string;
}

export interface GroupedLog {
  project: string;
  logs: LogEntry[];
}

@Component({
  selector: 'app-asset-logs',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './asset-logs.component.html',
  styleUrls: ['./asset-logs.component.css']
})
export class AssetLogsComponent implements OnInit {
  @Input() type: 'tool' | 'component' = 'tool';
  @Input() isEmbedded = false;

  activeType: 'tool' | 'component' = 'tool';
  isLoading = false;
  loadError = '';

  allLogs: LogEntry[] = [];
  filteredLogs: LogEntry[] = [];
  paginatedLogs: LogEntry[] = [];
  groupedLogs: GroupedLog[] = [];

  userNamesMap: Record<number, string> = {};
  projectsMap: Record<number, string> = {};
  projectsList: { id: number; name: string }[] = [];

  // Filters
  searchTerm = '';
  typeFilter = 'all'; // all, request, return
  statusFilter = 'all';
  projectFilter = 'all'; // all, projectId
  dateFilter = '';
  sortOrder: 'latest' | 'oldest' = 'latest';
  groupByProject = false;

  // Pagination
  currentPage = 1;
  readonly pageSize = 10;
  totalItems = 0;

  constructor(
    private readonly router: Router,
    private readonly toolInventoryService: ToolInventoryService,
    private readonly componentInventoryService: ComponentInventoryService,
    private readonly userService: UserService,
    private readonly projectService: ProjectService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    if (this.isEmbedded) {
      this.activeType = this.type;
    } else {
      const currentUrl = window.location.pathname;
      this.activeType = currentUrl.includes('component-logs') ? 'component' : 'tool';
    }
    this.loadLogs();
  }

  loadLogs(): void {
    this.isLoading = true;
    this.loadError = '';

    forkJoin({
      users: this.userService.getAllUsers().pipe(catchError(() => of([] as UserResponse[]))),
      projects: this.projectService.getAllProjects().pipe(catchError(() => of([] as ProjectTeamDto[])))
    }).subscribe({
      next: (res) => {
        // Map users
        this.userNamesMap = {};
        if (res.users && res.users.length > 0) {
          res.users.forEach((user: any) => {
            const id = Number(user.userId || user.id);
            const name = user.name || user.userName || user.fullName || '';
            if (id) {
              this.userNamesMap[id] = name;
            }
          });
        }

        // Map projects
        this.projectsMap = {};
        this.projectsList = [];
        if (res.projects && res.projects.length > 0) {
          res.projects.forEach((proj: any) => {
            const id = Number(proj.projectId || proj.id);
            const name = proj.projectName || proj.name || '';
            if (id) {
              this.projectsMap[id] = name;
              this.projectsList.push({ id, name });
            }
          });
        }

        this.fetchTransactions();
      },
      error: () => this.fetchTransactions()
    });
  }

  private fetchTransactions(): void {
    if (this.activeType === 'tool') {
      forkJoin({
        requests: this.toolInventoryService.getToolRequests().pipe(catchError(() => of([]))),
        returns: this.toolInventoryService.getToolReturns().pipe(catchError(() => of([])))
      }).pipe(
        finalize(() => {
          this.isLoading = false;
          this.applyFiltersAndSorting();
          this.cdr.markForCheck();
        })
      ).subscribe({
        next: (res) => {
          this.processToolData(res.requests, res.returns);
        },
        error: (err) => {
          console.error('Failed to fetch tool log data:', err);
          this.loadError = 'Failed to load transaction logs from backend.';
        }
      });
    } else {
      forkJoin({
        requests: this.componentInventoryService.getComponentRequests().pipe(catchError(() => of([]))),
        returns: this.componentInventoryService.getComponentReturns().pipe(catchError(() => of([])))
      }).pipe(
        finalize(() => {
          this.isLoading = false;
          this.applyFiltersAndSorting();
          this.cdr.markForCheck();
        })
      ).subscribe({
        next: (res) => {
          this.processComponentData(res.requests, res.returns);
        },
        error: (err) => {
          console.error('Failed to fetch component log data:', err);
          this.loadError = 'Failed to load transaction logs from backend.';
        }
      });
    }
  }

  private processToolData(requests: any[], returns: any[]): void {
    const logs: LogEntry[] = [];

    // Process Requests
    (requests || []).forEach(req => {
      const pId = Number(req.projectId);
      const projName = this.projectsMap[pId] 
        ? `${this.projectsMap[pId]} (Team #${pId})` 
        : `Team #${pId}`;
      logs.push({
        id: `REQ-TOL-${req.toolRequestId}`,
        rawId: req.toolRequestId,
        date: req.requestDate ? req.requestDate.split('T')[0] : 'N/A',
        project: projName,
        projectIdVal: pId,
        spoc: this.userNamesMap[req.requestedBy] || `Student #${req.requestedBy}`,
        type: 'Handover (Request)',
        items: req.items?.map((i: any) => `${i.toolName || 'Tool'} (x${i.approvedQuantity || i.requestedQuantity})`).join(', ') || 'N/A',
        quantity: req.items?.reduce((sum: number, i: any) => sum + (i.approvedQuantity || i.requestedQuantity || 0), 0) || 0,
        status: req.approvalStatus || 'Approved',
        remarks: req.remarks || 'No remarks'
      });
    });

    // Process Returns
    (returns || []).forEach(ret => {
      const pId = Number(ret.projectId || (ret.toolRequest?.projectId));
      const projName = this.projectsMap[pId] 
        ? `${this.projectsMap[pId]} (Team #${pId})` 
        : `Team #${pId}`;
      logs.push({
        id: `RET-TOL-${ret.toolReturnId}`,
        rawId: ret.toolReturnId,
        date: ret.returnDate ? ret.returnDate.split('T')[0] : (ret.createdAt ? ret.createdAt.split('T')[0] : 'N/A'),
        project: projName,
        projectIdVal: pId,
        spoc: this.userNamesMap[ret.returnedBy] || `Student #${ret.returnedBy}`,
        type: 'Return',
        items: ret.items?.map((i: any) => `${i.inventory?.itemName || i.toolName || 'Tool'} (x${i.returnedQuantity})`).join(', ') || 'N/A',
        quantity: ret.items?.reduce((sum: number, i: any) => sum + (i.returnedQuantity || 0), 0) || 0,
        status: ret.returnStatus || 'Completed',
        remarks: ret.remarks || 'Returned'
      });
    });

    this.allLogs = logs;
  }

  private processComponentData(requests: any[], returns: any[]): void {
    const logs: LogEntry[] = [];

    // Process Requests
    (requests || []).forEach(req => {
      const pId = Number(req.projectId);
      const projName = this.projectsMap[pId] 
        ? `${this.projectsMap[pId]} (Team #${pId})` 
        : `Team #${pId}`;
      logs.push({
        id: `REQ-CMP-${req.componentRequestId}`,
        rawId: req.componentRequestId,
        date: req.requestDate ? req.requestDate.split('T')[0] : 'N/A',
        project: projName,
        projectIdVal: pId,
        spoc: this.userNamesMap[req.requestedBy] || `Student #${req.requestedBy}`,
        type: 'Handover (Request)',
        items: req.items?.map((i: any) => `${i.componentName || 'Component'} (x${i.approvedQuantity || i.requestedQuantity})`).join(', ') || 'N/A',
        quantity: req.items?.reduce((sum: number, i: any) => sum + (i.approvedQuantity || i.requestedQuantity || 0), 0) || 0,
        status: req.approvalStatus || 'Approved',
        remarks: req.remarks || 'No remarks'
      });
    });

    // Process Returns
    (returns || []).forEach(ret => {
      const pId = Number(ret.projectId || (ret.componentRequest?.projectId));
      const projName = this.projectsMap[pId] 
        ? `${this.projectsMap[pId]} (Team #${pId})` 
        : `Team #${pId}`;
      logs.push({
        id: `RET-CMP-${ret.componentReturnId}`,
        rawId: ret.componentReturnId,
        date: ret.returnDate ? ret.returnDate.split('T')[0] : (ret.createdAt ? ret.createdAt.split('T')[0] : 'N/A'),
        project: projName,
        projectIdVal: pId,
        spoc: this.userNamesMap[ret.returnedBy] || `Student #${ret.returnedBy}`,
        type: 'Return',
        items: ret.items?.map((i: any) => `${i.inventory?.itemName || i.componentName || 'Component'} (x${i.returnedQuantity})`).join(', ') || 'N/A',
        quantity: ret.items?.reduce((sum: number, i: any) => sum + (i.returnedQuantity || 0), 0) || 0,
        status: ret.returnStatus || 'Completed',
        remarks: ret.remarks || 'Returned'
      });
    });

    this.allLogs = logs;
  }

  applyFiltersAndSorting(): void {
    let temp = [...this.allLogs];

    // Search term
    if (this.searchTerm.trim()) {
      const search = this.searchTerm.toLowerCase().trim();
      temp = temp.filter(log =>
        log.id.toLowerCase().includes(search) ||
        log.project.toLowerCase().includes(search) ||
        log.spoc.toLowerCase().includes(search) ||
        log.items.toLowerCase().includes(search)
      );
    }

    // Type filter
    if (this.typeFilter !== 'all') {
      if (this.typeFilter === 'request') {
        temp = temp.filter(log => log.type === 'Handover (Request)');
      } else {
        temp = temp.filter(log => log.type === 'Return');
      }
    }

    // Status filter
    if (this.statusFilter !== 'all') {
      temp = temp.filter(log => log.status.toLowerCase() === this.statusFilter.toLowerCase());
    }

    // Project/Team Filter
    if (this.projectFilter !== 'all') {
      const pId = Number(this.projectFilter);
      temp = temp.filter(log => log.projectIdVal === pId);
    }

    // Date filter
    if (this.dateFilter) {
      temp = temp.filter(log => log.date === this.dateFilter);
    }

    // Sort order
    temp.sort((a, b) => {
      const dateA = new Date(a.date).getTime() || 0;
      const dateB = new Date(b.date).getTime() || 0;
      return this.sortOrder === 'latest' ? dateB - dateA : dateA - dateB;
    });

    this.filteredLogs = temp;
    this.totalItems = temp.length;

    // Build grouped logs if grouping is active
    if (this.groupByProject) {
      const groups: Record<string, LogEntry[]> = {};
      this.filteredLogs.forEach(log => {
        const key = log.project;
        if (!groups[key]) {
          groups[key] = [];
        }
        groups[key].push(log);
      });
      this.groupedLogs = Object.keys(groups).map(k => ({
        project: k,
        logs: groups[k]
      }));
    } else {
      this.groupedLogs = [];
    }

    this.currentPage = 1;
    this.updatePaginatedLogs();
  }

  updatePaginatedLogs(): void {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    this.paginatedLogs = this.filteredLogs.slice(startIndex, startIndex + this.pageSize);
  }

  changePage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedLogs();
    }
  }

  get totalPages(): number {
    return Math.ceil(this.totalItems / this.pageSize) || 1;
  }

  getMathMin(a: number, b: number): number {
    return Math.min(a, b);
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.typeFilter = 'all';
    this.statusFilter = 'all';
    this.projectFilter = 'all';
    this.dateFilter = '';
    this.sortOrder = 'latest';
    this.groupByProject = false;
    this.applyFiltersAndSorting();
  }
}
