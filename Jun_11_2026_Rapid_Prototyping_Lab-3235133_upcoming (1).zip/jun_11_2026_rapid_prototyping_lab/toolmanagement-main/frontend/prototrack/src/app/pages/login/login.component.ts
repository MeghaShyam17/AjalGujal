import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;
  loading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: [
        '',
        [
          Validators.required,
          Validators.email
        ]
      ],
      password: [
        '',
        Validators.required
      ],
      rememberMe: [false],
      terms: [
        false,
        Validators.requiredTrue
      ]
    });
  }

  login(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    const payload = {
      email: this.loginForm.value.email,
      password: this.loginForm.value.password
    };

    console.log('Sending Login Request:', payload);

    this.authService.login(payload).subscribe({
      next: (response: any) => {
        this.loading = false;

        const persistent = Boolean(
          this.loginForm.value.rememberMe
        );

        const storage: Storage = persistent
          ? localStorage
          : sessionStorage;

        localStorage.clear();
        sessionStorage.clear();

        const responseData = response?.data ?? response;

        const token =
          responseData?.token ??
          responseData?.accessToken ??
          responseData?.jwt;

        const role =
          responseData?.role ??
          responseData?.userRole ??
          responseData?.roleName;

        const userId =
          responseData?.userId ??
          responseData?.id ??
          responseData?.user?.userId ??
          responseData?.user?.id;

        const name =
          responseData?.name ??
          responseData?.userName ??
          responseData?.fullName ??
          responseData?.user?.name ??
          responseData?.user?.userName ??
          responseData?.user?.fullName;

        const email =
          responseData?.email ??
          responseData?.user?.email ??
          this.loginForm.value.email;

        const phone =
          responseData?.phone ??
          responseData?.phoneNumber ??
          responseData?.user?.phone ??
          responseData?.user?.phoneNumber ??
          '';

        if (token) {
          storage.setItem('token', String(token));
        }

        if (role) {
          storage.setItem('role', String(role));
        }

        if (userId !== undefined && userId !== null) {
          storage.setItem('userId', String(userId));
        }

        if (name) {
          storage.setItem('name', String(name));
          storage.setItem('userName', String(name));
        }

        if (email) {
          storage.setItem('email', String(email));
        }

        if (phone) {
          storage.setItem('phone', String(phone));
        }

        this.navigateByRole(String(role ?? ''));
      },

      error: (error: any) => {
        this.loading = false;

        console.error('Login Error:', error);

        if (error.status === 0) {
          this.errorMessage =
            'Cannot connect to server. Please make sure Spring Boot is running.';
        } else if (error.status === 401) {
          this.errorMessage = 'Invalid Email or Password';
        } else if (error.status === 403) {
          this.errorMessage = 'Access Denied';
        } else {
          this.errorMessage = 'Login Failed. Please try again.';
        }
      }
    });
  }

  private navigateByRole(role: string): void {
    if (!role) {
      this.errorMessage = 'Role not found in login response.';
      return;
    }

    const normalizedRole = role
      .toLowerCase()
      .trim()
      .replace(/[\s_-]+/g, '');

    switch (normalizedRole) {
      case 'admin':
        this.router.navigate(['/admin/dashboard']);
        break;

      case 'seniorfaculty':
        this.router.navigate([
          '/senior-faculty/senior-dashboard'
        ]);
        break;

      case 'technicalfaculty':
      case 'faculty':
        this.router.navigate(['/faculty/dashboard']);
        break;

      case 'labincharge':
        this.router.navigate(['/lab-incharge/dashboard']);
        break;

      case 'trainee':
      case 'student':
      case 'user':
      case 'member':
      case 'scrum':
        this.router.navigate(['/student/dashboard']);
        break;

      default:
        console.warn('Unknown role:', role);
        this.errorMessage = 'Role not configured.';
        break;
    }
  }
}