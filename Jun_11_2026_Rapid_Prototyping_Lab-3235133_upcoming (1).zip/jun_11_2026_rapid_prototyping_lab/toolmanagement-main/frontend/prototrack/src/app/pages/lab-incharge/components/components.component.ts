import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ComponentInventoryService } from '../../../core/services/component-inventory.service';
import { RequestsStatusComponent } from '../requests-status/requests-status.component';
import { MaterialReturnsComponent } from '../material-returns/material-returns.component';
import { AssetLogsComponent } from '../asset-logs/asset-logs.component';

@Component({
  selector: 'app-components-management',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    RequestsStatusComponent,
    MaterialReturnsComponent,
    AssetLogsComponent
  ],
  templateUrl: './components.component.html',
  styleUrls: ['./components.component.css']
})
export class ComponentsManagementComponent implements OnInit {
  activeTab = 'requests'; // requests, returns, logs
  
  requestsAwaitingHandover = 0;
  returnsPendingVerification = 0;
  fullyHandedOverProjects = 0;
  
  isLoading = false;
  
  constructor(
    private componentInventoryService: ComponentInventoryService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {}
  
  ngOnInit(): void {
    this.listenForTabNavigation();
    this.loadMetrics();
  }

  private listenForTabNavigation(): void {
    this.activatedRoute.queryParamMap.subscribe(params => {
      const requestedTab = params.get('tab');
      if (requestedTab === 'requests' || requestedTab === 'returns' || requestedTab === 'logs') {
        this.activeTab = requestedTab;
      }
    });
  }
  
  loadMetrics(): void {
    this.isLoading = true;
    forkJoin({
      requests: this.componentInventoryService.getComponentRequests().pipe(catchError(() => of([]))),
      returns: this.componentInventoryService.getComponentReturns().pipe(catchError(() => of([])))
    }).subscribe({
      next: (res) => {
        // Calculate requests awaiting handover (status is PENDING or PARTIAL or APPROVED)
        const pendingReqs = res.requests.filter((r: any) => 
          r.approvalStatus === 'PENDING' || 
          r.approvalStatus === 'PARTIAL' || 
          r.approvalStatus === 'Ready for Handover' || 
          r.approvalStatus === 'Partially Handed Over'
        );
        this.requestsAwaitingHandover = pendingReqs.length;

        // Calculate Project Returns Pending Verification
        const pendingRets = res.returns.filter((r: any) => 
          r.returnStatus === 'PENDING' || 
          r.returnStatus === 'Pending' || 
          r.returnStatus === 'Awaiting Verification'
        );
        this.returnsPendingVerification = pendingRets.length;

        // Fully Handed Over Projects
        const completedProjects = res.requests.filter((r: any) => 
          r.approvalStatus === 'ISSUED' || 
          r.approvalStatus === 'COMPLETED' || 
          r.approvalStatus === 'Fully Handed Over'
        );
        this.fullyHandedOverProjects = completedProjects.length;
        
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading component metrics:', err);
        this.isLoading = false;
      }
    });
  }

  selectTab(tab: string): void {
    this.activeTab = tab;
    this.router.navigate([], {
      relativeTo: this.activatedRoute,
      queryParams: { tab },
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }
}