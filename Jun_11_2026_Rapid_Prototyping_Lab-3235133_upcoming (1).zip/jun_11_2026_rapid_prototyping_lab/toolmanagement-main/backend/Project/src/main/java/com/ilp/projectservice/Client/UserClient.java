package com.ilp.projectservice.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ilp.projectservice.DTO.UserResponseDto;

@FeignClient(
        name = "user-service",
        url = "${user.service.url}"
)
public interface UserClient {

    @GetMapping("/api/users/{userId}")
    UserResponseDto getUserById(
            @PathVariable Integer userId);
}