package com.ilp.projectservice.ServiceImplementation;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BulkProjectRowDto;
import com.ilp.projectservice.DTO.BulkUploadError;
import com.ilp.projectservice.DTO.BulkUploadResult;
import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Entity.TeamMember;
import com.ilp.projectservice.Exception.BadRequestException;
import com.ilp.projectservice.Exception.BulkUploadException;
import com.ilp.projectservice.Exception.BusinessException;
import com.ilp.projectservice.Exception.ResourceNotFoundException;
import com.ilp.projectservice.Repository.ProjectTeamRepository;
import com.ilp.projectservice.Repository.TeamMemberRepository;
import com.ilp.projectservice.Service.ProjectTeamService;

@Service
@Transactional
public class ProjectTeamServiceImpl implements ProjectTeamService {

    private static final String PROJECTS_SHEET = "Teams";
    private static final int EXPECTED_COLUMN_COUNT = 11;
    private static final int MAX_MEMBERS_PER_PROJECT = 15;

    private static final Set<String> VALID_STATUSES =
            Set.of("Pending", "Ongoing", "Completed");

    private static final String[] EXPECTED_HEADERS = {
            "Project Key",
            "Project Name",
            "Description",
            "Year",
            "Batch ID",
            "Team Leader ID",
            "Faculty ID",
            "Deadline",
            "Project Status",
            "Trainee ID",
            "Member Role"
    };

    private final ProjectTeamRepository projectTeamRepository;
    private final TeamMemberRepository teamMemberRepository;
    private final DataFormatter formatter = new DataFormatter(Locale.ENGLISH);

    public ProjectTeamServiceImpl(
            ProjectTeamRepository projectTeamRepository,
            TeamMemberRepository teamMemberRepository) {
        this.projectTeamRepository = projectTeamRepository;
        this.teamMemberRepository = teamMemberRepository;
    }

    @Override
    public void hardDeleteProject(Integer projectId) {
        ProjectTeam project = projectTeamRepository
                .findById(projectId)
                .orElseThrow(() -> new ResourceNotFoundException("Project", projectId));
        projectTeamRepository.delete(project);
    }

    private void checkTraineeAvailability(Integer traineeId, Integer targetProjectId) {
        List<TeamMember> activeAssignments =
                teamMemberRepository.findByTraineeIdAndIsDeletedFalse(traineeId);

        for (TeamMember assignment : activeAssignments) {
            if (targetProjectId != null
                    && targetProjectId.equals(assignment.getProjectId())) {
                continue;
            }

            projectTeamRepository
                    .findByProjectIdAndIsDeletedFalse(assignment.getProjectId())
                    .ifPresent(project -> {
                        if (!"Completed".equalsIgnoreCase(project.getProjectStatus())) {
                            throw new BusinessException(
                                    "Trainee with ID " + traineeId
                                            + " is already assigned to active project '"
                                            + project.getProjectName()
                                            + "' and cannot join a new project until it is completed.");
                        }
                    });
        }
    }

    @Override
    public ProjectTeam createProject(ProjectTeam projectTeam) {
        validateProject(projectTeam);
        projectTeam.setProjectId(null);

        String status = projectTeam.getProjectStatus();
        projectTeam.setProjectStatus(
                isBlank(status) ? "Pending" : normalizeRequiredStatus(status));

        ProjectTeam savedProject = projectTeamRepository.save(projectTeam);

        if (projectTeam.getTeamMembers() != null
                && !projectTeam.getTeamMembers().isEmpty()) {
            Set<Integer> traineeIds = new HashSet<>();

            if (projectTeam.getTeamMembers().size() > MAX_MEMBERS_PER_PROJECT) {
                throw new BadRequestException("Maximum 15 team members are allowed");
            }

            for (TeamMember member : projectTeam.getTeamMembers()) {
                if (member.getTraineeId() == null) {
                    throw new BadRequestException("Trainee ID is required");
                }
                if (!traineeIds.add(member.getTraineeId())) {
                    throw new BadRequestException(
                            "Duplicate trainee ID: " + member.getTraineeId());
                }

                checkTraineeAvailability(member.getTraineeId(), null);
                member.setTeamMemberId(null);
                member.setProjectId(savedProject.getProjectId());
                member.setMemberRole(
                        isBlank(member.getMemberRole()) ? "Member" : member.getMemberRole().trim());
                member.setIsDeleted(false);
                teamMemberRepository.save(member);
            }

            savedProject.setTeamMembers(projectTeam.getTeamMembers());
        }

        return savedProject;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getAllProjects() {
        return projectTeamRepository.findByIsDeletedFalse();
    }

    @Override
    @Transactional(readOnly = true)
    public ProjectTeam getProjectById(Integer projectId) {
        return findProjectById(projectId);
    }

    @Override
    public ProjectTeam updateProject(Integer projectId, ProjectTeam projectTeam) {
        validateProject(projectTeam);
        ProjectTeam existingProject = findProjectById(projectId);

        String status = projectTeam.getProjectStatus();
        if (isBlank(status)) {
            status = existingProject.getProjectStatus();
        }

        existingProject.setProjectName(projectTeam.getProjectName().trim());
        existingProject.setDescription(projectTeam.getDescription());
        existingProject.setTeamLeaderId(projectTeam.getTeamLeaderId());
        existingProject.setFacultyId(projectTeam.getFacultyId());
        existingProject.setBatchId(projectTeam.getBatchId());
        existingProject.setYear(projectTeam.getYear());
        existingProject.setDeadline(projectTeam.getDeadline());
        existingProject.setProjectStatus(normalizeRequiredStatus(status));

        return projectTeamRepository.save(existingProject);
    }

    @Override
    public ProjectTeam updateProjectStatus(Integer projectId, String projectStatus) {
        ProjectTeam existingProject = findProjectById(projectId);
        existingProject.setProjectStatus(normalizeRequiredStatus(projectStatus));
        return projectTeamRepository.save(existingProject);
    }

    @Override
    public void deleteProject(Integer projectId) {
        ProjectTeam project = findProjectById(projectId);
        project.setIsDeleted(true);
        projectTeamRepository.save(project);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByStatus(String projectStatus) {
        return projectTeamRepository.findByProjectStatusAndIsDeletedFalse(
                normalizeRequiredStatus(projectStatus));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByTeamLeader(Integer teamLeaderId) {
        return projectTeamRepository.findByTeamLeaderIdAndIsDeletedFalse(teamLeaderId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByFaculty(Integer facultyId) {
        return projectTeamRepository.findByFacultyIdAndIsDeletedFalse(facultyId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByBatch(Integer batchId) {
        return projectTeamRepository.findByBatchIdAndIsDeletedFalse(batchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByYear(Integer year) {
        return projectTeamRepository.findByYearAndIsDeletedFalse(year);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> searchProjectsByName(String projectName) {
        if (isBlank(projectName)) {
            return projectTeamRepository.findByIsDeletedFalse();
        }
        return projectTeamRepository
                .findByProjectNameContainingIgnoreCaseAndIsDeletedFalse(projectName.trim());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public BulkUploadResult uploadProjectTeamsAndMembers(MultipartFile file) {
        validateExcelFile(file);

        ParsedWorkbook parsed = parseWorkbook(file);
        List<BulkUploadError> errors = validateWorkbook(parsed.projects());

        if (!errors.isEmpty()) {
            throw new BulkUploadException(
                    "Excel validation failed. No records were inserted.", errors);
        }

        Map<String, List<BulkProjectRowDto>> groupedProjects = new LinkedHashMap<>();
        for (BulkProjectRowDto row : parsed.projects()) {
            groupedProjects
                    .computeIfAbsent(row.projectKey().trim(), key -> new ArrayList<>())
                    .add(row);
        }

        Map<String, Integer> generatedProjectIds = new LinkedHashMap<>();
        int projectsInserted = 0;
        int membersInserted = 0;

        for (Map.Entry<String, List<BulkProjectRowDto>> entry
                : groupedProjects.entrySet()) {
            String projectKey = entry.getKey();
            List<BulkProjectRowDto> projectRows = entry.getValue();
            BulkProjectRowDto firstRow = projectRows.get(0);

            ProjectTeam savedProject = projectTeamRepository.save(toProjectEntity(firstRow));
            Integer generatedProjectId = savedProject.getProjectId();

            for (BulkProjectRowDto memberRow : projectRows) {
                checkTraineeAvailability(memberRow.traineeId(), null);

                TeamMember member = new TeamMember();
                member.setTeamMemberId(null);
                member.setProjectId(generatedProjectId);
                member.setTraineeId(memberRow.traineeId());
                member.setMemberRole(
                        isBlank(memberRow.memberRole())
                                ? "Member"
                                : memberRow.memberRole().trim());
                member.setIsDeleted(false);
                teamMemberRepository.save(member);
                membersInserted++;
            }

            generatedProjectIds.put(projectKey, generatedProjectId);
            projectsInserted++;
        }

        projectTeamRepository.flush();
        teamMemberRepository.flush();

        return new BulkUploadResult(
                true,
                projectsInserted,
                membersInserted,
                projectsInserted + " projects and " + membersInserted
                        + " team members uploaded successfully",
                Map.copyOf(generatedProjectIds));
    }

    private ParsedWorkbook parseWorkbook(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream();
                Workbook workbook = WorkbookFactory.create(inputStream)) {

            Sheet sheet = workbook.getSheet(PROJECTS_SHEET);
            if (sheet == null) {
                sheet = workbook.getSheetAt(0);
            }

            validateHeaders(sheet);
            return new ParsedWorkbook(readProjects(sheet));
        } catch (IOException exception) {
            throw new BadRequestException("Unable to read workbook", exception);
        }
    }

    private void validateHeaders(Sheet sheet) {
        List<BulkUploadError> errors = new ArrayList<>();
        checkHeaders(sheet, PROJECTS_SHEET, EXPECTED_HEADERS, errors);

        if (!errors.isEmpty()) {
            throw new BulkUploadException("Excel header validation failed", errors);
        }
    }

    private void checkHeaders(
            Sheet sheet,
            String sheetName,
            String[] expected,
            List<BulkUploadError> errors) {

        Row header = sheet.getRow(0);
        if (header == null) {
            errors.add(new BulkUploadError(sheetName, 1, "Header row is missing"));
            return;
        }

        for (int index = 0; index < expected.length; index++) {
            String actual = text(header.getCell(index));
            if (!expected[index].equalsIgnoreCase(actual)) {
                errors.add(new BulkUploadError(
                        sheetName,
                        1,
                        "Column " + (index + 1) + " must be '" + expected[index]
                                + "' but was '" + actual + "'"));
            }
        }
    }

    private List<BulkProjectRowDto> readProjects(Sheet sheet) {
        List<BulkProjectRowDto> rows = new ArrayList<>();

        for (int index = 1; index <= sheet.getLastRowNum(); index++) {
            Row row = sheet.getRow(index);
            if (row == null || isEmpty(row)) {
                continue;
            }

            rows.add(new BulkProjectRowDto(
                    index + 1,
                    text(row.getCell(0)),
                    text(row.getCell(1)),
                    nullableText(row.getCell(2)),
                    integer(row.getCell(3)),
                    integer(row.getCell(4)),
                    integer(row.getCell(5)),
                    integer(row.getCell(6)),
                    date(row.getCell(7)),
                    text(row.getCell(8)),
                    integer(row.getCell(9)),
                    text(row.getCell(10))));
        }

        return rows;
    }

    private List<BulkUploadError> validateWorkbook(List<BulkProjectRowDto> projects) {
        List<BulkUploadError> errors = new ArrayList<>();

        if (projects.isEmpty()) {
            addError(errors, PROJECTS_SHEET, 0, "At least one project row is required");
            return errors;
        }

        Map<String, List<BulkProjectRowDto>> groupedProjects = new LinkedHashMap<>();

        for (BulkProjectRowDto row : projects) {
            int excelRow = row.rowNumber();

            if (isBlank(row.projectKey())) {
                addError(errors, PROJECTS_SHEET, excelRow, "Project Key is required");
            }
            if (isBlank(row.projectName())) {
                addError(errors, PROJECTS_SHEET, excelRow, "Project Name is required");
            } else if (row.projectName().trim().length() > 200) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Project Name cannot exceed 200 characters");
            }
            if (row.year() == null || row.year() < 2000 || row.year() > 2100) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Year must be a valid four-digit year");
            }
            if (row.batchId() == null || row.batchId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Batch ID is required");
            }
            if (row.teamLeaderId() == null || row.teamLeaderId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Team Leader ID is required");
            }
            if (row.facultyId() == null || row.facultyId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Faculty ID is required");
            }
            if (row.deadline() == null) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Deadline is required and must use yyyy-MM-dd");
            } else if (!row.deadline().isAfter(LocalDate.now())) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Deadline must be greater than the current date");
            }
            if (row.traineeId() == null || row.traineeId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Trainee ID is required");
            }
            if (normalizeValue(row.projectStatus(), VALID_STATUSES) == null) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Project Status must be Pending, Ongoing, or Completed");
            }

            if (!isBlank(row.projectKey())) {
                groupedProjects
                        .computeIfAbsent(row.projectKey().trim(), key -> new ArrayList<>())
                        .add(row);
            }
        }

        for (Map.Entry<String, List<BulkProjectRowDto>> entry
                : groupedProjects.entrySet()) {
            String projectKey = entry.getKey();
            List<BulkProjectRowDto> projectRows = entry.getValue();
            BulkProjectRowDto first = projectRows.get(0);

            if (projectRows.size() > MAX_MEMBERS_PER_PROJECT) {
                addError(errors, PROJECTS_SHEET, first.rowNumber(),
                        "Project Key " + projectKey + " contains more than 15 members");
            }

            Set<Integer> traineeIds = new HashSet<>();

            for (BulkProjectRowDto row : projectRows) {
                if (row.traineeId() != null && !traineeIds.add(row.traineeId())) {
                    addError(errors, PROJECTS_SHEET, row.rowNumber(),
                            "Duplicate Trainee ID " + row.traineeId()
                                    + " for Project Key " + projectKey);
                }

                if (!sameProjectDetails(first, row)) {
                    addError(errors, PROJECTS_SHEET, row.rowNumber(),
                            "Project details are inconsistent for Project Key " + projectKey);
                }
            }
        }

        return errors;
    }

    private boolean sameProjectDetails(BulkProjectRowDto first, BulkProjectRowDto row) {
        return Objects.equals(first.projectName(), row.projectName())
                && Objects.equals(first.description(), row.description())
                && Objects.equals(first.year(), row.year())
                && Objects.equals(first.batchId(), row.batchId())
                && Objects.equals(first.teamLeaderId(), row.teamLeaderId())
                && Objects.equals(first.facultyId(), row.facultyId())
                && Objects.equals(first.deadline(), row.deadline())
                && Objects.equals(
                        normalizeValue(first.projectStatus(), VALID_STATUSES),
                        normalizeValue(row.projectStatus(), VALID_STATUSES));
    }

    private ProjectTeam toProjectEntity(BulkProjectRowDto row) {
        ProjectTeam project = new ProjectTeam();
        project.setProjectId(null);
        project.setProjectName(row.projectName().trim());
        project.setDescription(row.description());
        project.setYear(row.year());
        project.setBatchId(row.batchId());
        project.setTeamLeaderId(row.teamLeaderId());
        project.setFacultyId(row.facultyId());
        project.setDeadline(row.deadline());
        project.setProjectStartDate(LocalDate.now());
        project.setProjectStatus(normalizeRequiredStatus(row.projectStatus()));
        project.setIsDeleted(false);
        return project;
    }

    private record ParsedWorkbook(List<BulkProjectRowDto> projects) {
    }

    private ProjectTeam findProjectById(Integer projectId) {
        if (projectId == null) {
            throw new BadRequestException("Project ID is required");
        }

        return projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(projectId)
                .orElseThrow(() -> new ResourceNotFoundException("Project", projectId));
    }

    private void validateProject(ProjectTeam projectTeam) {
        if (projectTeam == null) {
            throw new BadRequestException("Project details are required");
        }
        if (isBlank(projectTeam.getProjectName())) {
            throw new BadRequestException("Project name is required");
        }

        String projectName = projectTeam.getProjectName().trim();
        if (projectName.length() > 200) {
            throw new BadRequestException("Project name cannot exceed 200 characters");
        }
        projectTeam.setProjectName(projectName);

        if (projectTeam.getDeadline() == null) {
            throw new BadRequestException("Project deadline is required");
        }
        if (!projectTeam.getDeadline().isAfter(LocalDate.now())) {
            throw new BadRequestException("Deadline must be greater than current date");
        }
    }

    private String normalizeRequiredStatus(String projectStatus) {
        String normalized = normalizeValue(projectStatus, VALID_STATUSES);
        if (normalized == null) {
            throw new BadRequestException(
                    "Project status must be Pending, Ongoing, or Completed");
        }
        return normalized;
    }

    private void validateExcelFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("Excel file is required");
        }

        String fileName = file.getOriginalFilename();
        if (fileName == null
                || !fileName.toLowerCase(Locale.ROOT).endsWith(".xlsx")) {
            throw new BadRequestException("Only .xlsx files are allowed");
        }
    }

    private String text(Cell cell) {
        return cell == null ? "" : formatter.formatCellValue(cell).trim();
    }

    private String nullableText(Cell cell) {
        String value = text(cell);
        return value.isBlank() ? null : value;
    }

    private Integer integer(Cell cell) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return null;
        }

        try {
            if (cell.getCellType() == CellType.NUMERIC) {
                double value = cell.getNumericCellValue();
                if (value != Math.rint(value)) {
                    return null;
                }
                return Math.toIntExact((long) value);
            }

            String value = text(cell);
            if (value.endsWith(".0")) {
                value = value.substring(0, value.length() - 2);
            }
            return Integer.valueOf(value);
        } catch (Exception exception) {
            return null;
        }
    }

    private LocalDate date(Cell cell) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return null;
        }

        try {
            if (cell.getCellType() == CellType.NUMERIC
                    && DateUtil.isCellDateFormatted(cell)) {
                return cell.getLocalDateTimeCellValue().toLocalDate();
            }
            return LocalDate.parse(text(cell));
        } catch (DateTimeParseException | IllegalStateException exception) {
            return null;
        }
    }

    private boolean isEmpty(Row row) {
        if (row.getFirstCellNum() < 0) {
            return true;
        }

        for (int index = 0; index < EXPECTED_COLUMN_COUNT; index++) {
            if (!text(row.getCell(index)).isBlank()) {
                return false;
            }
        }
        return true;
    }

    private String normalizeValue(String value, Set<String> allowedValues) {
        if (isBlank(value)) {
            return null;
        }

        String trimmed = value.trim();
        return allowedValues.stream()
                .filter(item -> item.equalsIgnoreCase(trimmed))
                .findFirst()
                .orElse(null);
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private void addError(
            List<BulkUploadError> errors,
            String sheet,
            int row,
            String message) {
        errors.add(new BulkUploadError(sheet, row, message));
    }

}
