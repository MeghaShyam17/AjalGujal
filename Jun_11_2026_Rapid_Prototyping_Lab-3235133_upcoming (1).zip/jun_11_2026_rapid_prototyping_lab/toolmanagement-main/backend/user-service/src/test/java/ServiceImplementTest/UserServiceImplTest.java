package ServiceImplementTest;

import com.ilp.user_service.serviceImpl.UserServiceImpl;
import com.ilp.user_service.dto.UserResponse;
import com.ilp.user_service.entity.BatchEntity;
import com.ilp.user_service.entity.RoleEntity;
import com.ilp.user_service.entity.UserEntity;
import com.ilp.user_service.exception.UserNotFoundException;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private BatchRepository batchRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    private UserEntity user;
    private RoleEntity role;
    private BatchEntity batch;

    @BeforeEach
    void setUp() {

        role = new RoleEntity();
        role.setRoleId(1);
        role.setRoleName("Student");

        batch = new BatchEntity();
        batch.setBatchId(1);
        batch.setBatchName("ILP-2025");
        batch.setYear(2025);

        user = new UserEntity();
        user.setUserId(1);
        user.setRole(role);
        user.setBatch(batch);
        user.setName("Megha");
        user.setPhone("9876543210");
        user.setEmail("megha@test.com");
        user.setGender("Female");
        user.setYear(2025);
        user.setStatus("ACTIVE");
    }

    @Test
    void createUser_ShouldReturnUserResponse() {

        when(userRepository.save(any(UserEntity.class)))
                .thenReturn(user);

        UserResponse response = userService.createUser(user);

        assertNotNull(response);
        assertEquals("Megha", response.getName());

        verify(userRepository).save(user);
    }

    @Test
    void getUserById_ShouldReturnUserResponse() {

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        UserResponse response = userService.getUserById(1);

        assertNotNull(response);
        assertEquals("Megha", response.getName());
    }

    @Test
    void getUserById_ShouldThrowException_WhenUserNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> userService.getUserById(1)
        );
    }

    @Test
    void updateUser_ShouldReturnUpdatedUser() {

        UserEntity updatedUser = new UserEntity();
        updatedUser.setRole(role);
        updatedUser.setBatch(batch);
        updatedUser.setName("Updated");
        updatedUser.setPhone("9999999999");
        updatedUser.setEmail("updated@test.com");
        updatedUser.setGender("Female");
        updatedUser.setYear(2026);
        updatedUser.setStatus("ACTIVE");

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        when(userRepository.save(any(UserEntity.class)))
                .thenReturn(user);

        UserResponse response =
                userService.updateUser(1, updatedUser);

        assertNotNull(response);
    }

    @Test
    void softDeleteUser_ShouldSetInactiveStatus() {

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        userService.softDeleteUser(1);

        assertEquals("INACTIVE", user.getStatus());

        verify(userRepository).save(user);
    }

    @Test
    void getAllUsers_ShouldReturnAllUsers() {

        when(userRepository.findByStatus("ACTIVE"))
                .thenReturn(List.of(user));

        List<UserResponse> users =
                userService.getAllUsers();

        assertEquals(1, users.size());
    }

    @Test
    void deleteUser_ShouldDeleteUser() {

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        userService.deleteUser(1);

        verify(userRepository).delete(user);
    }

    @Test
    void deleteUser_ShouldThrowException_WhenUserNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> userService.deleteUser(1)
        );
    }
}