package com.ilp.user_service.controller;

import com.ilp.user_service.entity.UserEntity;
import com.ilp.user_service.dto.UserResponse;
import com.ilp.user_service.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/users")

public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<UserResponse> createUser(
            @RequestBody UserEntity user) {
        
        return ResponseEntity.ok(userService.createUser(user));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<UserResponse> getUserById(
            @PathVariable Integer userId) {

        UserResponse user = userService.getUserById(userId);

        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(user);
    }

    @GetMapping
    public ResponseEntity<List<UserResponse>> getAllUsers() {

        List<UserResponse> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @PutMapping("/{userId}")
    public ResponseEntity<UserResponse> updateUser(
            @PathVariable Integer userId,
            @RequestBody UserEntity user) {

        UserResponse updatedUser =
                userService.updateUser(userId, user);

        if (updatedUser == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(updatedUser);
    }

    
    @PutMapping("/soft-delete/{userId}")
    public ResponseEntity<String> softDeleteUser(
            @PathVariable Integer userId) {

        userService.softDeleteUser(userId);

        return ResponseEntity.ok(
                "User soft deleted successfully");
    }
    @DeleteMapping("/{userId}")
    public ResponseEntity<String> deleteUser(
            @PathVariable Integer userId) {

        userService.deleteUser(userId);

        return ResponseEntity.ok("User deleted successfully");
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadUsers(
            @RequestParam("file") MultipartFile file) {

        String response = userService.uploadUsers(file);

        return ResponseEntity.ok(response);
    }
}