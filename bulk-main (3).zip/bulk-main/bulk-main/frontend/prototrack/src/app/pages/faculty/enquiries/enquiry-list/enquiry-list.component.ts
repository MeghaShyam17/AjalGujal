import { Component, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
  catchError,
  forkJoin,
  map,
  of,
  switchMap
} from 'rxjs';

import { EnquiryManagementService } from '../../../../core/services/enquiry.service';
import { FacultyService } from '../../../../core/services/faculty.service';
import { ToastService } from '../../../../core/services/toast.service';
import { UserService } from '../../../../core/services/user.service';
import { EnquiryResponse } from '../../../../core/models/enquiry';

export interface EnquiryItem {
  id: number;
  question: string;
  sender: string;
  senderRole: string;
  stageNo: number;
  stageName: string;
  status: 'Pending' | 'Answered';
  time: string;
  response?: string;
  respondedOn?: string;
  replyText?: string;
}

export interface TeamEnquiryGroup {
  team: string;
  projectId: number;
  batch: string;
  enquiries: EnquiryItem[];
}

interface UserLookup {
  userId: number;
  name: string;
  roleName: string;
}

@Component({
  selector: 'app-enquiry-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  templateUrl: './enquiry-list.component.html',
  styleUrl: './enquiry-list.component.css'
})
export class EnquiryListComponent implements OnInit {

  teamGroups: TeamEnquiryGroup[] = [];
  filteredGroups: TeamEnquiryGroup[] = [];

  selectedGroup: TeamEnquiryGroup | null = null;

  selectedBatch = 'all';
  searchText = '';
  batches: string[] = [];

  loading = false;
  toastMessage = '';
  errorMessage = '';

  facultyId = Number(sessionStorage.getItem('userId'));

  constructor(
    private toastService: ToastService,
    private userService: UserService,
    @Optional() private enquiryService?: EnquiryManagementService,
    @Optional() private facultyService?: FacultyService
  ) {}

  ngOnInit(): void {
    if (!this.facultyId) {
      this.errorMessage = 'Faculty ID not found. Please login again.';
      return;
    }

    this.loadEnquiries();
  }

  loadEnquiries(): void {
    this.loading = true;
    this.errorMessage = '';

    if (!this.enquiryService) {
      this.errorMessage = 'Enquiry service not available.';
      this.loading = false;
      return;
    }

    const enquiriesObs =
      this.enquiryService.getEnquiriesByFacultyId(this.facultyId);

    const projectsObs =
      this.facultyService
        ? this.facultyService.getProjectsByFacultyId(this.facultyId)
        : of([]);

    forkJoin({
      enquiries: enquiriesObs,
      projects: projectsObs
    })
      .pipe(
        switchMap(({
          enquiries,
          projects
        }: {
          enquiries: EnquiryResponse[] | any;
          projects: any[] | any;
        }) => {

          const rawEnquiries: EnquiryResponse[] =
            Array.isArray(enquiries)
              ? enquiries
              : enquiries?.data || [];

          const rawProjects: any[] =
            Array.isArray(projects)
              ? projects
              : projects?.data || [];

          const userIds = Array.from(
            new Set(
              rawEnquiries
                .map((enquiry: EnquiryResponse) =>
                  Number(enquiry.userId)
                )
                .filter((userId: number) =>
                  Number.isFinite(userId) && userId > 0
                )
            )
          );

          if (userIds.length === 0) {
            return of({
              rawEnquiries,
              rawProjects,
              userMap: new Map<number, UserLookup>()
            });
          }

          const userRequests = userIds.map((userId: number) =>
            this.userService.getUserById(userId).pipe(
              map((response: any) =>
                this.mapUserResponse(response, userId)
              ),
              catchError((error: any) => {
                console.warn(
                  `Failed to fetch user details for userId ${userId}:`,
                  error
                );

                return of({
                  userId,
                  name: `Trainee #${userId}`,
                  roleName: 'Student'
                });
              })
            )
          );

          return forkJoin(userRequests).pipe(
            map((users: UserLookup[]) => {
              const userMap = new Map<number, UserLookup>();

              users.forEach((user: UserLookup) => {
                userMap.set(user.userId, user);
              });

              return {
                rawEnquiries,
                rawProjects,
                userMap
              };
            })
          );
        })
      )
      .subscribe({
        next: ({
          rawEnquiries,
          rawProjects,
          userMap
        }: {
          rawEnquiries: EnquiryResponse[];
          rawProjects: any[];
          userMap: Map<number, UserLookup>;
        }) => {

          const groupMap = new Map<number, TeamEnquiryGroup>();

          rawProjects.forEach((project: any) => {
            const projectId = Number(project.projectId);

            if (!Number.isFinite(projectId) || projectId <= 0) {
              return;
            }

            groupMap.set(projectId, {
              team:
                this.toTitleCase(project.projectName) ||
                `Project ${projectId}`,
              projectId,
              batch:
                this.toTitleCase(project.batchName) ||
                `Batch ${String.fromCharCode(64 + (project.batchId || 1))}`,
              enquiries: []
            });
          });

          rawEnquiries.forEach((enquiry: EnquiryResponse) => {
            const projectId = Number(enquiry.projectId);

            if (!Number.isFinite(projectId) || projectId <= 0) {
              console.warn(
                'Skipping enquiry because projectId is missing:',
                enquiry
              );
              return;
            }

            if (!groupMap.has(projectId)) {
              groupMap.set(projectId, {
                team:
                  this.toTitleCase(enquiry.projectName) ||
                  `Project ${projectId}`,
                projectId,
                batch: 'Batch A',
                enquiries: []
              });
            }

            const group = groupMap.get(projectId);

            const statusText =
              enquiry.enquiryStatus
                ? enquiry.enquiryStatus.toUpperCase()
                : '';

            const isAnswered =
              !!enquiry.facultyComment ||
              statusText === 'RESOLVED' ||
              statusText === 'ANSWERED' ||
              statusText === 'CLOSED' ||
              statusText === 'REPLIED';

            const userId = Number(enquiry.userId);
            const user = userMap.get(userId);

            const enquiryItem: EnquiryItem = {
              id: enquiry.enquiryId,
              question:
                enquiry.userComment ||
                'Project technical query submitted by student.',
              sender:
                user?.name ||
                `Trainee #${enquiry.userId}`,
              senderRole:
                user?.roleName ||
                'Student',
              stageNo: 1,
              stageName: 'Project Query',
              status: isAnswered ? 'Answered' : 'Pending',
              time:
                enquiry.createdAt
                  ? new Date(enquiry.createdAt).toLocaleDateString()
                  : 'Recent',
              response: enquiry.facultyComment || undefined,
              respondedOn:
                enquiry.repliedAt
                  ? new Date(enquiry.repliedAt).toLocaleDateString()
                  : undefined,
              replyText: ''
            };

            if (group) {
              group.enquiries.push(enquiryItem);
            }
          });

          this.teamGroups = Array.from(groupMap.values())
            .map((group: TeamEnquiryGroup) => ({
              ...group,
              team: this.toTitleCase(group.team),
              batch: this.toTitleCase(group.batch),
              enquiries: [...group.enquiries].sort(
                (first: EnquiryItem, second: EnquiryItem) =>
                  second.id - first.id
              )
            }))
            .sort(
              (
                first: TeamEnquiryGroup,
                second: TeamEnquiryGroup
              ) => first.projectId - second.projectId
            );

          const batchSet = new Set<string>();

          this.teamGroups.forEach((group: TeamEnquiryGroup) => {
            batchSet.add(group.batch);
          });

          this.batches = Array.from(batchSet).sort();

          this.filterGroups();

          this.loading = false;
        },

        error: (error: any) => {
          console.error('Failed to fetch enquiries from backend:', error);
          this.errorMessage = 'Could not load enquiries from backend server.';
          this.loading = false;
        }
      });
  }

  filterGroups(): void {
    const query = this.searchText.toLowerCase().trim();

    this.filteredGroups = this.teamGroups.filter(
      (group: TeamEnquiryGroup) => {

        const matchesBatch =
          this.selectedBatch === 'all' ||
          group.batch === this.selectedBatch;

        const questionsText =
          group.enquiries
            .map((enquiry: EnquiryItem) => {
              return enquiry.question + ' ' + (enquiry.response || '');
            })
            .join(' ')
            .toLowerCase();

        const matchesQuery =
          !query ||
          group.team.toLowerCase().includes(query) ||
          group.projectId.toString().includes(query) ||
          questionsText.includes(query);

        return matchesBatch && matchesQuery;
      }
    );
  }

  openTeam(group: TeamEnquiryGroup): void {
    this.selectedGroup = group;
  }

  closeTeam(): void {
    this.selectedGroup = null;
  }

  getPendingCount(group: TeamEnquiryGroup): number {
    return group.enquiries.filter(
      (enquiry: EnquiryItem) => enquiry.status === 'Pending'
    ).length;
  }

  getAnsweredCount(group: TeamEnquiryGroup): number {
    return group.enquiries.filter(
      (enquiry: EnquiryItem) => enquiry.status === 'Answered'
    ).length;
  }

  get pendingEnquiries(): EnquiryItem[] {
    if (!this.selectedGroup) {
      return [];
    }

    return this.selectedGroup.enquiries.filter(
      (enquiry: EnquiryItem) => enquiry.status === 'Pending'
    );
  }

  get answeredEnquiries(): EnquiryItem[] {
    if (!this.selectedGroup) {
      return [];
    }

    return this.selectedGroup.enquiries.filter(
      (enquiry: EnquiryItem) => enquiry.status === 'Answered'
    );
  }

  sendReply(enquiry: EnquiryItem): void {
    if (!enquiry.replyText || !enquiry.replyText.trim()) {
      this.toastService.showWarning('Please enter a response before submitting.');
      return;
    }

    if (!this.enquiryService) {
      this.toastService.showError('Enquiry service is currently not available.');
      return;
    }

    const replyContent = enquiry.replyText.trim();

    this.enquiryService
      .facultyReply(enquiry.id, replyContent)
      .subscribe({
        next: (response: EnquiryResponse) => {
          enquiry.status = 'Answered';
          enquiry.response = response.facultyComment || replyContent;
          enquiry.respondedOn = 'Just now';
          enquiry.replyText = '';

          this.showToast(
            `Response submitted successfully for ${enquiry.sender}.`
          );
        },

        error: (error: any) => {
          console.error('Backend reply failed:', error);

          this.showToast(
            `Failed to submit response for ${enquiry.sender}.`
          );
        }
      });
  }

  showToast(message: string): void {
    this.toastMessage = message;

    setTimeout(() => {
      this.toastMessage = '';
    }, 3000);
  }

  private mapUserResponse(
    response: any,
    fallbackUserId: number
  ): UserLookup {
    const source =
      response?.data && typeof response.data === 'object'
        ? response.data
        : response;

    const role = source?.role;

    const roleObject =
      role && typeof role === 'object'
        ? role
        : null;

    const userId =
      Number(
        source?.userId ??
        source?.id ??
        fallbackUserId
      ) || fallbackUserId;

    const name = String(
      source?.name ??
      source?.fullName ??
      source?.userName ??
      source?.username ??
      ''
    ).trim();

    const roleName = String(
      source?.roleName ??
      roleObject?.roleName ??
      'Student'
    ).trim();

    return {
      userId,
      name:
        this.toTitleCase(name) ||
        `Trainee #${fallbackUserId}`,
      roleName:
        this.toTitleCase(roleName) ||
        'Student'
    };
  }

  private toTitleCase(value: string | null | undefined): string {
    if (!value) {
      return '';
    }

    return value
      .toString()
      .trim()
      .split(/\s+/)
      .filter((word: string) => word.length > 0)
      .map((word: string) => {
        const cleanWord = word.trim();

        if (!cleanWord) {
          return '';
        }

        if (
          cleanWord.length <= 4 &&
          cleanWord === cleanWord.toUpperCase() &&
          /[A-Z]/.test(cleanWord)
        ) {
          return cleanWord;
        }

        if (cleanWord.length === 1) {
          return cleanWord.toUpperCase();
        }

        return (
          cleanWord.charAt(0).toUpperCase() +
          cleanWord.slice(1).toLowerCase()
        );
      })
      .join(' ');
  }
}