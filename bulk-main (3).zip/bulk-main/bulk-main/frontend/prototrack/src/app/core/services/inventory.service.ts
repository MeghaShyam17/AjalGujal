import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import {
  BulkUploadResponse,
  DamageReport,
  Inventory
} from '../models/inventory';

import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  /**
   * Backend controller base mapping:
   * @RequestMapping("/inventory")
   *
   * If environment.apiUrl is http://localhost:8080, the final base URL is
   * http://localhost:8080/inventory.
   */
  private readonly apiUrl = `${environment.apiBaseUrl}/inventory`;

  constructor(private http: HttpClient) {}

  getAllInventory(): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(`${this.apiUrl}/all`);
  }
  getAllDamageReports(): Observable<DamageReport[]> {
  return this.http.get<DamageReport[]>(
    `${this.apiUrl}/damage-reports`
  );
}

  getInventoryById(itemId: number): Observable<Inventory> {
    this.validateItemId(itemId);
    return this.http.get<Inventory>(`${this.apiUrl}/${itemId}`);
  }

  getInventoryByCode(itemCode: string): Observable<Inventory> {
    return this.http.get<Inventory>(
      `${this.apiUrl}/code/${encodeURIComponent(itemCode)}`
    );
  }

  getInventoryByCategory(category: string): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(
      `${this.apiUrl}/category/${encodeURIComponent(category)}`
    );
  }

  searchInventoryByName(itemName: string): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(
      `${this.apiUrl}/search/${encodeURIComponent(itemName)}`
    );
  }

  getInventoryByStatus(status: string): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(
      `${this.apiUrl}/status/${encodeURIComponent(status)}`
    );
  }

  getLowStockItems(): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(`${this.apiUrl}/low-stock`);
  }

  getMinimumStockItems(): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(`${this.apiUrl}/minimum-stock`);
  }

  getAvailableItems(): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(`${this.apiUrl}/available`);
  }

  getOutOfStockItems(): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(`${this.apiUrl}/out-of-stock`);
  }

  checkAvailableStock(
    itemId: number,
    requestedQuantity: number
  ): Observable<Inventory> {
    this.validateItemId(itemId);

    return this.http.get<Inventory>(
      `${this.apiUrl}/check-stock/${itemId}/${requestedQuantity}`
    );
  }

  countLowStockItems(): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/low-stock/count`);
  }

  getTotalAvailableStock(): Observable<number> {
    return this.http.get<number>(
      `${this.apiUrl}/total-available-stock`
    );
  }

  saveInventory(inventory: Inventory): Observable<Inventory> {
    return this.http.post<Inventory>(
      `${this.apiUrl}/save`,
      inventory
    );
  }

  updateInventory(inventory: Inventory): Observable<Inventory> {
    const itemId = Number(inventory.itemId);
    this.validateItemId(itemId);

    return this.http.put<Inventory>(
      `${this.apiUrl}/update`,
      inventory
    );
  }

  deleteInventory(itemId: number): Observable<string> {
    const validItemId = Number(itemId);
    this.validateItemId(validItemId);

    const url = `${this.apiUrl}/delete/${validItemId}`;

    console.log('Inventory DELETE request:', {
      itemId: validItemId,
      url
    });

    /*
     * InventoryController returns a plain String, not JSON.
     * responseType must therefore be text.
     */
    return this.http.delete(url, {
      responseType: 'text'
    });
  }

  uploadImage(itemId: number, file: File): Observable<string> {
    this.validateItemId(itemId);

    const formData = new FormData();
    formData.append('file', file);

    return this.http.post(
      `${this.apiUrl}/upload-image/${itemId}`,
      formData,
      {
        responseType: 'text'
      }
    );
  }

  bulkUpload(file: File): Observable<BulkUploadResponse> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<BulkUploadResponse>(
      `${this.apiUrl}/bulk-upload`,
      formData
    );
  }

  private validateItemId(itemId: number): void {
    if (!Number.isInteger(itemId) || itemId <= 0) {
      throw new Error(
        `A valid inventory item ID is required. Received: ${itemId}`
      );
    }
  }
}
