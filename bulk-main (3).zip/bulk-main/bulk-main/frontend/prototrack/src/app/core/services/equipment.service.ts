import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

import {
  EquipmentMasterRequestDto,
  EquipmentMasterResponseDto,
  EquipmentRequestDto,
  EquipmentResponseDto,
  EquipmentBookingRequestDto,
  EquipmentBookingResponseDto,
  EquipmentMaintenanceRequestDto,
  EquipmentMaintenanceResponseDto
} from '../models/equipment';

@Injectable({
  providedIn: 'root'
})
export class EquipmentService {

  /*
    Use 8087 directly for Equipment Service now.
    Later, if API Gateway works, change this to:
    private baseUrl = 'http://localhost:8080';
  */
  private baseUrl = environment.apiBaseUrl;

  private masterUrl = `${this.baseUrl}/api/equipment-masters`;
  private equipmentUrl = `${this.baseUrl}/api/equipment`;
  private bookingUrl = `${this.baseUrl}/equipment-bookings`;
  private maintenanceUrl = `${this.baseUrl}/api/maintenance`;

  constructor(
    private http: HttpClient
  ) {}

  // ==========================================
  // EQUIPMENT MASTER
  // ==========================================

  createEquipmentMaster(
    data: EquipmentMasterRequestDto
  ): Observable<EquipmentMasterResponseDto> {
    return this.http.post<EquipmentMasterResponseDto>(
      this.masterUrl,
      data
    );
  }

  getEquipmentMasters(): Observable<EquipmentMasterResponseDto[]> {
    return this.http.get<EquipmentMasterResponseDto[]>(
      this.masterUrl
    );
  }

  getEquipmentMasterById(
    id: number
  ): Observable<EquipmentMasterResponseDto> {
    return this.http.get<EquipmentMasterResponseDto>(
      `${this.masterUrl}/${id}`
    );
  }

  updateEquipmentMaster(
    id: number,
    data: EquipmentMasterRequestDto
  ): Observable<EquipmentMasterResponseDto> {
    return this.http.put<EquipmentMasterResponseDto>(
      `${this.masterUrl}/${id}`,
      data
    );
  }

  deleteEquipmentMaster(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.masterUrl}/${id}`
    );
  }

  bulkUpload(
    file: File
  ): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<any>(
      `${this.masterUrl}/bulk-upload`,
      formData
    );
  }

  // ==========================================
  // EQUIPMENT ITEMS
  // ==========================================

  createEquipment(
    data: EquipmentRequestDto
  ): Observable<EquipmentResponseDto> {
    return this.http.post<EquipmentResponseDto>(
      this.equipmentUrl,
      data
    );
  }

  getEquipments(): Observable<EquipmentResponseDto[]> {
    return this.http.get<EquipmentResponseDto[]>(
      this.equipmentUrl
    );
  }

  getEquipmentById(
    id: number
  ): Observable<EquipmentResponseDto> {
    return this.http.get<EquipmentResponseDto>(
      `${this.equipmentUrl}/${id}`
    );
  }

  updateEquipment(
    id: number,
    data: EquipmentRequestDto
  ): Observable<EquipmentResponseDto> {
    return this.http.put<EquipmentResponseDto>(
      `${this.equipmentUrl}/${id}`,
      data
    );
  }

  deleteEquipment(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.equipmentUrl}/${id}`
    );
  }

  // ==========================================
  // EQUIPMENT BOOKING
  // ==========================================

  createBooking(
    data: EquipmentBookingRequestDto
  ): Observable<EquipmentBookingResponseDto> {
    return this.http.post<EquipmentBookingResponseDto>(
      this.bookingUrl,
      data
    );
  }

  getBookings(): Observable<EquipmentBookingResponseDto[]> {
    return this.http.get<EquipmentBookingResponseDto[]>(
      this.bookingUrl
    );
  }

  getBookingById(
    id: number
  ): Observable<EquipmentBookingResponseDto> {
    return this.http.get<EquipmentBookingResponseDto>(
      `${this.bookingUrl}/${id}`
    );
  }

  approveBooking(
    id: number,
    approvedBy: number
  ): Observable<EquipmentBookingResponseDto> {
    const params = new HttpParams()
      .set('approvedBy', approvedBy.toString());

    return this.http.put<EquipmentBookingResponseDto>(
      `${this.bookingUrl}/${id}/approve`,
      {},
      { params }
    );
  }

  rejectBooking(
    id: number,
    approvedBy: number
  ): Observable<EquipmentBookingResponseDto> {
    const params = new HttpParams()
      .set('approvedBy', approvedBy.toString());

    return this.http.put<EquipmentBookingResponseDto>(
      `${this.bookingUrl}/${id}/reject`,
      {},
      { params }
    );
  }

  getBookingsByProjectId(
    projectId: number
  ): Observable<EquipmentBookingResponseDto[]> {
    return this.http.get<EquipmentBookingResponseDto[]>(
      `${this.bookingUrl}/project/${projectId}`
    );
  }

  updateBooking(
    id: number,
    data: EquipmentBookingRequestDto
  ): Observable<EquipmentBookingResponseDto> {
    return this.http.put<EquipmentBookingResponseDto>(
      `${this.bookingUrl}/${id}`,
      data
    );
  }

  deleteBooking(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.bookingUrl}/${id}`
    );
  }

  // ==========================================
  // EQUIPMENT MAINTENANCE
  // ==========================================

  createMaintenance(
    data: EquipmentMaintenanceRequestDto
  ): Observable<EquipmentMaintenanceResponseDto> {
    return this.http.post<EquipmentMaintenanceResponseDto>(
      this.maintenanceUrl,
      data
    );
  }

  getMaintenanceRecords(): Observable<EquipmentMaintenanceResponseDto[]> {
    return this.http.get<EquipmentMaintenanceResponseDto[]>(
      this.maintenanceUrl
    );
  }

  getMaintenanceById(
    id: number
  ): Observable<EquipmentMaintenanceResponseDto> {
    return this.http.get<EquipmentMaintenanceResponseDto>(
      `${this.maintenanceUrl}/${id}`
    );
  }

  updateMaintenance(
    id: number,
    data: EquipmentMaintenanceRequestDto
  ): Observable<EquipmentMaintenanceResponseDto> {
    return this.http.put<EquipmentMaintenanceResponseDto>(
      `${this.maintenanceUrl}/${id}`,
      data
    );
  }

  getMaintenancesByEquipmentId(
    equipmentId: number
  ): Observable<EquipmentMaintenanceResponseDto[]> {
    return this.http.get<EquipmentMaintenanceResponseDto[]>(
      `${this.maintenanceUrl}/equipment/${equipmentId}`
    );
  }

  deleteMaintenance(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.maintenanceUrl}/${id}`
    );
  }

}