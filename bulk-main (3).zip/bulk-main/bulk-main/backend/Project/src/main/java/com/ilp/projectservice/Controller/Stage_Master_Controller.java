package com.ilp.projectservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Service.Stage_Master_Service;

@CrossOrigin(origins = {
	    "http://localhost:4200",
	    "http://127.0.0.1:4200"
	})
@RestController
@RequestMapping("/stage-master")
public class Stage_Master_Controller {
    @Autowired
    private Stage_Master_Service service;

    @PostMapping("/save")
    public Stage_Master_Entity saveStage(
            @RequestBody Stage_Master_Entity stage) {

        return service.saveStage(stage);
    }

    @GetMapping("/all")
    public List<Stage_Master_Entity> getAllStages() {

        return service.getAllStages();
    }

    @GetMapping("/{id}")
    public Stage_Master_Entity getStageById(
            @PathVariable Long id) {

        return service.getStageById(id);
    }

    @PutMapping("/{id}")
    public Stage_Master_Entity updateStage(
            @PathVariable Long id,
            @RequestBody Stage_Master_Entity stage) {

        return service.updateStage(id, stage);
    }

    @DeleteMapping("/{id}")
    public String deleteStage(
            @PathVariable Long id) {

        service.deleteStage(id);

        return "Stage deleted successfully";
    }
}