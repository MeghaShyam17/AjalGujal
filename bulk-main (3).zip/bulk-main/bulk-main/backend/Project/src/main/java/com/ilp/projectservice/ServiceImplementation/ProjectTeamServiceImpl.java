package com.ilp.projectservice.ServiceImplementation;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.projectservice.DTO.BulkProjectRowDto;
import com.ilp.projectservice.DTO.BulkUploadError;
import com.ilp.projectservice.DTO.BulkUploadResult;
import com.ilp.projectservice.DTO.RegisterUserRequestDto;
import com.ilp.projectservice.DTO.UserResponseDto;
import com.ilp.projectservice.DTO.BatchDto;
import com.ilp.projectservice.Entity.Stage_Master_Entity;
import com.ilp.projectservice.Entity.Project_Stage_Entity;
import com.ilp.projectservice.Entity.ProjectTeam;
import com.ilp.projectservice.Entity.TeamMember;
import com.ilp.projectservice.Exception.BadRequestException;
import com.ilp.projectservice.Exception.BulkUploadException;
import com.ilp.projectservice.Exception.BusinessException;
import com.ilp.projectservice.Exception.ResourceNotFoundException;
import com.ilp.projectservice.Repository.ProjectTeamRepository;
import com.ilp.projectservice.Repository.TeamMemberRepository;
import com.ilp.projectservice.Service.ProjectTeamService;

@Service
@Transactional
public class ProjectTeamServiceImpl implements ProjectTeamService {

    private static final String PROJECTS_SHEET = "Teams";
    private static final int EXPECTED_COLUMN_COUNT = 11;
    private static final int MAX_MEMBERS_PER_PROJECT = 15;

    private static final Set<String> VALID_STATUSES =
            Set.of("Pending", "Ongoing", "Completed");

    private static final String[] EXPECTED_HEADERS = {
            "Project Key",
            "Project Name",
            "Description",
            "Year",
            "Batch ID",
            "Team Leader ID",
            "Faculty ID",
            "Deadline",
            "Project Status",
            "Trainee ID",
            "Member Role"
    };

    private final ProjectTeamRepository projectTeamRepository;
    private final TeamMemberRepository teamMemberRepository;
    private final com.ilp.projectservice.Client.UserClient userClient;
    private final com.ilp.projectservice.Repository.Stage_Master_Repository stageMasterRepository;
    private final com.ilp.projectservice.Repository.Project_Stage_Repository projectStageRepository;
    private final DataFormatter formatter = new DataFormatter(Locale.ENGLISH);

    public ProjectTeamServiceImpl(
            ProjectTeamRepository projectTeamRepository,
            TeamMemberRepository teamMemberRepository,
            com.ilp.projectservice.Client.UserClient userClient,
            com.ilp.projectservice.Repository.Stage_Master_Repository stageMasterRepository,
            com.ilp.projectservice.Repository.Project_Stage_Repository projectStageRepository) {
        this.projectTeamRepository = projectTeamRepository;
        this.teamMemberRepository = teamMemberRepository;
        this.userClient = userClient;
        this.stageMasterRepository = stageMasterRepository;
        this.projectStageRepository = projectStageRepository;
    }

    @Override
    public void hardDeleteProject(Integer projectId) {
        ProjectTeam project = projectTeamRepository
                .findById(projectId)
                .orElseThrow(() -> new ResourceNotFoundException("Project", projectId));
        projectTeamRepository.delete(project);
    }

    private void checkTraineeAvailability(Integer traineeId, Integer targetProjectId) {
        List<TeamMember> activeAssignments =
                teamMemberRepository.findByTraineeIdAndIsDeletedFalse(traineeId);

        for (TeamMember assignment : activeAssignments) {
            if (targetProjectId != null
                    && targetProjectId.equals(assignment.getProjectId())) {
                continue;
            }

            projectTeamRepository
                    .findByProjectIdAndIsDeletedFalse(assignment.getProjectId())
                    .ifPresent(project -> {
                        if (!"Completed".equalsIgnoreCase(project.getProjectStatus())) {
                            throw new BusinessException(
                                    "Trainee with ID " + traineeId
                                            + " is already assigned to active project '"
                                            + project.getProjectName()
                                            + "' and cannot join a new project until it is completed.");
                        }
                    });
        }
    }

    @Override
    public ProjectTeam createProject(ProjectTeam projectTeam) {
        validateProject(projectTeam);
        projectTeam.setProjectId(null);

        String status = projectTeam.getProjectStatus();
        projectTeam.setProjectStatus(
                isBlank(status) ? "Pending" : normalizeRequiredStatus(status));

        ProjectTeam savedProject = projectTeamRepository.save(projectTeam);

        if (projectTeam.getTeamMembers() != null
                && !projectTeam.getTeamMembers().isEmpty()) {
            Set<Integer> traineeIds = new HashSet<>();

            if (projectTeam.getTeamMembers().size() > MAX_MEMBERS_PER_PROJECT) {
                throw new BadRequestException("Maximum 15 team members are allowed");
            }

            for (TeamMember member : projectTeam.getTeamMembers()) {
                if (member.getTraineeId() == null) {
                    throw new BadRequestException("Trainee ID is required");
                }
                if (!traineeIds.add(member.getTraineeId())) {
                    throw new BadRequestException(
                            "Duplicate trainee ID: " + member.getTraineeId());
                }

                checkTraineeAvailability(member.getTraineeId(), null);
                member.setTeamMemberId(null);
                member.setProjectId(savedProject.getProjectId());
                member.setMemberRole(
                        isBlank(member.getMemberRole()) ? "Member" : member.getMemberRole().trim());
                member.setIsDeleted(false);
                teamMemberRepository.save(member);
            }

            savedProject.setTeamMembers(projectTeam.getTeamMembers());
        }

        return savedProject;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getAllProjects() {
        return projectTeamRepository.findByIsDeletedFalse();
    }

    @Override
    @Transactional(readOnly = true)
    public ProjectTeam getProjectById(Integer projectId) {
        return findProjectById(projectId);
    }

    @Override
    public ProjectTeam updateProject(Integer projectId, ProjectTeam projectTeam) {
        validateProject(projectTeam);
        ProjectTeam existingProject = findProjectById(projectId);

        String status = projectTeam.getProjectStatus();
        if (isBlank(status)) {
            status = existingProject.getProjectStatus();
        }

        existingProject.setProjectName(projectTeam.getProjectName().trim());
        existingProject.setDescription(projectTeam.getDescription());
        existingProject.setTeamLeaderId(projectTeam.getTeamLeaderId());
        existingProject.setFacultyId(projectTeam.getFacultyId());
        existingProject.setBatchId(projectTeam.getBatchId());
        existingProject.setYear(projectTeam.getYear());
        existingProject.setDeadline(projectTeam.getDeadline());
        existingProject.setProjectStatus(normalizeRequiredStatus(status));

        return projectTeamRepository.save(existingProject);
    }

    @Override
    public ProjectTeam updateProjectStatus(Integer projectId, String projectStatus) {
        ProjectTeam existingProject = findProjectById(projectId);
        existingProject.setProjectStatus(normalizeRequiredStatus(projectStatus));
        return projectTeamRepository.save(existingProject);
    }

    @Override
    public void deleteProject(Integer projectId) {
        ProjectTeam project = findProjectById(projectId);
        project.setIsDeleted(true);
        projectTeamRepository.save(project);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByStatus(String projectStatus) {
        return projectTeamRepository.findByProjectStatusAndIsDeletedFalse(
                normalizeRequiredStatus(projectStatus));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByTeamLeader(Integer teamLeaderId) {
        return projectTeamRepository.findByTeamLeaderIdAndIsDeletedFalse(teamLeaderId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByFaculty(Integer facultyId) {
        return projectTeamRepository.findByFacultyIdAndIsDeletedFalse(facultyId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByBatch(Integer batchId) {
        return projectTeamRepository.findByBatchIdAndIsDeletedFalse(batchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> getProjectsByYear(Integer year) {
        return projectTeamRepository.findByYearAndIsDeletedFalse(year);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectTeam> searchProjectsByName(String projectName) {
        if (isBlank(projectName)) {
            return projectTeamRepository.findByIsDeletedFalse();
        }
        return projectTeamRepository
                .findByProjectNameContainingIgnoreCaseAndIsDeletedFalse(projectName.trim());
    }

    private static class RowData {
        int excelRowNumber;
        String projectKey;
        String projectName;
        String description;
        Integer year;
        String batchName;
        LocalDate batchStartDate;
        LocalDate batchEndDate;
        String leaderEmail;
        String facultyEmail;
        LocalDate projectDeadline;
        String traineeName;
        String traineeEmail;
        String traineePhone;
        String traineeGender;
        String memberRole;
        Map<Integer, StageData> stages = new HashMap<>();
    }

    private static class StageData {
        String name;
        String description;
        LocalDate batchDeadline;
        LocalDate projectDeadline;
    }

    private String getStringValue(Row row, Map<String, Integer> headerMap, String headerName) {
        Integer index = headerMap.get(headerName.toLowerCase(Locale.ENGLISH).trim());
        if (index == null) return "";
        return text(row.getCell(index));
    }

    private String getNullableStringValue(Row row, Map<String, Integer> headerMap, String headerName) {
        Integer index = headerMap.get(headerName.toLowerCase(Locale.ENGLISH).trim());
        if (index == null) return null;
        return nullableText(row.getCell(index));
    }

    private Integer getIntValue(Row row, Map<String, Integer> headerMap, String headerName) {
        Integer index = headerMap.get(headerName.toLowerCase(Locale.ENGLISH).trim());
        if (index == null) return null;
        return integer(row.getCell(index));
    }

    private LocalDate getDateValue(Row row, Map<String, Integer> headerMap, String headerName) {
        Integer index = headerMap.get(headerName.toLowerCase(Locale.ENGLISH).trim());
        if (index == null) return null;
        return date(row.getCell(index));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public BulkUploadResult uploadProjectTeamsAndMembers(MultipartFile file) {
        validateExcelFile(file);

        List<RowData> parsedRows = new ArrayList<>();
        List<BulkUploadError> errors = new ArrayList<>();

        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new BadRequestException("The uploaded workbook is empty.");
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new BadRequestException("Header row is missing in the Excel sheet.");
            }

            Map<String, Integer> headerMap = new HashMap<>();
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                String val = text(headerRow.getCell(i));
                if (!val.isBlank()) {
                    headerMap.put(val.toLowerCase(Locale.ENGLISH).trim(), i);
                }
            }

            // Read rows
            for (int index = 1; index <= sheet.getLastRowNum(); index++) {
                Row row = sheet.getRow(index);
                if (row == null) continue;

                String projectKey = getStringValue(row, headerMap, "Project Key");
                String traineeEmail = getStringValue(row, headerMap, "Trainee Email");
                if (projectKey.isBlank() && traineeEmail.isBlank()) {
                    continue; // Skip empty rows
                }

                RowData rData = new RowData();
                rData.excelRowNumber = index + 1;
                rData.projectKey = projectKey.trim();
                rData.projectName = getStringValue(row, headerMap, "Project Name");
                rData.description = getNullableStringValue(row, headerMap, "Description");
                rData.year = getIntValue(row, headerMap, "Year");
                rData.batchName = getStringValue(row, headerMap, "Batch Name");
                rData.batchStartDate = getDateValue(row, headerMap, "Batch Start Date");
                rData.batchEndDate = getDateValue(row, headerMap, "Batch End Date");
                rData.leaderEmail = getStringValue(row, headerMap, "Leader Email");
                rData.facultyEmail = getStringValue(row, headerMap, "Faculty Email");
                rData.projectDeadline = getDateValue(row, headerMap, "Project Deadline");
                rData.traineeName = getStringValue(row, headerMap, "Trainee Name");
                rData.traineeEmail = traineeEmail.trim();
                rData.traineePhone = getNullableStringValue(row, headerMap, "Trainee Phone");
                rData.traineeGender = getStringValue(row, headerMap, "Trainee Gender");
                rData.memberRole = getStringValue(row, headerMap, "Member Role");

                // Parse stage columns dynamically
                for (int n = 1; n <= 15; n++) {
                    String nameVal = getStringValue(row, headerMap, "Stage " + n + " Name");
                    if (nameVal.isBlank()) break;
                    StageData sd = new StageData();
                    sd.name = nameVal.trim();
                    sd.description = getNullableStringValue(row, headerMap, "Stage " + n + " Description");
                    sd.batchDeadline = getDateValue(row, headerMap, "Stage " + n + " Batch Deadline");
                    sd.projectDeadline = getDateValue(row, headerMap, "Stage " + n + " Project Deadline");
                    rData.stages.put(n, sd);
                }

                parsedRows.add(rData);

                // Run basic syntax checks on the row
                int excelRow = rData.excelRowNumber;
                if (rData.projectKey.isBlank()) {
                    errors.add(new BulkUploadError("Teams", excelRow, "Project Key is required"));
                }
                if (rData.traineeEmail.isBlank()) {
                    errors.add(new BulkUploadError("Teams", excelRow, "Trainee Email is required"));
                }
                if (rData.traineeName.isBlank()) {
                    errors.add(new BulkUploadError("Teams", excelRow, "Trainee Name is required"));
                }
                if (!isBlank(rData.projectName)) {
                    if (rData.year == null || rData.year < 2000 || rData.year > 2100) {
                        errors.add(new BulkUploadError("Teams", excelRow, "Year must be a valid four-digit year"));
                    }
                    if (rData.batchName.isBlank()) {
                        errors.add(new BulkUploadError("Teams", excelRow, "Batch Name is required"));
                    }
                    if (rData.leaderEmail.isBlank()) {
                        errors.add(new BulkUploadError("Teams", excelRow, "Leader Email is required"));
                    }
                    if (rData.facultyEmail.isBlank()) {
                        errors.add(new BulkUploadError("Teams", excelRow, "Faculty Email is required"));
                    }
                    if (rData.projectDeadline == null) {
                        errors.add(new BulkUploadError("Teams", excelRow, "Project Deadline is required"));
                    } else if (!rData.projectDeadline.isAfter(LocalDate.now())) {
                        errors.add(new BulkUploadError("Teams", excelRow, "Project Deadline must be greater than current date"));
                    }
                }
            }

        } catch (IOException exception) {
            throw new BadRequestException("Unable to read workbook", exception);
        }

        if (!errors.isEmpty()) {
            throw new BulkUploadException("Excel validation failed. No records were inserted.", errors);
        }

        // Group rows by projectKey to process teams
        Map<String, List<RowData>> groupedProjects = new LinkedHashMap<>();
        for (RowData r : parsedRows) {
            groupedProjects.computeIfAbsent(r.projectKey, key -> new ArrayList<>()).add(r);
        }

        // Propagate project-level details from the first row of each project key
        for (Map.Entry<String, List<RowData>> entry : groupedProjects.entrySet()) {
            List<RowData> groupRows = entry.getValue();
            RowData metadataRow = null;
            for (RowData r : groupRows) {
                if (!isBlank(r.projectName)) {
                    metadataRow = r;
                    break;
                }
            }

            if (metadataRow == null) {
                errors.add(new BulkUploadError("Teams", groupRows.get(0).excelRowNumber,
                        "No project metadata (Name, Year, Batch Name, etc.) defined for Project Key: " + entry.getKey()));
                continue;
            }

            for (RowData r : groupRows) {
                r.projectName = metadataRow.projectName;
                r.description = metadataRow.description;
                r.year = metadataRow.year;
                r.batchName = metadataRow.batchName;
                r.batchStartDate = metadataRow.batchStartDate;
                r.batchEndDate = metadataRow.batchEndDate;
                r.leaderEmail = metadataRow.leaderEmail;
                r.facultyEmail = metadataRow.facultyEmail;
                r.projectDeadline = metadataRow.projectDeadline;
                r.stages = metadataRow.stages;
            }
        }

        if (!errors.isEmpty()) {
            throw new BulkUploadException("Excel metadata resolution failed. No records were inserted.", errors);
        }

        Map<String, Integer> generatedProjectIds = new LinkedHashMap<>();
        int projectsInserted = 0;
        int membersInserted = 0;

        // Fetch all existing batches from user-service
        List<BatchDto> existingBatches = userClient.getBatches();
        Map<String, Integer> batchNameToIdMap = new HashMap<>();
        for (BatchDto b : existingBatches) {
            batchNameToIdMap.put(b.getBatchName().toLowerCase(Locale.ENGLISH).trim(), b.getBatchId());
        }

        for (Map.Entry<String, List<RowData>> entry : groupedProjects.entrySet()) {
            String projectKey = entry.getKey();
            List<RowData> projectRows = entry.getValue();
            RowData firstRow = projectRows.get(0);

            // 1. Resolve or Create Batch
            String normBatchName = firstRow.batchName.toLowerCase(Locale.ENGLISH).trim();
            Integer batchId = batchNameToIdMap.get(normBatchName);
            if (batchId == null) {
                BatchDto newBatch = new BatchDto();
                newBatch.setBatchName(firstRow.batchName.trim());
                newBatch.setYear(firstRow.year);
                newBatch.setStartDate(firstRow.batchStartDate != null ? firstRow.batchStartDate : LocalDate.of(firstRow.year, 8, 1));
                newBatch.setEndDate(firstRow.batchEndDate != null ? firstRow.batchEndDate : LocalDate.of(firstRow.year, 12, 20));
                newBatch = userClient.createBatch(newBatch);
                batchId = newBatch.getBatchId();
                batchNameToIdMap.put(normBatchName, batchId);
            }

            // 2. Resolve/Create Stage Master configurations for this batch
            for (Map.Entry<Integer, StageData> stageEntry : firstRow.stages.entrySet()) {
                Integer stageNo = stageEntry.getKey();
                StageData sd = stageEntry.getValue();

                Optional<Stage_Master_Entity> stageOpt = stageMasterRepository.findByBatchIdAndStageNo(batchId, stageNo);
                if (stageOpt.isPresent()) {
                    Stage_Master_Entity existingStage = stageOpt.get();
                    if (!existingStage.getStageName().equalsIgnoreCase(sd.name)) {
                        existingStage.setStageName(sd.name);
                        existingStage.setDescription(sd.description != null ? sd.description : sd.name);
                        stageMasterRepository.save(existingStage);
                    }
                } else {
                    Stage_Master_Entity newStage = new Stage_Master_Entity();
                    newStage.setBatchId(batchId);
                    newStage.setStageNo(stageNo);
                    newStage.setStageName(sd.name);
                    newStage.setDescription(sd.description != null ? sd.description : sd.name);
                    stageMasterRepository.save(newStage);
                }
            }

            // Flush stage configurations
            stageMasterRepository.flush();

            // 3. Resolve Faculty guide
            UserResponseDto faculty = null;
            try {
                faculty = userClient.getUserByEmail(firstRow.facultyEmail.trim());
            } catch (Exception ex) {
                // Ignore Feign decode exception
            }
            if (faculty == null) {
                throw new BadRequestException("Faculty guide with email '" + firstRow.facultyEmail + "' not found in user service.");
            }

            // 4. Resolve Leader profile
            UserResponseDto leader = null;
            try {
                leader = userClient.getUserByEmail(firstRow.leaderEmail.trim());
            } catch (Exception ex) {
                // Ignore
            }
            if (leader == null) {
                // Search for the leader's row details in this project group
                RowData leaderRow = null;
                for (RowData r : projectRows) {
                    if (r.traineeEmail.equalsIgnoreCase(firstRow.leaderEmail)) {
                        leaderRow = r;
                        break;
                    }
                }
                if (leaderRow != null) {
                    RegisterUserRequestDto reg = new RegisterUserRequestDto(
                            leaderRow.traineeName, leaderRow.traineeEmail,
                            leaderRow.traineePhone, leaderRow.traineeGender,
                            leaderRow.year, batchId, "Temp@123"
                    );
                    leader = userClient.autoRegisterUser(reg);
                } else {
                    throw new BadRequestException("Leader email '" + firstRow.leaderEmail + "' is not mapped to any trainee in Project Key: " + projectKey);
                }
            }

            // 5. Create Project Team
            ProjectTeam project = new ProjectTeam();
            project.setProjectId(null);
            project.setProjectName(firstRow.projectName.trim());
            project.setDescription(firstRow.description);
            project.setYear(firstRow.year);
            project.setBatchId(batchId);
       project.setTeamLeaderId(Integer.valueOf(leader.getUserId().intValue()));
project.setFacultyId(Integer.valueOf(faculty.getUserId().intValue()));
            project.setDeadline(firstRow.projectDeadline);
            project.setProjectStartDate(LocalDate.now());
            project.setProjectStatus("Ongoing");
            project.setIsDeleted(false);
            
            project = projectTeamRepository.save(project);
            Integer generatedProjectId = project.getProjectId();

            // 6. Register Trainees and link members
            for (RowData memberRow : projectRows) {
                UserResponseDto trainee = null;
                try {
                    trainee = userClient.getUserByEmail(memberRow.traineeEmail.trim());
                } catch (Exception ex) {
                    // Ignore
                }
                if (trainee == null) {
                    RegisterUserRequestDto reg = new RegisterUserRequestDto(
                            memberRow.traineeName, memberRow.traineeEmail,
                            memberRow.traineePhone, memberRow.traineeGender,
                            memberRow.year, batchId, "Temp@123"
                    );
                    trainee = userClient.autoRegisterUser(reg);
                }

                TeamMember member = new TeamMember();
                member.setTeamMemberId(null);
                member.setProjectId(generatedProjectId);
               member.setTraineeId(Integer.valueOf(trainee.getUserId().intValue()));
                member.setMemberRole(isBlank(memberRow.memberRole) ? "Member" : memberRow.memberRole.trim());
                member.setIsDeleted(false);

                teamMemberRepository.save(member);
                membersInserted++;
            }

            // 7. Initialize and map project_stage timelines
            List<Stage_Master_Entity> batchStages = stageMasterRepository.findByBatchIdOrderByStageNoAsc(batchId);
            if (batchStages.isEmpty()) {
                batchStages = stageMasterRepository.findByBatchIdIsNullOrderByStageNoAsc();
            }

            for (Stage_Master_Entity sm : batchStages) {
                Project_Stage_Entity ps = new Project_Stage_Entity();
                ps.setProjectId(generatedProjectId);
                ps.setStageMaster(sm);
                ps.setVersionNo(1);
                ps.setIsOverdue(false);
                ps.setIsAcknowledged(false);

                if (sm.getStageNo() == 1) {
                    ps.setSubmissionStatus("IN_PROGRESS");
                    ps.setCurrentStage(true);
                } else {
                    ps.setSubmissionStatus("NOT_STARTED");
                    ps.setCurrentStage(false);
                }

                // Map dynamic project stage deadline
                StageData sd = firstRow.stages.get(sm.getStageNo());
                if (sd != null && sd.projectDeadline != null) {
                    ps.setStageDeadline(sd.projectDeadline);
                } else {
                    ps.setStageDeadline(sd != null && sd.batchDeadline != null ? sd.batchDeadline : firstRow.projectDeadline);
                }

                projectStageRepository.save(ps);
            }

            generatedProjectIds.put(projectKey, generatedProjectId);
            projectsInserted++;
        }

        projectTeamRepository.flush();
        teamMemberRepository.flush();
        projectStageRepository.flush();

        return new BulkUploadResult(
                true,
                projectsInserted,
                membersInserted,
                projectsInserted + " projects and " + membersInserted
                        + " team members uploaded successfully",
                Map.copyOf(generatedProjectIds));
    }

    private List<BulkUploadError> validateWorkbook(List<BulkProjectRowDto> projects) {
        List<BulkUploadError> errors = new ArrayList<>();

        if (projects.isEmpty()) {
            addError(errors, PROJECTS_SHEET, 0, "At least one project row is required");
            return errors;
        }

        Map<String, List<BulkProjectRowDto>> groupedProjects = new LinkedHashMap<>();

        for (BulkProjectRowDto row : projects) {
            int excelRow = row.rowNumber();

            if (isBlank(row.projectKey())) {
                addError(errors, PROJECTS_SHEET, excelRow, "Project Key is required");
            }
            if (isBlank(row.projectName())) {
                addError(errors, PROJECTS_SHEET, excelRow, "Project Name is required");
            } else if (row.projectName().trim().length() > 200) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Project Name cannot exceed 200 characters");
            }
            if (row.year() == null || row.year() < 2000 || row.year() > 2100) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Year must be a valid four-digit year");
            }
            if (row.batchId() == null || row.batchId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Batch ID is required");
            }
            if (row.teamLeaderId() == null || row.teamLeaderId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Team Leader ID is required");
            }
            if (row.facultyId() == null || row.facultyId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Faculty ID is required");
            }
            if (row.deadline() == null) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Deadline is required and must use yyyy-MM-dd");
            } else if (!row.deadline().isAfter(LocalDate.now())) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Deadline must be greater than the current date");
            }
            if (row.traineeId() == null || row.traineeId() <= 0) {
                addError(errors, PROJECTS_SHEET, excelRow, "Trainee ID is required");
            }
            if (normalizeValue(row.projectStatus(), VALID_STATUSES) == null) {
                addError(errors, PROJECTS_SHEET, excelRow,
                        "Project Status must be Pending, Ongoing, or Completed");
            }

            if (!isBlank(row.projectKey())) {
                groupedProjects
                        .computeIfAbsent(row.projectKey().trim(), key -> new ArrayList<>())
                        .add(row);
            }
        }

        for (Map.Entry<String, List<BulkProjectRowDto>> entry
                : groupedProjects.entrySet()) {
            String projectKey = entry.getKey();
            List<BulkProjectRowDto> projectRows = entry.getValue();
            BulkProjectRowDto first = projectRows.get(0);

            if (projectRows.size() > MAX_MEMBERS_PER_PROJECT) {
                addError(errors, PROJECTS_SHEET, first.rowNumber(),
                        "Project Key " + projectKey + " contains more than 15 members");
            }

            Set<Integer> traineeIds = new HashSet<>();

            for (BulkProjectRowDto row : projectRows) {
                if (row.traineeId() != null && !traineeIds.add(row.traineeId())) {
                    addError(errors, PROJECTS_SHEET, row.rowNumber(),
                            "Duplicate Trainee ID " + row.traineeId()
                                    + " for Project Key " + projectKey);
                }

                if (!sameProjectDetails(first, row)) {
                    addError(errors, PROJECTS_SHEET, row.rowNumber(),
                            "Project details are inconsistent for Project Key " + projectKey);
                }
            }
        }

        return errors;
    }

    private boolean sameProjectDetails(BulkProjectRowDto first, BulkProjectRowDto row) {
        return Objects.equals(first.projectName(), row.projectName())
                && Objects.equals(first.description(), row.description())
                && Objects.equals(first.year(), row.year())
                && Objects.equals(first.batchId(), row.batchId())
                && Objects.equals(first.teamLeaderId(), row.teamLeaderId())
                && Objects.equals(first.facultyId(), row.facultyId())
                && Objects.equals(first.deadline(), row.deadline())
                && Objects.equals(
                        normalizeValue(first.projectStatus(), VALID_STATUSES),
                        normalizeValue(row.projectStatus(), VALID_STATUSES));
    }

    private ProjectTeam toProjectEntity(BulkProjectRowDto row) {
        ProjectTeam project = new ProjectTeam();
        project.setProjectId(null);
        project.setProjectName(row.projectName().trim());
        project.setDescription(row.description());
        project.setYear(row.year());
        project.setBatchId(row.batchId());
        project.setTeamLeaderId(row.teamLeaderId());
        project.setFacultyId(row.facultyId());
        project.setDeadline(row.deadline());
        project.setProjectStartDate(LocalDate.now());
        project.setProjectStatus(normalizeRequiredStatus(row.projectStatus()));
        project.setIsDeleted(false);
        return project;
    }

    private record ParsedWorkbook(List<BulkProjectRowDto> projects) {
    }

    private ProjectTeam findProjectById(Integer projectId) {
        if (projectId == null) {
            throw new BadRequestException("Project ID is required");
        }

        return projectTeamRepository
                .findByProjectIdAndIsDeletedFalse(projectId)
                .orElseThrow(() -> new ResourceNotFoundException("Project", projectId));
    }

    private void validateProject(ProjectTeam projectTeam) {
        if (projectTeam == null) {
            throw new BadRequestException("Project details are required");
        }
        if (isBlank(projectTeam.getProjectName())) {
            throw new BadRequestException("Project name is required");
        }

        String projectName = projectTeam.getProjectName().trim();
        if (projectName.length() > 200) {
            throw new BadRequestException("Project name cannot exceed 200 characters");
        }
        projectTeam.setProjectName(projectName);

        if (projectTeam.getDeadline() == null) {
            throw new BadRequestException("Project deadline is required");
        }
        if (!projectTeam.getDeadline().isAfter(LocalDate.now())) {
            throw new BadRequestException("Deadline must be greater than current date");
        }
    }

    private String normalizeRequiredStatus(String projectStatus) {
        String normalized = normalizeValue(projectStatus, VALID_STATUSES);
        if (normalized == null) {
            throw new BadRequestException(
                    "Project status must be Pending, Ongoing, or Completed");
        }
        return normalized;
    }

    private void validateExcelFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("Excel file is required");
        }

        String fileName = file.getOriginalFilename();
        if (fileName == null
                || !fileName.toLowerCase(Locale.ROOT).endsWith(".xlsx")) {
            throw new BadRequestException("Only .xlsx files are allowed");
        }
    }

    private String text(Cell cell) {
        return cell == null ? "" : formatter.formatCellValue(cell).trim();
    }

    private String nullableText(Cell cell) {
        String value = text(cell);
        return value.isBlank() ? null : value;
    }

    private Integer integer(Cell cell) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return null;
        }

        try {
            if (cell.getCellType() == CellType.NUMERIC) {
                double value = cell.getNumericCellValue();
                if (value != Math.rint(value)) {
                    return null;
                }
                return Math.toIntExact((long) value);
            }

            String value = text(cell);
            if (value.endsWith(".0")) {
                value = value.substring(0, value.length() - 2);
            }
            return Integer.valueOf(value);
        } catch (Exception exception) {
            return null;
        }
    }

    private LocalDate date(Cell cell) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return null;
        }

        try {
            if (cell.getCellType() == CellType.NUMERIC
                    && DateUtil.isCellDateFormatted(cell)) {
                return cell.getLocalDateTimeCellValue().toLocalDate();
            }
            return LocalDate.parse(text(cell));
        } catch (DateTimeParseException | IllegalStateException exception) {
            return null;
        }
    }

    private boolean isEmpty(Row row) {
        if (row.getFirstCellNum() < 0) {
            return true;
        }

        for (int index = 0; index < EXPECTED_COLUMN_COUNT; index++) {
            if (!text(row.getCell(index)).isBlank()) {
                return false;
            }
        }
        return true;
    }

    private String normalizeValue(String value, Set<String> allowedValues) {
        if (isBlank(value)) {
            return null;
        }

        String trimmed = value.trim();
        return allowedValues.stream()
                .filter(item -> item.equalsIgnoreCase(trimmed))
                .findFirst()
                .orElse(null);
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private void addError(
            List<BulkUploadError> errors,
            String sheet,
            int row,
            String message) {
        errors.add(new BulkUploadError(sheet, row, message));
    }

}
