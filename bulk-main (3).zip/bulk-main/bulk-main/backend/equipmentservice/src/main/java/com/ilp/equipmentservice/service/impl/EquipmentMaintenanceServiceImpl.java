package com.ilp.equipmentservice.service.impl;

import java.time.LocalDate;


import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import feign.FeignException;

import com.ilp.equipmentservice.dto.request.EquipmentMaintenanceRequestDTO;
import com.ilp.equipmentservice.dto.response.EquipmentMaintenanceResponseDTO;
import com.ilp.equipmentservice.entity.Equipment;
import com.ilp.equipmentservice.entity.EquipmentMaintenance;
import com.ilp.equipmentservice.exception.EquipmentMaintenanceException;
import com.ilp.equipmentservice.exception.ResourceNotFoundException;
import com.ilp.equipmentservice.repository.EquipmentMaintenanceRepository;
import com.ilp.equipmentservice.repository.EquipmentRepository;
import com.ilp.equipmentservice.service.EquipmentMaintenanceService;
import com.ilp.equipmentservice.client.UserFeignClient;
import com.ilp.equipmentservice.dto.response.UserResponseDTO;
import com.ilp.equipmentservice.client.NotificationFeignClient;
import com.ilp.equipmentservice.dto.request.NotificationRequestDTO;
import com.ilp.equipmentservice.entity.EquipmentBooking;
import com.ilp.equipmentservice.repository.EquipmentBookingRepository;

@Service
public class EquipmentMaintenanceServiceImpl
        implements EquipmentMaintenanceService {

    private final EquipmentMaintenanceRepository maintenanceRepository;
    private final EquipmentRepository equipmentRepository;
    private final UserFeignClient userFeignClient;
    private final EquipmentBookingRepository equipmentBookingRepository;
    private final NotificationFeignClient notificationFeignClient;

    
    public EquipmentMaintenanceServiceImpl(
            EquipmentMaintenanceRepository maintenanceRepository,
            EquipmentRepository equipmentRepository,
            UserFeignClient userFeignClient,
            EquipmentBookingRepository equipmentBookingRepository,
            NotificationFeignClient notificationFeignClient) {

        this.maintenanceRepository = maintenanceRepository;

        this.equipmentRepository = equipmentRepository;

        this.userFeignClient = userFeignClient;

        this.equipmentBookingRepository = equipmentBookingRepository;

        this.notificationFeignClient = notificationFeignClient;
    }

    @Override
    public EquipmentMaintenanceResponseDTO createMaintenanceSchedule(
            EquipmentMaintenanceRequestDTO requestDTO) {
    	
    	UserResponseDTO user;

    	try {

    	    user = userFeignClient.getUserById(
    	            requestDTO.getMaintainedBy()
    	                    .intValue());

    	} catch (FeignException.NotFound ex) {

    	    throw new ResourceNotFoundException(
    	            "Maintenance user not found");
    	}

        Equipment equipment = equipmentRepository
                .findById(requestDTO.getEquipmentId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Equipment not found"));

        if (requestDTO.getStartDate().isBefore(LocalDate.now())) {

            throw new EquipmentMaintenanceException(
                    "Maintenance start date cannot be in the past");
        }
        
        if (requestDTO.getEndDate().isBefore(
                requestDTO.getStartDate())) {

            throw new EquipmentMaintenanceException(
                    "Maintenance end date cannot be before start date");
        }

        validateMaintenanceOverlap(
                requestDTO.getEquipmentId(),
                null,
                requestDTO.getStartDate(),
                requestDTO.getEndDate());

        EquipmentMaintenance maintenance =
                new EquipmentMaintenance();

        maintenance.setEquipment(equipment);
        maintenance.setMaintenanceType(
                requestDTO.getMaintenanceType());
        maintenance.setMaintenanceReason(
                requestDTO.getMaintenanceReason());
        maintenance.setMaintenanceStatus(
                requestDTO.getMaintenanceStatus());
        maintenance.setStartDate(
                requestDTO.getStartDate());
        maintenance.setEndDate(
                requestDTO.getEndDate());
        maintenance.setMaintainedBy(
                requestDTO.getMaintainedBy());
        maintenance.setRemarks(
                requestDTO.getRemarks());
        maintenance.setCreatedAt(
                LocalDateTime.now());
        
        EquipmentMaintenance saved =
                maintenanceRepository.save(maintenance);
        
        cancelAffectedBookings(saved);

        return mapToDTO(saved);
    }

    @Override
    public EquipmentMaintenanceResponseDTO updateMaintenanceSchedule(
            Long maintenanceId,
            EquipmentMaintenanceRequestDTO requestDTO) {
    	
    	UserResponseDTO user;

    	try {

    	    user = userFeignClient.getUserById(
    	            requestDTO.getMaintainedBy()
    	                    .intValue());

    	} catch (FeignException.NotFound ex) {

    	    throw new ResourceNotFoundException(
    	            "Maintenance user not found");
    	}
    	
    	if (requestDTO.getEndDate().isBefore(
    	        requestDTO.getStartDate())) {

    	    throw new EquipmentMaintenanceException(
    	            "Maintenance end date cannot be before start date");
    	}

        EquipmentMaintenance maintenance =
                maintenanceRepository.findById(
                        maintenanceId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Maintenance record not found"));

        validateMaintenanceOverlap(
                requestDTO.getEquipmentId(),
                maintenanceId,
                requestDTO.getStartDate(),
                requestDTO.getEndDate());

        maintenance.setMaintenanceType(
                requestDTO.getMaintenanceType());

        maintenance.setMaintenanceReason(
                requestDTO.getMaintenanceReason());

        maintenance.setMaintenanceStatus(
                requestDTO.getMaintenanceStatus());

        maintenance.setStartDate(
                requestDTO.getStartDate());

        maintenance.setEndDate(
                requestDTO.getEndDate());

        maintenance.setMaintainedBy(
                requestDTO.getMaintainedBy());

        maintenance.setRemarks(
                requestDTO.getRemarks());

        EquipmentMaintenance updated =
                maintenanceRepository.save(
                        maintenance);

        return mapToDTO(updated);
    }

    @Override
    public EquipmentMaintenanceResponseDTO getMaintenanceById(
            Long maintenanceId) {

        EquipmentMaintenance maintenance =
                maintenanceRepository.findById(
                        maintenanceId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Maintenance record not found"));

        return mapToDTO(maintenance);
    }

    @Override
    public List<EquipmentMaintenanceResponseDTO>
    getAllMaintenanceSchedules() {

        return maintenanceRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<EquipmentMaintenanceResponseDTO>
    getMaintenanceByEquipmentId(Long equipmentId) {

        return maintenanceRepository
                .findByEquipmentEquipmentId(equipmentId)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    public void deleteMaintenanceSchedule(
            Long maintenanceId) {

        EquipmentMaintenance maintenance =
                maintenanceRepository.findById(
                        maintenanceId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Maintenance record not found"));

        maintenanceRepository.delete(
                maintenance);
    }

    private void validateMaintenanceOverlap(
            Long equipmentId,
            Long maintenanceId,
            LocalDate startDate,
            LocalDate endDate) {

        List<EquipmentMaintenance> schedules =
                maintenanceRepository
                        .findByEquipmentEquipmentId(
                                equipmentId);

        for (EquipmentMaintenance maintenance : schedules) {

            if (maintenanceId != null &&
                    maintenance.getMaintenanceId()
                            .equals(maintenanceId)) {

                continue;
            }

            boolean overlap =
                    !endDate.isBefore(
                            maintenance.getStartDate())
                    &&
                    !startDate.isAfter(
                            maintenance.getEndDate());

            if (overlap) {

                throw new EquipmentMaintenanceException(
                        "Maintenance schedule overlaps with an existing maintenance schedule");
            }
        }
    }
    
    private void cancelAffectedBookings(
            EquipmentMaintenance maintenance) {

        List<EquipmentBooking> bookings =
                equipmentBookingRepository
                        .findByEquipmentEquipmentId(
                                maintenance.getEquipment()
                                        .getEquipmentId());

        for (EquipmentBooking booking : bookings) {

            if ("Rejected".equalsIgnoreCase(
                    booking.getApprovalStatus())) {

                continue;
            }

            boolean overlap =
                    !booking.getBookingDate()
                            .isBefore(
                                    maintenance.getStartDate())
                    &&
                    !booking.getBookingDate()
                            .isAfter(
                                    maintenance.getEndDate());

            if (overlap) {

                booking.setApprovalStatus(
                        "Rejected");

                booking.setApprovedBy(
                        maintenance.getMaintainedBy());

                booking.setApprovedOn(
                        LocalDateTime.now());

                String remarks =
                        booking.getRemarks() == null
                        ? ""
                        : booking.getRemarks() + " | ";

                booking.setRemarks(
                        remarks
                        + "Automatically cancelled due to scheduled maintenance.");

                equipmentBookingRepository.save(
                        booking);

                NotificationRequestDTO notification =
                        new NotificationRequestDTO();

                notification.setUserId(
                        booking.getRequestedBy()
                                .intValue());

                notification.setTitle(
                        "Equipment Booking Cancelled");

                notification.setMessage(
                        "Your booking for equipment "
                                + booking.getEquipment()
                                        .getAssetCode()
                                + " on "
                                + booking.getBookingDate()
                                + " has been cancelled because the equipment has been scheduled for maintenance.");

                notification.setNotificationType(
                        "MAINTENANCE");

                notification.setModuleName(
                        "EQUIPMENT");

                notification.setReferenceId(
                        booking.getBookingId()
                                .intValue());

                notification.setPriority(
                        "High");

                notification.setCreatedBy(
                        maintenance.getMaintainedBy()
                                .intValue());

                notificationFeignClient
                        .createNotification(
                                notification);
            }
        }
    }

    private EquipmentMaintenanceResponseDTO mapToDTO(
            EquipmentMaintenance maintenance) {

        EquipmentMaintenanceResponseDTO dto =
                new EquipmentMaintenanceResponseDTO();

        dto.setMaintenanceId(
                maintenance.getMaintenanceId());

        dto.setEquipmentId(
                maintenance.getEquipment()
                        .getEquipmentId());

        dto.setAssetCode(
                maintenance.getEquipment()
                        .getAssetCode());

        dto.setMaintenanceType(
                maintenance.getMaintenanceType());

        dto.setMaintenanceReason(
                maintenance.getMaintenanceReason());

        dto.setMaintenanceStatus(
                maintenance.getMaintenanceStatus());

        dto.setStartDate(
                maintenance.getStartDate());

        dto.setEndDate(
                maintenance.getEndDate());

        dto.setMaintainedBy(
                maintenance.getMaintainedBy());

        dto.setRemarks(
                maintenance.getRemarks());

        dto.setCreatedAt(
                maintenance.getCreatedAt());

        return dto;
    }
}