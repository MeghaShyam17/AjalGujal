package com.ilp.user_service.dto;

import jakarta.validation.constraints.Email;

import jakarta.validation.constraints.NotBlank;



import jakarta.validation.constraints.Pattern;

public class RegisterUserRequest {

    private Integer roleId;

    private Integer batchId;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Phone number is required")
    @Pattern(
            regexp = "^[0-9]{10}$",
            message = "Phone number must contain exactly 10 digits"
    )
    private String phone;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Gender is required")
    @Pattern(
            regexp = "^(Male|Female)$",
            message = "Gender must be either Male or Female"
    )
    private String gender;

    private Integer year;

    @NotBlank(message = "Password is required")
    
    private String password;

    // No-Args Constructor
    public RegisterUserRequest() {
    }

    // All-Args Constructor
    public RegisterUserRequest(Integer roleId, Integer batchId, String name,
                               String phone, String email, String gender,
                               Integer year, String password) {
        this.roleId = roleId;
        this.batchId = batchId;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.gender = gender;
        this.year = year;
        this.password = password;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}