package com.ilp.user_service.repository;
import java.util.List;
import com.ilp.user_service.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Integer> {

    Optional<UserEntity> findByEmail(String email);

    Optional<UserEntity> findByPhone(String phone);

    boolean existsByEmail(String email);

    boolean existsByPhone(String phone);
 
    boolean existsByRole_RoleId(Integer roleId);

    boolean existsByBatch_BatchId(Integer batchId);
    
    List<UserEntity> findByStatus(String status);}