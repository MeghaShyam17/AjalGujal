package ServiceImplementTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import com.ilp.user_service.entity.UserEntity;
import com.ilp.user_service.exception.UserNotFoundException;
import com.ilp.user_service.repository.BatchRepository;
import com.ilp.user_service.repository.RoleRepository;
import com.ilp.user_service.repository.UserRepository;
import com.ilp.user_service.serviceImpl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private BatchRepository batchRepository;

    @InjectMocks
    private UserServiceImpl userService;

    @Test
    void createUserSuccess() {

        UserEntity user = new UserEntity();
        user.setUserId(1);
        user.setName("Test User");

        when(userRepository.save(user))
                .thenReturn(user);

        UserEntity result =
                userService.createUser(user);

        assertNotNull(result);
        assertEquals(
                "Test User",
                result.getName());
    }

    @Test
    void getUserByIdSuccess() {

        UserEntity user = new UserEntity();
        user.setUserId(1);

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        UserEntity result =
                userService.getUserById(1);

        assertNotNull(result);
        assertEquals(1, result.getUserId());
    }

    @Test
    void getUserByIdNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        UserEntity result =
                userService.getUserById(1);

        assertNull(result);
    }

    @Test
    void getAllUsersSuccess() {

        UserEntity u1 = new UserEntity();
        UserEntity u2 = new UserEntity();

        when(userRepository.findAll())
                .thenReturn(Arrays.asList(u1, u2));

        assertEquals(
                2,
                userService.getAllUsers().size());
    }

    @Test
    void getAllUsersEmptyList() {

        when(userRepository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(
                userService.getAllUsers().isEmpty());
    }

    @Test
    void updateUserSuccess() {

        UserEntity existing = new UserEntity();
        existing.setUserId(1);
        existing.setName("Old Name");

        UserEntity updated = new UserEntity();
        updated.setName("New Name");
        updated.setEmail("new@gmail.com");

        when(userRepository.findById(1))
                .thenReturn(Optional.of(existing));

        when(userRepository.save(any(UserEntity.class)))
                .thenReturn(existing);

        UserEntity result =
                userService.updateUser(1, updated);

        assertNotNull(result);
        assertEquals(
                "New Name",
                existing.getName());
    }

    @Test
    void updateUserNotFound() {

        UserEntity user = new UserEntity();

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        UserEntity result =
                userService.updateUser(1, user);

        assertNull(result);
    }

    @Test
    void deleteUserSuccess() {

        UserEntity user = new UserEntity();
        user.setUserId(1);

        when(userRepository.findById(1))
                .thenReturn(Optional.of(user));

        userService.deleteUser(1);

        verify(userRepository)
                .delete(user);
    }

    @Test
    void deleteUserNotFound() {

        when(userRepository.findById(1))
                .thenReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> userService.deleteUser(1));
    }

    @Test
    void uploadUsersInvalidFile() throws IOException {

        MultipartFile file =
                mock(MultipartFile.class);

        when(file.getInputStream())
                .thenThrow(new IOException());

        String result =
                userService.uploadUsers(file);

        assertEquals(
                "Failed to upload users",
                result);
    }

    @Test
    void createUserRepositoryCalled() {

        UserEntity user = new UserEntity();

        when(userRepository.save(any(UserEntity.class)))
                .thenReturn(user);

        userService.createUser(user);

        verify(userRepository)
                .save(user);
    }
}